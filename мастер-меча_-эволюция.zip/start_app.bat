@echo off
cd /d "%~dp0"
echo Starting game server...
if not exist "node_modules\" (
    echo Installing dependencies...
    call npm install
)
start http://localhost:3000
npm run dev
pause
