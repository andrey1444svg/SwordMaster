import { CustomRoomData } from '../types/roomEditor';
import starterRoom from './Стартовая_комната_с_выходом_вниз.json';

export const DEFAULT_ROOMS: CustomRoomData[] = [
  starterRoom as CustomRoomData
];

