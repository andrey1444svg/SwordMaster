import React, { useState, useEffect } from 'react';
import { CharacterStats, DifficultyConfig, Weapon } from '../types/game';
import { 
  Heart, 
  Sparkles, 
  Briefcase, 
  Pause, 
  Crown,
  Skull,
  Maximize2,
  Minimize2,
  Wrench
} from 'lucide-react';
import { toggleFullscreen } from '../utils/orientation';

interface HUDProps {
  stats: CharacterStats;
  equippedWeapon: Weapon;
  difficulty: DifficultyConfig;
  score: number;
  highScore: number;
  onOpenInventory: (tab?: 'character' | 'inventory' | 'forge' | 'resources') => void;
  onPause: () => void;
  onOpenTesterArmory?: () => void;
}

export const HUD = React.memo<HUDProps>(({
  stats,
  equippedWeapon,
  score,
  highScore,
  onOpenInventory,
  onPause,
  onOpenTesterArmory
}) => {
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const xpPercent = Math.min(100, Math.floor((stats.xp / stats.maxXp) * 100));
  
  const hpPercent = Math.min(100, Math.max(0, (stats.hp / stats.maxHp) * 100));
  const manaPercent = Math.min(100, Math.max(0, (stats.mana / (stats.maxMana || 1)) * 100));

  useEffect(() => {
    const checkFs = () => {
      setIsFullscreen(Boolean(document.fullscreenElement || (document as any).webkitFullscreenElement));
    };
    document.addEventListener('fullscreenchange', checkFs);
    document.addEventListener('webkitfullscreenchange', checkFs);
    return () => {
      document.removeEventListener('fullscreenchange', checkFs);
      document.removeEventListener('webkitfullscreenchange', checkFs);
    };
  }, []);

  const handleToggleFs = async () => {
    const fs = await toggleFullscreen();
    setIsFullscreen(fs);
  };

  return (
    <div className="absolute top-0 left-0 right-0 p-1.5 sm:p-2.5 pointer-events-none flex flex-col gap-1.5 z-20">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between gap-2 w-full">
        {/* Left Stats: Level, XP, HP Bar, Mana Bar */}
        <div className="w-[125px] sm:w-[155px] md:w-[225px] h-[32px] sm:h-[36px] relative pointer-events-auto">
          <div className="absolute top-0 left-0 flex items-center gap-2 sm:gap-3 bg-slate-950/95 py-1.5 px-2.5 rounded-xl border border-slate-700/80 shadow-lg origin-top-left scale-[0.36] sm:scale-[0.42] md:scale-[0.45] transition-transform whitespace-nowrap">
            {/* Level Badge */}
            <div 
              onClick={() => onOpenInventory('character')}
              className="flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition-opacity"
              title="Характеристики героя (C)"
            >
              <div className="relative flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-extrabold text-xs shadow-inner">
                {stats.level}
                {stats.statPoints > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-3 w-3 items-center justify-center rounded-full bg-amber-400 text-slate-950 text-[8px] font-black animate-pulse">
                    +{stats.statPoints}
                  </span>
                )}
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1 text-[10px] text-slate-300 font-bold leading-tight">
                  <span>Ур.{stats.level}</span>
                  {stats.statPoints > 0 && (
                    <span className="text-[9px] text-amber-400 font-extrabold">
                      +{stats.statPoints} очк.
                    </span>
                  )}
                </div>
                {/* XP Bar */}
                <div className="w-16 sm:w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700/50 relative mt-0.5">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-400 transition-all duration-300" 
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Divider */}
            <div className="w-px h-6 bg-slate-700/60 mx-0.5" />

            {/* Health & Mana Bars */}
            <div className="flex flex-col gap-1 min-w-[120px] sm:min-w-[150px]">
              {/* HP Bar */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between text-[10px] leading-tight font-extrabold text-rose-300 mb-0.5">
                  <span className="flex items-center gap-1">
                    <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                    <span>HP</span>
                  </span>
                  <span>{Math.ceil(stats.hp)} / {stats.maxHp}</span>
                </div>
                <div className="w-full h-2 sm:h-2.5 bg-slate-900 rounded-full overflow-hidden border border-rose-950/80 relative shadow-inner">
                  <div 
                    className="h-full bg-gradient-to-r from-rose-600 via-rose-500 to-red-400 transition-all duration-200 rounded-full shadow-[0_0_8px_rgba(244,63,94,0.5)]" 
                    style={{ width: `${hpPercent}%` }}
                  />
                </div>
              </div>

              {/* Mana Bar */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between text-[9px] leading-tight font-extrabold text-sky-300 mb-0.5">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-sky-400" />
                    <span>MP</span>
                  </span>
                  <span>{stats.mana.toFixed(1)} / {stats.maxMana.toFixed(1)}</span>
                </div>
                <div className="w-full h-1.5 sm:h-2 bg-slate-900 rounded-full overflow-hidden border border-sky-950/80 relative shadow-inner">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-600 via-sky-500 to-cyan-400 transition-all duration-200 rounded-full shadow-[0_0_6px_rgba(56,189,248,0.5)]" 
                    style={{ width: `${manaPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Equipped Weapon Badge (Desktop / Tablet) */}
            <div 
              onClick={() => onOpenInventory('inventory')}
              className="hidden md:flex items-center gap-1.5 bg-slate-800/70 px-2.5 py-1 rounded-lg border border-slate-700/60 cursor-pointer hover:border-sky-500 transition-colors text-[11px]"
            >
              <span className="text-slate-200 font-bold truncate max-w-[100px]">
                {equippedWeapon.name} {equippedWeapon.upgradeLevel > 0 && <span className="text-amber-400 font-extrabold">+{equippedWeapon.upgradeLevel}</span>}
              </span>
              <span 
                className="w-2 h-2 rounded-full shadow-sm" 
                style={{ backgroundColor: equippedWeapon.color }}
              />
            </div>
          </div>
        </div>

        {/* Right Controls: Inventory Button, Fullscreen Toggle, Pause */}
        <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto">

          {/* Character & Inventory Button */}
          <button
            onClick={() => onOpenInventory('character')}
            className="relative bg-sky-600/90 hover:bg-sky-500 text-white font-bold p-1.5 sm:px-3 sm:py-1.5 rounded-xl shadow-lg border border-sky-400/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer text-xs"
            title="Характеристики и Инвентарь (I / C)"
          >
            <Briefcase className="w-4 h-4 text-sky-100" />
            <span className="hidden sm:inline text-[11px] uppercase font-black">Герой</span>
            {stats.statPoints > 0 && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-amber-400 text-slate-950 text-[9px] font-black animate-bounce shadow">
                +{stats.statPoints}
              </span>
            )}
          </button>

          {/* Tester Armory Button */}
          {onOpenTesterArmory && (
            <button
              onClick={onOpenTesterArmory}
              className="bg-amber-500/90 hover:bg-amber-400 text-slate-950 font-bold p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl shadow-lg border border-amber-300/50 flex items-center gap-1 transition-all active:scale-95 cursor-pointer text-xs"
              title="Арсенал Тестировщика (Спавн и примерка любого шмота)"
            >
              <Wrench className="w-4 h-4 text-slate-950" />
              <span className="hidden md:inline text-[10px] uppercase font-black">Тест</span>
            </button>
          )}

          {/* Fullscreen Toggle */}
          <button
            onClick={handleToggleFs}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 p-2 rounded-xl border border-slate-700/70 shadow-lg transition-all active:scale-95 cursor-pointer"
            title="На весь экран / Горизонтально"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4 text-sky-400" /> : <Maximize2 className="w-4 h-4 text-slate-300" />}
          </button>

          {/* Pause Button */}
          <button
            onClick={onPause}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 p-2 rounded-xl border border-slate-700/70 shadow-lg transition-all active:scale-95 cursor-pointer"
            title="Пауза (ESC)"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
});
