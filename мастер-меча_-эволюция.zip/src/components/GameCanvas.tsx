import React, { useEffect, useRef, useState } from 'react';
import { 
  CharacterStats, 
  Weapon, 
  Skill, 
  DifficultyConfig, 
  LootDrop, 
  Chest, 
  Particle, 
  DamageText,
  IngredientType,
  ItemRarity,
  EquipmentState
} from '../types/game';
import { INGREDIENTS, getMaxXpForLevel } from '../utils/gameDefaults';
import { soundManager } from '../utils/audio';
import { generateEquipmentDrop } from '../utils/lootGenerator';
import starterRoom from '../rooms/Стартовая_комната_с_выходом_вниз.json';
import { roomStorage } from '../utils/roomStorage';
import { RoomElement, CustomRoomData } from '../types/roomEditor';

import plate1ImgSrc from '../assets/images/plate 1.png';
import plate2ImgSrc from '../assets/images/plate 2.png';
import plate3ImgSrc from '../assets/images/plate 3.png';
import plate4ImgSrc from '../assets/images/plate 4.png';
import plate5ImgSrc from '../assets/images/plate 5.png';
import plate6ImgSrc from '../assets/images/plate 6.png';
import plate7ImgSrc from '../assets/images/plate 7.png';
import plate8ImgSrc from '../assets/images/plate 8.png';
import plate9ImgSrc from '../assets/images/plate 9.png';
import plate10ImgSrc from '../assets/images/plate 10.png';
import plate11ImgSrc from '../assets/images/plate 11.png';
import yashikImgSrc from '../assets/images/Yashik.png';
import sundukImgSrc from '../assets/images/Sunduk.png';
import kuvshinImgSrc from '../assets/images/Kuvshin.png';
import kuvshin2ImgSrc from '../assets/images/Kuvshin 2.png';
import flagImgSrc from '../assets/images/Flag 1.png';
import bochkaImgSrc from '../assets/images/Bochka.png';
import fakel1ImgSrc from '../assets/images/Fakel 1.png';
import fakel2ImgSrc from '../assets/images/Fakel 2.png';
import fakel3ImgSrc from '../assets/images/Fakel 3.png';
import altarImgSrc from '../assets/images/Altar.png';

// In-Game Ingredient Assets
import mglashardGameImgSrc from '../assets/images/Осколок мглы игра.png';
import magiccrystalGameImgSrc from '../assets/images/Магический кристалл игра.png';
import monstercoreGameImgSrc from '../assets/images/Ядро монстра игра.png';
import voidsealGameImgSrc from '../assets/images/Печать пустоты игра.png';

// In-Game Ground Helmets by Rarity
import helmetGroundCommonSrc from '../assets/images/Шлемы на земле/Шлем обычный.png';
import helmetGroundMagicSrc from '../assets/images/Шлемы на земле/Шлем магический.png';
import helmetGroundRareSrc from '../assets/images/Шлемы на земле/Шлем редкий.png';
import helmetGroundEpicSrc from '../assets/images/Шлемы на земле/Шлем эпический.png';

// In-Game Ground & Hand Spears by Rarity (12 Variations)
import spearCommon1Src from '../assets/images/Копья на земле/Копье обычное 1.png';
import spearCommon2Src from '../assets/images/Копья на земле/Копье обычное 2.png';
import spearCommon3Src from '../assets/images/Копья на земле/Копье обычное 3.png';

import spearMagic1Src from '../assets/images/Копья на земле/Копье магическое 1.png';
import spearMagic2Src from '../assets/images/Копья на земле/Копье магическое 2.png';
import spearMagic3Src from '../assets/images/Копья на земле/Копье магическое 3.png';

import spearRare1Src from '../assets/images/Копья на земле/Копье редкое 1.png';
import spearRare2Src from '../assets/images/Копья на земле/Копье редкое 2.png';
import spearRare3Src from '../assets/images/Копья на земле/Копье редкое 3.png';

import spearEpic1Src from '../assets/images/Копья на земле/Копье эпическое 1.png';
import spearEpic2Src from '../assets/images/Копья на земле/Копье эпическое 2.png';
import spearEpic3Src from '../assets/images/Копья на земле/Копье эпическое 3.png';

// In-Game Ground & Hand Hammers by Rarity (12 Variations)
import hammerCommon1Src from '../assets/images/Молотки на земле/Молот обычный 1.png';
import hammerCommon2Src from '../assets/images/Молотки на земле/Молот обычный 2.png';
import hammerCommon3Src from '../assets/images/Молотки на земле/Молот обычный 3.png';

import hammerMagic1Src from '../assets/images/Молотки на земле/Молот магический 1.png';
import hammerMagic2Src from '../assets/images/Молотки на земле/Молот магический 2.png';
import hammerMagic3Src from '../assets/images/Молотки на земле/Молот магический 3.png';

import hammerRare1Src from '../assets/images/Молотки на земле/Молот редкий 1.png';
import hammerRare2Src from '../assets/images/Молотки на земле/Молот редкий 2.png';
import hammerRare3Src from '../assets/images/Молотки на земле/Молот редкий 3.png';

import hammerEpic1Src from '../assets/images/Молотки на земле/Молот эпический 1.png';
import hammerEpic2Src from '../assets/images/Молотки на земле/Молот эпический 2.png';
import hammerEpic3Src from '../assets/images/Молотки на земле/Молот эпический 3.png';

// In-Game Ground Gloves by Rarity
import glovesGroundCommonSrc from '../assets/images/Перчатки на земле/Обычная перчатка.png';
import glovesGroundMagicSrc from '../assets/images/Перчатки на земле/Магическая перчатка.png';
import glovesGroundRareSrc from '../assets/images/Перчатки на земле/Редкая перчатка.png';
import glovesGroundEpicSrc from '../assets/images/Перчатки на земле/Эпическая перчатка.png';

// In-Game Ground Rings by Rarity
import ringGroundCommonSrc from '../assets/images/Кольца на земле/Обычное кольцо.png';
import ringGroundMagicSrc from '../assets/images/Кольца на земле/Магическое кольцо.png';
import ringGroundRareSrc from '../assets/images/Кольца на земле/Редкое кольцо.png';
import ringGroundEpicSrc from '../assets/images/Кольца на земле/Эпическое кольцо.png';

// In-Game Ground Belts by Rarity
import beltGroundCommonSrc from '../assets/images/Пояса на земле/Обычный пояс.png';
import beltGroundMagicSrc from '../assets/images/Пояса на земле/Магический пояс.png';
import beltGroundRareSrc from '../assets/images/Пояса на земле/Редкий пояс.png';
import beltGroundEpicSrc from '../assets/images/Пояса на земле/Эпический пояс.png';

// In-Game Ground & Hand Swords by Rarity (12 Variations)
import swordCommon1Src from '../assets/images/Мечи на земле/Меч обычный 1.png';
import swordCommon2Src from '../assets/images/Мечи на земле/Меч обычный 2.png';
import swordCommon3Src from '../assets/images/Мечи на земле/Меч обычный 3.png';

import swordMagic1Src from '../assets/images/Мечи на земле/Меч магический 1.png';
import swordMagic2Src from '../assets/images/Мечи на земле/Меч магический 2.png';
import swordMagic3Src from '../assets/images/Мечи на земле/Меч магический 3.png';

import swordRare1Src from '../assets/images/Мечи на земле/Меч редкий 1.png';
import swordRare2Src from '../assets/images/Мечи на земле/Меч редкий 2.png';
import swordRare3Src from '../assets/images/Мечи на земле/Меч редкий 3.png';

import swordEpic1Src from '../assets/images/Мечи на земле/Меч эпический 1.png';
import swordEpic2Src from '../assets/images/Мечи на земле/Меч эпический 2.png';
import swordEpic3Src from '../assets/images/Мечи на земле/Меч эпический 3.png';

// In-Game Ground & Hand Axes by Rarity (12 Variations)
import axeCommon1Src from '../assets/images/Топоры на земле/Топор обычный 1.png';
import axeCommon2Src from '../assets/images/Топоры на земле/Топор обычный 2.png';
import axeCommon3Src from '../assets/images/Топоры на земле/Топор обычный 3.png';

import axeMagic1Src from '../assets/images/Топоры на земле/Топор магический 1.png';
import axeMagic2Src from '../assets/images/Топоры на земле/Топор магический 2.png';
import axeMagic3Src from '../assets/images/Топоры на земле/Топор магический 3.png';

import axeRare1Src from '../assets/images/Топоры на земле/Топор редкий 1.png';
import axeRare2Src from '../assets/images/Топоры на земле/Топор редкий 2.png';
import axeRare3Src from '../assets/images/Топоры на земле/Топор редкий 3.png';

import axeEpic1Src from '../assets/images/Топоры на земле/Топор эпический 1.png';
import axeEpic2Src from '../assets/images/Топоры на земле/Топор эпический 2.png';
import axeEpic3Src from '../assets/images/Топоры на земле/Топор эпический 3.png';

// In-Game Ground Bracers by Rarity
import bracersGroundCommonSrc from '../assets/images/Наручи на земле/Обычные наручи.png';
import bracersGroundMagicSrc from '../assets/images/Наручи на земле/Магические наручи.png';
import bracersGroundRareSrc from '../assets/images/Наручи на земле/Редкие наручи.png';
import bracersGroundEpicSrc from '../assets/images/Наручи на земле/Эпические наручи.png';

// In-Game Ground Chestplates by Rarity
import chestGroundCommonSrc from '../assets/images/Нагрудники на земле/Обычный нагрудник.png';
import chestGroundMagicSrc from '../assets/images/Нагрудники на земле/Магический нагрудник.png';
import chestGroundRareSrc from '../assets/images/Нагрудники на земле/Редкий нагрудник.png';
import chestGroundEpicSrc from '../assets/images/Нагрудники на земле/Эпический нагрудник.png';

// In-Game Ground Pants by Rarity
import pantsGroundCommonSrc from '../assets/images/Штаны на земле/Обычные штаны.png';
import pantsGroundMagicSrc from '../assets/images/Штаны на земле/Магические штаны.png';
import pantsGroundRareSrc from '../assets/images/Штаны на земле/Редкие штаны.png';
import pantsGroundEpicSrc from '../assets/images/Штаны на земле/Эпические штаны.png';

// In-Game Ground Boots by Rarity
import bootsGroundCommonSrc from '../assets/images/Обувь на земле/Обычная обувь.png';
import bootsGroundMagicSrc from '../assets/images/Обувь на земле/Магическая обувь.png';
import bootsGroundRareSrc from '../assets/images/Обувь на земле/Редкая обувь.png';
import bootsGroundEpicSrc from '../assets/images/Обувь на земле/Эпическая обувь.png';

// In-Game Ground Trinkets by Rarity
import trinketGroundCommonSrc from '../assets/images/Аксессуары на земле/Обычный аксессуар.png';
import trinketGroundMagicSrc from '../assets/images/Аксессуары на земле/Магический аксессуар.png';
import trinketGroundRareSrc from '../assets/images/Аксессуары на земле/Редкий аксессуар.png';
import trinketGroundEpicSrc from '../assets/images/Аксессуары на земле/Эпический аксессуар.png';

// In-Game Ground Cloaks by Rarity
import cloakGroundCommonSrc from '../assets/images/Плащи на земле/Плащ обычный.png';
import cloakGroundMagicSrc from '../assets/images/Плащи на земле/Плащ магический.png';
import cloakGroundRareSrc from '../assets/images/Плащи на земле/Плащ редкий.png';
import cloakGroundEpicSrc from '../assets/images/Плащи на земле/Плащ эпический.png';

// Dungeon Image Assets Cache
const gameAssets = {
  plate1: typeof Image !== 'undefined' ? new Image() : null,
  plate2: typeof Image !== 'undefined' ? new Image() : null,
  plate3: typeof Image !== 'undefined' ? new Image() : null,
  plate4: typeof Image !== 'undefined' ? new Image() : null,
  plate5: typeof Image !== 'undefined' ? new Image() : null,
  plate6: typeof Image !== 'undefined' ? new Image() : null,
  plate7: typeof Image !== 'undefined' ? new Image() : null,
  plate8: typeof Image !== 'undefined' ? new Image() : null,
  plate9: typeof Image !== 'undefined' ? new Image() : null,
  plate10: typeof Image !== 'undefined' ? new Image() : null,
  plate11: typeof Image !== 'undefined' ? new Image() : null,
  plates: [] as HTMLImageElement[],
  yashik: typeof Image !== 'undefined' ? new Image() : null,
  sunduk: typeof Image !== 'undefined' ? new Image() : null,
  kuvshin: typeof Image !== 'undefined' ? new Image() : null,
  kuvshin2: typeof Image !== 'undefined' ? new Image() : null,
  flag: typeof Image !== 'undefined' ? new Image() : null,
  bochka: typeof Image !== 'undefined' ? new Image() : null,
  fakel1: typeof Image !== 'undefined' ? new Image() : null,
  fakel2: typeof Image !== 'undefined' ? new Image() : null,
  fakel3: typeof Image !== 'undefined' ? new Image() : null,
  altar: typeof Image !== 'undefined' ? new Image() : null,

  ing_iron_ore: typeof Image !== 'undefined' ? new Image() : null,
  ing_magic_crystal: typeof Image !== 'undefined' ? new Image() : null,
  ing_monster_core: typeof Image !== 'undefined' ? new Image() : null,
  ing_ancient_rune: typeof Image !== 'undefined' ? new Image() : null,
  ing_fire_essence: typeof Image !== 'undefined' ? new Image() : null,

  helmet_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  helmet_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  helmet_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  helmet_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  spear_common_1: typeof Image !== 'undefined' ? new Image() : null,
  spear_common_2: typeof Image !== 'undefined' ? new Image() : null,
  spear_common_3: typeof Image !== 'undefined' ? new Image() : null,

  spear_magic_1: typeof Image !== 'undefined' ? new Image() : null,
  spear_magic_2: typeof Image !== 'undefined' ? new Image() : null,
  spear_magic_3: typeof Image !== 'undefined' ? new Image() : null,

  spear_rare_1: typeof Image !== 'undefined' ? new Image() : null,
  spear_rare_2: typeof Image !== 'undefined' ? new Image() : null,
  spear_rare_3: typeof Image !== 'undefined' ? new Image() : null,

  spear_epic_1: typeof Image !== 'undefined' ? new Image() : null,
  spear_epic_2: typeof Image !== 'undefined' ? new Image() : null,
  spear_epic_3: typeof Image !== 'undefined' ? new Image() : null,

  hammer_common_1: typeof Image !== 'undefined' ? new Image() : null,
  hammer_common_2: typeof Image !== 'undefined' ? new Image() : null,
  hammer_common_3: typeof Image !== 'undefined' ? new Image() : null,

  hammer_magic_1: typeof Image !== 'undefined' ? new Image() : null,
  hammer_magic_2: typeof Image !== 'undefined' ? new Image() : null,
  hammer_magic_3: typeof Image !== 'undefined' ? new Image() : null,

  hammer_rare_1: typeof Image !== 'undefined' ? new Image() : null,
  hammer_rare_2: typeof Image !== 'undefined' ? new Image() : null,
  hammer_rare_3: typeof Image !== 'undefined' ? new Image() : null,

  hammer_epic_1: typeof Image !== 'undefined' ? new Image() : null,
  hammer_epic_2: typeof Image !== 'undefined' ? new Image() : null,
  hammer_epic_3: typeof Image !== 'undefined' ? new Image() : null,

  gloves_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  gloves_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  gloves_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  gloves_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  ring_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  ring_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  ring_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  ring_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  belt_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  belt_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  belt_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  belt_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  sword_common_1: typeof Image !== 'undefined' ? new Image() : null,
  sword_common_2: typeof Image !== 'undefined' ? new Image() : null,
  sword_common_3: typeof Image !== 'undefined' ? new Image() : null,

  sword_magic_1: typeof Image !== 'undefined' ? new Image() : null,
  sword_magic_2: typeof Image !== 'undefined' ? new Image() : null,
  sword_magic_3: typeof Image !== 'undefined' ? new Image() : null,

  sword_rare_1: typeof Image !== 'undefined' ? new Image() : null,
  sword_rare_2: typeof Image !== 'undefined' ? new Image() : null,
  sword_rare_3: typeof Image !== 'undefined' ? new Image() : null,

  sword_epic_1: typeof Image !== 'undefined' ? new Image() : null,
  sword_epic_2: typeof Image !== 'undefined' ? new Image() : null,
  sword_epic_3: typeof Image !== 'undefined' ? new Image() : null,

  axe_common_1: typeof Image !== 'undefined' ? new Image() : null,
  axe_common_2: typeof Image !== 'undefined' ? new Image() : null,
  axe_common_3: typeof Image !== 'undefined' ? new Image() : null,

  axe_magic_1: typeof Image !== 'undefined' ? new Image() : null,
  axe_magic_2: typeof Image !== 'undefined' ? new Image() : null,
  axe_magic_3: typeof Image !== 'undefined' ? new Image() : null,

  axe_rare_1: typeof Image !== 'undefined' ? new Image() : null,
  axe_rare_2: typeof Image !== 'undefined' ? new Image() : null,
  axe_rare_3: typeof Image !== 'undefined' ? new Image() : null,

  axe_epic_1: typeof Image !== 'undefined' ? new Image() : null,
  axe_epic_2: typeof Image !== 'undefined' ? new Image() : null,
  axe_epic_3: typeof Image !== 'undefined' ? new Image() : null,

  bracers_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  bracers_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  bracers_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  bracers_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  chest_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  chest_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  chest_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  chest_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  pants_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  pants_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  pants_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  pants_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  boots_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  boots_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  boots_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  boots_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  trinket_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  trinket_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  trinket_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  trinket_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  cloak_ground_common: typeof Image !== 'undefined' ? new Image() : null,
  cloak_ground_magic: typeof Image !== 'undefined' ? new Image() : null,
  cloak_ground_rare: typeof Image !== 'undefined' ? new Image() : null,
  cloak_ground_epic: typeof Image !== 'undefined' ? new Image() : null,

  loadedCount: 0
};

if (typeof Image !== 'undefined') {
  const onImgLoad = () => { gameAssets.loadedCount++; };
  if (gameAssets.plate1) { gameAssets.plate1.onload = onImgLoad; gameAssets.plate1.src = plate1ImgSrc; }
  if (gameAssets.plate2) { gameAssets.plate2.onload = onImgLoad; gameAssets.plate2.src = plate2ImgSrc; }
  if (gameAssets.plate3) { gameAssets.plate3.onload = onImgLoad; gameAssets.plate3.src = plate3ImgSrc; }
  if (gameAssets.plate4) { gameAssets.plate4.onload = onImgLoad; gameAssets.plate4.src = plate4ImgSrc; }
  if (gameAssets.plate5) { gameAssets.plate5.onload = onImgLoad; gameAssets.plate5.src = plate5ImgSrc; }
  if (gameAssets.plate6) { gameAssets.plate6.onload = onImgLoad; gameAssets.plate6.src = plate6ImgSrc; }
  if (gameAssets.plate7) { gameAssets.plate7.onload = onImgLoad; gameAssets.plate7.src = plate7ImgSrc; }
  if (gameAssets.plate8) { gameAssets.plate8.onload = onImgLoad; gameAssets.plate8.src = plate8ImgSrc; }
  if (gameAssets.plate9) { gameAssets.plate9.onload = onImgLoad; gameAssets.plate9.src = plate9ImgSrc; }
  if (gameAssets.plate10) { gameAssets.plate10.onload = onImgLoad; gameAssets.plate10.src = plate10ImgSrc; }
  if (gameAssets.plate11) { gameAssets.plate11.onload = onImgLoad; gameAssets.plate11.src = plate11ImgSrc; }
  gameAssets.plates = [
    gameAssets.plate1,
    gameAssets.plate2,
    gameAssets.plate3,
    gameAssets.plate4,
    gameAssets.plate5,
    gameAssets.plate6,
    gameAssets.plate7,
    gameAssets.plate8,
    gameAssets.plate9,
    gameAssets.plate10,
    gameAssets.plate11
  ].filter(Boolean) as HTMLImageElement[];

  if (gameAssets.yashik) { gameAssets.yashik.onload = onImgLoad; gameAssets.yashik.src = yashikImgSrc; }
  if (gameAssets.sunduk) { gameAssets.sunduk.onload = onImgLoad; gameAssets.sunduk.src = sundukImgSrc; }
  if (gameAssets.kuvshin) { gameAssets.kuvshin.onload = onImgLoad; gameAssets.kuvshin.src = kuvshinImgSrc; }
  if (gameAssets.kuvshin2) { gameAssets.kuvshin2.onload = onImgLoad; gameAssets.kuvshin2.src = kuvshin2ImgSrc; }
  if (gameAssets.flag) { gameAssets.flag.onload = onImgLoad; gameAssets.flag.src = flagImgSrc; }
  if (gameAssets.bochka) { gameAssets.bochka.onload = onImgLoad; gameAssets.bochka.src = bochkaImgSrc; }
  if (gameAssets.fakel1) { gameAssets.fakel1.onload = onImgLoad; gameAssets.fakel1.src = fakel1ImgSrc; }
  if (gameAssets.fakel2) { gameAssets.fakel2.onload = onImgLoad; gameAssets.fakel2.src = fakel2ImgSrc; }
  if (gameAssets.fakel3) { gameAssets.fakel3.onload = onImgLoad; gameAssets.fakel3.src = fakel3ImgSrc; }
  if (gameAssets.altar) { gameAssets.altar.onload = onImgLoad; gameAssets.altar.src = altarImgSrc; }

  // 4 In-Game Ingredient Assets with Glow
  if (gameAssets.ing_iron_ore) { gameAssets.ing_iron_ore.onload = onImgLoad; gameAssets.ing_iron_ore.src = mglashardGameImgSrc; }
  if (gameAssets.ing_magic_crystal) { gameAssets.ing_magic_crystal.onload = onImgLoad; gameAssets.ing_magic_crystal.src = magiccrystalGameImgSrc; }
  if (gameAssets.ing_monster_core) { gameAssets.ing_monster_core.onload = onImgLoad; gameAssets.ing_monster_core.src = monstercoreGameImgSrc; }
  if (gameAssets.ing_ancient_rune) { gameAssets.ing_ancient_rune.onload = onImgLoad; gameAssets.ing_ancient_rune.src = voidsealGameImgSrc; }

  // 4 In-Game Ground Helmets by Rarity
  if (gameAssets.helmet_ground_common) { gameAssets.helmet_ground_common.onload = onImgLoad; gameAssets.helmet_ground_common.src = helmetGroundCommonSrc; }
  if (gameAssets.helmet_ground_magic) { gameAssets.helmet_ground_magic.onload = onImgLoad; gameAssets.helmet_ground_magic.src = helmetGroundMagicSrc; }
  if (gameAssets.helmet_ground_rare) { gameAssets.helmet_ground_rare.onload = onImgLoad; gameAssets.helmet_ground_rare.src = helmetGroundRareSrc; }
  if (gameAssets.helmet_ground_epic) { gameAssets.helmet_ground_epic.onload = onImgLoad; gameAssets.helmet_ground_epic.src = helmetGroundEpicSrc; }

  // 12 In-Game Ground & Hand Spears by Rarity
  if (gameAssets.spear_common_1) { gameAssets.spear_common_1.onload = onImgLoad; gameAssets.spear_common_1.src = spearCommon1Src; }
  if (gameAssets.spear_common_2) { gameAssets.spear_common_2.onload = onImgLoad; gameAssets.spear_common_2.src = spearCommon2Src; }
  if (gameAssets.spear_common_3) { gameAssets.spear_common_3.onload = onImgLoad; gameAssets.spear_common_3.src = spearCommon3Src; }

  if (gameAssets.spear_magic_1) { gameAssets.spear_magic_1.onload = onImgLoad; gameAssets.spear_magic_1.src = spearMagic1Src; }
  if (gameAssets.spear_magic_2) { gameAssets.spear_magic_2.onload = onImgLoad; gameAssets.spear_magic_2.src = spearMagic2Src; }
  if (gameAssets.spear_magic_3) { gameAssets.spear_magic_3.onload = onImgLoad; gameAssets.spear_magic_3.src = spearMagic3Src; }

  if (gameAssets.spear_rare_1) { gameAssets.spear_rare_1.onload = onImgLoad; gameAssets.spear_rare_1.src = spearRare1Src; }
  if (gameAssets.spear_rare_2) { gameAssets.spear_rare_2.onload = onImgLoad; gameAssets.spear_rare_2.src = spearRare2Src; }
  if (gameAssets.spear_rare_3) { gameAssets.spear_rare_3.onload = onImgLoad; gameAssets.spear_rare_3.src = spearRare3Src; }

  if (gameAssets.spear_epic_1) { gameAssets.spear_epic_1.onload = onImgLoad; gameAssets.spear_epic_1.src = spearEpic1Src; }
  if (gameAssets.spear_epic_2) { gameAssets.spear_epic_2.onload = onImgLoad; gameAssets.spear_epic_2.src = spearEpic2Src; }
  if (gameAssets.spear_epic_3) { gameAssets.spear_epic_3.onload = onImgLoad; gameAssets.spear_epic_3.src = spearEpic3Src; }

  // 12 In-Game Ground & Hand Hammers by Rarity
  if (gameAssets.hammer_common_1) { gameAssets.hammer_common_1.onload = onImgLoad; gameAssets.hammer_common_1.src = hammerCommon1Src; }
  if (gameAssets.hammer_common_2) { gameAssets.hammer_common_2.onload = onImgLoad; gameAssets.hammer_common_2.src = hammerCommon2Src; }
  if (gameAssets.hammer_common_3) { gameAssets.hammer_common_3.onload = onImgLoad; gameAssets.hammer_common_3.src = hammerCommon3Src; }

  if (gameAssets.hammer_magic_1) { gameAssets.hammer_magic_1.onload = onImgLoad; gameAssets.hammer_magic_1.src = hammerMagic1Src; }
  if (gameAssets.hammer_magic_2) { gameAssets.hammer_magic_2.onload = onImgLoad; gameAssets.hammer_magic_2.src = hammerMagic2Src; }
  if (gameAssets.hammer_magic_3) { gameAssets.hammer_magic_3.onload = onImgLoad; gameAssets.hammer_magic_3.src = hammerMagic3Src; }

  if (gameAssets.hammer_rare_1) { gameAssets.hammer_rare_1.onload = onImgLoad; gameAssets.hammer_rare_1.src = hammerRare1Src; }
  if (gameAssets.hammer_rare_2) { gameAssets.hammer_rare_2.onload = onImgLoad; gameAssets.hammer_rare_2.src = hammerRare2Src; }
  if (gameAssets.hammer_rare_3) { gameAssets.hammer_rare_3.onload = onImgLoad; gameAssets.hammer_rare_3.src = hammerRare3Src; }

  if (gameAssets.hammer_epic_1) { gameAssets.hammer_epic_1.onload = onImgLoad; gameAssets.hammer_epic_1.src = hammerEpic1Src; }
  if (gameAssets.hammer_epic_2) { gameAssets.hammer_epic_2.onload = onImgLoad; gameAssets.hammer_epic_2.src = hammerEpic2Src; }
  if (gameAssets.hammer_epic_3) { gameAssets.hammer_epic_3.onload = onImgLoad; gameAssets.hammer_epic_3.src = hammerEpic3Src; }

  // 4 In-Game Ground Gloves by Rarity
  if (gameAssets.gloves_ground_common) { gameAssets.gloves_ground_common.onload = onImgLoad; gameAssets.gloves_ground_common.src = glovesGroundCommonSrc; }
  if (gameAssets.gloves_ground_magic) { gameAssets.gloves_ground_magic.onload = onImgLoad; gameAssets.gloves_ground_magic.src = glovesGroundMagicSrc; }
  if (gameAssets.gloves_ground_rare) { gameAssets.gloves_ground_rare.onload = onImgLoad; gameAssets.gloves_ground_rare.src = glovesGroundRareSrc; }
  if (gameAssets.gloves_ground_epic) { gameAssets.gloves_ground_epic.onload = onImgLoad; gameAssets.gloves_ground_epic.src = glovesGroundEpicSrc; }

  // 4 In-Game Ground Rings by Rarity
  if (gameAssets.ring_ground_common) { gameAssets.ring_ground_common.onload = onImgLoad; gameAssets.ring_ground_common.src = ringGroundCommonSrc; }
  if (gameAssets.ring_ground_magic) { gameAssets.ring_ground_magic.onload = onImgLoad; gameAssets.ring_ground_magic.src = ringGroundMagicSrc; }
  if (gameAssets.ring_ground_rare) { gameAssets.ring_ground_rare.onload = onImgLoad; gameAssets.ring_ground_rare.src = ringGroundRareSrc; }
  if (gameAssets.ring_ground_epic) { gameAssets.ring_ground_epic.onload = onImgLoad; gameAssets.ring_ground_epic.src = ringGroundEpicSrc; }

  // 4 In-Game Ground Belts by Rarity
  if (gameAssets.belt_ground_common) { gameAssets.belt_ground_common.onload = onImgLoad; gameAssets.belt_ground_common.src = beltGroundCommonSrc; }
  if (gameAssets.belt_ground_magic) { gameAssets.belt_ground_magic.onload = onImgLoad; gameAssets.belt_ground_magic.src = beltGroundMagicSrc; }
  if (gameAssets.belt_ground_rare) { gameAssets.belt_ground_rare.onload = onImgLoad; gameAssets.belt_ground_rare.src = beltGroundRareSrc; }
  if (gameAssets.belt_ground_epic) { gameAssets.belt_ground_epic.onload = onImgLoad; gameAssets.belt_ground_epic.src = beltGroundEpicSrc; }

  // 12 In-Game Ground & Hand Swords by Rarity
  if (gameAssets.sword_common_1) { gameAssets.sword_common_1.onload = onImgLoad; gameAssets.sword_common_1.src = swordCommon1Src; }
  if (gameAssets.sword_common_2) { gameAssets.sword_common_2.onload = onImgLoad; gameAssets.sword_common_2.src = swordCommon2Src; }
  if (gameAssets.sword_common_3) { gameAssets.sword_common_3.onload = onImgLoad; gameAssets.sword_common_3.src = swordCommon3Src; }

  if (gameAssets.sword_magic_1) { gameAssets.sword_magic_1.onload = onImgLoad; gameAssets.sword_magic_1.src = swordMagic1Src; }
  if (gameAssets.sword_magic_2) { gameAssets.sword_magic_2.onload = onImgLoad; gameAssets.sword_magic_2.src = swordMagic2Src; }
  if (gameAssets.sword_magic_3) { gameAssets.sword_magic_3.onload = onImgLoad; gameAssets.sword_magic_3.src = swordMagic3Src; }

  if (gameAssets.sword_rare_1) { gameAssets.sword_rare_1.onload = onImgLoad; gameAssets.sword_rare_1.src = swordRare1Src; }
  if (gameAssets.sword_rare_2) { gameAssets.sword_rare_2.onload = onImgLoad; gameAssets.sword_rare_2.src = swordRare2Src; }
  if (gameAssets.sword_rare_3) { gameAssets.sword_rare_3.onload = onImgLoad; gameAssets.sword_rare_3.src = swordRare3Src; }

  if (gameAssets.sword_epic_1) { gameAssets.sword_epic_1.onload = onImgLoad; gameAssets.sword_epic_1.src = swordEpic1Src; }
  if (gameAssets.sword_epic_2) { gameAssets.sword_epic_2.onload = onImgLoad; gameAssets.sword_epic_2.src = swordEpic2Src; }
  if (gameAssets.sword_epic_3) { gameAssets.sword_epic_3.onload = onImgLoad; gameAssets.sword_epic_3.src = swordEpic3Src; }

  // 12 In-Game Ground & Hand Axes by Rarity
  if (gameAssets.axe_common_1) { gameAssets.axe_common_1.onload = onImgLoad; gameAssets.axe_common_1.src = axeCommon1Src; }
  if (gameAssets.axe_common_2) { gameAssets.axe_common_2.onload = onImgLoad; gameAssets.axe_common_2.src = axeCommon2Src; }
  if (gameAssets.axe_common_3) { gameAssets.axe_common_3.onload = onImgLoad; gameAssets.axe_common_3.src = axeCommon3Src; }

  if (gameAssets.axe_magic_1) { gameAssets.axe_magic_1.onload = onImgLoad; gameAssets.axe_magic_1.src = axeMagic1Src; }
  if (gameAssets.axe_magic_2) { gameAssets.axe_magic_2.onload = onImgLoad; gameAssets.axe_magic_2.src = axeMagic2Src; }
  if (gameAssets.axe_magic_3) { gameAssets.axe_magic_3.onload = onImgLoad; gameAssets.axe_magic_3.src = axeMagic3Src; }

  if (gameAssets.axe_rare_1) { gameAssets.axe_rare_1.onload = onImgLoad; gameAssets.axe_rare_1.src = axeRare1Src; }
  if (gameAssets.axe_rare_2) { gameAssets.axe_rare_2.onload = onImgLoad; gameAssets.axe_rare_2.src = axeRare2Src; }
  if (gameAssets.axe_rare_3) { gameAssets.axe_rare_3.onload = onImgLoad; gameAssets.axe_rare_3.src = axeRare3Src; }

  if (gameAssets.axe_epic_1) { gameAssets.axe_epic_1.onload = onImgLoad; gameAssets.axe_epic_1.src = axeEpic1Src; }
  if (gameAssets.axe_epic_2) { gameAssets.axe_epic_2.onload = onImgLoad; gameAssets.axe_epic_2.src = axeEpic2Src; }
  if (gameAssets.axe_epic_3) { gameAssets.axe_epic_3.onload = onImgLoad; gameAssets.axe_epic_3.src = axeEpic3Src; }

  // 4 In-Game Ground Bracers by Rarity
  if (gameAssets.bracers_ground_common) { gameAssets.bracers_ground_common.onload = onImgLoad; gameAssets.bracers_ground_common.src = bracersGroundCommonSrc; }
  if (gameAssets.bracers_ground_magic) { gameAssets.bracers_ground_magic.onload = onImgLoad; gameAssets.bracers_ground_magic.src = bracersGroundMagicSrc; }
  if (gameAssets.bracers_ground_rare) { gameAssets.bracers_ground_rare.onload = onImgLoad; gameAssets.bracers_ground_rare.src = bracersGroundRareSrc; }
  if (gameAssets.bracers_ground_epic) { gameAssets.bracers_ground_epic.onload = onImgLoad; gameAssets.bracers_ground_epic.src = bracersGroundEpicSrc; }

  // 4 In-Game Ground Chestplates by Rarity
  if (gameAssets.chest_ground_common) { gameAssets.chest_ground_common.onload = onImgLoad; gameAssets.chest_ground_common.src = chestGroundCommonSrc; }
  if (gameAssets.chest_ground_magic) { gameAssets.chest_ground_magic.onload = onImgLoad; gameAssets.chest_ground_magic.src = chestGroundMagicSrc; }
  if (gameAssets.chest_ground_rare) { gameAssets.chest_ground_rare.onload = onImgLoad; gameAssets.chest_ground_rare.src = chestGroundRareSrc; }
  if (gameAssets.chest_ground_epic) { gameAssets.chest_ground_epic.onload = onImgLoad; gameAssets.chest_ground_epic.src = chestGroundEpicSrc; }

  // 4 In-Game Ground Pants by Rarity
  if (gameAssets.pants_ground_common) { gameAssets.pants_ground_common.onload = onImgLoad; gameAssets.pants_ground_common.src = pantsGroundCommonSrc; }
  if (gameAssets.pants_ground_magic) { gameAssets.pants_ground_magic.onload = onImgLoad; gameAssets.pants_ground_magic.src = pantsGroundMagicSrc; }
  if (gameAssets.pants_ground_rare) { gameAssets.pants_ground_rare.onload = onImgLoad; gameAssets.pants_ground_rare.src = pantsGroundRareSrc; }
  if (gameAssets.pants_ground_epic) { gameAssets.pants_ground_epic.onload = onImgLoad; gameAssets.pants_ground_epic.src = pantsGroundEpicSrc; }

  // 4 In-Game Ground Boots by Rarity
  if (gameAssets.boots_ground_common) { gameAssets.boots_ground_common.onload = onImgLoad; gameAssets.boots_ground_common.src = bootsGroundCommonSrc; }
  if (gameAssets.boots_ground_magic) { gameAssets.boots_ground_magic.onload = onImgLoad; gameAssets.boots_ground_magic.src = bootsGroundMagicSrc; }
  if (gameAssets.boots_ground_rare) { gameAssets.boots_ground_rare.onload = onImgLoad; gameAssets.boots_ground_rare.src = bootsGroundRareSrc; }
  if (gameAssets.boots_ground_epic) { gameAssets.boots_ground_epic.onload = onImgLoad; gameAssets.boots_ground_epic.src = bootsGroundEpicSrc; }

  // 4 In-Game Ground Trinkets by Rarity
  if (gameAssets.trinket_ground_common) { gameAssets.trinket_ground_common.onload = onImgLoad; gameAssets.trinket_ground_common.src = trinketGroundCommonSrc; }
  if (gameAssets.trinket_ground_magic) { gameAssets.trinket_ground_magic.onload = onImgLoad; gameAssets.trinket_ground_magic.src = trinketGroundMagicSrc; }
  if (gameAssets.trinket_ground_rare) { gameAssets.trinket_ground_rare.onload = onImgLoad; gameAssets.trinket_ground_rare.src = trinketGroundRareSrc; }
  if (gameAssets.trinket_ground_epic) { gameAssets.trinket_ground_epic.onload = onImgLoad; gameAssets.trinket_ground_epic.src = trinketGroundEpicSrc; }

  // 4 In-Game Ground Cloaks by Rarity
  if (gameAssets.cloak_ground_common) { gameAssets.cloak_ground_common.onload = onImgLoad; gameAssets.cloak_ground_common.src = cloakGroundCommonSrc; }
  if (gameAssets.cloak_ground_magic) { gameAssets.cloak_ground_magic.onload = onImgLoad; gameAssets.cloak_ground_magic.src = cloakGroundMagicSrc; }
  if (gameAssets.cloak_ground_rare) { gameAssets.cloak_ground_rare.onload = onImgLoad; gameAssets.cloak_ground_rare.src = cloakGroundRareSrc; }
  if (gameAssets.cloak_ground_epic) { gameAssets.cloak_ground_epic.onload = onImgLoad; gameAssets.cloak_ground_epic.src = cloakGroundEpicSrc; }
}

function getSpearAsset(rarity: string, key?: string | number): HTMLImageElement | null {
  let idx = 0;
  if (typeof key === 'number') {
    idx = Math.abs(key) % 3;
  } else if (typeof key === 'string') {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    idx = Math.abs(hash) % 3;
  }
  const normRarity = rarity || 'common';
  if (normRarity === 'magic') {
    const list = [gameAssets.spear_magic_1, gameAssets.spear_magic_2, gameAssets.spear_magic_3];
    return list[idx] || gameAssets.spear_magic_1;
  } else if (normRarity === 'rare') {
    const list = [gameAssets.spear_rare_1, gameAssets.spear_rare_2, gameAssets.spear_rare_3];
    return list[idx] || gameAssets.spear_rare_1;
  } else if (normRarity === 'epic') {
    const list = [gameAssets.spear_epic_1, gameAssets.spear_epic_2, gameAssets.spear_epic_3];
    return list[idx] || gameAssets.spear_epic_1;
  } else {
    const list = [gameAssets.spear_common_1, gameAssets.spear_common_2, gameAssets.spear_common_3];
    return list[idx] || gameAssets.spear_common_1;
  }
}

function getHammerAsset(rarity: string, key?: string | number): HTMLImageElement | null {
  let idx = 0;
  if (typeof key === 'number') {
    idx = Math.abs(key) % 3;
  } else if (typeof key === 'string') {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    idx = Math.abs(hash) % 3;
  }
  const normRarity = rarity || 'common';
  if (normRarity === 'magic') {
    const list = [gameAssets.hammer_magic_1, gameAssets.hammer_magic_2, gameAssets.hammer_magic_3];
    return list[idx] || gameAssets.hammer_magic_1;
  } else if (normRarity === 'rare') {
    const list = [gameAssets.hammer_rare_1, gameAssets.hammer_rare_2, gameAssets.hammer_rare_3];
    return list[idx] || gameAssets.hammer_rare_1;
  } else if (normRarity === 'epic') {
    const list = [gameAssets.hammer_epic_1, gameAssets.hammer_epic_2, gameAssets.hammer_epic_3];
    return list[idx] || gameAssets.hammer_epic_1;
  } else {
    const list = [gameAssets.hammer_common_1, gameAssets.hammer_common_2, gameAssets.hammer_common_3];
    return list[idx] || gameAssets.hammer_common_1;
  }
}

function getAxeAsset(rarity: string, key?: string | number): HTMLImageElement | null {
  let idx = 0;
  if (typeof key === 'number') {
    idx = Math.abs(key) % 3;
  } else if (typeof key === 'string') {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    idx = Math.abs(hash) % 3;
  }
  const normRarity = rarity || 'common';
  if (normRarity === 'magic') {
    const list = [gameAssets.axe_magic_1, gameAssets.axe_magic_2, gameAssets.axe_magic_3];
    return list[idx] || gameAssets.axe_magic_1;
  } else if (normRarity === 'rare') {
    const list = [gameAssets.axe_rare_1, gameAssets.axe_rare_2, gameAssets.axe_rare_3];
    return list[idx] || gameAssets.axe_rare_1;
  } else if (normRarity === 'epic') {
    const list = [gameAssets.axe_epic_1, gameAssets.axe_epic_2, gameAssets.axe_epic_3];
    return list[idx] || gameAssets.axe_epic_1;
  } else {
    const list = [gameAssets.axe_common_1, gameAssets.axe_common_2, gameAssets.axe_common_3];
    return list[idx] || gameAssets.axe_common_1;
  }
}

function getSwordAsset(rarity: string, key?: string | number): HTMLImageElement | null {
  let idx = 0;
  if (typeof key === 'number') {
    idx = Math.abs(key) % 3;
  } else if (typeof key === 'string') {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    idx = Math.abs(hash) % 3;
  }
  const normRarity = rarity || 'common';
  if (normRarity === 'magic') {
    const list = [gameAssets.sword_magic_1, gameAssets.sword_magic_2, gameAssets.sword_magic_3];
    return list[idx] || gameAssets.sword_magic_1;
  } else if (normRarity === 'rare') {
    const list = [gameAssets.sword_rare_1, gameAssets.sword_rare_2, gameAssets.sword_rare_3];
    return list[idx] || gameAssets.sword_rare_1;
  } else if (normRarity === 'epic') {
    const list = [gameAssets.sword_epic_1, gameAssets.sword_epic_2, gameAssets.sword_epic_3];
    return list[idx] || gameAssets.sword_epic_1;
  } else {
    const list = [gameAssets.sword_common_1, gameAssets.sword_common_2, gameAssets.sword_common_3];
    return list[idx] || gameAssets.sword_common_1;
  }
}

interface GameCanvasProps {
  targetBoss?: { id: string; level: number } | null;
  startLevel?: number;
  stats: CharacterStats;
  equippedWeapon: Weapon;
  equipment?: EquipmentState;
  difficulty: DifficultyConfig;
  skills: Skill[];
  showShadows?: boolean;
  isPaused: boolean;
  onUpdateStats: (updater: (prev: CharacterStats) => CharacterStats) => void;
  onAddScore: (points: number) => void;
  onAddLoot: (drop: LootDrop) => void;
  onGameOver: (victory?: boolean) => void;
  onSkillUsed: (skillId: string) => void;
  onOpenInventory: (tab?: 'character' | 'inventory' | 'forge' | 'resources') => void;
  isInventoryFull: boolean;
}

interface FlyingEyeRibbon {
  points: { x: number; y: number; oldX: number; oldY: number }[];
  offsetAngle: number;
  length: number;
  width: number;
  color: string;
}

interface FlyingEyeEnemy {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  parent: any;
  topBound: number;
  bottomBound: number;
  leftBound: number;
  rightBound: number;
  timer: number;
  phase: 'idle' | 'aiming' | 'charging' | 'firing' | 'cooldown';
  currentAngle: number;
  lockedAngle: number;
  targetPointX: number;
  targetPointY: number;
  lockedTargetX: number;
  lockedTargetY: number;
  lockedDist: number;
  isStruck: boolean;
  hitCooldown: number;
  ribbons: FlyingEyeRibbon[];
  roomBounds?: { minX: number; maxX: number; minY: number; maxY: number };
  floorZones?: any[];
}

interface LaserDrone {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
  parent: any;
  hp: number;
  maxHp: number;
  alive: boolean;
  phase: 'idle' | 'charging' | 'firing' | 'cooldown';
  timer: number;
  chargeProgress: number;
  rotorAngle: number;
  beamY: number;
  isStruck: boolean;
  hitCooldown: number;
}

export interface LevelTheme {
  name: string;
  bgColor: string;
  brick1: string;
  brick2: string;
  pillarColors: [string, string, string];
  pillarEdges: [string, string, string];
  pillarSpikes: [string, string, string];
  platColor: string;
  platNeon: string;
  wallColor: string;
  sawBody: string;
  sawBorder: string;
  sawTeeth: string;
  iceBody: string;
  iceBorder: string;
  knightBorder: string;
  knightCrest: string;
  eyeBorder: string;
  droneBorder: string;
  phantomBody: string;
  phantomBorder: string;
  phantomRune: string;
}

const LEVEL_THEMES: LevelTheme[] = [
  // Level 1: Gothic Slate & Cyan (matching reference screenshot)
  {
    name: "Готическая Твердыня",
    bgColor: "#0b121c",
    brick1: "#101824",
    brick2: "#182436",
    pillarColors: ["#080d1a", "#111827", "#1c2838"],
    pillarEdges: ["#0f172a", "#1f293d", "#334155"],
    pillarSpikes: ["#0b101d", "#192233", "#2b384e"],
    platColor: "#182333",
    platNeon: "#38bdf8",
    wallColor: "#1c2838",
    sawBody: "#1c2838",
    sawBorder: "#38bdf8",
    sawTeeth: "#334155",
    iceBody: "#0284c7",
    iceBorder: "#38bdf8",
    knightBorder: "#94a3b8",
    knightCrest: "#f59e0b",
    eyeBorder: "#ef4444",
    droneBorder: "#38bdf8",
    phantomBody: "#0369a1",
    phantomBorder: "#38bdf8",
    phantomRune: "#7dd3fc"
  },
  // Level 2: Toxic Emerald Grotto
  {
    name: "Изумрудный Грот",
    bgColor: "#022c22",
    brick1: "#022c22",
    brick2: "#064e3b",
    pillarColors: ["#011712", "#03382c", "#065f46"],
    pillarEdges: ["#022c22", "#044738", "#059669"],
    pillarSpikes: ["#011e17", "#024032", "#047857"],
    platColor: "#064e3b",
    platNeon: "#34d399",
    wallColor: "#064e3b",
    sawBody: "#064e3b",
    sawBorder: "#34d399",
    sawTeeth: "#059669",
    iceBody: "#0d9488",
    iceBorder: "#2dd4bf",
    knightBorder: "#34d399",
    knightCrest: "#a3e635",
    eyeBorder: "#a855f7",
    droneBorder: "#34d399",
    phantomBody: "#047857",
    phantomBorder: "#34d399",
    phantomRune: "#6ee7b7"
  },
  // Level 3: Crimson Blood Citadel
  {
    name: "Кровавая Цитадель",
    bgColor: "#450a0a",
    brick1: "#450a0a",
    brick2: "#7f1d1d",
    pillarColors: ["#260404", "#450a0a", "#991b1b"],
    pillarEdges: ["#360707", "#5c0e0e", "#b91c1c"],
    pillarSpikes: ["#2d0505", "#4d0b0b", "#a11a1a"],
    platColor: "#7f1d1d",
    platNeon: "#f43f5e",
    wallColor: "#7f1d1d",
    sawBody: "#7f1d1d",
    sawBorder: "#f43f5e",
    sawTeeth: "#b91c1c",
    iceBody: "#e11d48",
    iceBorder: "#fda4af",
    knightBorder: "#f43f5e",
    knightCrest: "#fbbf24",
    eyeBorder: "#fbbf24",
    droneBorder: "#f43f5e",
    phantomBody: "#991b1b",
    phantomBorder: "#f43f5e",
    phantomRune: "#fda4af"
  },
  // Level 4: Abyssal Violet Void
  {
    name: "Фиолетовая Бездна",
    bgColor: "#2e1065",
    brick1: "#2e1065",
    brick2: "#3b0764",
    pillarColors: ["#170733", "#2e1065", "#581c87"],
    pillarEdges: ["#230a4d", "#3b0764", "#7e22ce"],
    pillarSpikes: ["#1c083e", "#330857", "#6b21a8"],
    platColor: "#3b0764",
    platNeon: "#c084fc",
    wallColor: "#3b0764",
    sawBody: "#3b0764",
    sawBorder: "#c084fc",
    sawTeeth: "#7e22ce",
    iceBody: "#9333ea",
    iceBorder: "#c084fc",
    knightBorder: "#c084fc",
    knightCrest: "#38bdf8",
    eyeBorder: "#38bdf8",
    droneBorder: "#c084fc",
    phantomBody: "#581c87",
    phantomBorder: "#c084fc",
    phantomRune: "#e879f9"
  },
  // Level 5: Burnt Copper Desert
  {
    name: "Солнечные Руины",
    bgColor: "#451a03",
    brick1: "#451a03",
    brick2: "#78350f",
    pillarColors: ["#240d02", "#451a03", "#92400e"],
    pillarEdges: ["#361402", "#5c2204", "#b45309"],
    pillarSpikes: ["#2c1002", "#4f1c04", "#a14707"],
    platColor: "#78350f",
    platNeon: "#fbbf24",
    wallColor: "#78350f",
    sawBody: "#78350f",
    sawBorder: "#fbbf24",
    sawTeeth: "#b45309",
    iceBody: "#d97706",
    iceBorder: "#fef08a",
    knightBorder: "#fbbf24",
    knightCrest: "#ef4444",
    eyeBorder: "#f43f5e",
    droneBorder: "#fbbf24",
    phantomBody: "#b45309",
    phantomBorder: "#fbbf24",
    phantomRune: "#fef08a"
  },
  // Level 6: Glacial Frost Realm
  {
    name: "Ледяной Предел",
    bgColor: "#082f49",
    brick1: "#082f49",
    brick2: "#0c4a6e",
    pillarColors: ["#031826", "#082f49", "#075985"],
    pillarEdges: ["#0c4a6e", "#0284c7", "#38bdf8"],
    pillarSpikes: ["#032133", "#0c4a6e", "#0284c7"],
    platColor: "#0c4a6e",
    platNeon: "#bae6fd",
    wallColor: "#0c4a6e",
    sawBody: "#0c4a6e",
    sawBorder: "#38bdf8",
    sawTeeth: "#7dd3fc",
    iceBody: "#0284c7",
    iceBorder: "#f0f9ff",
    knightBorder: "#bae6fd",
    knightCrest: "#38bdf8",
    eyeBorder: "#67e8f9",
    droneBorder: "#38bdf8",
    phantomBody: "#075985",
    phantomBorder: "#bae6fd",
    phantomRune: "#f0f9ff"
  },
  // Level 7: Volcanic Ash & Magma
  {
    name: "Пепельные Пустоши",
    bgColor: "#1c1917",
    brick1: "#1c1917",
    brick2: "#292524",
    pillarColors: ["#0c0a09", "#1c1917", "#44403c"],
    pillarEdges: ["#292524", "#78350f", "#ea580c"],
    pillarSpikes: ["#1c1917", "#44403c", "#c2410c"],
    platColor: "#292524",
    platNeon: "#f97316",
    wallColor: "#292524",
    sawBody: "#292524",
    sawBorder: "#f97316",
    sawTeeth: "#ea580c",
    iceBody: "#c2410c",
    iceBorder: "#fed7aa",
    knightBorder: "#f97316",
    knightCrest: "#fde047",
    eyeBorder: "#fb923c",
    droneBorder: "#f97316",
    phantomBody: "#57534e",
    phantomBorder: "#f97316",
    phantomRune: "#fed7aa"
  },
  // Level 8: Bioluminescent Deep Sea
  {
    name: "Морская Пучина",
    bgColor: "#042f2e",
    brick1: "#042f2e",
    brick2: "#115e59",
    pillarColors: ["#021b1b", "#042f2e", "#134e4a"],
    pillarEdges: ["#0f766e", "#14b8a6", "#2dd4bf"],
    pillarSpikes: ["#022322", "#0f766e", "#0d9488"],
    platColor: "#115e59",
    platNeon: "#2dd4bf",
    wallColor: "#115e59",
    sawBody: "#115e59",
    sawBorder: "#2dd4bf",
    sawTeeth: "#14b8a6",
    iceBody: "#0d9488",
    iceBorder: "#99f6e4",
    knightBorder: "#2dd4bf",
    knightCrest: "#67e8f9",
    eyeBorder: "#a7f3d0",
    droneBorder: "#2dd4bf",
    phantomBody: "#134e4a",
    phantomBorder: "#2dd4bf",
    phantomRune: "#ccfbf1"
  },
  // Level 9: Toxic Necropolis
  {
    name: "Токсичный Некрополь",
    bgColor: "#18181b",
    brick1: "#18181b",
    brick2: "#27272a",
    pillarColors: ["#09090b", "#18181b", "#3f3f46"],
    pillarEdges: ["#27272a", "#4d7c0f", "#84cc16"],
    pillarSpikes: ["#18181b", "#3f3f46", "#65a30d"],
    platColor: "#27272a",
    platNeon: "#a3e635",
    wallColor: "#27272a",
    sawBody: "#27272a",
    sawBorder: "#a3e635",
    sawTeeth: "#65a30d",
    iceBody: "#4d7c0f",
    iceBorder: "#d9f99d",
    knightBorder: "#a3e635",
    knightCrest: "#facc15",
    eyeBorder: "#bef264",
    droneBorder: "#a3e635",
    phantomBody: "#3f3f46",
    phantomBorder: "#a3e635",
    phantomRune: "#ecfccb"
  },
  // Level 10: Celestial Sanctuary
  {
    name: "Звездное Святилище",
    bgColor: "#0f0728",
    brick1: "#0f0728",
    brick2: "#1e1145",
    pillarColors: ["#070214", "#0f0728", "#311868"],
    pillarEdges: ["#1e1145", "#6b21a8", "#d946ef"],
    pillarSpikes: ["#0c0421", "#311868", "#9333ea"],
    platColor: "#1e1145",
    platNeon: "#fde047",
    wallColor: "#1e1145",
    sawBody: "#1e1145",
    sawBorder: "#fde047",
    sawTeeth: "#c084fc",
    iceBody: "#7e22ce",
    iceBorder: "#fef08a",
    knightBorder: "#fde047",
    knightCrest: "#e879f9",
    eyeBorder: "#f43f5e",
    droneBorder: "#fde047",
    phantomBody: "#311868",
    phantomBorder: "#e879f9",
    phantomRune: "#fef08a"
  }
];

const getThemeForLevel = (lvl: number): LevelTheme => {
  const index = Math.max(0, (lvl || 1) - 1) % LEVEL_THEMES.length;
  return LEVEL_THEMES[index];
};

export const GameCanvas = React.memo<GameCanvasProps>(({
  targetBoss,
  startLevel,
  stats,
  equippedWeapon,
  equipment,
  difficulty,
  skills,
  showShadows = true,
  isPaused,
  onUpdateStats,
  onAddScore,
  onAddLoot,
  onGameOver,
  onSkillUsed,
  onOpenInventory,
  isInventoryFull
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const equipmentRef = useRef(equipment);
  equipmentRef.current = equipment;

  const isInventoryFullRef = useRef(isInventoryFull);
  isInventoryFullRef.current = isInventoryFull;

  // Active touch joystick DOM refs for direct 60/120Hz update without React re-renders
  const moveBaseRef = useRef<HTMLDivElement | null>(null);
  const moveKnobRef = useRef<HTMLDivElement | null>(null);
  const swordBaseRef = useRef<HTMLDivElement | null>(null);
  const swordKnobRef = useRef<HTMLDivElement | null>(null);
  const swordPointerRef = useRef<HTMLDivElement | null>(null);
  const collectLootRef = useRef<(x: number, y: number) => boolean>(() => false);
  const onAddLootRef = useRef(onAddLoot);
  onAddLootRef.current = onAddLoot;

  const lastMoveActiveRef = useRef(false);
  const lastSwordActiveRef = useRef(false);

  const updateMoveStickUI = (active: boolean, baseX: number, baseY: number, x: number, y: number) => {
    const baseEl = moveBaseRef.current;
    const knobEl = moveKnobRef.current;
    if (baseEl) {
      if (active !== lastMoveActiveRef.current) {
        if (active) {
          baseEl.style.position = 'fixed';
          baseEl.style.left = `${baseX}px`;
          baseEl.style.top = `${baseY}px`;
          baseEl.style.transform = 'translate(-50%, -50%)';
          baseEl.style.transition = 'none';
          baseEl.className = 'w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none flex items-center justify-center bg-sky-950/75 border-2 border-sky-400 shadow-md ring-4 ring-sky-500/25 scale-105';
        } else {
          baseEl.style.position = '';
          baseEl.style.left = '';
          baseEl.style.top = '';
          baseEl.style.transform = '';
          baseEl.style.transition = '';
          baseEl.className = 'w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none flex items-center justify-center absolute bottom-3.5 left-3.5 sm:bottom-6 sm:left-6 bg-slate-950/70 border-2 border-slate-700/50 shadow-lg';
        }
      }
    }
    if (knobEl) {
      knobEl.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      knobEl.style.transition = active ? 'none' : 'transform 0.15s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
      if (active !== lastMoveActiveRef.current) {
        if (active) {
          knobEl.className = 'w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center bg-gradient-to-br from-sky-400 to-blue-600 border-2 border-white shadow-md scale-105 text-white';
        } else {
          knobEl.className = 'w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center bg-gradient-to-br from-slate-700/90 to-slate-800/90 border border-slate-500/60 shadow-md text-slate-400';
        }
      }
    }
    lastMoveActiveRef.current = active;
  };

  const updateSwordStickUI = (active: boolean, baseX: number, baseY: number, x: number, y: number, angle: number) => {
    const baseEl = swordBaseRef.current;
    const knobEl = swordKnobRef.current;
    const ptrEl = swordPointerRef.current;
    if (baseEl) {
      if (active !== lastSwordActiveRef.current) {
        if (active) {
          baseEl.style.position = 'fixed';
          baseEl.style.left = `${baseX}px`;
          baseEl.style.top = `${baseY}px`;
          baseEl.style.transform = 'translate(-50%, -50%)';
          baseEl.style.transition = 'none';
          baseEl.className = 'w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none flex items-center justify-center bg-amber-950/75 border-2 border-amber-400 shadow-md ring-4 ring-amber-500/25 scale-105';
        } else {
          baseEl.style.position = '';
          baseEl.style.left = '';
          baseEl.style.top = '';
          baseEl.style.transform = '';
          baseEl.style.transition = '';
          baseEl.className = 'w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none flex items-center justify-center absolute bottom-3.5 right-3.5 sm:bottom-6 sm:right-6 bg-slate-950/70 border-2 border-slate-700/50 shadow-lg';
        }
      }
    }
    if (knobEl) {
      knobEl.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      knobEl.style.transition = active ? 'none' : 'transform 0.15s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
      if (active !== lastSwordActiveRef.current) {
        if (active) {
          knobEl.className = 'relative w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center bg-gradient-to-br from-amber-400 to-rose-600 border-2 border-white shadow-md scale-105 text-white';
        } else {
          knobEl.className = 'relative w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center bg-gradient-to-br from-slate-700/90 to-slate-800/90 border border-slate-500/60 shadow-md text-slate-400';
        }
      }
    }
    if (ptrEl) {
      ptrEl.style.display = active ? 'flex' : 'none';
      if (active) {
        ptrEl.style.transform = `rotate(${angle}rad)`;
      }
    }
    lastSwordActiveRef.current = active;
  };

  const moveOriginRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const swordOriginRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Camera Zoom Factor: Zoom in close on ground, dynamic zoom out smoothly during jumps based on jump height
  const getCameraScale = () => {
    const canvas = canvasRef.current;
    if (!canvas) return 1.0;
    
    // Zoom out 15% on mobile devices as requested
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || (window.innerWidth < 800);
    const mobileZoomFactor = isMobile ? 0.85 : 1.0;

    // Zoom out slightly on mobile landscape (stacking with general mobile zoom)
    const isMobileLandscape = (window.innerWidth < 1000 && window.innerWidth > window.innerHeight);
    const mobileLandscapeFactor = isMobileLandscape ? 1.05 : 1.0;

    // Base target world height: 420px (close up view). Dynamic smooth zoom out up to ~580px at highest jump apex
    const jumpZoom = gameStateRef.current ? gameStateRef.current.jumpZoomOut : 0;
    const effectiveHeight = (420 + jumpZoom * 160) * mobileLandscapeFactor;
    
    const baseScale = Math.min(1.25, Math.max(0.40, canvas.height / effectiveHeight));
    return baseScale * mobileZoomFactor;
  };

  const getObjTheme = (x: number): LevelTheme => {
    const lvl = gameStateRef.current.level || 1;
    return getThemeForLevel(lvl);
  };
  
  const IS_MOBILE = typeof window !== 'undefined' && (
    window.innerWidth < 1000 ||
    /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ||
    (navigator.maxTouchPoints > 0 && window.innerWidth <= 1024)
  );
  const getShadowBlur = (_blur: number) => 0;

  const drawGroundAura = (c: CanvasRenderingContext2D, rarity: string, radius: number = 20) => {
    const s = gameStateRef.current;
    const aura = rarity === 'epic' ? s.lootAuraEpic : (rarity === 'rare' ? s.lootAuraRare : (rarity === 'magic' ? s.lootAuraMagic : s.lootAuraCommon));
    if (aura) {
      c.drawImage(aura, -radius, -radius, radius * 2, radius * 2);
    } else {
      c.fillStyle = rarity === 'epic' ? 'rgba(192, 132, 252, 0.45)' : (rarity === 'rare' ? 'rgba(56, 189, 248, 0.45)' : (rarity === 'magic' ? 'rgba(74, 222, 128, 0.45)' : 'rgba(203, 213, 225, 0.35)'));
      c.beginPath();
      c.arc(0, 0, radius, 0, Math.PI * 2);
      c.fill();
    }
  };

  const drawGroundNameTag = (c: CanvasRenderingContext2D, text: string, color: string, yOffset: number = -18) => {
    c.font = 'bold 10px sans-serif';
    c.textAlign = 'center';
    c.fillStyle = '#000000';
    c.fillText(text, 1, yOffset + 1);
    c.fillStyle = color;
    c.fillText(text, 0, yOffset);
  };

  const getLevelCooldownMult = (): number => {
    return 2.0; // Doubled sword hit cooldown (was 1.0)
  };

  // Helper to calculate effective attack recovery time (cooldown) in seconds
  // Base is 0.50s (was 0.40s). Gloves reduce this by their attackRecoverySpeed %. Minimum is strictly 0.05s.
  const getAttackRecoveryTimeSec = (): number => {
    let reductionPercent = 0;
    const eq = equipmentRef.current;
    if (eq) {
      (Object.values(eq) as any[]).forEach(item => {
        if (item && item.stats && item.stats.attackRecoverySpeed) {
          reductionPercent += item.stats.attackRecoverySpeed;
        } else if (item && item.attackRecoverySpeed) {
          reductionPercent += item.attackRecoverySpeed;
        }
      });
    }
    const baseSec = 0.50;
    const effectiveSec = baseSec * (1 - Math.min(87.5, reductionPercent) / 100);
    return Math.max(0.05, Math.round(effectiveSec * 100) / 100);
  };

  // High performance game state ref
  const gameStateRef = useRef({
    cleanupTicks: 0,
    cameraX: 0,
    maxCameraX: 0,
    cameraY: 0,
    currentBlockStartX: 0, // Leftmost X boundary player can retreat to within current platform block
    jumpZoomOut: 0, // 0 = close up, 1 = expanded view on jumps
    lastGroundedY: 485, // baseline Y when player was last on the ground
    level: 1,
    distance: 0,
    mobsKilled: 0,
    invFullWarningTimer: 0,
    nextPlatformX: 600,
    nextFattyDistance: 400,
    fattyArena: null as { arenaX: number; arenaEndX: number; arenaY: number; arenaEndY?: number; bossId: string; triggered: boolean; gateUnlocked?: boolean } | null,
    dungeonRooms: [] as { minX: number; maxX: number; minY: number; maxY: number; isBoss?: boolean }[],
    lastChainLightningTime: 0,
    dungeonBounds: { minX: -600, maxX: 6000, minY: -600, maxY: 6000 },
    portal: null as { x: number; y: number; r: number; active: boolean; angle: number; countdownTimer?: number; maxCountdown?: number } | null,
    spawnPoint: { x: 300, y: 300 } as { x: number; y: number },
    swordLock: 0,
    doubleStrikeCdTimer: 0,
    targetSwordAngle: 0,
    isSwordMoving: false,
    isJoystickActive: false,
    isSwinging: false,
    swordTipSpeed: 0,
    swingDistance: 0,
    swingArc: 0,
    prevSwordAngle: 0,
    swingSoundTimer: 0,
    swordTrail: [] as { baseX: number; baseY: number; tipX: number; tipY: number; angle: number; length: number; alpha: number; width: number }[],
    smoothTargetX: 0,
    smoothTargetY: 0,
    levelText: { msg: "Уровень 1", alpha: 2.0, active: true },
    isPortalTransitioning: false,
    portalTransitionTimer: 0,
    isMaterializing: true,
    materializeTimer: 0,
    materializeDuration: 120,
    controlsEnabled: false,
    blackFadeAlpha: 1.0,
    player: {
      x: 100, y: 100, w: 35, h: 35, vx: 0, vy: 0,
      speed: 4.9, jumpPower: -18, jumpCut: 0.4,
      grounded: false, hp: 20, maxHp: 20, invincible: 0, lockControl: 0,
      angle: 0, safeX: 100, safeY: 100, slowTimer: 0, alive: false
    },
    ropePoints: [] as { x: number; y: number; oldX: number; oldY: number }[],
    platforms: [] as any[],
    walls: [] as any[],
    enemies: [] as any[],
    flyingEyes: [] as FlyingEyeEnemy[],
    drones: [] as any[],
    spikeTraps: [] as any[],
    iceProjectiles: [] as any[],
    flameWaves: [] as any[],
    chests: [] as Chest[],
    lootDrops: [] as LootDrop[],
    particles: [] as Particle[],
    shockwaves: [] as { x: number; y: number; r: number; maxR: number; color: string; life: number; maxLife: number; isFrostNova?: boolean; isFattyLandingHalo?: boolean }[],
    screenShake: 0,
    damageTexts: [] as DamageText[],
    levelUpBeams: [] as { x: number; y: number; timer: number; maxTimer: number }[],
    vampirismBeams: [] as { id: string; target?: any; targetX: number; targetY: number; timer: number; maxTimer: number }[],
    lightningArcs: [] as {
      id: string;
      x1: number;
      y1: number;
      x2: number;
      y2: number;
      timer: number;
      maxTimer: number;
      mainSegments: { x: number; y: number }[];
      segments?: { x: number; y: number }[];
      secondaryRays: { x: number; y: number }[][];
      branches: { segments: { x: number; y: number }[]; width: number; alpha: number }[];
    }[],
    dungeonDecorations: [] as any[],
    backgroundProps: [] as any[],
    backgroundTowers: [] as any[],
    backgroundBridges: [] as any[],
    backgroundCrossroads: [] as any[],
    backgroundDeepTowers: [] as any[],
    backgroundDeepBridges: [] as any[],
    backgroundDeepCrossroads: [] as any[],
    keys: { left: false, right: false, up: false, down: false },
    touchIds: { move: null as number | null, sword: null as number | null },
    obstacleColliders: [] as { x: number; y: number; w: number; h: number }[],
    wasFlameSkillActive: false,
    deferredForegroundObjects: [] as Array<{ type: 'dec' | 'chest' | 'column' | 'corner_pillar'; item: any; baseY: number; isRetracting?: boolean }>,
    abyssGrad: null as CanvasGradient | null,
    lastAbyssW: 0,
    lastAbyssH: 0,
    bgPattern: null as CanvasPattern | null,
    floorPattern: null as CanvasPattern | null,
    wallPattern: null as CanvasPattern | null,
    spikePattern: null as CanvasPattern | null,
    torchGlowCanvas: null as HTMLCanvasElement | null,
    deepTorchGlowCanvas: null as HTMLCanvasElement | null,
    cliffCanvas: null as HTMLCanvasElement | null,
    shadowCanvas: null as HTMLCanvasElement | null,
    fogCanvas: null as HTMLCanvasElement | null,
    lootAuraCommon: null as HTMLCanvasElement | null,
    lootAuraMagic: null as HTMLCanvasElement | null,
    lootAuraRare: null as HTMLCanvasElement | null,
    lootAuraEpic: null as HTMLCanvasElement | null
  });

  // State refs for access in animation frame loop
  const statsRef = useRef(stats);
  statsRef.current = stats;
  const weaponRef = useRef(equippedWeapon);
  weaponRef.current = equippedWeapon;
  const diffRef = useRef(difficulty);
  diffRef.current = difficulty;
  const skillsRef = useRef(skills);
  skillsRef.current = skills;
  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;

  const triggerFlameWave = () => {
    const state = gameStateRef.current;
    const swordP = state.ropePoints[state.ropePoints.length - 1];
    const prevP = state.ropePoints[state.ropePoints.length - 2] || state.player;
    const swordAngle = state.ropePoints.length > 1 ? Math.atan2(swordP.y - prevP.y, swordP.x - prevP.x) : (state.player.vx >= 0 ? 0 : Math.PI);
    const speed = 18;
    state.flameWaves.push({
      id: 'fw_' + Date.now() + Math.random(),
      x: swordP ? swordP.x : state.player.x + 20,
      y: swordP ? swordP.y : state.player.y + 15,
      vx: Math.cos(swordAngle) * speed,
      vy: Math.sin(swordAngle) * speed,
      life: 1.5,
      maxLife: 1.5,
      alive: true,
      hitIds: new Set()
    });
    soundManager.playSwing(1.8, 1.0);
  };

  useEffect(() => {
    const isMobile = window.innerWidth < 1000;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: false }) as CanvasRenderingContext2D | null;
    if (!ctx) return;

    // Globally disable and bypass expensive Canvas shadowBlur computations on all devices
    try {
      const originalShadowBlurDescriptor = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, 'shadowBlur');
      if (originalShadowBlurDescriptor && originalShadowBlurDescriptor.set) {
        Object.defineProperty(CanvasRenderingContext2D.prototype, 'shadowBlur', {
          set(_val) {
            originalShadowBlurDescriptor.set!.call(this, 0);
          },
          get() {
            return 0;
          },
          configurable: true
        });
      }
    } catch (e) {
      console.warn("Could not override shadowBlur", e);
    }

    const state = gameStateRef.current;
    if (!state.particles) {
      state.particles = [];
    }

    // Pre-render patterns & sprite canvases for extreme 60fps performance
    const createBrickPattern = (theme?: LevelTheme) => {
      const activeTheme = theme || getThemeForLevel(state.level || 1);

      // 1. Abyss void brick background pattern
      const pCanvas = document.createElement('canvas');
      const pCtx = pCanvas.getContext('2d');
      if (pCtx) {
        const w = 100, h = 100;
        pCanvas.width = w; pCanvas.height = h;
        pCtx.fillStyle = activeTheme.brick1;
        pCtx.fillRect(0, 0, w, h);
        pCtx.fillStyle = activeTheme.brick2;

        for (let row = 0; row < 4; row++) {
          let offset = (row % 2 === 0) ? 0 : 25;
          for (let col = -1; col < 2; col++) {
            let bx = col * 50 + offset;
            let by = row * 25;
            pCtx.beginPath();
            pCtx.roundRect(bx + 5, by + 5, 45, 20, 2);
            pCtx.fill();
          }
        }
        pCtx.fillStyle = 'rgba(0, 0, 0, 0.65)';
        pCtx.fillRect(0, 0, w, h);
        state.bgPattern = ctx.createPattern(pCanvas, 'repeat');
      }

      // 2. High-performance Dungeon Plate Floor Pattern (plate 1 to 11)
      const fCanvas = document.createElement('canvas');
      const fCtx = fCanvas.getContext('2d');
      if (fCtx) {
        const gridCount = 4; // 4x4 grid of 64px plate tiles (256x256)
        const tSize = 64;
        const size = gridCount * tSize; // 256
        fCanvas.width = size; fCanvas.height = size;
        fCtx.fillStyle = '#111827';
        fCtx.fillRect(0, 0, size, size);

        const loadedPlates = gameAssets.plates.filter(img => img && img.complete && img.naturalWidth > 0);
        if (loadedPlates.length > 0) {
          // Regular plates (plates 1-10) for repeating backdrop pattern, keeping plate 11 rare
          const regularPlates = loadedPlates.filter(img => img !== gameAssets.plate11);
          const platesToUse = regularPlates.length > 0 ? regularPlates : loadedPlates;
          const tileIndices = [
            0, 3, 7, 1,
            5, 8, 2, 9,
            4, 6, 0, 3,
            2, 7, 1, 5
          ];
          for (let r = 0; r < gridCount; r++) {
            for (let c = 0; c < gridCount; c++) {
              const rawIdx = tileIndices[(r * gridCount + c) % tileIndices.length];
              const pIdx = rawIdx % platesToUse.length;
              fCtx.drawImage(platesToUse[pIdx], c * tSize, r * tSize, tSize, tSize);
            }
          }
        } else {
          const slabs = [
            { x: 0, y: 0, w: 64, h: 64, col: '#1a2636' },
            { x: 64, y: 0, w: 64, h: 64, col: '#162232' },
            { x: 0, y: 64, w: 64, h: 64, col: '#182434' },
            { x: 64, y: 64, w: 64, h: 64, col: '#1d2a3c' }
          ];
          slabs.forEach(s => {
            fCtx.fillStyle = s.col;
            fCtx.fillRect(s.x, s.y, s.w, s.h);
          });
        }

        fCtx.strokeStyle = 'rgba(8, 14, 24, 0.4)';
        fCtx.lineWidth = 1.5;
        fCtx.strokeRect(0, 0, size, size);

        state.floorPattern = ctx.createPattern(fCanvas, 'repeat');
      }

      // 3. High-performance Labyrinth Ashlar Masonry Wall Pattern (Pre-rendered)
      const wCanvas = document.createElement('canvas');
      const wCtx = wCanvas.getContext('2d');
      if (wCtx) {
        const bw = 36, bh = 18;
        const wWidth = bw * 4; // 144
        const wHeight = bh * 4; // 72
        wCanvas.width = wWidth; wCanvas.height = wHeight;
        wCtx.fillStyle = activeTheme.wallColor || '#1c2838';
        wCtx.fillRect(0, 0, wWidth, wHeight);

        for (let r = 0; r < 4; r++) {
          const by = r * bh;
          const rowOffset = (r % 2) * (bw / 2);
          for (let c = -1; c < 5; c++) {
            const bx = c * bw + rowOffset;
            const rx = Math.max(0, bx);
            const rw = Math.min(bw - (rx - bx), wWidth - rx);
            if (rw <= 2) continue;

            const seed = Math.sin(bx * 73.15 + by * 91.23) * 23847.12;
            const rand = Math.abs(seed) % 1;
            
            // Stone brick base
            wCtx.fillStyle = rand > 0.6 ? '#223246' : rand < 0.3 ? '#162230' : '#1c2838';
            wCtx.fillRect(rx + 1, by + 1, rw - 2, bh - 2);

            // Top-left highlight
            wCtx.fillStyle = 'rgba(255, 255, 255, 0.08)';
            wCtx.fillRect(rx + 1, by + 1, rw - 2, 1.2);
            wCtx.fillRect(rx + 1, by + 1, 1.2, bh - 2);

            // Bottom-right shadow
            wCtx.fillStyle = 'rgba(0, 0, 0, 0.45)';
            wCtx.fillRect(rx + 1, by + bh - 2, rw - 2, 1);
            wCtx.fillRect(rx + rw - 2, by + 1, 1, bh - 2);

            // Dark mortar seams
            wCtx.fillStyle = '#0a1018';
            wCtx.fillRect(rx + rw - 1, by, 1, bh);
            wCtx.fillRect(rx, by + bh - 1, rw, 1);
          }
        }
        state.wallPattern = ctx.createPattern(wCanvas, 'repeat');
      }

      // 4. Pre-rendered Metallic Pyramidal Spikes Pattern for Spiked Columns
      const sCanvas = document.createElement('canvas');
      const sCtx = sCanvas.getContext('2d');
      if (sCtx) {
        const step = 15;
        const sSize = step * 2; // 30x30
        sCanvas.width = sSize; sCanvas.height = sSize;
        sCtx.fillStyle = '#182234';
        sCtx.fillRect(0, 0, sSize, sSize);

        const sR = 5.5;
        for (let sx = step / 2; sx < sSize; sx += step) {
          for (let sy = step / 2; sy < sSize; sy += step) {
            // Top facet
            sCtx.fillStyle = '#e2e8f0';
            sCtx.beginPath();
            sCtx.moveTo(sx - sR, sy - sR);
            sCtx.lineTo(sx + sR, sy - sR);
            sCtx.lineTo(sx, sy);
            sCtx.closePath();
            sCtx.fill();
            // Left facet
            sCtx.fillStyle = '#94a3b8';
            sCtx.beginPath();
            sCtx.moveTo(sx - sR, sy - sR);
            sCtx.lineTo(sx - sR, sy + sR);
            sCtx.lineTo(sx, sy);
            sCtx.closePath();
            sCtx.fill();
            // Right facet
            sCtx.fillStyle = '#64748b';
            sCtx.beginPath();
            sCtx.moveTo(sx + sR, sy - sR);
            sCtx.lineTo(sx + sR, sy + sR);
            sCtx.lineTo(sx, sy);
            sCtx.closePath();
            sCtx.fill();
            // Bottom facet
            sCtx.fillStyle = '#334155';
            sCtx.beginPath();
            sCtx.moveTo(sx - sR, sy + sR);
            sCtx.lineTo(sx + sR, sy + sR);
            sCtx.lineTo(sx, sy);
            sCtx.closePath();
            sCtx.fill();
            // Apex metallic glint
            sCtx.fillStyle = '#ffffff';
            sCtx.fillRect(sx - 0.75, sy - 0.75, 1.5, 1.5);
          }
        }
        state.spikePattern = ctx.createPattern(sCanvas, 'repeat');
      }

      // 5. Pre-rendered Torch & Light Glow Sprites (replaces runtime createRadialGradient allocations)
      const tgCanvas = document.createElement('canvas');
      tgCanvas.width = 44; tgCanvas.height = 44;
      const tgCtx = tgCanvas.getContext('2d');
      if (tgCtx) {
        const rad = tgCtx.createRadialGradient(22, 22, 1, 22, 22, 22);
        rad.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
        rad.addColorStop(0.5, 'rgba(220, 38, 38, 0.16)');
        rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        tgCtx.fillStyle = rad;
        tgCtx.beginPath();
        tgCtx.arc(22, 22, 22, 0, Math.PI * 2);
        tgCtx.fill();
        state.torchGlowCanvas = tgCanvas;
      }

      const warmCanvas = document.createElement('canvas');
      warmCanvas.width = 120; warmCanvas.height = 120;
      const warmCtx = warmCanvas.getContext('2d');
      if (warmCtx) {
        const rad = warmCtx.createRadialGradient(60, 60, 4, 60, 60, 60);
        rad.addColorStop(0, 'rgba(249, 115, 22, 0.32)');
        rad.addColorStop(0.45, 'rgba(234, 88, 12, 0.14)');
        rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        warmCtx.fillStyle = rad;
        warmCtx.beginPath();
        warmCtx.arc(60, 60, 60, 0, Math.PI * 2);
        warmCtx.fill();
        state.warmGlowCanvas = warmCanvas;
      }

      const haloCanvas = document.createElement('canvas');
      haloCanvas.width = 120; haloCanvas.height = 60;
      const haloCtx = haloCanvas.getContext('2d');
      if (haloCtx) {
        const rad = haloCtx.createRadialGradient(60, 30, 4, 60, 30, 60);
        rad.addColorStop(0, 'rgba(251, 146, 60, 0.28)');
        rad.addColorStop(0.5, 'rgba(234, 179, 8, 0.12)');
        rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        haloCtx.fillStyle = rad;
        haloCtx.beginPath();
        haloCtx.ellipse(60, 30, 60, 30, 0, 0, Math.PI * 2);
        haloCtx.fill();
        state.floorHaloCanvas = haloCanvas;
      }

      const dtCanvas = document.createElement('canvas');
      dtCanvas.width = 24; dtCanvas.height = 24;
      const dtCtx = dtCanvas.getContext('2d');
      if (dtCtx) {
        const rad = dtCtx.createRadialGradient(12, 12, 1, 12, 12, 12);
        rad.addColorStop(0, 'rgba(56, 189, 248, 0.4)');
        rad.addColorStop(0.6, 'rgba(14, 165, 233, 0.12)');
        rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        dtCtx.fillStyle = rad;
        dtCtx.beginPath();
        dtCtx.arc(12, 12, 12, 0, Math.PI * 2);
        dtCtx.fill();
        state.deepTorchGlowCanvas = dtCanvas;
      }

      // Pre-rendered Ground Loot Auras (replaces runtime createRadialGradient allocations)
      const createAuraCanvas = (color: string) => {
        const c = document.createElement('canvas');
        c.width = 48; c.height = 48;
        const cx = c.getContext('2d');
        if (cx) {
          const rad = cx.createRadialGradient(24, 24, 2, 24, 24, 24);
          rad.addColorStop(0, color);
          rad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          cx.fillStyle = rad;
          cx.beginPath();
          cx.arc(24, 24, 24, 0, Math.PI * 2);
          cx.fill();
        }
        return c;
      };
      state.lootAuraCommon = createAuraCanvas('rgba(203, 213, 225, 0.45)');
      state.lootAuraMagic = createAuraCanvas('rgba(74, 222, 128, 0.55)');
      state.lootAuraRare = createAuraCanvas('rgba(56, 189, 248, 0.55)');
      state.lootAuraEpic = createAuraCanvas('rgba(192, 132, 252, 0.55)');

      // 6. Pre-rendered Platform Cliff & Shadow Sprites
      const cliffCanvas = document.createElement('canvas');
      cliffCanvas.width = 1; cliffCanvas.height = 40;
      const cCtx = cliffCanvas.getContext('2d');
      if (cCtx) {
        const cGrad = cCtx.createLinearGradient(0, 0, 0, 40);
        cGrad.addColorStop(0, '#131e33');
        cGrad.addColorStop(0.35, '#0b1322');
        cGrad.addColorStop(1, '#02050a');
        cCtx.fillStyle = cGrad;
        cCtx.fillRect(0, 0, 1, 40);
        state.cliffCanvas = cliffCanvas;
      }

      const shadowCanvas = document.createElement('canvas');
      shadowCanvas.width = 1; shadowCanvas.height = 65;
      const shCtx = shadowCanvas.getContext('2d');
      if (shCtx) {
        const sGrad = shCtx.createLinearGradient(0, 0, 0, 65);
        sGrad.addColorStop(0, 'rgba(0, 0, 0, 0.96)');
        sGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        shCtx.fillStyle = sGrad;
        shCtx.fillRect(0, 0, 1, 65);
        state.shadowCanvas = shadowCanvas;
      }

      // 7. Pre-rendered Abyssal Fog Band
      const fogCanvas = document.createElement('canvas');
      fogCanvas.width = 1; fogCanvas.height = 120;
      const fgCtx = fogCanvas.getContext('2d');
      if (fgCtx) {
        const fGrad = fgCtx.createLinearGradient(0, 0, 0, 120);
        fGrad.addColorStop(0, 'rgba(2, 6, 23, 0)');
        fGrad.addColorStop(0.5, 'rgba(8, 15, 30, 0.35)');
        fGrad.addColorStop(1, 'rgba(2, 6, 23, 0)');
        fgCtx.fillStyle = fGrad;
        fgCtx.fillRect(0, 0, 1, 120);
        state.fogCanvas = fogCanvas;
      }
    };

    // Initialize player rope
    const initRope = () => {
      state.ropePoints = [];
      const ropeSegments = 5;
      for (let i = 0; i <= ropeSegments; i++) {
        state.ropePoints.push({ 
          x: state.player.x, 
          y: state.player.y, 
          oldX: state.player.x, 
          oldY: state.player.y 
        });
      }
    };

    // Background Abyss Generator: Multi-Layer Citadel Towers & Fully Interconnected Bridges
    const generateBackgroundProps = () => {
      state.backgroundProps = [];
      state.backgroundDeepBridges = [];
      state.backgroundDeepCrossroads = [];
      state.backgroundDeepTowers = [];
      state.backgroundTowers = [];
      state.backgroundBridges = [];
      state.backgroundCrossroads = [];
      return; // Early return to completely remove background/procedural bridges and towers!
      const db = state.dungeonBounds || { minX: -600, maxX: 5000, minY: -600, maxY: 5000 };

      // Wide world coverage so background covers everywhere
      const startX = db.minX - 1200;
      const endX = db.maxX + 1200;
      const startY = db.minY - 1200;
      const endY = db.maxY + 1200;

      // -------------------------------------------------------------
      // 1. DEEP BACKGROUND LAYER (Further in the abyss, Parallax 0.038)
      // -------------------------------------------------------------
      const deepTowers: any[] = [];
      const deepBridges: any[] = [];
      const deepCrossroads: any[] = [];

      const deepCols = 7;
      const deepRows = 7;
      const deepStepX = (endX - startX) / deepCols;
      const deepStepY = (endY - startY) / deepRows;
      const deepColX = Array.from({ length: deepCols }, (_, c) => startX + (c + 0.5) * deepStepX);
      const deepRowY = Array.from({ length: deepRows }, (_, r) => startY + (r + 0.5) * deepStepY);

      const deepTowerSize = 54;
      const deepBridgeWidth = 14;

      for (let r = 0; r < deepRows; r++) {
        for (let c = 0; c < deepCols; c++) {
          const cx = deepColX[c];
          const cy = deepRowY[r];
          const tx = cx - deepTowerSize / 2;
          const ty = cy - deepTowerSize / 2;

          deepTowers.push({
            id: `dtower_${r}_${c}`,
            r, c,
            x: tx, y: ty,
            size: deepTowerSize,
            wallThick: 8,
            torches: [
              { x: tx + 3, y: ty + 3 },
              { x: tx + deepTowerSize - 3, y: ty + 3 },
              { x: tx + 3, y: ty + deepTowerSize - 3 },
              { x: tx + deepTowerSize - 3, y: ty + deepTowerSize - 3 }
            ]
          });

          // Horizontal bridge to East tower
          if (c < deepCols - 1) {
            const nextCx = deepColX[c + 1];
            const x1 = tx + deepTowerSize;
            const x2 = nextCx - deepTowerSize / 2;
            const y1 = cy;
            const span = x2 - x1;

            const torches: { x: number; y: number; side: 'top' | 'bottom' }[] = [];
            const numT = Math.floor(span / 80);
            for (let k = 1; k <= numT; k++) {
              torches.push({
                x: x1 + (span / (numT + 1)) * k,
                y: y1 + (k % 2 === 0 ? -deepBridgeWidth / 2 : deepBridgeWidth / 2),
                side: k % 2 === 0 ? 'top' : 'bottom'
              });
            }

            deepBridges.push({
              x1, y1, x2, y2: y1,
              width: deepBridgeWidth,
              dir: 'H',
              torches
            });
          }

          // Vertical bridge to South tower
          if (r < deepRows - 1) {
            const nextCy = deepRowY[r + 1];
            const y1 = ty + deepTowerSize;
            const y2 = nextCy - deepTowerSize / 2;
            const x1 = cx;
            const span = y2 - y1;

            const torches: { x: number; y: number; side: 'left' | 'right' }[] = [];
            const numT = Math.floor(span / 80);
            for (let k = 1; k <= numT; k++) {
              torches.push({
                x: x1 + (k % 2 === 0 ? -deepBridgeWidth / 2 : deepBridgeWidth / 2),
                y: y1 + (span / (numT + 1)) * k,
                side: k % 2 === 0 ? 'left' : 'right'
              });
            }

            deepBridges.push({
              x1, y1, x2: x1, y2,
              width: deepBridgeWidth,
              dir: 'V',
              torches
            });
          }
        }
      }

      // Deep Crossroads with perpendicular connected bridge arms
      for (let r = 0; r < deepRows - 1; r++) {
        for (let c = 0; c < deepCols - 1; c++) {
          if ((r + c) % 2 === 1) {
            const midX = (deepColX[c] + deepColX[c + 1]) / 2;
            const midY = (deepRowY[r] + deepRowY[r + 1]) / 2;
            const crossSize = 24;

            deepCrossroads.push({
              x: midX - crossSize / 2,
              y: midY - crossSize / 2,
              size: crossSize,
              torches: [
                { x: midX - crossSize / 2 + 3, y: midY - crossSize / 2 + 3 },
                { x: midX + crossSize / 2 - 3, y: midY - crossSize / 2 + 3 },
                { x: midX - crossSize / 2 + 3, y: midY + crossSize / 2 - 3 },
                { x: midX + crossSize / 2 - 3, y: midY + crossSize / 2 - 3 }
              ]
            });

            // 4 Perpendicular arms seamlessly connecting crossroad to surrounding bridges
            deepBridges.push({
              x1: deepColX[c], y1: midY,
              x2: midX - crossSize / 2, y2: midY,
              width: deepBridgeWidth - 2, dir: 'H', torches: []
            });
            deepBridges.push({
              x1: midX + crossSize / 2, y1: midY,
              x2: deepColX[c + 1], y2: midY,
              width: deepBridgeWidth - 2, dir: 'H', torches: []
            });
            deepBridges.push({
              x1: midX, y1: deepRowY[r],
              x2: midX, y2: midY - crossSize / 2,
              width: deepBridgeWidth - 2, dir: 'V', torches: []
            });
            deepBridges.push({
              x1: midX, y1: midY + crossSize / 2,
              x2: midX, y2: deepRowY[r + 1],
              width: deepBridgeWidth - 2, dir: 'V', torches: []
            });
          }
        }
      }

      state.backgroundDeepTowers = deepTowers;
      state.backgroundDeepBridges = deepBridges;
      state.backgroundDeepCrossroads = deepCrossroads;

      // -------------------------------------------------------------
      // 2. MID BACKGROUND LAYER (Closer, Parallax 0.08, high detail)
      // -------------------------------------------------------------
      const midTowers: any[] = [];
      const midBridges: any[] = [];
      const midCrossroads: any[] = [];

      const midCols = 6;
      const midRows = 6;
      const midStepX = (endX - startX) / midCols;
      const midStepY = (endY - startY) / midRows;
      const midColX = Array.from({ length: midCols }, (_, c) => startX + (c + 0.5) * midStepX);
      const midRowY = Array.from({ length: midRows }, (_, r) => startY + (r + 0.5) * midStepY);

      const midTowerSize = 84;
      const midBridgeWidth = 22;

      for (let r = 0; r < midRows; r++) {
        for (let c = 0; c < midCols; c++) {
          const cx = midColX[c];
          const cy = midRowY[r];
          const tx = cx - midTowerSize / 2;
          const ty = cy - midTowerSize / 2;

          midTowers.push({
            id: `mtower_${r}_${c}`,
            r, c,
            x: tx, y: ty,
            size: midTowerSize,
            wallThick: 12,
            torches: [
              { x: tx + 4, y: ty + 4 },
              { x: tx + midTowerSize - 4, y: ty + 4 },
              { x: tx + 4, y: ty + midTowerSize - 4 },
              { x: tx + midTowerSize - 4, y: ty + midTowerSize - 4 }
            ]
          });

          // Horizontal bridge to East tower
          if (c < midCols - 1) {
            const nextCx = midColX[c + 1];
            const x1 = tx + midTowerSize;
            const x2 = nextCx - midTowerSize / 2;
            const y1 = cy;
            const span = x2 - x1;

            const torches: { x: number; y: number; side: 'top' | 'bottom' }[] = [];
            const numT = Math.floor(span / 70);
            for (let k = 1; k <= numT; k++) {
              torches.push({
                x: x1 + (span / (numT + 1)) * k,
                y: y1 + (k % 2 === 0 ? -midBridgeWidth / 2 : midBridgeWidth / 2),
                side: k % 2 === 0 ? 'top' : 'bottom'
              });
            }

            midBridges.push({
              x1, y1, x2, y2: y1,
              width: midBridgeWidth,
              dir: 'H',
              torches
            });
          }

          // Vertical bridge to South tower
          if (r < midRows - 1) {
            const nextCy = midRowY[r + 1];
            const y1 = ty + midTowerSize;
            const y2 = nextCy - midTowerSize / 2;
            const x1 = cx;
            const span = y2 - y1;

            const torches: { x: number; y: number; side: 'left' | 'right' }[] = [];
            const numT = Math.floor(span / 70);
            for (let k = 1; k <= numT; k++) {
              torches.push({
                x: x1 + (k % 2 === 0 ? -midBridgeWidth / 2 : midBridgeWidth / 2),
                y: y1 + (span / (numT + 1)) * k,
                side: k % 2 === 0 ? 'left' : 'right'
              });
            }

            midBridges.push({
              x1, y1, x2: x1, y2,
              width: midBridgeWidth,
              dir: 'V',
              torches
            });
          }
        }
      }

      // Mid Crossroads with perpendicular connected bridge arms (no floating ends!)
      for (let r = 0; r < midRows - 1; r++) {
        for (let c = 0; c < midCols - 1; c++) {
          if ((r + c) % 2 === 1) {
            const midX = (midColX[c] + midColX[c + 1]) / 2;
            const midY = (midRowY[r] + midRowY[r + 1]) / 2;
            const crossSize = 34;

            midCrossroads.push({
              x: midX - crossSize / 2,
              y: midY - crossSize / 2,
              size: crossSize,
              torches: [
                { x: midX - crossSize / 2 + 3, y: midY - crossSize / 2 + 3 },
                { x: midX + crossSize / 2 - 3, y: midY - crossSize / 2 + 3 },
                { x: midX - crossSize / 2 + 3, y: midY + crossSize / 2 - 3 },
                { x: midX + crossSize / 2 - 3, y: midY + crossSize / 2 - 3 }
              ]
            });

            // 4 Perpendicular arms seamlessly connecting crossroad to surrounding bridges
            midBridges.push({
              x1: midColX[c], y1: midY,
              x2: midX - crossSize / 2, y2: midY,
              width: midBridgeWidth - 2, dir: 'H',
              torches: [{ x: (midColX[c] + midX - crossSize / 2) / 2, y: midY - (midBridgeWidth - 2) / 2, side: 'top' }]
            });
            midBridges.push({
              x1: midX + crossSize / 2, y1: midY,
              x2: midColX[c + 1], y2: midY,
              width: midBridgeWidth - 2, dir: 'H',
              torches: [{ x: (midX + crossSize / 2 + midColX[c + 1]) / 2, y: midY + (midBridgeWidth - 2) / 2, side: 'bottom' }]
            });
            midBridges.push({
              x1: midX, y1: midRowY[r],
              x2: midX, y2: midY - crossSize / 2,
              width: midBridgeWidth - 2, dir: 'V',
              torches: [{ x: midX - (midBridgeWidth - 2) / 2, y: (midRowY[r] + midY - crossSize / 2) / 2, side: 'left' }]
            });
            midBridges.push({
              x1: midX, y1: midY + crossSize / 2,
              x2: midX, y2: midRowY[r + 1],
              width: midBridgeWidth - 2, dir: 'V',
              torches: [{ x: midX + (midBridgeWidth - 2) / 2, y: (midY + crossSize / 2 + midRowY[r + 1]) / 2, side: 'right' }]
            });
          }
        }
      }

      state.backgroundTowers = midTowers;
      state.backgroundBridges = midBridges;
      state.backgroundCrossroads = midCrossroads;
    };

    // --- ENEMY SPAWNERS WITH LEVEL SCALING ---

    // 1. Saw Circle Enemy (Спавнится в комнате со случайным 2D вектором движения)
    const spawnSawEnemy = (p: any, roomBounds?: { minX: number; maxX: number; minY: number; maxY: number }, isRedSaw?: boolean, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;
      const explosionChargeTimer = Math.max(25, Math.round(90 / (1.0 + (lvl - 1) * 0.03)));

      const rb = roomBounds || {
        minX: p.x,
        maxX: p.x + (p.width || 300),
        minY: p.y,
        maxY: p.y + (p.height || 300)
      };

      const r = 18;
      // Спавн строго в зоне пола или внутри периметра комнаты вдалеке от дверных проходов
      const startX = spawnPos ? spawnPos.x : (rb.minX + 50 + Math.random() * Math.max(30, rb.maxX - rb.minX - 100));
      const startY = spawnPos ? spawnPos.y : (rb.minY + 50 + Math.random() * Math.max(30, rb.maxY - rb.minY - 100));

      // Полностью случайный 2D вектор движения во все стороны (360 градусов)
      const baseSpeed = (2.2 + Math.random() * 1.2) * lvlSpeedMult;
      const moveAngle = Math.random() * Math.PI * 2;
      const vx = Math.cos(moveAngle) * baseSpeed;
      const vy = Math.sin(moveAngle) * baseSpeed;
      const isRed = isRedSaw !== undefined ? isRedSaw : (Math.random() < 0.45);

      state.enemies.push({
        id: 'saw_' + Date.now() + Math.random(),
        x: startX,
        y: startY,
        r,
        parent: p,
        roomBounds: rb,
        floorZones: floorZones || (rb as any)?.floorZones || (p as any)?.floorZones || [],
        vx,
        vy,
        alive: true,
        type: 'saw',
        isRedSaw: isRed,
        isChargingExplosion: false,
        explosionTimer: 0,
        maxExplosionTimer: explosionChargeTimer,
        explosionFinished: false,
        angle: 0,
        hp: Math.round((isRed ? 22 : 16) * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round((isRed ? 22 : 16) * diffRef.current.hpMultiplier * lvlHpMult),
        isStruck: false,
        hitCooldown: 0
      });
    };

    // 2. Ice Enemy (Спавнится в комнате со случайным 2D вектором движения)
    const spawnIceEnemy = (p: any, roomBounds?: { minX: number; maxX: number; minY: number; maxY: number }, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;

      const rb = roomBounds || {
        minX: p.x,
        maxX: p.x + (p.width || 300),
        minY: p.y,
        maxY: p.y + (p.height || 300)
      };

      const r = 20;
      // Спавн строго в зоне пола или внутри периметра комнаты вдалеке от дверных проходов
      const startX = spawnPos ? spawnPos.x : (rb.minX + 50 + Math.random() * Math.max(30, rb.maxX - rb.minX - 100));
      const startY = spawnPos ? spawnPos.y : (rb.minY + 50 + Math.random() * Math.max(30, rb.maxY - rb.minY - 100));

      // Полностью случайный 2D вектор движения во все стороны (360 градусов)
      const baseSpeed = (1.6 + Math.random() * 0.9) * lvlSpeedMult;
      const moveAngle = Math.random() * Math.PI * 2;
      const vx = Math.cos(moveAngle) * baseSpeed;
      const vy = Math.sin(moveAngle) * baseSpeed;

      state.enemies.push({
        id: 'ice_' + Date.now() + Math.random(),
        x: startX,
        y: startY,
        r,
        parent: p,
        roomBounds: rb,
        floorZones: floorZones || (rb as any)?.floorZones || (p as any)?.floorZones || [],
        vx,
        vy,
        alive: true,
        type: 'ice',
        angle: 0,
        shootTimer: Math.random() * 60,
        hp: Math.round(22 * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round(22 * diffRef.current.hpMultiplier * lvlHpMult),
        isStruck: false,
        hitCooldown: 0
      });
    };

    // 3. Knight Enemy (Рыцарь с мечом)
    const spawnKnight = (p: any, roomBounds?: { minX: number; maxX: number; minY: number; maxY: number }, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;
      // Knight attack speed increases by 5% per level (windup time reduced, min 22 frames)
      const knightMaxWindup = Math.max(22, Math.round(90 / (1.0 + (lvl - 1) * 0.05)));

      const rb = roomBounds || {
        minX: p.x,
        maxX: p.x + (p.width || 300),
        minY: p.y,
        maxY: p.y + (p.height || 300)
      };

      const startX = spawnPos ? spawnPos.x : (rb.minX + 50 + Math.random() * Math.max(30, rb.maxX - rb.minX - 100));
      const startY = spawnPos ? spawnPos.y : (rb.minY + 50 + Math.random() * Math.max(30, rb.maxY - rb.minY - 100));

      let knight = {
        id: 'knight_' + Date.now() + Math.random(),
        x: startX,
        y: startY,
        r: 18,
        w: 36,
        h: 36,
        parent: p,
        roomBounds: rb,
        floorZones: floorZones || (rb as any)?.floorZones || (p as any)?.floorZones || [],
        vx: 1.0 * (Math.random() > 0.5 ? 1 : -1) * lvlSpeedMult,
        vy: 0,
        alive: true,
        type: 'knight',
        smoothAngle: 0,
        state: 'idle' as 'idle' | 'windup' | 'strike' | 'recovery',
        windupTimer: 0,
        maxWindup: knightMaxWindup,
        strikeTimer: 0,
        recoveryTimer: 0,
        targetAngle: 0,
        attackTimer: 0,
        swordCooldown: 0,
        ropePoints: [] as any[],
        hp: Math.round(55 * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round(55 * diffRef.current.hpMultiplier * lvlHpMult),
        isStruck: false,
        hitCooldown: 0
      };
      for (let i = 0; i < 5; i++) {
        knight.ropePoints.push({ x: knight.x, y: knight.y, oldX: knight.x, oldY: knight.y });
      }
      state.enemies.push(knight);
    };

    // 4. Flying Eye with Flowing Legs / Ribbons (Летающий глаз)
    const spawnFlyingEye = (p: any, buildingData: any = null, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;

      const eyeX = spawnPos ? spawnPos.x : (p.x + p.width / 2);
      const eyeY = spawnPos ? spawnPos.y : (p.y - 130);

      // 12 graceful lazy floating tentacles
      const ribbons: FlyingEyeRibbon[] = [];
      const t = getThemeForLevel(lvl);
      const baseRibbonColors = [
        '#4b5563', '#6b7280', '#9ca3af', '#374151', '#1f2937', '#d1d5db',
        '#4b5563', '#6b7280', '#9ca3af', '#374151', '#1f2937', '#d1d5db'
      ];
      for (let i = 0; i < 12; i++) {
        const offsetAngle = (i - 5.5) * 0.15;
        const segmentCount = 5;
        const pts: { x: number; y: number; oldX: number; oldY: number }[] = [];
        const isLeft = i < 6;
        const vertOffset = (i % 6) * 6 - 15;
        const rootX = eyeX + (isLeft ? -15 : 15);
        const rootY = eyeY + vertOffset;
        for (let s = 0; s < segmentCount; s++) {
          pts.push({ x: rootX, y: rootY + s * 12, oldX: rootX, oldY: rootY + s * 12 });
        }
        ribbons.push({
          points: pts,
          offsetAngle,
          length: 25,
          width: 2.2 - (Math.abs((i % 6) - 2.5) * 0.2),
          color: baseRibbonColors[i % baseRibbonColors.length]
        });
      }

      const moveAngle = Math.random() * Math.PI * 2;
      const eyeSpeed = (1.6 + Math.random() * 0.6) * lvlSpeedMult;

      const eye: FlyingEyeEnemy = {
        x: eyeX,
        y: eyeY,
        vx: Math.cos(moveAngle) * eyeSpeed,
        vy: Math.sin(moveAngle) * eyeSpeed,
        r: 24,
        hp: Math.round(45 * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round(45 * diffRef.current.hpMultiplier * lvlHpMult),
        alive: true,
        parent: p,
        floorZones: floorZones || (buildingData as any)?.floorZones || (p as any)?.floorZones || [],
        topBound: buildingData ? buildingData.topY - 60 : p.y - 180,
        bottomBound: buildingData ? buildingData.bottomY - 20 : p.y - 50,
        leftBound: buildingData ? buildingData.minX : p.x,
        rightBound: buildingData ? buildingData.maxX : p.x + p.width,
        timer: Math.random() * 50,
        phase: 'idle',
        currentAngle: 0,
        lockedAngle: 0,
        targetPointX: eyeX,
        targetPointY: eyeY + 100,
        lockedTargetX: eyeX,
        lockedTargetY: eyeY + 100,
        lockedDist: 100,
        isStruck: false,
        hitCooldown: 0,
        ribbons
      };

      state.flyingEyes.push(eye);
    };

    // 5. Laser Drone on Platform / Inside Room
    const spawnLaserDrone = (p: any, roomBounds?: { minX: number; maxX: number; minY: number; maxY: number }, isRoom: boolean = false, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;

      let droneX = spawnPos ? spawnPos.x : (p.x + p.width * (0.15 + Math.random() * 0.7));
      let droneY = spawnPos ? spawnPos.y : (isRoom ? (p.y + p.height * (0.15 + Math.random() * 0.7)) : (p.y - 26));

      if (!spawnPos) {
        // Try up to 25 times to avoid obstacle/wall collisions
        for (let attempt = 0; attempt < 25; attempt++) {
          let collides = false;
          for (const wall of state.walls) {
            if (!wall.alive || (wall.isFattyArenaWall && (wall.retractProgress || 0) >= 0.85)) continue;
            if (droneX + 22 > wall.x && droneX - 22 < wall.x + wall.w &&
                droneY + 22 > wall.y && droneY - 22 < wall.y + wall.h) {
              collides = true;
              break;
            }
          }
          if (!collides) break;
          droneX = p.x + p.width * (0.15 + Math.random() * 0.7);
          droneY = isRoom ? (p.y + p.height * (0.15 + Math.random() * 0.7)) : (p.y - 26);
        }
      }
      
      const maxHpVal = Math.round(30 * (1.0 + (lvl - 1) * 1.098) * diffRef.current.hpMultiplier);

      const orientation = isRoom ? (Math.random() < 0.5 ? 'horizontal' : 'vertical') : 'horizontal';
      const moveDir = Math.random() < 0.5 ? 1 : -1;

      state.drones.push({
        id: 'drone_' + Date.now() + Math.random(),
        x: droneX,
        y: droneY,
        w: 32,
        h: 32,
        r: 16,
        orientation,
        moveDir,
        parent: p,
        roomBounds,
        floorZones: floorZones || (roomBounds as any)?.floorZones || (p as any)?.floorZones || [],
        isRoomDrone: isRoom,
        spawnX: droneX,
        spawnY: droneY,
        hp: maxHpVal,
        maxHp: maxHpVal,
        alive: true,
        phase: 'idle',
        timer: Math.random() * 60,
        chargeProgress: 0,
        rotorAngle: 0,
        beamY: droneY,
        isStruck: false,
        hitCooldown: 0
      });
    };

    // Sorcerer Enemy (Колдун в капюшоне / Ледяной колдун)
    const spawnSorcerer = (p: any, roomBounds?: { minX: number; maxX: number; minY: number; maxY: number }, isFrostMage?: boolean, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;

      const rb = roomBounds || { minX: p.x, maxX: p.x + p.width, minY: p.y, maxY: p.y + p.height };
      const startX = spawnPos ? spawnPos.x : (rb.minX + 45 + Math.random() * Math.max(30, rb.maxX - rb.minX - 90));
      const startY = spawnPos ? spawnPos.y : (rb.minY + 45 + Math.random() * Math.max(30, rb.maxY - rb.minY - 90));
      const isFrost = isFrostMage !== undefined ? isFrostMage : (Math.random() < 0.5);

      state.enemies.push({
        id: 'sorcerer_' + Date.now() + Math.random(),
        x: startX,
        y: startY,
        r: 20,
        w: 40,
        h: 40,
        parent: p,
        roomBounds: rb,
        floorZones: floorZones || (rb as any)?.floorZones || (p as any)?.floorZones || [],
        vx: 0,
        vy: 0,
        alive: true,
        type: 'sorcerer',
        isFrostMage: isFrost,
        state: 'idle', // 'idle' | 'charging' | 'teleporting'
        facingDir: 1,
        shootTimer: 0,
        chargeProgress: 0,
        cooldownTimer: 60 + Math.random() * 60,
        hp: Math.round((isFrost ? 60 : 50) * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round((isFrost ? 60 : 50) * diffRef.current.hpMultiplier * lvlHpMult),
        isStruck: false,
        hitCooldown: 0
      });
    };

    // 6. Fatty Boss / Mini-boss with folds, fire breath and punch
    const spawnFattyEnemy = (p: any) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const aimSpeedMult = 1.0 + (lvl - 1) * 0.04;

      state.enemies.push({
        id: 'fatty_' + Date.now() + Math.random(),
        x: p.x + p.width / 2,
        y: p.y - 96,
        r: 96,
        w: 168,
        h: 168,
        parent: p,
        vx: 0,
        vy: 0,
        alive: true,
        type: 'fatty',
        hp: Math.round(2000 * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round(2000 * diffRef.current.hpMultiplier * lvlHpMult),
        handsAnim: 0,
        shootTimer: 0,
        maxShootTimer: Math.max(40, 120 / aimSpeedMult),
        state: 'idle' as 'idle' | 'windup' | 'strike' | 'recovery',
        windupTimer: 0,
        maxWindup: Math.max(15, 60 / aimSpeedMult),
        strikeTimer: 0,
        recoveryTimer: 0,
        isStruck: false,
        hitCooldown: 0,
        fattyPhase: 'normal',
        triggered70: false,
        triggered30: false,
        laserTimer: 0,
        laserFireTimer: 0,
        laserCyclesCount: 0,
        laserAngles: [] as number[],
        isBoss: true
      });
    };

    // 7. Void Spectre / Phantom Enemy (Парящий Фантом / Белый Фантом)
    const spawnPhantomEnemy = (p: any, buildingData?: { topY: number; bottomY: number; minX: number; maxX: number }, isWhitePhantom?: boolean, spawnPos?: { x: number; y: number }, floorZones?: any[]) => {
      const lvl = state.level || 1;
      const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
      const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;

      const px = spawnPos ? spawnPos.x : (p.x + p.width * (0.2 + Math.random() * 0.6));
      const py = spawnPos ? spawnPos.y : (buildingData ? buildingData.topY + 30 : p.y - 110 - Math.random() * 40);
      const isWhite = isWhitePhantom !== undefined ? isWhitePhantom : (Math.random() < 0.5);

      const moveAng = Math.random() * Math.PI * 2;
      const baseSpeed = 1.35 * lvlSpeedMult;
      const initialVx = Math.cos(moveAng) * baseSpeed;
      const initialVy = Math.sin(moveAng) * (baseSpeed * 0.75);

      state.enemies.push({
        id: 'phantom_' + Date.now() + Math.random(),
        x: px,
        y: py,
        vx: initialVx,
        vy: initialVy,
        targetVx: initialVx,
        targetVy: initialVy,
        r: 20,
        w: 40,
        h: 40,
        parent: p,
        floorZones: floorZones || (buildingData as any)?.floorZones || (p as any)?.floorZones || [],
        roomBounds: buildingData ? {
          minX: buildingData.minX,
          maxX: buildingData.maxX,
          minY: buildingData.topY,
          maxY: buildingData.bottomY,
          topY: buildingData.topY,
          bottomY: buildingData.bottomY
        } : undefined,
        topBound: buildingData ? buildingData.topY - 40 : p.y - 220,
        bottomBound: buildingData ? buildingData.bottomY - 30 : p.y - 50,
        leftBound: buildingData ? buildingData.minX : p.x - 40,
        rightBound: buildingData ? buildingData.maxX : p.x + p.width + 40,
        alive: true,
        type: 'phantom',
        isWhitePhantom: isWhite,
        isSplitClone: false,
        hoverAngle: Math.random() * Math.PI * 2,
        chargeTimer: Math.random() * 40,
        cooldownTimer: 0,
        state: 'hover' as 'hover' | 'charge' | 'dash',
        dashVx: 0,
        dashVy: 0,
        dashTimer: 0,
        fadeAlpha: 1.0,
        hp: Math.round((isWhite ? 46 : 38) * diffRef.current.hpMultiplier * lvlHpMult),
        maxHp: Math.round((isWhite ? 46 : 38) * diffRef.current.hpMultiplier * lvlHpMult),
        isStruck: false,
        hitCooldown: 0
      });
    };

    // --- Floor Zone & Safe Object Spawn Helpers ---
    const getRoomFloorZones = (roomData: any, rx: number, ry: number, minOffX: number = 0, minOffY: number = 0): { x: number; y: number; w: number; h: number }[] => {
      const zones: { x: number; y: number; w: number; h: number }[] = [];
      if (Array.isArray(roomData?.floorZones) && roomData.floorZones.length > 0) {
        for (const z of roomData.floorZones) {
          if (z.w > 16 && z.h > 16) {
            zones.push({
              x: rx + (z.x - minOffX),
              y: ry + (z.y - minOffY),
              w: z.w,
              h: z.h
            });
          }
        }
      }
      if (zones.length === 0 && Array.isArray(roomData?.collisionBoxes)) {
        for (const b of roomData.collisionBoxes) {
          if (b.enabled === false) continue;
          const lbl = (b.label || '').toLowerCase();
          if (lbl.includes('пол') || lbl.includes('floor') || b.type === 'floor') {
            zones.push({
              x: rx + (b.x - minOffX),
              y: ry + (b.y - minOffY),
              w: b.w,
              h: b.h
            });
          }
        }
      }
      return zones;
    };

    const findSafeFloorZonePosition = (
      zones: { x: number; y: number; w: number; h: number }[],
      objW: number,
      objH: number,
      clearance: number = 24,
      avoidPos?: { x: number; y: number; dist: number }
    ): { x: number; y: number } | null => {
      if (!zones || zones.length === 0) return null;

      const totalArea = zones.reduce((acc, z) => acc + Math.max(1, z.w * z.h), 0);

      // Attempt random placement within floor zones avoiding obstacles
      for (let attempt = 0; attempt < 70; attempt++) {
        let randWeight = Math.random() * totalArea;
        let selectedZone = zones[0];
        for (const z of zones) {
          randWeight -= z.w * z.h;
          if (randWeight <= 0) {
            selectedZone = z;
            break;
          }
        }

        const padX = Math.min(clearance, selectedZone.w * 0.15);
        const padY = Math.min(clearance, selectedZone.h * 0.15);
        const minX = selectedZone.x + padX;
        const maxX = Math.max(minX, selectedZone.x + selectedZone.w - padX - objW);
        const minY = selectedZone.y + padY;
        const maxY = Math.max(minY, selectedZone.y + selectedZone.h - padY - objH);

        const testX = minX + Math.random() * (maxX - minX);
        const testY = minY + Math.random() * (maxY - minY);

        // 1. Obstacle Check: Solid Walls (state.walls)
        let collides = false;
        for (const w of state.walls) {
          if (!w.alive) continue;
          if (
            testX + objW + clearance > w.x &&
            testX - clearance < w.x + w.w &&
            testY + objH + clearance > w.y &&
            testY - clearance < w.y + w.h
          ) {
            collides = true;
            break;
          }
        }
        if (collides) continue;

        // 2. Obstacle Check: Obstacle colliders (altars, braziers, destructible props)
        if (state.obstacleColliders) {
          for (const obs of state.obstacleColliders) {
            if (
              testX + objW + clearance > obs.x &&
              testX - clearance < obs.x + obs.w &&
              testY + objH + clearance > obs.y &&
              testY - clearance < obs.y + obs.h
            ) {
              collides = true;
              break;
            }
          }
        }
        if (collides) continue;

        // 3. Obstacle Check: Existing Chests
        for (const ch of state.chests) {
          if (
            testX + objW + 30 > ch.x &&
            testX - 30 < ch.x + ch.w &&
            testY + objH + 30 > ch.y &&
            testY - 30 < ch.y + ch.h
          ) {
            collides = true;
            break;
          }
        }
        if (collides) continue;

        // 4. Obstacle Check: Existing Spike Traps
        for (const tr of state.spikeTraps) {
          if (
            testX + objW + 30 > tr.x &&
            testX - 30 < tr.x + tr.w &&
            testY + objH + 30 > tr.y &&
            testY - 30 < tr.y + tr.h
          ) {
            collides = true;
            break;
          }
        }
        if (collides) continue;

        // 5. Avoid custom position / Player Spawn
        if (avoidPos && Math.hypot((testX + objW / 2) - avoidPos.x, (testY + objH / 2) - avoidPos.y) < avoidPos.dist) {
          continue;
        }
        if (state.spawnPoint && Math.hypot((testX + objW / 2) - state.spawnPoint.x, (testY + objH / 2) - state.spawnPoint.y) < 130) {
          continue;
        }

        // 6. Verify center is strictly inside at least one floor zone
        const centerX = testX + objW / 2;
        const centerY = testY + objH / 2;
        const insideZone = zones.some(
          z => centerX >= z.x && centerX <= z.x + z.w && centerY >= z.y && centerY <= z.y + z.h
        );
        if (!insideZone) continue;

        return { x: testX, y: testY };
      }

      // Fallback: Return center of first zone
      return {
        x: zones[0].x + zones[0].w / 2 - objW / 2,
        y: zones[0].y + zones[0].h / 2 - objH / 2
      };
    };

    // Procedural Labyrinth Dungeon Generation:
    // Fully randomized dynamic grid, randomized start and boss room positions, rich architectural archetypes,
    // procedural interiors, breakable secret chambers, dynamic mob scaling, and guaranteed reachable single-entry boss colosseum.
    const generateLabyrinthLevel = (levelNum: number) => {
      const wallThick = 36;
      const colSize = 44;
      const colPad = (colSize - wallThick) / 2; // 4px
      const doorWidth = 160;

      // 1. Dynamic Grid Sizing (6x6 grid to easily accommodate 17-room linear sequence)
      const cols = 6;
      const rows = 6;

      // 2. Randomized Linear Sequence: Exactly 16 rooms before the boss (17 rooms total)
      // Every generated room has strictly 1 entrance and 1 exit (start room has 1 exit, boss room has 1 entrance)
      const PRE_BOSS_ROOMS = 16;
      const TOTAL_PATH_LEN = PRE_BOSS_ROOMS + 1; // 16 rooms before boss + 1 boss arena room = 17 rooms total

      const perimeterCells: [number, number][] = [];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (r === 0 || r === rows - 1 || c === 0 || c === cols - 1) {
            perimeterCells.push([c, r]);
          }
        }
      }

      let path: [number, number][] = [];

      // Filter perimeter start cells so that startR < rows - 1 (allowing exit facing downward / south)
      const validStartCells = perimeterCells.filter(([_, r]) => r < rows - 1);
      const startPool = validStartCells.length > 0 ? validStartCells : perimeterCells;

      for (let attempt = 0; attempt < 800; attempt++) {
        const startCell = startPool[Math.floor(Math.random() * startPool.length)];
        const startC = startCell[0];
        const startR = startCell[1];
        const visited: boolean[][] = Array.from({ length: rows }, () => Array(cols).fill(false));
        visited[startR][startC] = true;

        // Force first step from starter room to be SOUTH (downwards: startR + 1)
        const currentPath: [number, number][] = [[startC, startR]];
        if (startR + 1 < rows) {
          visited[startR + 1][startC] = true;
          currentPath.push([startC, startR + 1]);
        }

        const walk = (c: number, r: number): boolean => {
          if (currentPath.length >= TOTAL_PATH_LEN) return true;
          const dirs: [number, number][] = ([[0, -1], [0, 1], [-1, 0], [1, 0]] as [number, number][]).sort(() => Math.random() - 0.5);

          for (const [dc, dr] of dirs) {
            const nc = c + dc;
            const nr = r + dr;
            if (nc >= 0 && nc < cols && nr >= 0 && nr < rows && !visited[nr][nc]) {
              visited[nr][nc] = true;
              currentPath.push([nc, nr]);
              if (walk(nc, nr)) return true;
              currentPath.pop();
              visited[nr][nc] = false;
            }
          }
          return false;
        };

        const lastPathCell = currentPath[currentPath.length - 1];
        walk(lastPathCell[0], lastPathCell[1]);
        if (currentPath.length > path.length) {
          path = [...currentPath];
        }
        if (path.length >= TOTAL_PATH_LEN) break;
      }

      // Guaranteed deterministic fallback: snake pattern of exactly 17 cells
      if (path.length < TOTAL_PATH_LEN) {
        path = [];
        let curR = 0;
        let curC = 0;
        let dir = 1;
        while (path.length < TOTAL_PATH_LEN) {
          path.push([curC, curR]);
          curC += dir;
          if (curC >= cols || curC < 0) {
            dir *= -1;
            curC += dir;
            curR += 1;
          }
        }
      }

      const startRoomC = path[0][0];
      const startRoomR = path[0][1];
      const bossRoomC = path[path.length - 1][0];
      const bossRoomR = path[path.length - 1][1];
      const activeRoomsSet = new Set(path.map(([c, r]) => `${c},${r}`));

      const allRooms = roomStorage.getAllRooms();
      const activeRoom = allRooms.find(r => r.roomType === 'start') || allRooms[0] || starterRoom;
      const roomSizes: { w: number; h: number; archetype: string }[][] = [];
      for (let r = 0; r < rows; r++) {
        const rowArr: { w: number; h: number; archetype: string }[] = [];
        for (let c = 0; c < cols; c++) {
          rowArr.push({
            w: activeRoom.width || 900,
            h: activeRoom.height || 650,
            archetype: 'room_from_rooms_folder'
          });
        }
        roomSizes.push(rowArr);
      }

      // Corridor length variation per level - snapped to 64
      const corrLen = 0; // Directly connect and snap room transitions together!

      // Max width per column and max height per row
      const colMaxW = Array.from({ length: cols }, (_, c) =>
        Math.max(...Array.from({ length: rows }, (_, r) => roomSizes[r][c].w))
      );
      const rowMaxH = Array.from({ length: rows }, (_, r) =>
        Math.max(...Array.from({ length: cols }, (_, c) => roomSizes[r][c].h))
      );

      // Compute column centers - all snapped to 64
      const colCenterX: number[] = [];
      let curColX = colMaxW[0] / 2 + 64;
      colCenterX.push(curColX);
      for (let c = 1; c < cols; c++) {
        curColX += colMaxW[c - 1] / 2 + corrLen + colMaxW[c] / 2;
        colCenterX.push(curColX);
      }

      // Compute row centers - all snapped to 64
      const rowCenterY: number[] = [];
      let curRowY = rowMaxH[0] / 2 + 64;
      rowCenterY.push(curRowY);
      for (let r = 1; r < rows; r++) {
        curRowY += rowMaxH[r - 1] / 2 + corrLen + rowMaxH[r] / 2;
        rowCenterY.push(curRowY);
      }

      // Store overall dungeon bounding box for safe player bounds check
      const maxDungeonX = colCenterX[cols - 1] + colMaxW[cols - 1] / 2 + 500;
      const maxDungeonY = rowCenterY[rows - 1] + rowMaxH[rows - 1] / 2 + 500;
      state.dungeonBounds = {
        minX: -500,
        maxX: maxDungeonX,
        minY: -500,
        maxY: maxDungeonY
      };

      // Clear existing level
      state.platforms = [];
      state.walls = [];
      state.enemies = [];
      state.flyingEyes = [];
      state.drones = [];
      state.spikeTraps = [];
      state.iceProjectiles = [];
      state.flameWaves = [];
      state.chests = [];
      state.lootDrops = [];
      state.damageTexts = [];
      state.particles = [];
      state.shockwaves = [];
      state.vampirismBeams = [];
      state.lightningArcs = [];
      state.dungeonDecorations = [];
      state.dungeonRooms = [];
      state.portal = null;
      state.fattyArena = null;

      // 4. Connect Strictly Consecutive Rooms in the Path (1 entrance, 1 exit per room)
      const H: boolean[][] = Array.from({ length: rows }, () => Array(cols - 1).fill(false));
      const V: boolean[][] = Array.from({ length: rows - 1 }, () => Array(cols).fill(false));

      for (let i = 0; i < path.length - 1; i++) {
        const [c1, r1] = path[i];
        const [c2, r2] = path[i + 1];
        if (r1 === r2) {
          if (c2 === c1 + 1) H[r1][c1] = true;
          else if (c2 === c1 - 1) H[r1][c2] = true;
        } else if (c1 === c2) {
          if (r2 === r1 + 1) V[r1][c1] = true;
          else if (r2 === r1 - 1) V[r2][c1] = true;
        }
      }

      const addCornerPillar = (px: number, py: number, isBack: boolean = false) => {
        const exists = state.walls.some(w => w.isCornerPillar && Math.abs(w.x - px) < 8 && Math.abs(w.y - py) < 8);
        if (exists) return;
        state.walls.push({
          x: px,
          y: py,
          w: colSize,
          h: colSize,
          alive: true,
          color: '#334155',
          isDungeonWall: true,
          indestructible: true,
          isCornerPillar: true,
          isBackPillar: isBack,
          isFrontPillar: !isBack
        });
      };

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (!activeRoomsSet.has(`${c},${r}`)) continue;
          const { w: roomW, h: roomH } = roomSizes[r][c];
          const rx = Math.round((colCenterX[c] - roomW / 2) / 32) * 32;
          const ry = Math.round((rowCenterY[r] - roomH / 2) / 32) * 32;
          const isStart = (c === startRoomC && r === startRoomR);
          const isBoss = (c === bossRoomC && r === bossRoomR);

          // Register strict boundaries for this room
          state.dungeonRooms.push({
            minX: rx,
            maxX: rx + roomW,
            minY: ry,
            maxY: ry + roomH,
            isBoss,
            isStart,
            lighting: { enableLighting: false, ambientDarkness: 0 },
            elements: activeRoom.elements as RoomElement[]
          });

          // Check connections
          const hasN = r > 0 && V[r - 1][c];
          const hasS = r < rows - 1 && V[r][c];
          const hasW = c > 0 && H[r][c - 1];
          const hasE = c < cols - 1 && H[r][c];

          if (isBoss) {
            // --- BOSS ARENA ROOM (EXACTLY 1 ENTRANCE GATE) ---
            const arenaW = roomW;
            const arenaH = roomH;
            const arenaX = rx;
            const arenaY = ry;

            // Floor (Always mark isStartFloor: true to prevent procedural floor stone plates and cliffs)
            state.platforms.push({
              x: arenaX, y: arenaY, width: arenaW, height: arenaH,
              color: '#1e293b', isDungeonFloor: true, isFattyArena: true, isStartFloor: true
            });

            // Invisible physics collision boxes from preset (strictly preserved, NEVER destroyed)
            if (Array.isArray(activeRoom.collisionBoxes)) {
              activeRoom.collisionBoxes.forEach((box: any) => {
                if (box.enabled === false) return;
                if (box.type === 'wall' || box.type === 'hazard') {
                  state.walls.push({
                    x: arenaX + box.x,
                    y: arenaY + box.y,
                    w: box.w,
                    h: box.h,
                    alive: true,
                    color: '#334155',
                    isDungeonWall: true,
                    indestructible: true,
                    isInvisible: true
                  });
                }
              });
            }

            // Baked room images (under hero and above hero)
            if ((activeRoom as CustomRoomData).bakedUnderHeroImage) {
              state.dungeonDecorations.push({
                id: 'baked_under_' + Math.random(),
                type: 'baked_image',
                src: (activeRoom as CustomRoomData).bakedUnderHeroImage,
                x: arenaX,
                y: arenaY,
                w: activeRoom.width || arenaW,
                h: activeRoom.height || arenaH,
                renderAboveHero: false,
                zIndex: 0
              });
            }
            if ((activeRoom as CustomRoomData).bakedAboveHeroImage) {
              state.dungeonDecorations.push({
                id: 'baked_above_' + Math.random(),
                type: 'baked_image',
                src: (activeRoom as CustomRoomData).bakedAboveHeroImage,
                x: arenaX,
                y: arenaY,
                w: activeRoom.width || arenaW,
                h: activeRoom.height || arenaH,
                renderAboveHero: true,
                zIndex: 9999
              });
            }

            // Visual elements from preset for the boss room (strictly preserved, NEVER destroyed)
            if (Array.isArray(activeRoom.elements)) {
              activeRoom.elements.forEach((el: any) => {
                state.dungeonDecorations.push({
                  id: 'boss_el_' + el.id + '_' + Date.now() + Math.random(),
                  type: 'custom_element',
                  x: arenaX + el.x,
                  y: arenaY + el.y,
                  w: el.w,
                  h: el.h,
                  src: el.src,
                  assetId: el.assetId,
                  name: el.name,
                  layer: el.layer,
                  zIndex: el.zIndex ?? 1,
                  opacity: el.opacity ?? 1,
                  flipX: el.flipX ?? false,
                  flipY: el.flipY ?? false,
                  rotation: el.rotation ?? 0,
                  hasLight: el.hasLight ?? false,
                  lightRadius: el.lightRadius ?? 80,
                  lightColor: el.lightColor ?? '#ff9d3b',
                  lightIntensity: el.lightIntensity ?? 1.0,
                  lightFlicker: el.lightFlicker ?? false,
                  hasFireEffect: el.hasFireEffect ?? false,
                  fireScale: el.fireScale ?? 1.0,
                  isShadowSource: el.isShadowSource ?? false,
                  shadowDensity: el.shadowDensity ?? 0.8,
                  shadowShape: el.shadowShape,
                  shadowCorners: el.shadowCorners,
                  shadowCornerRadius: el.shadowCornerRadius,
                  renderAboveHero: el.renderAboveHero !== undefined ? el.renderAboveHero : ((el.zIndex ?? 0) > 100)
                });
              });
              state.dungeonDecorations.sort((a: any, b: any) => {
                const aAbove = Boolean(a.renderAboveHero ?? ((a.zIndex || 0) > 100));
                const bAbove = Boolean(b.renderAboveHero ?? ((b.zIndex || 0) > 100));
                if (aAbove !== bAbove) return aAbove ? 1 : -1;
                return (a.zIndex || 0) - (b.zIndex || 0);
              });
            }

            // Spawn Fatty Boss (Safely inside floor zone if available)
            const lvlHpMult = 1.0 + (levelNum - 1) * 2.607;
            const aimSpeedMult = 1.0 + (levelNum - 1) * 0.04;
            const bossFloorZones = getRoomFloorZones(activeRoom, arenaX, arenaY);
            let fattySpawnX = arenaX + arenaW / 2;
            let fattySpawnY = arenaY + arenaH / 2;
            if (bossFloorZones.length > 0) {
              const bPos = findSafeFloorZonePosition(bossFloorZones, 168, 168, 36);
              if (bPos) {
                fattySpawnX = bPos.x + 84;
                fattySpawnY = bPos.y + 84;
              }
            }

            const fattyEnemy = {
              id: 'fatty_' + Date.now() + Math.random(),
              x: fattySpawnX,
              y: fattySpawnY,
              r: 96,
              w: 168,
              h: 168,
              parent: { x: arenaX, y: arenaY, width: arenaW, height: arenaH },
              vx: 0,
              vy: 0,
              alive: true,
              type: 'fatty',
              hp: Math.round(2000 * diffRef.current.hpMultiplier * lvlHpMult),
              maxHp: Math.round(2000 * diffRef.current.hpMultiplier * lvlHpMult),
              handsAnim: 0,
              shootTimer: 0,
              maxShootTimer: Math.max(40, 120 / aimSpeedMult),
              recoveryTimer: 0,
              fireballPhase: 'idle',
              isBoss: true
            };
            state.enemies.push(fattyEnemy);

            state.fattyArena = {
              arenaX,
              arenaEndX: arenaX + arenaW,
              arenaY,
              arenaEndY: arenaY + arenaH,
              bossId: fattyEnemy.id,
              triggered: false,
              gateUnlocked: false
            };

          } else {
            // --- STANDARD DUNGEON ROOM ---
            // Floor (Always mark isStartFloor: true so we don't render procedural floor stone plates and cliffs)
            state.platforms.push({
              x: rx, y: ry, width: roomW, height: roomH,
              color: '#1e293b', isDungeonFloor: true, isStartFloor: true
            });

            // Collision boxes from preset (strictly preserved, NEVER destroyed)
            if (Array.isArray(activeRoom.collisionBoxes)) {
              activeRoom.collisionBoxes.forEach((box: any) => {
                if (box.enabled === false) return;
                if (box.type === 'wall' || box.type === 'hazard') {
                  state.walls.push({
                    x: rx + box.x,
                    y: ry + box.y,
                    w: box.w,
                    h: box.h,
                    alive: true,
                    color: '#334155',
                    isDungeonWall: true,
                    indestructible: true,
                    isInvisible: true
                  });
                }
              });
            }

            // Baked room images (under hero and above hero)
            if ((activeRoom as CustomRoomData).bakedUnderHeroImage) {
              state.dungeonDecorations.push({
                id: 'baked_under_' + Math.random(),
                type: 'baked_image',
                src: (activeRoom as CustomRoomData).bakedUnderHeroImage,
                x: rx,
                y: ry,
                w: activeRoom.width || roomW,
                h: activeRoom.height || roomH,
                renderAboveHero: false,
                zIndex: 0
              });
            }
            if ((activeRoom as CustomRoomData).bakedAboveHeroImage) {
              state.dungeonDecorations.push({
                id: 'baked_above_' + Math.random(),
                type: 'baked_image',
                src: (activeRoom as CustomRoomData).bakedAboveHeroImage,
                x: rx,
                y: ry,
                w: activeRoom.width || roomW,
                h: activeRoom.height || roomH,
                renderAboveHero: true,
                zIndex: 9999
              });
            }

            // Visual elements from preset (strictly preserved, NEVER destroyed)
            if (Array.isArray(activeRoom.elements)) {
              activeRoom.elements.forEach((el: any) => {
                const isPropCrate = el.assetId === 'prop_crate';
                const isPropBarrel = el.assetId === 'prop_barrel';
                const isPropPot1 = el.assetId === 'prop_pot_1';
                const isPropPot2 = el.assetId === 'prop_pot_2';
                const isDestrProp = isPropCrate || isPropBarrel || isPropPot1 || isPropPot2;
                const propSubtype = isPropBarrel ? 'barrels' : (isPropCrate ? 'crate' : (isPropPot2 ? 'pot2' : (isPropPot1 ? 'pot' : undefined)));

                state.dungeonDecorations.push({
                  id: (isStart ? 'start_el_' : 'room_el_') + el.id + '_' + Date.now() + Math.random(),
                  type: 'custom_element',
                  x: rx + el.x,
                  y: ry + el.y,
                  w: el.w,
                  h: el.h,
                  src: el.src,
                  assetId: el.assetId,
                  name: el.name,
                  layer: el.layer,
                  zIndex: el.zIndex ?? 1,
                  opacity: el.opacity ?? 1,
                  flipX: el.flipX ?? false,
                  flipY: el.flipY ?? false,
                  rotation: el.rotation ?? 0,
                  hasLight: el.hasLight ?? false,
                  lightRadius: el.lightRadius ?? 80,
                  lightColor: el.lightColor ?? '#ff9d3b',
                  lightIntensity: el.lightIntensity ?? 1.0,
                  lightFlicker: el.lightFlicker ?? false,
                  hasFireEffect: el.hasFireEffect ?? false,
                  fireScale: el.fireScale ?? 1.0,
                  isShadowSource: el.isShadowSource ?? false,
                  shadowDensity: el.shadowDensity ?? 0.8,
                  shadowShape: el.shadowShape,
                  shadowCorners: el.shadowCorners,
                  shadowCornerRadius: el.shadowCornerRadius,
                  isDestructible: isDestrProp,
                  subtype: propSubtype,
                  alive: true,
                  opened: false,
                  renderAboveHero: el.renderAboveHero !== undefined ? el.renderAboveHero : ((el.zIndex ?? 0) > 100)
                });
              });
              state.dungeonDecorations.sort((a: any, b: any) => {
                const aAbove = Boolean(a.renderAboveHero ?? ((a.zIndex || 0) > 100));
                const bAbove = Boolean(b.renderAboveHero ?? ((b.zIndex || 0) > 100));
                if (aAbove !== bAbove) return aAbove ? 1 : -1;
                return (a.zIndex || 0) - (b.zIndex || 0);
              });
            }

            const roomFloorZones = getRoomFloorZones(activeRoom, rx, ry);

            if (isStart) {
              const spX = activeRoom.spawnPoint?.x ?? 430.8;
              const spY = activeRoom.spawnPoint?.y ?? 147.5;
              state.spawnPoint = { x: rx + spX, y: ry + spY };

              // In Level 1 starting room, spawn starter weapon chest strictly in Floor Zone and away from obstacles
              const isFirstLevelStart = (state.level || 1) === 1;
              if (isFirstLevelStart || Math.random() < 0.45) {
                const startChestPos = findSafeFloorZonePosition(
                  roomFloorZones,
                  52,
                  38,
                  28,
                  { x: state.spawnPoint.x, y: state.spawnPoint.y, dist: 130 }
                );
                if (startChestPos) {
                  state.chests.push({
                    id: isFirstLevelStart ? ('first_start_chest_' + Date.now() + Math.random()) : ('start_chest_' + Date.now() + Math.random()),
                    x: startChestPos.x,
                    y: startChestPos.y,
                    w: 52,
                    h: 38,
                    opened: false,
                    type: 'wooden',
                    isFirstLevelStartWeapon: isFirstLevelStart
                  });
                }
              }
            } else {
              // Standard Gameplay Entities: Enemies, Chests, Spike Traps (strictly in Floor Zone, never on obstacles)
              
              // 1. Spawn Regular Chest
              if (Math.random() < 0.55 && roomFloorZones.length > 0) {
                const chestPos = findSafeFloorZonePosition(roomFloorZones, 52, 38, 26);
                if (chestPos) {
                  state.chests.push({
                    id: 'chest_' + Date.now() + Math.random(),
                    x: chestPos.x,
                    y: chestPos.y,
                    w: 52,
                    h: 38,
                    opened: false,
                    type: Math.random() > 0.45 ? 'gold' : 'wooden'
                  });
                }
              }

              // 2. Spawn Spike Traps safely on floor zones (64x64 matching floor tiles, snapped strictly to single tiles)
              if (roomFloorZones.length > 0) {
                const targetTraps = Math.random() < 0.65 ? 1 : (Math.random() < 0.35 ? 2 : 0);
                for (let t = 0; t < targetTraps; t++) {
                  let trapPos: { x: number; y: number } | null = null;
                  for (let attempt = 0; attempt < 50; attempt++) {
                    const totalArea = roomFloorZones.reduce((acc, z) => acc + Math.max(1, z.w * z.h), 0);
                    let randWeight = Math.random() * totalArea;
                    let selZone = roomFloorZones[0];
                    for (const z of roomFloorZones) {
                      randWeight -= z.w * z.h;
                      if (randWeight <= 0) {
                        selZone = z;
                        break;
                      }
                    }
                    const minCol = Math.ceil(selZone.x / 64);
                    const maxCol = Math.floor((selZone.x + selZone.w) / 64) - 1;
                    const minRow = Math.ceil(selZone.y / 64);
                    const maxRow = Math.floor((selZone.y + selZone.h) / 64) - 1;

                    if (minCol > maxCol || minRow > maxRow) continue;

                    const col = minCol + Math.floor(Math.random() * (maxCol - minCol + 1));
                    const row = minRow + Math.floor(Math.random() * (maxRow - minRow + 1));

                    const testX = col * 64;
                    const testY = row * 64;

                    let collides = false;
                    for (const w of state.walls) {
                      if (!w.alive) continue;
                      if (testX + 64 > w.x && testX < w.x + w.w && testY + 64 > w.y && testY < w.y + w.h) {
                        collides = true;
                        break;
                      }
                    }
                    if (collides) continue;

                    if (state.obstacleColliders) {
                      for (const obs of state.obstacleColliders) {
                        if (testX + 64 > obs.x && testX < obs.x + obs.w && testY + 64 > obs.y && testY < obs.y + obs.h) {
                          collides = true;
                          break;
                        }
                      }
                    }
                    if (collides) continue;

                    for (const ch of state.chests) {
                      if (testX + 64 > ch.x && testX < ch.x + ch.w && testY + 64 > ch.y && testY < ch.y + ch.h) {
                        collides = true;
                        break;
                      }
                    }
                    if (collides) continue;

                    for (const tr of state.spikeTraps) {
                      if (testX === tr.x && testY === tr.y) {
                        collides = true;
                        break;
                      }
                    }
                    if (collides) continue;

                    trapPos = { x: testX, y: testY };
                    break;
                  }

                  if (trapPos) {
                    state.spikeTraps.push({
                      id: 'spike_trap_' + Date.now() + Math.random(),
                      x: trapPos.x,
                      y: trapPos.y,
                      w: 64,
                      h: 64,
                      state: 'hidden',
                      timer: 0,
                      shakeTimer: 0
                    });
                  }
                }
              }

              // 2.5 Spawn Destructible Props (Barrels, Crates, Pots/Urns) strictly in Floor Zone, never on obstacles
              if (roomFloorZones.length > 0) {
                const propTypes: ('crate' | 'pot' | 'pot2' | 'barrels')[] = ['crate', 'pot', 'pot2', 'barrels'];
                const numProps = 2 + Math.floor(Math.random() * 3);
                for (let pIdx = 0; pIdx < numProps; pIdx++) {
                  const pSub = propTypes[Math.floor(Math.random() * propTypes.length)];
                  const pPos = findSafeFloorZonePosition(roomFloorZones, 44, 44, 24);
                  if (pPos) {
                    state.dungeonDecorations.push({
                      id: 'prop_' + Date.now() + Math.random(),
                      type: 'prop_cluster',
                      subtype: pSub,
                      x: pPos.x,
                      y: pPos.y,
                      w: 44,
                      h: 44,
                      alive: true,
                      opened: false,
                      isDestructible: true
                    });
                  }
                }
              }

              // 3. Spawn Mobs across the FULL Floor Zone area (enemies utilize all floor zones in the room)
              const effMinX = roomFloorZones.length > 0 ? Math.min(...roomFloorZones.map(z => z.x)) : rx;
              const effMaxX = roomFloorZones.length > 0 ? Math.max(...roomFloorZones.map(z => z.x + z.w)) : (rx + roomW);
              const effMinY = roomFloorZones.length > 0 ? Math.min(...roomFloorZones.map(z => z.y)) : ry;
              const effMaxY = roomFloorZones.length > 0 ? Math.max(...roomFloorZones.map(z => z.y + z.h)) : (ry + roomH);

              const mobP = { x: effMinX, y: effMinY, width: effMaxX - effMinX, height: effMaxY - effMinY };
              const mobBounds = { minX: effMinX, maxX: effMaxX, minY: effMinY, maxY: effMaxY };
              const eyeBounds = { topY: effMinY, bottomY: effMaxY, minX: effMinX, maxX: effMaxX };
              const isLarge = ((effMaxX - effMinX) * (effMaxY - effMinY)) > 420000;

              const mobPool: ('saw' | 'knight' | 'ice' | 'sorcerer' | 'eye' | 'phantom' | 'drone')[] = ['saw', 'knight', 'ice', 'sorcerer', 'eye', 'phantom', 'drone'];
              const shuffledTypes = [...mobPool].sort(() => Math.random() - 0.5);
              const roomTypeCount = Math.random() < 0.25 ? 1 : 2;
              const selectedTypes = shuffledTypes.slice(0, roomTypeCount);

              const totalMobsInRoom = isLarge ? (3 + Math.floor(Math.random() * 3)) : (2 + Math.floor(Math.random() * 2));

              let eyeCountInRoom = 0;
              for (let m = 0; m < totalMobsInRoom; m++) {
                let mobType = selectedTypes[m % selectedTypes.length];
                if (mobType === 'eye') {
                  if (eyeCountInRoom >= 1) {
                    const fallbackTypes = selectedTypes.filter(t => t !== 'eye');
                    if (fallbackTypes.length > 0) {
                      mobType = fallbackTypes[Math.floor(Math.random() * fallbackTypes.length)];
                    } else {
                      mobType = 'phantom';
                    }
                  } else {
                    eyeCountInRoom++;
                  }
                }

                // Distribute mob spawns across all floor zones in the room
                const targetZone = roomFloorZones.length > 0 ? roomFloorZones[m % roomFloorZones.length] : null;
                const mobSpawnPos = targetZone ? (findSafeFloorZonePosition([targetZone], 40, 40, 24) || findSafeFloorZonePosition(roomFloorZones, 40, 40, 24)) : null;

                if (mobType === 'saw') spawnSawEnemy(mobP, mobBounds, undefined, mobSpawnPos || undefined);
                else if (mobType === 'knight') spawnKnight(mobP, mobBounds, mobSpawnPos || undefined);
                else if (mobType === 'ice') spawnIceEnemy(mobP, mobBounds, mobSpawnPos || undefined);
                else if (mobType === 'sorcerer') spawnSorcerer(mobP, mobBounds, undefined, mobSpawnPos || undefined);
                else if (mobType === 'eye') spawnFlyingEye(mobP, eyeBounds, mobSpawnPos || undefined);
                else if (mobType === 'phantom') spawnPhantomEnemy(mobP, eyeBounds, undefined, mobSpawnPos || undefined);
                else if (mobType === 'drone') {
                  const droneBounds = { minX: eyeBounds.minX, maxX: eyeBounds.maxX, minY: eyeBounds.topY, maxY: eyeBounds.bottomY };
                  spawnLaserDrone(mobP, droneBounds, true, mobSpawnPos || undefined);
                }
              }
            }
          }

          // Corridors and bridges are fully removed since rooms touch and connect directly without gaps
        }
      }

      // Purge all decorations from the Fatty boss gate, approach passage, and entrance walls
      if (state.fattyArena && state.dungeonDecorations) {
        const fa = state.fattyArena;
        const gateWalls = state.walls.filter(w => w.isBossGate);

        state.dungeonDecorations = state.dungeonDecorations.filter((dec: any) => {
          // A. No torches, banners, or flags in the entire Fatty boss room
          if (dec.type === 'torch' || dec.type === 'banner' || dec.type === 'tall_torch') {
            const endX = fa.arenaEndX || (fa.arenaX + 1100);
            const endY = fa.arenaEndY || (fa.arenaY + 900);
            if (dec.x >= fa.arenaX - 40 && dec.x <= endX + 40 &&
                dec.y >= fa.arenaY - 40 && dec.y <= endY + 40) {
              return false;
            }
          }

          // B. No decorations of ANY kind on or within 220px of any boss gate
          for (const gw of gateWalls) {
            const gcx = gw.x + gw.w / 2;
            const gcy = gw.y + gw.h / 2;
            if (Math.hypot(dec.x - gcx, dec.y - gcy) < 220) {
              return false;
            }
          }

          // C. No decorations inside the connecting corridor / passageway leading to the boss gate
          for (const p of state.platforms) {
            if (p.isDungeonFloor && !p.isFattyArena) {
              for (const gw of gateWalls) {
                const touchesGate = (
                  p.x <= gw.x + gw.w + 16 && p.x + p.width >= gw.x - 16 &&
                  p.y <= gw.y + gw.h + 16 && p.y + p.height >= gw.y - 16
                );
                if (touchesGate) {
                  // Decoration is along this entrance corridor passage
                  if (dec.x >= p.x - 20 && dec.x <= p.x + p.width + 20 &&
                      dec.y >= p.y - 20 && dec.y <= p.y + p.height + 20) {
                    return false;
                  }
                }
              }
            }
          }

          return true;
        });
      }

      rebuildObstacleColliders();
    };

    const rebuildObstacleColliders = () => {
      const colliders: { x: number; y: number; w: number; h: number }[] = [];
      if (state.chests) {
        state.chests.forEach(c => {
          if (!c.opened) {
            colliders.push({ x: c.x + 2, y: c.y + 16, w: Math.max(20, c.w - 4), h: Math.max(14, c.h - 16) });
          }
        });
      }
      if (state.dungeonDecorations) {
        state.dungeonDecorations.forEach((dec: any) => {
          if (dec.type === 'prop_cluster') {
            if (dec.isDestructible && !dec.alive) return;
            const px = dec.x;
            const py = dec.y;
            if (dec.subtype === 'barrels') {
              colliders.push({ x: px + 12 - 16, y: py + 10, w: 32, h: 16 });
            } else if (dec.subtype === 'pot' || dec.subtype === 'pot2') {
              const isPot2 = dec.subtype === 'pot2';
              if (isPot2) {
                colliders.push({ x: px + 22 - 18, y: py + 2, w: 36, h: 16 });
              } else {
                colliders.push({ x: px + 22 - 13, y: py + 2, w: 26, h: 15 });
              }
            } else if (dec.subtype === 'crate') {
              colliders.push({ x: px + 20 - 18, y: py + 10, w: 36, h: 16 });
            } else if (dec.subtype === 'rocks') {
              colliders.push({ x: px + 4, y: py + 8, w: 46, h: 18 });
            }
          } else if (dec.type === 'tall_torch') {
            colliders.push({ x: dec.x - 11, y: dec.y + 13, w: 22, h: 14 });
          } else if (dec.type === 'stone_brazier') {
            colliders.push({ x: dec.x - 14, y: dec.y + 8, w: 28, h: 12 });
          } else if (dec.type === 'altar') {
            colliders.push({ x: dec.x - 36, y: dec.y - 21, w: 72, h: 52 });
          } else if (dec.type === 'custom_element' && dec.isDestructible) {
            if (!dec.alive || dec.opened) return;
            const isPot = dec.assetId === 'prop_pot_1' || dec.assetId === 'prop_pot_2' || dec.subtype === 'pot' || dec.subtype === 'pot2';
            const yOffset = isPot ? 2 : (dec.h ? dec.h * 0.4 : 14);
            const colH = isPot ? 26 : Math.max(14, (dec.h ? dec.h * 0.6 : 24));
            colliders.push({ x: dec.x + 4, y: dec.y + yOffset, w: Math.max(20, (dec.w || 40) - 8), h: colH });
          }
        });
      }
      state.obstacleColliders = colliders;
    };

    const enterPortalToNextLevel = () => {
      if (state.level >= 20) {
        onGameOver(true);
        return;
      }
      const nextLvl = (state.level || 1) + 1;
      state.level = nextLvl;
      soundManager.playLevelUp();

      const newTheme = getThemeForLevel(nextLvl);
      createBrickPattern(newTheme);

      // Generate completely fresh level (all old objects deleted)
      generateLabyrinthLevel(nextLvl);
      generateBackgroundProps();

      // Position player at new level start
      state.player.x = state.spawnPoint?.x ?? 200;
      state.player.y = state.spawnPoint?.y ?? 200;
      state.player.vx = 0;
      state.player.vy = 0;
      state.player.safeX = state.player.x;
      state.player.safeY = state.player.y;
      state.player.invincible = 90;
      state.player.lockControl = 0;
      state.player.alive = false;

      // FIRST: Immediately snap and center camera directly over the spawned player
      const curCanvas = canvasRef.current || canvas;
      const curW = curCanvas ? curCanvas.width : (typeof window !== 'undefined' ? window.innerWidth : 800);
      const curH = curCanvas ? curCanvas.height : (typeof window !== 'undefined' ? window.innerHeight : 600);
      const scale = getCameraScale();
      const viewW = curW / scale;
      const viewH = curH / scale;
      state.cameraX = (state.player.x + state.player.w / 2) - (viewW * 0.5);
      state.cameraY = (state.player.y + state.player.h / 2) - (viewH * 0.5);

      // THEN: Start materialization sequence and suspend controls
      state.isPortalTransitioning = false;
      state.portalTransitionTimer = 0;
      state.isMaterializing = true;
      state.materializeTimer = 0;
      state.hasPlayedSpawnSound = false;
      state.controlsEnabled = false;
      state.blackFadeAlpha = 1.0;

      state.levelText = { msg: `Уровень ${nextLvl}`, alpha: 3.5, active: true };
      soundManager.playDungeonMusic(nextLvl);
      initRope();
    };

    const clearCache = () => {
      state.swordTrail = [];
      state.keys = { left: false, right: false, up: false, down: false };
      state.touchIds = { move: null, sword: null };
    };

    // Reset Game Fresh
    const resetGame = () => {
      clearCache();
      const targetLvl = startLevel || targetBoss?.level || 1;
      state.level = targetLvl;
      state.distance = 0;
      state.maxCameraX = 0;
      state.cameraX = 0;
      state.cameraY = 0;
      state.currentBlockStartX = 0;
      state.jumpZoomOut = 0;
      state.lastGroundedY = 350;
      const theme1 = getThemeForLevel(targetLvl);
      createBrickPattern(theme1);

      generateLabyrinthLevel(targetLvl);
      generateBackgroundProps();

      state.player.x = state.spawnPoint?.x ?? 200;
      state.player.y = state.spawnPoint?.y ?? 200;
      state.player.vx = 0;
      state.player.vy = 0;
      state.player.hp = statsRef.current.maxHp;
      state.player.maxHp = statsRef.current.maxHp;
      state.player.invincible = 0;
      state.player.lockControl = 0;
      state.player.slowTimer = 0;
      state.swordLock = 0;
      state.player.alive = false;

      // Handle Tester Boss Teleportation mode (Fatty)
      if (targetBoss && state.fattyArena) {
        const arenaX = state.fattyArena.arenaX;
        const arenaY = state.fattyArena.arenaY;
        const arenaEndY = state.fattyArena.arenaEndY;
        const arenaCenterY = (arenaY + arenaEndY) / 2;

        // Position player safely inside the boss arena near the left gate
        state.player.x = arenaX + 140;
        state.player.y = arenaCenterY - state.player.h / 2;
        state.player.safeX = state.player.x;
        state.player.safeY = state.player.y;

        // Lock gates & trigger fight immediately
        state.fattyArena.triggered = true;
        state.levelText = { msg: "АРЕНА БОССА: ТОЛСТЯК!", alpha: 4.5, active: true };
      } else {
        state.levelText = { msg: `Уровень ${targetLvl}`, alpha: 3.5, active: true };
      }
      soundManager.playDungeonMusic(targetLvl);

      // FIRST: Snap camera directly over the spawned player
      const curCanvas = canvasRef.current || canvas;
      const curW = curCanvas ? curCanvas.width : (typeof window !== 'undefined' ? window.innerWidth : 800);
      const curH = curCanvas ? curCanvas.height : (typeof window !== 'undefined' ? window.innerHeight : 600);
      const scale = getCameraScale();
      const viewW = curW / scale;
      const viewH = curH / scale;
      state.cameraX = (state.player.x + state.player.w / 2) - (viewW * 0.5);
      state.cameraY = (state.player.y + state.player.h / 2) - (viewH * 0.5);

      // THEN: Begin materialization sequence
      state.isPortalTransitioning = false;
      state.portalTransitionTimer = 0;
      state.isMaterializing = true;
      state.materializeTimer = 0;
      state.hasPlayedSpawnSound = false;
      state.controlsEnabled = false;
      state.blackFadeAlpha = 1.0;

      initRope();
    };

    // Resize Handler
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      if (state.platforms.length === 0) {
        state.platforms = [{ x: 0, y: 100, width: 600, height: 700, isDungeonFloor: true }];
      }
    };

    createBrickPattern();
    handleResize();
    resetGame();

    window.addEventListener('resize', handleResize);

    // Controls setup: 4-directional WASD + Arrow Keys
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') state.keys.left = true;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') state.keys.right = true;
      if (e.code === 'KeyS' || e.code === 'ArrowDown') state.keys.down = true;
      if (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') state.keys.up = true;
      if (e.code === 'KeyI') onOpenInventory('inventory');

      // Skills Hotkeys
      if (e.code === 'KeyQ') onSkillUsed('whirlwind');
      if (e.code === 'KeyE') onSkillUsed('flame_wave');
      if (e.code === 'KeyR') onSkillUsed('aegis_shield');
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') state.keys.left = false;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') state.keys.right = false;
      if (e.code === 'KeyS' || e.code === 'ArrowDown') state.keys.down = false;
      if (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') state.keys.up = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (state.touchIds.sword !== null || state.touchIds.move !== null) return;
      const scale = getCameraScale();
      const mouseX = (e.clientX / scale) + state.cameraX;
      const mouseY = (e.clientY / scale) + state.cameraY;
      state.smoothTargetX = mouseX;
      state.smoothTargetY = mouseY;
      state.isSwordMoving = true;
    };

    // Unified loot collection handler
    const collectLootDrop = (l: LootDrop): boolean => {
      if (!l.alive) return false;

      // If inventory is full, do not pick up anything other than HP hearts
      if (l.type !== 'hp' && isInventoryFullRef.current) {
        if (state.invFullWarningTimer <= 0) {
          state.damageTexts.push({
            id: 'inv_full_' + Date.now(),
            text: 'Инвентарь полон!',
            x: l.x,
            y: l.y - 15,
            vx: 0,
            vy: -4,
            life: 1.6,
            isCrit: true,
            color: '#f87171'
          });
          state.invFullWarningTimer = 1.2;
          soundManager.playError();
        }
        return false;
      }

      l.alive = false;
      soundManager.playLoot();

      if (l.type === 'hp') {
        const curMax = statsRef.current.maxHp;
        const healAmount = Math.max(1, Math.round(curMax * 0.20));
        state.player.hp = Math.min(curMax, state.player.hp + healAmount);
        onUpdateStats(prev => {
          const h = Math.max(1, Math.round(prev.maxHp * 0.20));
          return { ...prev, hp: Math.min(prev.maxHp, prev.hp + h) };
        });

        state.damageTexts.push({
          id: 'heal_' + Date.now() + Math.random(),
          text: `+${healAmount} ХП`,
          x: l.x, y: l.y - 10,
          vx: 0, vy: -6,
          life: 1.5,
          isCrit: true,
          color: '#f43f5e'
        });
      } else {
        onAddLootRef.current(l);
        let dropName = 'Предмет';
        let dropColor = '#38bdf8';
        if (l.type === 'ingredient' && l.ingredientType) {
          const ing = INGREDIENTS[l.ingredientType];
          dropName = `+${l.amount || 1} ${ing ? ing.name : 'Ресурс'}`;
          dropColor = ing ? ing.color : '#38bdf8';
        } else if (l.type === 'equipment' && l.itemData) {
          dropName = `+ ${l.itemData.name}`;
          dropColor = l.itemData.rarity === 'epic' ? '#c084fc' : l.itemData.rarity === 'rare' ? '#38bdf8' : l.itemData.rarity === 'magic' ? '#4ade80' : '#cbd5e1';
        }

        state.damageTexts.push({
          id: 'pickup_' + Date.now() + Math.random(),
          text: dropName,
          x: l.x, y: l.y - 15,
          vx: 0, vy: -4.5,
          life: 1.8,
          isCrit: true,
          color: dropColor
        });
      }

      for (let j = 0; j < 6; j++) {
        state.particles.push({
          x: l.x, y: l.y,
          vx: (Math.random() - 0.5) * 8, vy: (Math.random() - 0.5) * 8,
          life: 0.6, maxLife: 0.6, color: l.type === 'hp' ? '#f43f5e' : '#38bdf8', size: 3.8
        });
      }
      return true;
    };

    // Manual click/tap loot collection handler
    const tryCollectLootAtScreenCoords = (clientX: number, clientY: number): boolean => {
      const cvs = canvasRef.current;
      if (!cvs) return false;
      const rect = cvs.getBoundingClientRect();
      const canvasX = (clientX - rect.left) * (cvs.width / rect.width);
      const canvasY = (clientY - rect.top) * (cvs.height / rect.height);
      const scale = getCameraScale();
      const worldX = (canvasX / scale) + state.cameraX;
      const worldY = (canvasY / scale) + state.cameraY;

      // Check each loot drop with a generous 55px hit radius
      for (const l of state.lootDrops) {
        if (!l.alive) continue;
        const dist = Math.hypot(worldX - l.x, worldY - l.y);
        if (dist < 55) {
          return collectLootDrop(l);
        }
      }
      return false;
    };

    collectLootRef.current = tryCollectLootAtScreenCoords;

    const handleMouseDown = (e: MouseEvent) => {
      tryCollectLootAtScreenCoords(e.clientX, e.clientY);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);

    // Helper to calculate exact enemy damage with +20% scaling per level
    const getEnemyDamage = (type: 'spike' | 'knight_sword' | 'knight_body' | 'eye_laser' | 'eye_body' | 'drone_laser' | 'drone_body' | 'ice_projectile' | 'ice_body' | 'fatty_punch' | 'fatty_fireball' | 'fatty_body' | 'phantom_body' | 'sorcerer_magic' | 'sorcerer_body' | 'saw_explosion' | 'sorcerer_nova' | 'saw_body') => {
      const baseDamages: Record<string, number> = {
        spike: 3,
        knight_sword: 5,
        knight_body: 2,
        eye_laser: 7,
        eye_body: 2,
        drone_laser: 7,
        drone_body: 2,
        ice_projectile: 5,
        ice_body: 2,
        fatty_punch: 11,
        fatty_fireball: 8,
        fatty_body: 3,
        phantom_body: 3,
        sorcerer_magic: 6,
        sorcerer_body: 2,
        saw_explosion: 10,
        sorcerer_nova: 8,
        saw_body: 2
      };
      const lvl = Math.max(1, state.level || statsRef.current.level || 1);
      const scaling = 1.0 + (lvl - 1) * 1.176;
      const base = baseDamages[type] ?? 2;
      return Math.max(1, Math.round(base * scaling));
    };

    // Helper for vampirism healing (always heals at least 1 HP if vRate > 0) and dynamic 0.15s wavy red siphon beam
    const applyVampirismHealing = (dealtDmg: number, target?: { x: number; y: number } | any) => {
      const vRate = statsRef.current.vampirism || 0;
      if (vRate > 0 && dealtDmg > 0) {
        const rawStolen = dealtDmg * (vRate / 100);
        // Always heals at least 1 HP even if dealt damage is small
        const stolen = Math.max(1, Math.round(rawStolen * 10) / 10);
        if (stolen > 0) {
          const maxH = statsRef.current.maxHp || state.player.maxHp;
          state.player.hp = Math.min(maxH, Math.round((state.player.hp + stolen) * 10) / 10);
          statsRef.current.hp = state.player.hp;
          (state as any).needsHpSync = true;
        }

        // Add 0.15s wavy red beam anchored to centers of player and damaged target
        if (target) {
          state.vampirismBeams.push({
            id: 'vamp_beam_' + Date.now() + Math.random(),
            target,
            targetX: target.x ?? (state.player.x + 40),
            targetY: target.y ?? (state.player.y),
            timer: 0.15,
            maxTimer: 0.15
          });
        }
      }
    };

    // Helper to calculate exact raycast hit distance against walls, spiked pillars and solid obstacles (AABB culled for 60fps)
    const getLaserHitDistance = (ox: number, oy: number, dx: number, dy: number, maxDist: number): number => {
      let closestDist = maxDist;
      const len = Math.hypot(dx, dy);
      if (len === 0) return maxDist;
      const ndx = dx / len;
      const ndy = dy / len;

      for (let i = 0; i < state.walls.length; i++) {
        const w = state.walls[i];
        if (!w.alive) continue;
        if (w.isBossGate && !w.isClosed) continue;
        if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) continue; // retracted walls are below platform floor

        // Fast AABB bounding box culling: skip walls outside maximum search distance
        if (Math.abs(w.x + w.w * 0.5 - ox) > maxDist + w.w * 0.5 || Math.abs(w.y + w.h * 0.5 - oy) > maxDist + w.h * 0.5) {
          continue;
        }

        const minX = w.x;
        const maxX = w.x + w.w;
        const minY = w.y;
        const maxY = w.y + w.h;

        let tmin = 0;
        let tmax = closestDist;

        if (Math.abs(ndx) < 1e-6) {
          if (ox < minX || ox > maxX) continue;
        } else {
          const invD = 1.0 / ndx;
          let t1 = (minX - ox) * invD;
          let t2 = (maxX - ox) * invD;
          if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
          tmin = Math.max(tmin, t1);
          tmax = Math.min(tmax, t2);
          if (tmin > tmax) continue;
        }

        if (Math.abs(ndy) < 1e-6) {
          if (oy < minY || oy > maxY) continue;
        } else {
          const invD = 1.0 / ndy;
          let t1 = (minY - oy) * invD;
          let t2 = (maxY - oy) * invD;
          if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
          tmin = Math.max(tmin, t1);
          tmax = Math.min(tmax, t2);
          if (tmin > tmax) continue;
        }

        const hitT = tmin >= 0 ? tmin : (tmax >= 0 ? 0 : closestDist);
        if (hitT >= 0 && hitT < closestDist) {
          closestDist = hitT;
        }
      }

      // Check collision with altars in laser raycast
      if (state.dungeonDecorations) {
        for (let d = 0; d < state.dungeonDecorations.length; d++) {
          const dec = state.dungeonDecorations[d];
          if (dec.type === 'altar') {
            const minX = dec.x - 36;
            const maxX = dec.x + 36;
            const minY = dec.y - 21;
            const maxY = dec.y + 31;

            let tmin = 0;
            let tmax = closestDist;

            if (Math.abs(ndx) < 1e-6) {
              if (ox < minX || ox > maxX) continue;
            } else {
              const invD = 1.0 / ndx;
              let t1 = (minX - ox) * invD;
              let t2 = (maxX - ox) * invD;
              if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
              tmin = Math.max(tmin, t1);
              tmax = Math.min(tmax, t2);
              if (tmin > tmax) continue;
            }

            if (Math.abs(ndy) < 1e-6) {
              if (oy < minY || oy > maxY) continue;
            } else {
              const invD = 1.0 / ndy;
              let t1 = (minY - oy) * invD;
              let t2 = (maxY - oy) * invD;
              if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
              tmin = Math.max(tmin, t1);
              tmax = Math.min(tmax, t2);
              if (tmin > tmax) continue;
            }

            const hitT = tmin >= 0 ? tmin : (tmax >= 0 ? 0 : closestDist);
            if (hitT >= 0 && hitT < closestDist) {
              closestDist = hitT;
            }
          }
        }
      }

      return closestDist;
    };

    // Helper to get total player crit chance and crit damage multiplier
    const getPlayerCritStats = () => {
      const w = weaponRef.current || ({} as any);
      const s = statsRef.current;
      const totalCrit = (w.critChance || 0) + (s?.critChanceBonus || 0);
      const totalAgi = s?.effectiveAgi ?? s?.agility ?? 0;
      const baseWepCritMult = w.critMultiplier || 1.25;
      const critMult = baseWepCritMult + totalAgi * 0.0017;
      return { critChance: totalCrit, critMultiplier: critMult };
    };

    // Helper to calculate player sword damage against enemies based on strength, bonus gear damage, agility, and equipped weapon
    const calculatePlayerHitDamage = () => {
      const w = weaponRef.current;
      const s = statsRef.current;
      const minDmg = s.minDamage ?? (3 + w.minDamage + s.strength * 2.5);
      const maxDmg = s.maxDamage ?? (3 + w.maxDamage + s.strength * 2.5);
      let baseDmg = Math.round(minDmg + Math.random() * (maxDmg - minDmg));
      baseDmg = Math.max(1, baseDmg);

      const { critChance, critMultiplier } = getPlayerCritStats();
      const isCrit = Math.random() < critChance;
      let dmg = baseDmg;
      if (isCrit) {
        dmg = Math.round(baseDmg * critMultiplier);
      }
      return { dmg: Math.max(1, dmg), baseDmg, isCrit };
    };

    const isPlayerOnEnemyPlatform = (en: any) => {
      if (en.type === 'fatty') {
        if (state.fattyArena) {
          return Boolean(state.fattyArena.triggered);
        }
        if (en.parent) {
          const pX = state.player.x + state.player.w / 2;
          const pY = state.player.y + state.player.h / 2;
          return pX >= en.parent.x + 30 && pX <= en.parent.x + en.parent.width - 30 &&
                 pY >= en.parent.y + 30 && pY <= en.parent.y + en.parent.height - 30;
        }
        return false;
      }
      const dist = Math.hypot((state.player.x + state.player.w / 2) - en.x, (state.player.y + state.player.h / 2) - en.y);
      return dist < 650;
    };

    const calcLevelUpStats = (prev: CharacterStats, xpGained: number) => {
      let newXp = prev.xp + xpGained;
      let level = prev.level;
      let maxXp = prev.maxXp;
      let statPoints = prev.statPoints;
      let str = prev.strength;
      let agi = prev.agility;
      let end = prev.endurance;
      let intel = prev.intelligence;
      let levelsGained = 0;

      while (newXp >= maxXp) {
        newXp -= maxXp;
        level += 1;
        maxXp = getMaxXpForLevel(level);
        statPoints += 5; // +5 bonus points on level up
        str += 1;   // +1 to all 4 stats automatically on level up
        agi += 1;
        end += 1;
        intel += 1;
        levelsGained += 1;
        triggerLevelUp(level);
      }

      if (levelsGained === 0) {
        return {
          ...prev,
          xp: newXp
        };
      }

      // Preserve all equipment HP/Mana bonuses while adding level stat gains
      const addedMaxHp = levelsGained * 8;
      const addedMaxMana = levelsGained * 3.0;
      const newMaxHp = prev.maxHp + addedMaxHp;
      const newMaxMana = prev.maxMana + addedMaxMana;
      const newHp = Math.min(newMaxHp, prev.hp + addedMaxHp);
      const newMana = Math.min(newMaxMana, prev.mana + addedMaxMana);

      // Keep internal canvas player HP in sync instantly
      state.player.maxHp = newMaxHp;
      state.player.hp = newHp;

      return {
        ...prev,
        xp: newXp,
        level,
        maxXp,
        statPoints,
        strength: str,
        agility: agi,
        endurance: end,
        intelligence: intel,
        maxHp: newMaxHp,
        hp: newHp,
        maxMana: newMaxMana,
        mana: newMana
      };
    };

    // Helper to trigger triumphant level up visuals, yellow light beam, and audio fanfare
    const triggerLevelUp = (newLevel: number) => {
      soundManager.playLevelUp();
      const playerCenterX = state.player.x + state.player.w / 2;
      const playerBottomY = state.player.y + state.player.h;

      // Add yellow pillar of light extending upwards from player
      state.levelUpBeams.push({
        x: playerCenterX,
        y: playerBottomY,
        timer: 85,
        maxTimer: 85
      });

      state.damageTexts.push({
        id: 'lvlup_' + Date.now() + Math.random(),
        text: `LVL UP! ${newLevel} (+2 Очка)`,
        x: playerCenterX,
        y: state.player.y - 45,
        vx: 0,
        vy: -4,
        life: 2.2,
        isCrit: true,
        color: '#facc15'
      });

      // Upward surging gold spark particles
      for (let p = 0; p < 15; p++) {
        state.particles.push({
          x: playerCenterX + (Math.random() - 0.5) * 36,
          y: playerBottomY - Math.random() * 20,
          vx: (Math.random() - 0.5) * 5,
          vy: -7 - Math.random() * 8,
          life: 1.2,
          maxLife: 1.2,
          color: Math.random() > 0.4 ? '#fef08a' : '#facc15',
          size: 3 + Math.random() * 3
        });
      }
    };

    // Unified Mob & Prop Loot Generator with User-Specified Drop Probabilities:
    // Mobs: Epic: (2% / 3), Rare: (5% / 3), Magic/Green: (10% / 3), Common: (15% / 3) + Resources: (65% / 3)
    // Props (Barrels, Crates, Pots): Resources drop at SAME chance as mobs, Equipment items drop at HALF chance (0.5x)
    const dropMobLoot = (x: number, y: number, mobType?: string) => {
      const dungeonLvl = Math.max(1, state.level || 1);
      const isProp = Boolean(mobType && typeof mobType === 'string' && mobType.startsWith('prop_'));

      // 1. Equipment Item Roll (all chances reduced 3x per user directive; props have half chance 0.5x)
      const equipMult = isProp ? 0.5 : 1.0;
      const roll = Math.random();
      let droppedRarity: ItemRarity | null = null;
      const epicChance = (0.02 / 3) * equipMult;
      const rareChance = (0.05 / 3) * equipMult;
      const magicChance = (0.10 / 3) * equipMult;
      const commonChance = (0.15 / 3) * equipMult;
      if (roll < epicChance) {
        droppedRarity = 'epic';
      } else if (roll < epicChance + rareChance) {
        droppedRarity = 'rare';
      } else if (roll < epicChance + rareChance + magicChance) {
        droppedRarity = 'magic';
      } else if (roll < epicChance + rareChance + magicChance + commonChance) {
        droppedRarity = 'common';
      }

      if (droppedRarity) {
        const equipItem = generateEquipmentDrop(droppedRarity, dungeonLvl);
        const drop: LootDrop = {
          id: 'loot_eq_' + Date.now() + Math.random(),
          x,
          y: y - 8,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          type: 'equipment',
          itemData: equipItem,
          rarity: droppedRarity,
          alive: true,
          pickupDelay: 0.65
        };
        state.lootDrops.push(drop);
      }

      // 2. Resource Drop (with chances increased per user directive: Tier 1 +100%, Tier 2 +80%, Tier 3 +60%, Tier 4 +40%)
      // Props have the exact SAME resource drop chance as mobs (1.0x)
      const baseResChance = 0.65 / 3;
      
      // Determine base probabilities for this mob or prop type
      let pTier1 = 0; // iron_ore
      let pTier2 = 0; // magic_crystal
      let pTier3 = 0; // monster_core
      let pTier4 = 0; // ancient_rune

      if (mobType === 'ice') {
        pTier2 = baseResChance * 0.6;
        pTier1 = baseResChance * 0.4;
      } else if (mobType === 'phantom') {
        pTier4 = baseResChance * 0.5;
        pTier2 = baseResChance * 0.5;
      } else if (mobType === 'knight' || mobType === 'fatty') {
        pTier3 = baseResChance * 0.4;
        pTier2 = baseResChance * 0.35;
        pTier1 = baseResChance * 0.25;
      } else if (mobType === 'flying_eye') {
        pTier3 = baseResChance * 0.5;
        pTier2 = baseResChance * 0.5;
      } else if (isProp) {
        // Props drop resources with the same total chance as standard mobs
        pTier1 = baseResChance * 0.60;
        pTier2 = baseResChance * 0.28;
        pTier3 = baseResChance * 0.09;
        pTier4 = baseResChance * 0.03;
      } else {
        pTier2 = baseResChance * 0.3;
        pTier1 = baseResChance * 0.7;
      }

      // Apply the user-specified multipliers from their current drop chances:
      // Tier 1 (iron_ore): +100% -> x2.0
      // Tier 2 (magic_crystal): +80% -> x1.8
      // Tier 3 (monster_core): +60% -> x1.6
      // Tier 4 (ancient_rune): +40% -> x1.4
      pTier1 *= 2.0;
      pTier2 *= 1.8;
      pTier3 *= 1.6;
      pTier4 *= 1.4;

      // Roll from the combined sum of these probabilities
      const totalResChance = pTier1 + pTier2 + pTier3 + pTier4;
      const resRoll = Math.random();

      if (resRoll < totalResChance) {
        // Pick the resource type based on normalized relative weights
        let resType: IngredientType = 'iron_ore';
        const r = Math.random() * totalResChance;
        if (r < pTier1) {
          resType = 'iron_ore';
        } else if (r < pTier1 + pTier2) {
          resType = 'magic_crystal';
        } else if (r < pTier1 + pTier2 + pTier3) {
          resType = 'monster_core';
        } else {
          resType = 'ancient_rune';
        }

        const drop: LootDrop = {
          id: 'loot_res_' + Date.now() + Math.random(),
          x,
          y,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          type: 'ingredient',
          ingredientType: resType,
          amount: mobType === 'knight' || mobType === 'fatty' ? 2 : 1,
          alive: true,
          pickupDelay: 0.65
        };
        state.lootDrops.push(drop);
      }
    };

    // Unified death routine for standard enemies (state.enemies)
    const killEnemy = (en: any) => {
      if (!en.alive) return;

      // Special Death Mechanic for White Phantom Variant (Phase 1):
      // Smoothly fade out first before dying and splitting!
      if (en.type === 'phantom' && en.isWhitePhantom && !en.isSplitClone && !en.isDyingFadeOut) {
        en.isDyingFadeOut = true;
        en.fadeAlpha = 1.0;
        en.hp = 1;
        en.vx = 0;
        en.vy = 0;
        en.knockVx = 0;
        en.knockVy = 0;
        return;
      }

      // Special Death Mechanic for Red Saw Variant:
      // Does not die immediately; becomes invulnerable, roots in place, charges a pulsating plasma sphere like Fatty's laser phase, and then explodes!
      if (en.type === 'saw' && en.isRedSaw && !en.explosionFinished) {
        if (!en.isChargingExplosion) {
          en.isChargingExplosion = true;
          en.explosionTimer = 0;
          en.maxExplosionTimer = 90; // 1.5 seconds windup
          en.hp = 1;
          en.vx = 0;
          en.vy = 0;
          soundManager.playChargingLaser();
          return;
        }
      }

      en.alive = false;

      // Special Death Mechanic for White Phantom Variant:
      // Splits into 2 smaller white copies on death (one time only) with slow dispersal, fade-in and flickering
      if (en.type === 'phantom' && en.isWhitePhantom && !en.isSplitClone) {
        soundManager.playTeleport();
        const lvl = state.level || 1;
        const lvlHpMult = 1.0 + (lvl - 1) * 2.607;

        // Dramatic Spectral Split Shockwave & Burst Particles
        state.shockwaves.push({
          x: en.x,
          y: en.y,
          r: 12,
          maxR: 70,
          color: '#f0fdf4',
          life: 0.8,
          maxLife: 0.8
        });

        for (let p = 0; p < 8; p++) {
          const pAng = (p / 8) * Math.PI * 2 + Math.random() * 0.2;
          const pSpd = 3.5 + Math.random() * 4.5;
          state.particles.push({
            x: en.x,
            y: en.y,
            vx: Math.cos(pAng) * pSpd,
            vy: Math.sin(pAng) * pSpd,
            life: 0.6,
            maxLife: 0.6,
            color: p % 2 === 0 ? '#ffffff' : '#bae6fd',
            size: 3.5
          });
        }

        const minX = en.leftBound ?? (en.parent ? en.parent.x - 30 : en.x - 150);
        const maxX = en.rightBound ?? (en.parent ? en.parent.x + en.parent.width + 30 : en.x + 150);
        const topY = en.topBound ?? (en.parent ? en.parent.y - 250 : en.y - 120);
        const botY = en.bottomBound ?? (en.parent ? en.parent.y + 40 : en.y + 100);
        
        const clampedX = Math.max(minX + 20, Math.min(maxX - 20, en.x));
        const clampedY = Math.max(topY + 20, Math.min(botY - 20, en.y));

        for (let s = 0; s < 2; s++) {
          const spreadOffset = s === 0 ? -12 : 12;
          const driftVx = (s === 0 ? -0.85 : 0.85);
          const driftVy = (s === 0 ? -0.2 : 0.2) + (Math.random() - 0.5) * 0.3;
          state.enemies.push({
            id: 'phantom_mini_' + Date.now() + Math.random(),
            x: clampedX + spreadOffset,
            y: clampedY,
            vx: driftVx,
            vy: driftVy,
            targetVx: driftVx,
            targetVy: driftVy,
            r: 13,
            w: 26,
            h: 26,
            parent: en.parent,
            roomBounds: en.roomBounds,
            topBound: topY,
            bottomBound: botY,
            leftBound: minX,
            rightBound: maxX,
            alive: true,
            type: 'phantom',
            isWhitePhantom: true,
            isSplitClone: true,
            hoverAngle: Math.random() * Math.PI * 2,
            chargeTimer: 0,
            cooldownTimer: 60 + Math.random() * 30, // Ready to attack soon after full manifestation
            state: 'hover' as 'hover' | 'charge' | 'dash',
            dashVx: 0,
            dashVy: 0,
            dashTimer: 0,
            hp: Math.round(20 * diffRef.current.hpMultiplier * lvlHpMult),
            maxHp: Math.round(20 * diffRef.current.hpMultiplier * lvlHpMult),
            isStruck: false,
            hitCooldown: 0,
            
            // "а при раздвоении верни чтобы они пока мерцали разлетались медленно в разные стороны"
            fadeAlpha: 0.0,
            isFlickering: true,
            flickerTimer: 45,
            maxFlickerTimer: 45
          });
        }
      }

      // Update killed mobs count progression
      state.mobsKilled = (state.mobsKilled || 0) + 1;

      // XP calculation: base XP reduced 1.5x for all mobs (+20% per game level tier)
      const baseXpMap: Record<string, number> = {
        saw: 5,
        ice: 5,
        knight: 8,
        phantom: 7,
        fatty: 67
      };
      let baseXp = baseXpMap[en.type] ?? 8;
      if (en.isSplitClone) {
        baseXp = baseXp / 2; // "за уничтожение мелких копий дается ровно в 2 раза меньше опыта по сравнению с обычным призраком"
      }
      if (en.isPopped) {
        baseXp = baseXp * 0.25; // "опыт дающихся с призывных мобов сделай равным 25 процентов от обычного опыта за этих мобов"
      }
      const lvl = state.level || 1;
      const lvlXpMult = Math.pow(1.20, lvl - 1);
      const xpGained = Math.round(baseXp * diffRef.current.xpMultiplier * lvlXpMult);

      // Queue XP to prevent React re-render lag spikes
      state.pendingXp = (state.pendingXp || 0) + xpGained;

      // Floating XP text
      state.damageTexts.push({
        id: 'xp_' + Date.now() + Math.random(),
        text: `+${xpGained} XP`,
        x: en.x, y: en.y - 20,
        vx: (Math.random() - 0.5) * 3, vy: -7,
        life: 1.4,
        isCrit: true,
        color: '#fbbf24'
      });

      // After Fatty boss defeat: open all arena gates, spawn reward chest and start 10s portal countdown!
      if (en.type === 'fatty') {
        soundManager.playLoot();
        state.screenShake = 20;

        // Open/destroy boss gates
        state.walls.forEach(w => {
          if (w.isBossGate) {
            w.alive = false;
          }
        });

        // Spawn Boss Reward Chest (weapon or trinket: 30% epic, 70% rare, 100% magic)
        state.chests.push({
          id: 'boss_reward_chest_' + Date.now() + Math.random(),
          x: en.x - 70,
          y: en.y - 19,
          w: 52,
          h: 38,
          opened: false,
          type: 'gold',
          isBossChest: true
        });

        // Setup Portal in Fatty arena with 10-second countdown before activating
        state.portal = {
          x: en.x + 60,
          y: en.y,
          r: 46,
          active: false,
          angle: 0,
          countdownTimer: 10.0,
          maxCountdown: 10.0
        };

        // Notice text banner for boss chest and portal countdown
        state.damageTexts.push({
          id: 'boss_chest_spawn_' + Date.now(),
          text: '★ СУНДУК БОССА ПОЯВИЛСЯ! ПОРТАЛ ОТКРОЕТСЯ ЧЕРЕЗ 10 СЕК. ★',
          x: en.x,
          y: en.y - 45,
          vx: 0,
          vy: -3.5,
          life: 4.5,
          isCrit: true,
          color: '#38bdf8'
        });
      }

      // Impact screen shake & shockwave ring
      state.screenShake = en.type === 'fatty' ? 14 : en.type === 'knight' ? 8 : 6;
      const deathColor = en.type === 'ice' ? '#38bdf8' : en.type === 'knight' ? '#f43f5e' : en.type === 'phantom' ? '#8b5cf6' : '#a855f7';
      state.shockwaves.push({
        x: en.x, y: en.y - 10,
        r: 8, maxR: en.type === 'fatty' ? 80 : 55,
        color: deathColor,
        life: 1, maxLife: 1
      });

      // Drop mob loot (disabled for split clones: "и с них полностью отключен любой дроп предметов")
      if (!en.isSplitClone) {
        dropMobLoot(en.x, en.y, en.type);
      }

      // Rich Death Explosion Particles (sparks, embers, fragments)
      const count = en.type === 'fatty' ? 18 : 12;
      for (let j = 0; j < count; j++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = Math.random() * 18 + 4;
        state.particles.push({
          x: en.x + (Math.random() - 0.5) * 12,
          y: en.y - 10 + (Math.random() - 0.5) * 12,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd - 3,
          gravity: 0.25,
          life: Math.random() * 0.4 + 0.6,
          maxLife: 1,
          color: Math.random() < 0.3 ? '#ffffff' : Math.random() < 0.6 ? '#fbbf24' : deathColor,
          size: Math.random() * 4 + 2,
          shape: Math.random() < 0.4 ? 'spark' : 'circle'
        });
      }
    };

    // Unified death routine for Flying Eye enemies
    const killFlyingEye = (eye: FlyingEyeEnemy) => {
      if (!eye.alive) return;
      eye.alive = false;

      // Update mobs killed progression
      state.mobsKilled = (state.mobsKilled || 0) + 1;

      const lvl = state.level || 1;
      const lvlXpMult = Math.pow(1.20, lvl - 1);
      const xpGained = Math.round(5 * diffRef.current.xpMultiplier * lvlXpMult);

      // Queue XP to prevent React re-render lag spikes
      state.pendingXp = (state.pendingXp || 0) + xpGained;

      state.damageTexts.push({
        id: 'xp_' + Date.now() + Math.random(),
        text: `+${xpGained} XP`,
        x: eye.x, y: eye.y - 15,
        vx: (Math.random() - 0.5) * 3, vy: -6,
        life: 1.4,
        isCrit: true,
        color: '#34d399'
      });

      state.screenShake = 6;
      state.shockwaves.push({
        x: eye.x, y: eye.y,
        r: 6, maxR: 50,
        color: '#34d399',
        life: 1, maxLife: 1
      });

      // Drop mob loot with probability system
      dropMobLoot(eye.x, eye.y, 'flying_eye');

      for (let j = 0; j < 12; j++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = Math.random() * 16 + 3;
        state.particles.push({
          x: eye.x, y: eye.y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          gravity: 0.15,
          life: Math.random() * 0.4 + 0.6,
          maxLife: 1,
          color: Math.random() < 0.35 ? '#a7f3d0' : '#34d399',
          size: Math.random() * 4 + 2,
          shape: Math.random() < 0.5 ? 'spark' : 'circle'
        });
      }
    };

    // Unified death routine for Laser Drones
    const killDrone = (drone: any) => {
      if (!drone.alive) return;
      drone.alive = false;

      // Update mobs killed progression
      state.mobsKilled = (state.mobsKilled || 0) + 1;

      const lvl = state.level || 1;
      const lvlXpMult = Math.pow(1.20, lvl - 1);
      const xpGained = Math.round(7 * diffRef.current.xpMultiplier * lvlXpMult);

      // Queue XP to prevent React re-render lag spikes
      state.pendingXp = (state.pendingXp || 0) + xpGained;

      state.damageTexts.push({
        id: 'xp_' + Date.now() + Math.random(),
        text: `+${xpGained} XP`,
        x: drone.x, y: drone.y - 15,
        vx: (Math.random() - 0.5) * 3, vy: -6,
        life: 1.4,
        isCrit: true,
        color: '#38bdf8'
      });

      state.screenShake = 7;
      state.shockwaves.push({
        x: drone.x, y: drone.y,
        r: 6, maxR: 55,
        color: '#38bdf8',
        life: 1, maxLife: 1
      });

      // Drop mob loot with probability system
      dropMobLoot(drone.x, drone.y, 'drone');

      for (let j = 0; j < 15; j++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = Math.random() * 18 + 4;
        state.particles.push({
          x: drone.x, y: drone.y,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          gravity: 0.2,
          life: Math.random() * 0.4 + 0.6,
          maxLife: 1,
          color: Math.random() < 0.4 ? '#bae6fd' : Math.random() < 0.7 ? '#38bdf8' : '#f59e0b',
          size: Math.random() * 4.5 + 2,
          shape: Math.random() < 0.5 ? 'spark' : 'circle'
        });
      }
    };

    // Helper to fire a single chain lightning discharge
    const fireChainLightningDischarge = (initialTarget: any, playerHitDmg: number, chainDamageRatio: number) => {
      if (!initialTarget) return;

      // Electric sound effect & gentle screen shake for initial blast
      soundManager.playLightningZap();
      state.screenShake = Math.max(state.screenShake, 3);

      // 1. Identify the strict room of the initial target
      const getEntityRoom = (target: any): { minX: number; maxX: number; minY: number; maxY: number } | null => {
        if (!target) return null;

        // A. Explicit room bounds assigned on enemy/entity
        if (target.roomBounds) {
          const rb = target.roomBounds;
          const minX = rb.minX ?? rb.leftBound;
          const maxX = rb.maxX ?? rb.rightBound;
          const minY = rb.minY ?? rb.topBound ?? rb.topY;
          const maxY = rb.maxY ?? rb.bottomBound ?? rb.bottomY;
          if (minX !== undefined && maxX !== undefined && minY !== undefined && maxY !== undefined) {
            return { minX, maxX, minY, maxY };
          }
        }
        if (target.leftBound !== undefined && target.rightBound !== undefined &&
           (target.topBound !== undefined || target.topY !== undefined) &&
           (target.bottomBound !== undefined || target.bottomY !== undefined)) {
          return {
            minX: target.leftBound,
            maxX: target.rightBound,
            minY: target.topBound ?? target.topY,
            maxY: target.bottomBound ?? target.bottomY
          };
        }

        // B. Match target coordinate strictly inside registered dungeon rooms
        const tx = target.x;
        const ty = target.y;
        if (state.dungeonRooms && state.dungeonRooms.length > 0) {
          for (const room of state.dungeonRooms) {
            if (tx >= room.minX && tx <= room.maxX && ty >= room.minY && ty <= room.maxY) {
              return room;
            }
          }
        }

        // C. Match target coordinate inside boss arena
        if (state.fattyArena) {
          const fa = state.fattyArena;
          const endY = fa.arenaEndY ?? (fa.arenaY + (fa.arenaEndX - fa.arenaX));
          if (tx >= fa.arenaX && tx <= fa.arenaEndX && ty >= fa.arenaY && ty <= endY) {
            return { minX: fa.arenaX, maxX: fa.arenaEndX, minY: fa.arenaY, maxY: endY };
          }
        }

        // D. Match against non-corridor floor platforms
        for (const plat of state.platforms) {
          if (plat.isDungeonFloor && plat.width > 220 && plat.height > 220) {
            if (tx >= plat.x && tx <= plat.x + plat.width && ty >= plat.y && ty <= plat.y + plat.height) {
              return { minX: plat.x, maxX: plat.x + plat.width, minY: plat.y, maxY: plat.y + plat.height };
            }
          }
        }
        return null;
      };

      const targetRoom = getEntityRoom(initialTarget);

      // Helper to check if another candidate enemy is STRICTLY in the exact same room (no corridor/adjacent rooms)
      const isInSameRoom = (cand: any): boolean => {
        if (!cand || cand.alive === false || (cand.hp !== undefined && cand.hp <= 0)) return false;
        if (!targetRoom) {
          // Fallback if room could not be resolved: only allow closely adjacent enemies (< 250px)
          return Math.hypot(cand.x - initialTarget.x, cand.y - initialTarget.y) <= 250;
        }

        // Must be strictly within the exact room bounds
        const inBounds = cand.x >= targetRoom.minX && cand.x <= targetRoom.maxX &&
                         cand.y >= targetRoom.minY && cand.y <= targetRoom.maxY;
        if (!inBounds) return false;

        // If candidate also has its own roomBounds, ensure it matches this exact room
        if (cand.roomBounds) {
          const cMinX = cand.roomBounds.minX ?? cand.roomBounds.leftBound;
          const cMinY = cand.roomBounds.minY ?? cand.roomBounds.topBound ?? cand.roomBounds.topY;
          if (cMinX !== undefined && cMinY !== undefined) {
            if (Math.abs(cMinX - targetRoom.minX) > 80 || Math.abs(cMinY - targetRoom.minY) > 80) {
              return false;
            }
          }
        }

        return true;
      };

      // Gather all candidate enemies strictly located within this single room
      const roomCandidates: any[] = [];
      state.enemies.forEach(e => {
        if (e.alive && e.hp > 0 && isInSameRoom(e)) {
          roomCandidates.push(e);
        }
      });
      state.flyingEyes.forEach(eye => {
        if (eye.alive && eye.hp > 0 && isInSameRoom(eye)) {
          roomCandidates.push(eye);
        }
      });
      state.drones.forEach(drone => {
        if (drone.alive && drone.hp > 0 && isInSameRoom(drone)) {
          roomCandidates.push(drone);
        }
      });
      if (state.bossEye && state.bossEye.alive && state.bossEye.hp > 0 && isInSameRoom(state.bossEye)) {
        roomCandidates.push(state.bossEye);
      }
      if (state.droneBoss && state.droneBoss.alive && state.droneBoss.hp > 0 && isInSameRoom(state.droneBoss)) {
        roomCandidates.push(state.droneBoss);
      }

      // Helper to spawn electric arc between two points
      const spawnLightningArc = (x1: number, y1: number, x2: number, y2: number) => {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const dist = Math.hypot(dx, dy);
        const count = Math.max(6, Math.min(18, Math.floor(dist / 20)));
        const nx = -dy / (dist || 1);
        const ny = dx / (dist || 1);
        const baseAngle = Math.atan2(dy, dx);

        // 1. Primary sleek chaotic plasma bolt
        const mainSegments: { x: number; y: number }[] = [{ x: x1, y: y1 }];
        for (let i = 1; i < count; i++) {
          const t = i / count;
          const envelope = Math.sin(t * Math.PI);
          const displacement = (Math.random() - 0.5) * 28 * envelope;
          mainSegments.push({
            x: x1 + dx * t + nx * displacement,
            y: y1 + dy * t + ny * displacement
          });
        }
        mainSegments.push({ x: x2, y: y2 });

        // 2. Secondary intertwined tendril / ray (sleek weaving beam)
        const secondaryRays: { x: number; y: number }[][] = [];
        const raySegments: { x: number; y: number }[] = [{ x: x1, y: y1 }];
        const rayCount = Math.max(5, count - 2);
        for (let i = 1; i < rayCount; i++) {
          const t = i / rayCount;
          const envelope = Math.sin(t * Math.PI);
          const weave = Math.sin(t * Math.PI * 2.5 + 0.8) * 12 * envelope;
          const jitter = (Math.random() - 0.5) * 14 * envelope;
          raySegments.push({
            x: x1 + dx * t + nx * (weave + jitter),
            y: y1 + dy * t + ny * (weave + jitter)
          });
        }
        raySegments.push({ x: x2, y: y2 });
        secondaryRays.push(raySegments);

        // 3. Multi-tier Jagged Lightning Branches / Forks into the surrounding room
        const branches: { segments: { x: number; y: number }[]; width: number; alpha: number }[] = [];
        const numBranches = Math.min(4, Math.max(2, Math.floor(count / 3.5)));
        for (let b = 0; b < numBranches; b++) {
          const mainIdx = Math.floor(1 + Math.random() * (mainSegments.length - 2));
          const origin = mainSegments[mainIdx];
          const side = Math.random() < 0.5 ? 1 : -1;
          const branchAngle = baseAngle + side * (0.4 + Math.random() * 0.6);
          const branchLen = 14 + Math.random() * 18;
          const branchSteps = 2;
          const branchSegs: { x: number; y: number }[] = [{ x: origin.x, y: origin.y }];

          let curX = origin.x;
          let curY = origin.y;
          for (let s = 1; s <= branchSteps; s++) {
            const stepLen = branchLen / branchSteps;
            const subAngle = branchAngle + (Math.random() - 0.5) * 0.6;
            curX += Math.cos(subAngle) * stepLen;
            curY += Math.sin(subAngle) * stepLen;
            branchSegs.push({ x: curX, y: curY });
          }

          branches.push({
            segments: branchSegs,
            width: 0.6 + Math.random() * 0.4,
            alpha: 0.7 + Math.random() * 0.25
          });
        }

        // 4. Ambient crackling spark particles along the discharge line
        const sparkCount = Math.max(5, Math.floor(dist / 30));
        for (let i = 0; i < sparkCount; i++) {
          const t = Math.random();
          const pOrigin = mainSegments[Math.floor(t * (mainSegments.length - 1))];
          const spd = 2.0 + Math.random() * 4.0;
          const ang = Math.random() * Math.PI * 2;
          state.particles.push({
            x: pOrigin.x,
            y: pOrigin.y,
            vx: Math.cos(ang) * spd,
            vy: Math.sin(ang) * spd,
            life: 0.3 + Math.random() * 0.18,
            maxLife: 0.48,
            color: Math.random() < 0.65 ? '#00f0ff' : '#ffffff',
            size: 1.8 + Math.random() * 1.8
          });
        }

        state.lightningArcs.push({
          id: 'arc_' + Date.now() + Math.random(),
          x1, y1, x2, y2,
          timer: 0.28,
          maxTimer: 0.28,
          mainSegments,
          segments: mainSegments,
          secondaryRays,
          branches
        });
      };

      // Helper to apply lightning damage & spawn spark particles + damage text
      const applyLightningDamage = (target: any, damage: number, isCrit: boolean = false) => {
        // Immunity check: Fatty (Pylons), Saw (Explosion), Phantom (Flickering)
        const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
        const isImmuneFatty = target.type === 'fatty' && hasActivePylons;
        const isImmuneSaw = target.type === 'saw' && Boolean(target.isChargingExplosion);
        const isImmuneWhitePhantom = target.type === 'phantom' && Boolean(target.isFlickering);
        if (isImmuneFatty || isImmuneSaw || isImmuneWhitePhantom) return;

        target.hp -= damage;
        // Vampirism does NOT trigger from chain lightning damage

        // Electric spark particles
        const pCount = isCrit ? 14 : 9;
        for (let i = 0; i < pCount; i++) {
          const ang = Math.random() * Math.PI * 2;
          const spd = (isCrit ? 3.5 : 2) + Math.random() * 5.5;
          state.particles.push({
            x: target.x,
            y: target.y,
            vx: Math.cos(ang) * spd,
            vy: Math.sin(ang) * spd,
            life: 0.35 + Math.random() * 0.25,
            maxLife: 0.6,
            color: isCrit ? (Math.random() < 0.5 ? '#fbbf24' : '#00f0ff') : (Math.random() < 0.6 ? '#00f0ff' : '#ffffff'),
            size: (isCrit ? 3.5 : 2.5) + Math.random() * 2
          });
        }

        // Electric floating damage text
        state.damageTexts.push({
          id: 'dmg_light_' + Date.now() + Math.random(),
          text: `⚡ -${damage}`,
          x: target.x + (Math.random() - 0.5) * 16,
          y: target.y - 14,
          vx: (Math.random() - 0.5) * 4,
          vy: -6.5 - Math.random() * 2.5,
          life: 1.35,
          isCrit: isCrit,
          color: isCrit ? '#f59e0b' : '#00f0ff'
        });

        if (target.hp <= 0) {
          if (target === state.bossEye || state.flyingEyes.includes(target)) killFlyingEye(target);
          else if (target === state.droneBoss || state.drones.includes(target)) killDrone(target);
          else killEnemy(target);
        }
      };

      // Player center position (chest/core origin)
      const px = state.player.x + (state.player.w || 35) / 2;
      const py = state.player.y + (state.player.h || 35) / 2 - 4;

      // Burst of electric spark particles at player discharge origin
      for (let i = 0; i < 8; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = 2.5 + Math.random() * 4.5;
        state.particles.push({
          x: px,
          y: py,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          life: 0.35,
          maxLife: 0.35,
          color: Math.random() < 0.5 ? '#00f0ff' : '#ffffff',
          size: 2.8
        });
      }

      // 1. VISUAL: First lightning bolt erupts from player to the first target!
      spawnLightningArc(px, py, initialTarget.x, initialTarget.y);

      // 1st target takes initial % of player base attack damage with its own crit roll:
      const rawInitialDmg = Math.max(1, Math.round(playerHitDmg * chainDamageRatio));
      const { critChance: cCritChance, critMultiplier: cCritMult } = getPlayerCritStats();
      const isInitialCrit = Math.random() < cCritChance;
      const initialDmg = isInitialCrit ? Math.max(1, Math.round(rawInitialDmg * cCritMult)) : rawInitialDmg;
      applyLightningDamage(initialTarget, initialDmg, isInitialCrit);

      // 2. Pre-calculate chain jumps: STRICTLY max 1 hit per unique enemy in room, up to 4 targets total (initial + 3 jumps)
      const hitSequence: any[] = [initialTarget];
      const targetChain: { target: any; fromTarget: any; rawDamage: number }[] = [];
      let previousEnemy = initialTarget;
      let runningRawDmg = rawInitialDmg;

      for (let bounce = 1; bounce < 4; bounce++) {
        // Each subsequent enemy takes 10% less damage from the previous (90% multiplier):
        runningRawDmg = Math.max(1, Math.round(runningRawDmg * 0.90));

        // Strictly exclude any enemy that has already been hit in this chain!
        const nextPool = roomCandidates.filter(e => e && e.alive && e.hp > 0 && !hitSequence.includes(e));
        if (nextPool.length === 0) break;

        // Sort by closest distance to previousEnemy
        nextPool.sort((a, b) => {
          const distA = Math.hypot(a.x - previousEnemy.x, a.y - previousEnemy.y);
          const distB = Math.hypot(b.x - previousEnemy.x, b.y - previousEnemy.y);
          return distA - distB;
        });

        const nextEnemy = nextPool[0];
        hitSequence.push(nextEnemy);
        targetChain.push({
          target: nextEnemy,
          fromTarget: previousEnemy,
          rawDamage: runningRawDmg
        });
        previousEnemy = nextEnemy;
      }

      // 3. Execute each jump with a 0.1-second (100ms) delay per bounce, and play lightning sound on each jump!
      targetChain.forEach((stepItem, index) => {
        const delayMs = (index + 1) * 100;
        setTimeout(() => {
          const { target, fromTarget, rawDamage } = stepItem;
          const fromX = fromTarget.x ?? px;
          const fromY = fromTarget.y ?? py;
          const toX = target.x;
          const toY = target.y;

          soundManager.playLightningZap();
          state.screenShake = Math.max(state.screenShake, 2);
          spawnLightningArc(fromX, fromY, toX, toY);

          const { critChance: jCritChance, critMultiplier: jCritMult } = getPlayerCritStats();
          const isJumpCrit = Math.random() < jCritChance;
          const jumpDamage = isJumpCrit ? Math.max(1, Math.round(rawDamage * jCritMult)) : rawDamage;
          applyLightningDamage(target, jumpDamage, isJumpCrit);
        }, delayMs);
      });
    };

    // Helper to trigger Chain Lightning if player has Chain Lightning Trinket(s) equipped
    const triggerChainLightning = (initialTarget: any, playerHitDmg: number) => {
      if (!initialTarget) return;

      const eq = equipmentRef.current;
      if (!eq) return;

      const lightningTrinkets: { chance: number; dmgRatio: number }[] = [];
      (Object.values(eq) as any[]).forEach(item => {
        if (item && (item.chainLightningChance !== undefined || item.id?.includes('chain_lightning') || item.name?.includes('Цепн') || item.name?.includes('Грозов') || item.stats?.chainLightningChance !== undefined)) {
          const rarity = item.rarity || 'rare';
          const defaultChance = rarity === 'magic' ? 0.15 : rarity === 'epic' ? 0.40 : 0.25;
          const defaultDmg = rarity === 'magic' ? 0.30 : rarity === 'epic' ? 0.55 : 0.45;

          const chance = item.chainLightningChance ?? (item.stats?.chainLightningChance ?? defaultChance);
          const dmgRatio = item.chainLightningDamageRatio ?? (item.stats?.chainLightningDamageRatio ?? defaultDmg);
          lightningTrinkets.push({ chance, dmgRatio });
        }
      });

      if (lightningTrinkets.length === 0) return;

      // Roll each equipped chain lightning trinket independently (no global CD, both can proc!)
      let procCount = 0;
      lightningTrinkets.forEach((trinket) => {
        if (Math.random() < trinket.chance) {
          const currentProc = procCount;
          procCount++;
          if (currentProc === 0) {
            fireChainLightningDischarge(initialTarget, playerHitDmg, trinket.dmgRatio);
          } else {
            setTimeout(() => {
              fireChainLightningDischarge(initialTarget, playerHitDmg, trinket.dmgRatio);
            }, 60 * currentProc);
          }
        }
      });
    };

    // Damage logic for player - Synchronizes with HUD HP bar!
    const takeDamage = (targetX: number, amount: number = 1, isSpike: boolean = false) => {
      if (state.player.invincible > 0) return;

      // Check Aegis Shield active
      const aegisSkill = skillsRef.current.find(s => s.id === 'aegis_shield');
      if (aegisSkill && aegisSkill.isActive) {
        soundManager.playShieldBlock();
        return;
      }

      // Apply armor damage reduction from gear (halved: 5 armor = 0.67%, 10 armor = 1.33% -> 0.133% per point of armor, max 85%)
      const armor = statsRef.current.armor || 0;
      const reductionPercent = Math.min(0.85, armor * (0.002 / 1.5));
      const reducedAmount = Math.max(1, Math.round(amount * (1 - reductionPercent)));

      const actualDmg = Math.max(1, Math.round(reducedAmount * diffRef.current.damageMultiplier));
      const newHp = Math.max(0, state.player.hp - actualDmg);
      state.player.hp = newHp;
      statsRef.current.hp = newHp;
      (state as any).needsHpSync = true;

      // Floating damage text for player
      state.damageTexts.push({
        id: 'player_dmg_' + Date.now() + Math.random(),
        text: `-${actualDmg}`,
        x: state.player.x + state.player.w / 2,
        y: state.player.y - 12,
        vx: (Math.random() - 0.5) * 2,
        vy: -3.5,
        life: 1.6,
        isCrit: true,
        color: '#ef4444'
      });

      state.player.invincible = isSpike ? 30 : 38;
      state.player.lockControl = isSpike ? 6 : 14;

      let dirX = (state.player.x + state.player.w / 2 < targetX) ? -1 : 1;
      state.player.vx = dirX * (isSpike ? 6 : 10);
      state.player.vy = (Math.random() - 0.5) * 4;

      soundManager.playHit(false);

      if (newHp <= 0) {
        onGameOver();
      }
    };

    // --- GAME UPDATE LOOP ---
    const gravity = 0;
    const friction = 0.98;
    let lastTime = performance.now();
    let animationFrameId: number;

    const update = (dt: number) => {
      // Keep camera centered directly over player
      const initCenterX = state.player.x + state.player.w / 2;
      const initCenterY = state.player.y + state.player.h / 2;
      const curScale = getCameraScale();
      const curW = canvasRef.current ? canvasRef.current.width : (typeof window !== 'undefined' ? window.innerWidth : 800);
      const curH = canvasRef.current ? canvasRef.current.height : (typeof window !== 'undefined' ? window.innerHeight : 600);
      const initViewW = curW / curScale;
      const initViewH = curH / curScale;
      const targetCamX = initCenterX - (initViewW * 0.5);
      const targetCamY = initCenterY - (initViewH * 0.5);

      if (state.isMaterializing) {
        state.cameraX = targetCamX;
        state.cameraY = targetCamY;
      }

      if (isPausedRef.current) {
        // Move camera over player before halting game loop
        state.cameraX = targetCamX;
        state.cameraY = targetCamY;
        return;
      }

      // Sync maxHp from stats (reflects gear bonuses)
      if (statsRef.current.maxHp && state.player.maxHp !== statsRef.current.maxHp) {
        const hpDiff = statsRef.current.maxHp - state.player.maxHp;
        state.player.maxHp = statsRef.current.maxHp;
        if (hpDiff > 0) {
          state.player.hp = Math.min(state.player.maxHp, state.player.hp + hpDiff);
        } else {
          state.player.hp = Math.min(state.player.maxHp, state.player.hp);
        }
      }

      const step = Math.min(dt / 16, 2);
      if (state.swordLock > 0) {
        state.swordLock -= (dt / 1000);
        if (state.swordLock < 0) state.swordLock = 0;
      }
      if (state.doubleStrikeCdTimer > 0) {
        state.doubleStrikeCdTimer -= (dt / 1000);
        if (state.doubleStrikeCdTimer < 0) state.doubleStrikeCdTimer = 0;
      }
      if (state.swingSoundTimer > 0) {
        state.swingSoundTimer -= (dt / 1000);
        if (state.swingSoundTimer < 0) state.swingSoundTimer = 0;
      }
      if (state.player.slowTimer > 0) state.player.slowTimer -= (dt / 16);

      const whirlwindSkill = skillsRef.current.find(s => s.id === 'whirlwind');
      const flameSkill = skillsRef.current.find(s => s.id === 'flame_wave');
      if (flameSkill && flameSkill.isActive && !state.wasFlameSkillActive) {
        triggerFlameWave();
        state.wasFlameSkillActive = true;
      } else if (!flameSkill || !flameSkill.isActive) {
        state.wasFlameSkillActive = false;
      }
      const speedMult = state.player.slowTimer > 0 ? 0.6 : 1.0;
      const currentSpeed = state.player.speed * speedMult;
      
      // --- MATERIALIZATION & FADE FROM BLACK ---
      if (state.isMaterializing) {
        if (state.materializeTimer === 0 || state.particles.filter(p => p.targetX !== undefined).length === 0) {
          state.particles = state.particles.filter(p => p.targetX === undefined);
          const centerX = state.player.x + state.player.w / 2;
          const centerY = state.player.y + state.player.h / 2;
          
          const baseOffsets = [
            // Head
            { x: 0, y: -12 }, { x: -4, y: -14 }, { x: 4, y: -14 }, { x: -6, y: -10 }, { x: 6, y: -10 }, { x: 0, y: -16 }, { x: -2, y: -13 }, { x: 2, y: -13 },
            { x: -3, y: -15 }, { x: 3, y: -15 }, { x: -5, y: -12 }, { x: 5, y: -12 }, { x: 0, y: -18 },
            // Torso
            { x: 0, y: -4 }, { x: -5, y: -8 }, { x: 5, y: -8 }, { x: -8, y: -2 }, { x: 8, y: -2 },
            { x: 0, y: 2 }, { x: -6, y: 4 }, { x: 6, y: 4 }, { x: -4, y: 8 }, { x: 4, y: 8 }, { x: -2, y: 0 }, { x: 2, y: 0 },
            { x: -3, y: -6 }, { x: 3, y: -6 }, { x: -7, y: -4 }, { x: 7, y: -4 }, { x: -2, y: 6 }, { x: 2, y: 6 },
            // Arms / Limbs / Legs
            { x: -10, y: -2 }, { x: 10, y: -2 }, { x: -12, y: 3 }, { x: 12, y: 3 },
            { x: -6, y: 12 }, { x: 6, y: 12 }, { x: -8, y: 16 }, { x: 8, y: 16 },
            { x: -4, y: 18 }, { x: 4, y: 18 }, { x: 0, y: 14 }, { x: -10, y: 8 }, { x: 10, y: 8 },
            { x: -11, y: 0 }, { x: 11, y: 0 }, { x: -13, y: 6 }, { x: 13, y: 6 }, { x: -7, y: 14 }, { x: 7, y: 14 }
          ];

          const silhouetteOffsets: { x: number; y: number; alpha: number; size: number }[] = [];
          baseOffsets.forEach(off => {
            silhouetteOffsets.push({ x: off.x, y: off.y, alpha: 0.15 + Math.random() * 0.85, size: 0.8 + Math.random() * 1.6 });
            silhouetteOffsets.push({ x: off.x + (Math.random() - 0.5) * 3, y: off.y + (Math.random() - 0.5) * 3, alpha: 0.1 + Math.random() * 0.9, size: 0.6 + Math.random() * 1.4 });
            silhouetteOffsets.push({ x: off.x + (Math.random() - 0.5) * 4, y: off.y + (Math.random() - 0.5) * 4, alpha: 0.2 + Math.random() * 0.8, size: 1.0 + Math.random() * 1.5 });
          });

          silhouetteOffsets.forEach((off, i) => {
            const targetX = centerX + off.x;
            const targetY = centerY + off.y;
            const angle = Math.random() * Math.PI * 2;
            const dist = 50 + Math.random() * 70;
            // As soon as materialized, they start directly at startX, startY and immediately glide towards targetX, targetY
            const startX = targetX + Math.cos(angle) * dist;
            const startY = targetY + Math.sin(angle) * dist;

            state.particles.push({
              x: startX,
              y: startY,
              vx: 0,
              vy: 0,
              life: 999,
              maxLife: 999,
              color: i % 5 === 0 ? '#ffffff' : (i % 2 === 0 ? '#38bdf8' : '#f43f5e'),
              size: off.size,
              shape: 'circle',
              alpha: off.alpha,
              targetX,
              targetY
            });
          });
        }

        if (!state.hasPlayedSpawnSound) {
          state.hasPlayedSpawnSound = true;
          soundManager.playMaterializeImpact();
        }
        state.materializeTimer += step;
        state.materializeDuration = 135; // 2x faster fade/reveal (270 / 2)
        state.blackFadeAlpha = Math.max(0, 1.0 - (state.materializeTimer / 135));

        // Immediately drift/glide towards silhouette target position from the first frame
        state.particles.forEach(p => {
          if (p.targetX !== undefined && p.targetY !== undefined) {
            p.x += (p.targetX - p.x) * 0.05 * step;
            p.y += (p.targetY - p.y) * 0.05 * step;
          }
        });

        if (state.materializeTimer >= state.materializeDuration) {
          state.isMaterializing = false;
          state.controlsEnabled = true;
          state.player.alive = true;
          state.screenShake = 22;

          // Remove silhouette guide particles and trigger "Boom!" explosion burst
          state.particles = state.particles.filter(p => p.targetX === undefined);

          state.shockwaves.push({
            x: state.player.x + state.player.w / 2,
            y: state.player.y + state.player.h / 2,
            r: 10,
            maxR: 120,
            color: '#38bdf8',
            life: 0.95,
            maxLife: 0.95
          });

          for (let p = 0; p < 28; p++) {
            const ang = (p / 28) * Math.PI * 2;
            const spd = 6 + Math.random() * 10;
            state.particles.push({
              x: state.player.x + state.player.w / 2,
              y: state.player.y + state.player.h / 2,
              vx: Math.cos(ang) * spd,
              vy: Math.sin(ang) * spd,
              life: 0.8,
              maxLife: 0.8,
              color: p % 2 === 0 ? '#38bdf8' : '#ffffff',
              size: 4,
              shape: 'circle'
            });
          }
        }
        return;
      }

      // Memory management: strict bounds on active visual entities
      if (state.particles.length > 50) {
        state.particles = state.particles.slice(-50);
      }
      if (state.damageTexts.length > 15) {
        state.damageTexts = state.damageTexts.slice(-15);
      }
      if (state.shockwaves.length > 5) {
        state.shockwaves = state.shockwaves.slice(-5);
      }
      if (state.iceProjectiles.length > 12) {
        state.iceProjectiles = state.iceProjectiles.slice(-12);
      }
      if (state.flameWaves.length > 6) {
        state.flameWaves = state.flameWaves.slice(-6);
      }

      // Player 4-Directional Movement (Zero Gravity Labyrinth)
      const prevPlayerCenterX = state.player.x + state.player.w / 2;
      const prevPlayerCenterY = state.player.y + state.player.h / 2;

      if (state.player.lockControl <= 0 && state.controlsEnabled && !state.isPortalTransitioning) {
        let moveDirX = 0;
        let moveDirY = 0;

        if (state.keys.right) moveDirX += 1;
        if (state.keys.left) moveDirX -= 1;
        if (state.keys.down) moveDirY += 1;
        if (state.keys.up) moveDirY -= 1;

        if (moveDirX !== 0 || moveDirY !== 0) {
          const dirLen = Math.hypot(moveDirX, moveDirY);
          const normX = moveDirX / dirLen;
          const normY = moveDirY / dirLen;

          const accel = currentSpeed * 0.18 * step;
          state.player.vx += normX * accel;
          state.player.vy += normY * accel;

          // Cap velocity vector magnitude to currentSpeed so diagonal speed is identical to cardinal speed
          const totalVel = Math.hypot(state.player.vx, state.player.vy);
          if (totalVel > currentSpeed) {
            state.player.vx = (state.player.vx / totalVel) * currentSpeed;
            state.player.vy = (state.player.vy / totalVel) * currentSpeed;
          }
        } else {
          state.player.vx *= Math.pow(0.80, step);
          state.player.vy *= Math.pow(0.80, step);
        }
      } else {
        state.player.vx *= Math.pow(0.85, step);
        state.player.vy *= Math.pow(0.85, step);
        if (state.player.lockControl > 0) {
          state.player.lockControl -= step;
        }
      }

      if (state.player.invincible > 0) state.player.invincible -= step;

      // Update walls retraction animation (e.g. Fatty boss arena walls lowering into floor during laser phase)
      state.walls.forEach(w => {
        if (w.isFattyArenaWall) {
          const target = w.targetRetract || 0;
          const cur = w.retractProgress || 0;
          if (Math.abs(target - cur) > 0.005) {
            w.retractProgress = cur + (target - cur) * (0.045 * step);
            if (Math.abs(target - w.retractProgress) < 0.01) {
              w.retractProgress = target;
              if (target === 0 && cur > 0.1) {
                // Walls finished rising back up
                soundManager.playWallBump();
                state.screenShake = 5;
                for (let k = 0; k < 2; k++) {
                  state.particles.push({
                    x: w.x + Math.random() * w.w,
                    y: w.y + w.h,
                    vx: (Math.random() - 0.5) * 6,
                    vy: -Math.random() * 4,
                    life: 0.35, maxLife: 0.35,
                    color: '#94a3b8',
                    size: 2.5
                  });
                }
              }
            }
          }
        }
      });

      // 2-Axis Wall & Obstacle Collision with Sliding for smooth maze exploration:
      // Active physical obstacle colliders are cached in state.obstacleColliders and updated on changes
      const obstacleColliders = state.obstacleColliders || [];

      // Reusable 2-axis circular bounce physics for flying creatures & circular entities ("как кругляхи")
      // Resolves X and Y independently to guarantee entities bounce off walls without sticking for even a single frame
      const bounceCircleAgainstWallsAndObstacles = (
        entity: { x: number; y: number; vx: number; vy: number; r: number; targetVx?: number; targetVy?: number },
        s: number,
        bounds?: { minX: number; maxX: number; minY: number; maxY: number }
      ) => {
        // Instant de-penetration safety net: ensure entity is never embedded inside a wall or obstacle
        for (let i = 0; i < state.walls.length; i++) {
          const w = state.walls[i];
          if (!w.alive) continue;
          if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) continue;
          if (Math.abs(w.x - entity.x) > w.w + 120 || Math.abs(w.y - entity.y) > w.h + 120) continue;
          if (entity.x + entity.r > w.x && entity.x - entity.r < w.x + w.w &&
              entity.y + entity.r > w.y && entity.y - entity.r < w.y + w.h) {
            const oL = (entity.x + entity.r) - w.x;
            const oR = (w.x + w.w) - (entity.x - entity.r);
            const oT = (entity.y + entity.r) - w.y;
            const oB = (w.y + w.h) - (entity.y - entity.r);
            const minO = Math.min(oL, oR, oT, oB);
            if (minO === oL) { entity.x = w.x - entity.r; entity.vx = -Math.abs(entity.vx || 1.6); }
            else if (minO === oR) { entity.x = w.x + w.w + entity.r; entity.vx = Math.abs(entity.vx || 1.6); }
            else if (minO === oT) { entity.y = w.y - entity.r; entity.vy = -Math.abs(entity.vy || 1.6); }
            else { entity.y = w.y + w.h + entity.r; entity.vy = Math.abs(entity.vy || 1.6); }
            if (entity.targetVx !== undefined) entity.targetVx = Math.sign(entity.vx) * Math.abs(entity.targetVx || entity.vx);
            if (entity.targetVy !== undefined) entity.targetVy = Math.sign(entity.vy) * Math.abs(entity.targetVy || entity.vy);
          }
        }
        for (let i = 0; i < obstacleColliders.length; i++) {
          const obs = obstacleColliders[i];
          if (Math.abs(obs.x - entity.x) > obs.w + 120 || Math.abs(obs.y - entity.y) > obs.h + 120) continue;
          if (entity.x + entity.r > obs.x && entity.x - entity.r < obs.x + obs.w &&
              entity.y + entity.r > obs.y && entity.y - entity.r < obs.y + obs.h) {
            const oL = (entity.x + entity.r) - obs.x;
            const oR = (obs.x + obs.w) - (entity.x - entity.r);
            const oT = (entity.y + entity.r) - obs.y;
            const oB = (obs.y + obs.h) - (entity.y - entity.r);
            const minO = Math.min(oL, oR, oT, oB);
            if (minO === oL) { entity.x = obs.x - entity.r; entity.vx = -Math.abs(entity.vx || 1.6); }
            else if (minO === oR) { entity.x = obs.x + obs.w + entity.r; entity.vx = Math.abs(entity.vx || 1.6); }
            else if (minO === oT) { entity.y = obs.y - entity.r; entity.vy = -Math.abs(entity.vy || 1.6); }
            else { entity.y = obs.y + obs.h + entity.r; entity.vy = Math.abs(entity.vy || 1.6); }
            if (entity.targetVx !== undefined) entity.targetVx = Math.sign(entity.vx) * Math.abs(entity.targetVx || entity.vx);
            if (entity.targetVy !== undefined) entity.targetVy = Math.sign(entity.vy) * Math.abs(entity.targetVy || entity.vy);
          }
        }

        // 1. X-Axis Movement & Wall Collision
        const prevX = entity.x;
        entity.x += entity.vx * s;

        for (let i = 0; i < state.walls.length; i++) {
          const w = state.walls[i];
          if (!w.alive) continue;
          if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) continue;
          if (Math.abs(w.x - entity.x) > w.w + 100 || Math.abs(w.y - entity.y) > w.h + 100) continue;

          if (entity.x + entity.r > w.x && entity.x - entity.r < w.x + w.w &&
              entity.y + entity.r > w.y && entity.y - entity.r < w.y + w.h) {
            if (prevX + entity.r <= w.x + 2) {
              entity.x = w.x - entity.r;
              entity.vx = -Math.abs(entity.vx || 1.6);
            } else if (prevX - entity.r >= w.x + w.w - 2) {
              entity.x = w.x + w.w + entity.r;
              entity.vx = Math.abs(entity.vx || 1.6);
            } else {
              const oL = (entity.x + entity.r) - w.x;
              const oR = (w.x + w.w) - (entity.x - entity.r);
              if (oL < oR) {
                entity.x = w.x - entity.r;
                entity.vx = -Math.abs(entity.vx || 1.6);
              } else {
                entity.x = w.x + w.w + entity.r;
                entity.vx = Math.abs(entity.vx || 1.6);
              }
            }
            if (entity.targetVx !== undefined) entity.targetVx = Math.sign(entity.vx) * Math.abs(entity.targetVx || entity.vx);
          }
        }

        for (let i = 0; i < obstacleColliders.length; i++) {
          const obs = obstacleColliders[i];
          if (Math.abs(obs.x - entity.x) > obs.w + 100 || Math.abs(obs.y - entity.y) > obs.h + 100) continue;

          if (entity.x + entity.r > obs.x && entity.x - entity.r < obs.x + obs.w &&
              entity.y + entity.r > obs.y && entity.y - entity.r < obs.y + obs.h) {
            if (prevX + entity.r <= obs.x + 2) {
              entity.x = obs.x - entity.r;
              entity.vx = -Math.abs(entity.vx || 1.6);
            } else if (prevX - entity.r >= obs.x + obs.w - 2) {
              entity.x = obs.x + obs.w + entity.r;
              entity.vx = Math.abs(entity.vx || 1.6);
            } else {
              const oL = (entity.x + entity.r) - obs.x;
              const oR = (obs.x + obs.w) - (entity.x - entity.r);
              if (oL < oR) {
                entity.x = obs.x - entity.r;
                entity.vx = -Math.abs(entity.vx || 1.6);
              } else {
                entity.x = obs.x + obs.w + entity.r;
                entity.vx = Math.abs(entity.vx || 1.6);
              }
            }
            if (entity.targetVx !== undefined) entity.targetVx = Math.sign(entity.vx) * Math.abs(entity.targetVx || entity.vx);
          }
        }

        // 2. Y-Axis Movement & Wall Collision
        const prevY = entity.y;
        entity.y += entity.vy * s;

        for (let i = 0; i < state.walls.length; i++) {
          const w = state.walls[i];
          if (!w.alive) continue;
          if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) continue;
          if (Math.abs(w.x - entity.x) > w.w + 100 || Math.abs(w.y - entity.y) > w.h + 100) continue;

          if (entity.x + entity.r > w.x && entity.x - entity.r < w.x + w.w &&
              entity.y + entity.r > w.y && entity.y - entity.r < w.y + w.h) {
            if (prevY + entity.r <= w.y + 2) {
              entity.y = w.y - entity.r;
              entity.vy = -Math.abs(entity.vy || 1.6);
            } else if (prevY - entity.r >= w.y + w.h - 2) {
              entity.y = w.y + w.h + entity.r;
              entity.vy = Math.abs(entity.vy || 1.6);
            } else {
              const oT = (entity.y + entity.r) - w.y;
              const oB = (w.y + w.h) - (entity.y - entity.r);
              if (oT < oB) {
                entity.y = w.y - entity.r;
                entity.vy = -Math.abs(entity.vy || 1.6);
              } else {
                entity.y = w.y + w.h + entity.r;
                entity.vy = Math.abs(entity.vy || 1.6);
              }
            }
            if (entity.targetVy !== undefined) entity.targetVy = Math.sign(entity.vy) * Math.abs(entity.targetVy || entity.vy);
          }
        }

        for (let i = 0; i < obstacleColliders.length; i++) {
          const obs = obstacleColliders[i];
          if (Math.abs(obs.x - entity.x) > obs.w + 100 || Math.abs(obs.y - entity.y) > obs.h + 100) continue;

          if (entity.x + entity.r > obs.x && entity.x - entity.r < obs.x + obs.w &&
              entity.y + entity.r > obs.y && entity.y - entity.r < obs.y + obs.h) {
            if (prevY + entity.r <= obs.y + 2) {
              entity.y = obs.y - entity.r;
              entity.vy = -Math.abs(entity.vy || 1.6);
            } else if (prevY - entity.r >= obs.y + obs.h - 2) {
              entity.y = obs.y + obs.h + entity.r;
              entity.vy = Math.abs(entity.vy || 1.6);
            } else {
              const oT = (entity.y + entity.r) - obs.y;
              const oB = (obs.y + obs.h) - (entity.y - entity.r);
              if (oT < oB) {
                entity.y = obs.y - entity.r;
                entity.vy = -Math.abs(entity.vy || 1.6);
              } else {
                entity.y = obs.y + obs.h + entity.r;
                entity.vy = Math.abs(entity.vy || 1.6);
              }
            }
            if (entity.targetVy !== undefined) entity.targetVy = Math.sign(entity.vy) * Math.abs(entity.targetVy || entity.vy);
          }
        }

        // 3. Room Bounds Bounce
        if (bounds) {
          if (entity.x - entity.r < bounds.minX) {
            entity.x = bounds.minX + entity.r;
            entity.vx = Math.abs(entity.vx || 1.6);
            if (entity.targetVx !== undefined) entity.targetVx = Math.abs(entity.targetVx || 1.6);
          } else if (entity.x + entity.r > bounds.maxX) {
            entity.x = bounds.maxX - entity.r;
            entity.vx = -Math.abs(entity.vx || 1.6);
            if (entity.targetVx !== undefined) entity.targetVx = -Math.abs(entity.targetVx || 1.6);
          }
          if (entity.y - entity.r < bounds.minY) {
            entity.y = bounds.minY + entity.r;
            entity.vy = Math.abs(entity.vy || 1.6);
            if (entity.targetVy !== undefined) entity.targetVy = Math.abs(entity.targetVy || 1.6);
          } else if (entity.y + entity.r > bounds.maxY) {
            entity.y = bounds.maxY - entity.r;
            entity.vy = -Math.abs(entity.vy || 1.6);
            if (entity.targetVy !== undefined) entity.targetVy = -Math.abs(entity.targetVy || 1.6);
          }
        }
      };

      // 1. Move X first and resolve X collisions
      const prevX = state.player.x;
      state.player.x += state.player.vx * step;
      const pw = state.player.w, ph = state.player.h;

      // Gate collision message helper
      const checkBossGateBlocked = (w: any) => {
        if (w.isBossGate && w.isClosed && state.fattyArena && !state.fattyArena.triggered && !state.fattyArena.gateUnlocked) {
          const remNormal = state.enemies.filter(e => e.alive && e.type !== 'fatty').length;
          const remEyes = state.flyingEyes.filter(e => e.alive).length;
          const remDrones = state.drones.filter(d => d.alive).length;
          const totalRemaining = remNormal + remEyes + remDrones;
          if (state.invFullWarningTimer <= 0) {
            soundManager.playError();
            state.damageTexts.push({
              id: 'gate_closed_hint_' + Date.now(),
              text: `Врата заперты! Истребите всех мобов на уровне (Осталось: ${totalRemaining})`,
              x: state.player.x + pw / 2,
              y: state.player.y - 30,
              vx: 0,
              vy: 0,
              life: 2.6,
              isCrit: true,
              color: '#f87171'
            });
            state.invFullWarningTimer = 1.8;
          }
        }
      };

      state.walls.forEach(w => {
        if (!w.alive) return;
        if (w.isBossGate && !w.isClosed) return; // Open gates can be walked through
        if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) return; // Sunken walls can be walked over freely
        // Fast culling check
        if (Math.abs(w.x - state.player.x) > w.w + 100 || Math.abs(w.y - state.player.y) > w.h + 100) return;

        if (state.player.x + pw > w.x && state.player.x < w.x + w.w &&
            state.player.y + ph > w.y && state.player.y < w.y + w.h) {
          checkBossGateBlocked(w);

          // Determine entry side cleanly from previous X position to prevent teleportation
          if (prevX + pw <= w.x + 2) {
            state.player.x = w.x - pw;
            state.player.vx = 0;
          } else if (prevX >= w.x + w.w - 2) {
            state.player.x = w.x + w.w;
            state.player.vx = 0;
          } else {
            const overlapLeft = (state.player.x + pw) - w.x;
            const overlapRight = (w.x + w.w) - state.player.x;
            if (overlapLeft < overlapRight) {
              state.player.x = w.x - pw;
              state.player.vx = 0;
            } else {
              state.player.x = w.x + w.w;
              state.player.vx = 0;
            }
          }

          if (w.hasSpikes || w.isSpike) {
            const isFullyExtended = !w.isFattyArenaWall || (w.retractProgress || 0) <= 0.001;
            if (isFullyExtended) {
              takeDamage(w.x + w.w / 2, getEnemyDamage('spike'), true);
            }
          }
        }
      });

      // Player X vs Solid Obstacles (Barrels, Pots, Rocks, Standing Torches, Braziers, Unopened Chests)
      obstacleColliders.forEach(obs => {
        if (Math.abs(obs.x - state.player.x) > obs.w + 100 || Math.abs(obs.y - state.player.y) > obs.h + 100) return;
        if (state.player.x + pw > obs.x && state.player.x < obs.x + obs.w &&
            state.player.y + ph > obs.y && state.player.y < obs.y + obs.h) {
          if (prevX + pw <= obs.x + 2) {
            state.player.x = obs.x - pw;
            state.player.vx = 0;
          } else if (prevX >= obs.x + obs.w - 2) {
            state.player.x = obs.x + obs.w;
            state.player.vx = 0;
          } else {
            const overlapLeft = (state.player.x + pw) - obs.x;
            const overlapRight = (obs.x + obs.w) - state.player.x;
            if (overlapLeft < overlapRight) {
              state.player.x = obs.x - pw;
              state.player.vx = 0;
            } else {
              state.player.x = obs.x + obs.w;
              state.player.vx = 0;
            }
          }
        }
      });

      // 2. Move Y next and resolve Y collisions
      const prevY = state.player.y;
      state.player.y += state.player.vy * step;
      state.walls.forEach(w => {
        if (!w.alive) return;
        if (w.isBossGate && !w.isClosed) return; // Open gates can be walked through
        if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) return; // Sunken walls can be walked over freely
        // Fast culling check
        if (Math.abs(w.x - state.player.x) > w.w + 100 || Math.abs(w.y - state.player.y) > w.h + 100) return;

        if (state.player.x + pw > w.x && state.player.x < w.x + w.w &&
            state.player.y + ph > w.y && state.player.y < w.y + w.h) {
          checkBossGateBlocked(w);

          // Determine entry side cleanly from previous Y position to prevent teleportation
          if (prevY + ph <= w.y + 2) {
            state.player.y = w.y - ph;
            state.player.vy = 0;
          } else if (prevY >= w.y + w.h - 2) {
            state.player.y = w.y + w.h;
            state.player.vy = 0;
          } else {
            const overlapTop = (state.player.y + ph) - w.y;
            const overlapBottom = (w.y + w.h) - state.player.y;
            if (overlapTop < overlapBottom) {
              state.player.y = w.y - ph;
              state.player.vy = 0;
            } else {
              state.player.y = w.y + w.h;
              state.player.vy = 0;
            }
          }

          if (w.hasSpikes || w.isSpike) {
            const isFullyExtended = !w.isFattyArenaWall || (w.retractProgress || 0) <= 0.001;
            if (isFullyExtended) {
              takeDamage(w.x + w.w / 2, getEnemyDamage('spike'), true);
            }
          }
        }
      });

      // Player Y vs Solid Obstacles (Barrels, Pots, Rocks, Standing Torches, Braziers, Unopened Chests)
      obstacleColliders.forEach(obs => {
        if (Math.abs(obs.x - state.player.x) > obs.w + 100 || Math.abs(obs.y - state.player.y) > obs.h + 100) return;
        if (state.player.x + pw > obs.x && state.player.x < obs.x + obs.w &&
            state.player.y + ph > obs.y && state.player.y < obs.y + obs.h) {
          if (prevY + ph <= obs.y + 2) {
            state.player.y = obs.y - ph;
            state.player.vy = 0;
          } else if (prevY >= obs.y + obs.h - 2) {
            state.player.y = obs.y + obs.h;
            state.player.vy = 0;
          } else {
            const overlapTop = (state.player.y + ph) - obs.y;
            const overlapBottom = (obs.y + obs.h) - state.player.y;
            if (overlapTop < overlapBottom) {
              state.player.y = obs.y - ph;
              state.player.vy = 0;
            } else {
              state.player.y = obs.y + obs.h;
              state.player.vy = 0;
            }
          }
        }
      });

      // Keep safe coordinates updated
      state.player.safeX = state.player.x;
      state.player.safeY = state.player.y;
      state.player.grounded = true;

      // Boss passage unlock check: gate opens when all level mobs are destroyed
      if (state.fattyArena && !state.fattyArena.gateUnlocked && !state.fattyArena.triggered) {
        const remNormal = state.enemies.filter(e => e.alive && e.type !== 'fatty').length;
        const remEyes = state.flyingEyes.filter(e => e.alive).length;
        const remDrones = state.drones.filter(d => d.alive).length;
        const totalRemaining = remNormal + remEyes + remDrones;

        if (totalRemaining === 0) {
          state.fattyArena.gateUnlocked = true;
          soundManager.playLoot();
          state.screenShake = 16;

          // Open the boss arena entrance gate
          state.walls.forEach(w => {
            if (w.isBossGate) {
              w.isClosed = false;
            }
          });

          // Victorious banner
          state.damageTexts.push({
            id: 'gate_open_' + Date.now(),
            text: '★ ВСЕ МОБЫ ИСТРЕБЛЕНЫ! ПРОХОД К ТОЛСТЯКУ ОТКРЫТ! ★',
            x: state.player.x,
            y: state.player.y - 45,
            vx: 0,
            vy: -3.5,
            life: 5.0,
            isCrit: true,
            color: '#38bdf8'
          });
        }
      }

      // Trigger gate enclosure when player steps inside Fatty's boss room
      if (state.fattyArena && state.fattyArena.gateUnlocked && !state.fattyArena.triggered) {
        const fa = state.fattyArena;
        const endX = fa.arenaEndX || (fa.arenaX + 1100);
        const endY = fa.arenaEndY || (fa.arenaY + 900);
        if (state.player.x >= fa.arenaX + 50 && state.player.x <= endX - 50 &&
            state.player.y >= fa.arenaY + 50 && state.player.y <= endY - 50) {
          fa.triggered = true;
          soundManager.playBossAwaken();
          state.screenShake = 22;

          // Close entrance gate to enclose the boss arena for the final duel!
          state.walls.forEach(w => {
            if (w.isBossGate) {
              w.isClosed = true;
            }
          });

          // Impact notice
          state.damageTexts.push({
            id: 'gate_lock_' + Date.now(),
            text: '⚠ ПРОХОД ПЕРЕКРЫТ! БОЙ С БОССОМ! ⚠',
            x: state.player.x,
            y: state.player.y - 35,
            vx: 0,
            vy: -3.5,
            life: 3.5,
            isCrit: true,
            color: '#ef4444'
          });
        }
      }

      // Flip animation
      if (!state.player.grounded) {
        let rotationDir = state.player.vx >= 0 ? 1 : -1;
        state.player.angle += rotationDir * 0.15 * step;
      } else {
        state.player.angle *= Math.pow(0.5, step);
        if (Math.abs(state.player.angle) < 0.01) state.player.angle = 0;
      }

      // Sword Physics
      let bladeCheckPoints: { x: number; y: number }[] = [];
      let isFullWindupCut = Boolean(whirlwindSkill && whirlwindSkill.isActive);

      if (state.ropePoints.length > 0) {
        const centerX = state.player.x + state.player.w / 2;
        const centerY = state.player.y + state.player.h / 2;
        state.ropePoints[0].x = centerX;
        state.ropePoints[0].y = centerY;

        const lastP = state.ropePoints[state.ropePoints.length - 1];

        // Whirlwind skill 360 rotation
        if (whirlwindSkill && whirlwindSkill.isActive) {
          if (state.swordLock <= 0) {
            state.targetSwordAngle += 0.38 * step;
          }
          state.isSwordMoving = true;
        } else if (state.isSwordMoving && state.swordLock <= 0) {
          let desiredAngle;
          if (state.isJoystickActive) {
            desiredAngle = state.targetSwordAngle;
          } else {
            const dx = state.smoothTargetX - centerX;
            const dy = state.smoothTargetY - centerY;
            if (Math.hypot(dx, dy) > 8) desiredAngle = Math.atan2(dy, dx);
            else desiredAngle = state.targetSwordAngle;
          }

          let angleDiff = desiredAngle - state.targetSwordAngle;
          while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
          while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;

          let lerpFactor = state.isJoystickActive ? 0.1875 : 0.20625;
          state.targetSwordAngle += angleDiff * lerpFactor * step;
        }

        for (let i = 1; i < state.ropePoints.length; i++) {
          let p = state.ropePoints[i];
          let pvx = (p.x - p.oldX) * friction;
          let pvy = (p.y - p.oldY) * friction;
          p.oldX = p.x; p.oldY = p.y;
          p.x += pvx;
          p.y += pvy;
        }

        if (state.isSwordMoving && state.swordLock <= 0) {
          const baseForce = state.isJoystickActive ? 8.0 : 10.875;
          const pullPower = (baseForce / Math.max(0.6, weaponRef.current.weight * 0.8)) * step;
          lastP.x += Math.cos(state.targetSwordAngle) * pullPower;
          lastP.y += Math.sin(state.targetSwordAngle) * pullPower;
        }

        const segmentLen = 8 * (Math.max(65, weaponRef.current.length) / 85);
        for (let n = 0; n < 6; n++) {
          for (let i = 0; i < state.ropePoints.length - 1; i++) {
            let p1 = state.ropePoints[i], p2 = state.ropePoints[i + 1];
            let dx = p2.x - p1.x, dy = p2.y - p1.y;
            let d = Math.sqrt(dx * dx + dy * dy) || 0.1;
            let diff = (segmentLen - d) / d;
            if (i !== 0) { p1.x -= dx * diff * 0.5; p1.y -= dy * diff * 0.5; }
            p2.x += dx * diff * 0.5; p2.y += dy * diff * 0.5;
          }
        }

        // Prevent weapon points from passing through solid walls
        for (let i = 1; i < state.ropePoints.length; i++) {
          const rp = state.ropePoints[i];
          for (const w of state.walls) {
            if (!w.alive) continue;
            if (Math.abs(w.x - state.player.x) > w.w + 140 || Math.abs(w.y - state.player.y) > w.h + 140) continue;
            if (rp.x >= w.x - 4 && rp.x <= w.x + w.w + 4 && rp.y >= w.y - 4 && rp.y <= w.y + w.h + 4) {
              const dL = Math.abs(rp.x - w.x);
              const dR = Math.abs(rp.x - (w.x + w.w));
              const dT = Math.abs(rp.y - w.y);
              const dB = Math.abs(rp.y - (w.y + w.h));
              const m = Math.min(dL, dR, dT, dB);
              if (m === dL) rp.x = w.x - 6;
              else if (m === dR) rp.x = w.x + w.w + 6;
              else if (m === dT) rp.y = w.y - 6;
              else rp.y = w.y + w.h + 6;
            }
          }
        }

        // Calculate Sword Blade Points
        const prevP = state.ropePoints[state.ropePoints.length - 2];
        const ang = Math.atan2(lastP.y - prevP.y, lastP.x - prevP.x);
        const perpAng = ang + Math.PI / 2;
        const len = weaponRef.current.length || 80;

        const wType = weaponRef.current.type || 'greatsword';

        // Calculate Weapon Damage Collision Points:
        if (wType === 'fist') {
          // UNARMED / FIST: Damage collision is directly at the fist on the end of the arm
          for (let d = 0; d <= 18; d += 4) {
            bladeCheckPoints.push({
              x: lastP.x + Math.cos(ang) * d,
              y: lastP.y + Math.sin(ang) * d
            });
          }
          const fistX = lastP.x + Math.cos(ang) * 10;
          const fistY = lastP.y + Math.sin(ang) * 10;
          bladeCheckPoints.push({
            x: fistX + Math.cos(perpAng) * 6,
            y: fistY + Math.sin(perpAng) * 6
          });
          bladeCheckPoints.push({
            x: fistX - Math.cos(perpAng) * 6,
            y: fistY - Math.sin(perpAng) * 6
          });
        } else if (wType === 'axe') {
          // AXE / BATTLEAXE: Head collisions shifted 20% lower vertically along the shaft
          const effectiveLen = Math.round(59 * 0.80); // 20% lower vertically (~47 for len=80)
          const baseHeadD = Math.max(10, Math.round(effectiveLen - 24)); // Lower beard region (~23 for len=80)

          // 1. Central spine of the axe head (from beard to top tip)
          for (let d = baseHeadD; d <= effectiveLen; d += 3) {
            bladeCheckPoints.push({
              x: lastP.x + Math.cos(ang) * d,
              y: lastP.y + Math.sin(ang) * d
            });
          }

          // 2. Lateral cutting blades & crescent wings (left and right cutting edges matching axe asset geometry)
          // Lower beard region
          for (let d = baseHeadD + 2; d <= baseHeadD + 8; d += 2) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 5; off <= 20; off += 4) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }

          // Main cutting blade body & widest crescent edges
          for (let d = baseHeadD + 9; d <= effectiveLen - 3; d += 2) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 5; off <= 32; off += 4) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }

          // Top horns / upper blade edges
          for (let d = effectiveLen - 2; d <= effectiveLen; d += 2) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 5; off <= 24; off += 5) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }
        } else if (wType === 'spear') {
          // SPEAR: Long wooden pole does NOT hit enemies! Only the spearhead/tip, shifted 10% lower along the shaft
          const effectiveLen = Math.round((len + 16) * 0.90); // 10% lower vertically (~86 for len=80)
          const baseTipD = Math.round((len - 10) * 0.90); // Base of spear blade socket (~63 for len=80)

          for (let d = baseTipD; d <= effectiveLen; d += 4) {
            bladeCheckPoints.push({
              x: lastP.x + Math.cos(ang) * d,
              y: lastP.y + Math.sin(ang) * d
            });
          }
          const spearHeadD = Math.round((len - 4) * 0.90); // Widest section of spearhead (~68 for len=80)
          const spearHeadX = lastP.x + Math.cos(ang) * spearHeadD;
          const spearHeadY = lastP.y + Math.sin(ang) * spearHeadD;
          bladeCheckPoints.push({
            x: spearHeadX + Math.cos(perpAng) * 4.5,
            y: spearHeadY + Math.sin(perpAng) * 4.5
          });
          bladeCheckPoints.push({
            x: spearHeadX - Math.cos(perpAng) * 4.5,
            y: spearHeadY - Math.sin(perpAng) * 4.5
          });
          const spearFlangeD = baseTipD + 3;
          const flangeX = lastP.x + Math.cos(ang) * spearFlangeD;
          const flangeY = lastP.y + Math.sin(ang) * spearFlangeD;
          bladeCheckPoints.push({
            x: flangeX + Math.cos(perpAng) * 3.5,
            y: flangeY + Math.sin(perpAng) * 3.5
          });
          bladeCheckPoints.push({
            x: flangeX - Math.cos(perpAng) * 3.5,
            y: flangeY - Math.sin(perpAng) * 3.5
          });
        } else if (wType === 'hammer') {
          // WARHAMMER: Head collisions 20% lower vertically along the shaft
          const effectiveLen = Math.round((((len - 12) / 2) * 0.9 + ((len + 20) / 2) * 0.9) * 0.80); // 20% lower vertically (~60 for len=80)
          const baseHeadD = Math.max(16, Math.round(effectiveLen - 26)); // Lower socket collar (~34)

          // 1. Central core of the hammerhead (from lower socket to top crown)
          for (let d = baseHeadD; d <= effectiveLen; d += 4) {
            bladeCheckPoints.push({
              x: lastP.x + Math.cos(ang) * d,
              y: lastP.y + Math.sin(ang) * d
            });
          }

          // 2. Lower collar & socket ring
          for (let d = baseHeadD + 2; d <= baseHeadD + 7; d += 3) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 6; off <= 18; off += 6) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }

          // 3. Massive main iron striking block / faces
          for (let d = baseHeadD + 8; d <= effectiveLen - 3; d += 3) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 6; off <= 32; off += 5) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }

          // 4. Top crown & upper anvil spikes
          for (let d = effectiveLen - 2; d <= effectiveLen; d += 2) {
            const hx = lastP.x + Math.cos(ang) * d;
            const hy = lastP.y + Math.sin(ang) * d;
            for (let off = 6; off <= 26; off += 6) {
              bladeCheckPoints.push({ x: hx + Math.cos(perpAng) * off, y: hy + Math.sin(perpAng) * off });
              bladeCheckPoints.push({ x: hx - Math.cos(perpAng) * off, y: hy - Math.sin(perpAng) * off });
            }
          }
        } else {
          // SWORD / GREATSWORD / KATANA / RAPIER / DAGGER:
          // The entire blade starting past the crossguard (d >= 10) to the tip deals damage
          for (let d = 10; d <= len; d += 10) {
            bladeCheckPoints.push({
              x: lastP.x + Math.cos(ang) * d,
              y: lastP.y + Math.sin(ang) * d
            });
          }
          if (wType === 'greatsword') {
            for (let d = 15; d <= len - 10; d += 15) {
              const bx = lastP.x + Math.cos(ang) * d;
              const by = lastP.y + Math.sin(ang) * d;
              bladeCheckPoints.push({ x: bx + Math.cos(perpAng) * 6, y: by + Math.sin(perpAng) * 6 });
              bladeCheckPoints.push({ x: bx - Math.cos(perpAng) * 6, y: by - Math.sin(perpAng) * 6 });
            }
          }
        }

        // Calculate Sword Tip Speed & Angular Sweep relative to player hilt (excludes player movement!)
        const curRelX = lastP.x - centerX;
        const curRelY = lastP.y - centerY;
        const curSwordAngle = Math.atan2(curRelY, curRelX);

        let dAngle = curSwordAngle - state.prevSwordAngle;
        while (dAngle < -Math.PI) dAngle += Math.PI * 2;
        while (dAngle > Math.PI) dAngle -= Math.PI * 2;
        state.prevSwordAngle = curSwordAngle;

        const oldRelX = lastP.oldX - prevPlayerCenterX;
        const oldRelY = lastP.oldY - prevPlayerCenterY;
        const pureSwingSpeed = Math.hypot(curRelX - oldRelX, curRelY - oldRelY);
        state.swordTipSpeed = pureSwingSpeed;

        // Accumulate swing distance / arc from start of windup to strike point
        if (pureSwingSpeed < 0.6) {
          state.swingDistance = 0;
          state.swingArc = 0;
        } else {
          state.swingDistance += pureSwingSpeed * step * 1.4;
          state.swingArc += Math.abs(dAngle);

          // Full windup detection (sound disabled per user request)
          const isFullWindup = (state.swingDistance >= 95 || state.swingArc >= 1.6);
        }

        // Full windup (e.g. from behind the head / wide continuous arc) vs short jab/poke
        isFullWindupCut = (state.swingDistance >= 95 || state.swingArc >= 1.6) || Boolean(whirlwindSkill && whirlwindSkill.isActive);
        const isSwinging = (pureSwingSpeed >= 0.8) || Boolean(whirlwindSkill && whirlwindSkill.isActive);
        state.isSwinging = isSwinging;

        // Record sword slash trail (dynamically scales width, length, alpha & blur with swing distance & speed)
        if (pureSwingSpeed > 0.6 || Boolean(whirlwindSkill && whirlwindSkill.isActive)) {
          if (state.ropePoints.length > 1) {
            const distRatio = Math.min(1.0, Math.max(0.1, state.swingDistance / 95));
            const bladeLen = weaponRef.current.length;
            const tipX = lastP.x + Math.cos(ang) * bladeLen;
            const tipY = lastP.y + Math.sin(ang) * bladeLen;

            state.swordTrail.push({
              baseX: lastP.x,
              baseY: lastP.y,
              tipX: tipX,
              tipY: tipY,
              angle: ang,
              length: bladeLen,
              alpha: Math.min(1.0, 0.35 + distRatio * 0.65),
              width: 10 + distRatio * 30
            });

            // Fast wide swings produce crisp flowing arcs with halved slice count for zero lag
            const maxTrailSlices = Math.min(5, Math.max(2, Math.round(2 + distRatio * 3)));
            while (state.swordTrail.length > maxTrailSlices) {
              state.swordTrail.shift();
            }
          }
        }

        // Fade sword trail smoothly and briskly
        const fadeRate = pureSwingSpeed > 5.0 ? 0.72 : 0.60;
        state.swordTrail.forEach(tr => {
          tr.alpha *= fadeRate;
        });
        state.swordTrail = state.swordTrail.filter(tr => tr.alpha > 0.08);

        // Chests breaking (requires deliberate contact/swing) -> Drops HP Heart, plus Gold Chest drops (5% Rare, 2% Epic, 10% Tier 3/4 resource)
        state.chests.forEach(c => {
          if (c.opened) return;
          for (let pt of bladeCheckPoints) {
            if (pt.x > c.x && pt.x < c.x + c.w && pt.y > c.y && pt.y < c.y + c.h) {
              c.opened = true;
              rebuildObstacleColliders();
              soundManager.playLoot();

              // 1. Check if this is the Starter Chest on Level 1 (ONLY drops a single common weapon of Level 1)
              if (c.isFirstLevelStartWeapon || (Boolean(c.id) && typeof c.id === 'string' && c.id.startsWith('first_start_chest_'))) {
                const starterWeaponItem = generateEquipmentDrop('common', 1, 'weapon');
                state.lootDrops.push({
                  id: 'chest_wep_' + Date.now() + Math.random(),
                  x: c.x + c.w / 2,
                  y: c.y - 16,
                  vx: (Math.random() - 0.5) * 3,
                  vy: -4 - Math.random() * 1.5,
                  type: 'equipment',
                  itemData: starterWeaponItem,
                  rarity: 'common',
                  alive: true,
                  pickupDelay: 0.5
                });
              } else if (c.isBossChest || (Boolean(c.id) && typeof c.id === 'string' && c.id.startsWith('boss_reward_chest_'))) {
                // 2. Boss Chest: Drops either weapon or amulet (30% Epic, 70% Rare, 100% fallback Magic)
                const dungeonLvl = Math.max(1, state.level || 1);
                const bossCategory: 'weapon' | 'trinket' = Math.random() < 0.5 ? 'weapon' : 'trinket';
                let droppedRarity: ItemRarity = 'magic';
                if (Math.random() < 0.30) {
                  droppedRarity = 'epic'; // 30% Epic
                } else if (Math.random() < 0.70) {
                  droppedRarity = 'rare'; // 70% Rare
                } else {
                  droppedRarity = 'magic'; // 100% Magic
                }
                const bossDropItem = generateEquipmentDrop(droppedRarity, dungeonLvl, bossCategory);
                state.lootDrops.push({
                  id: 'boss_drop_' + Date.now() + Math.random(),
                  x: c.x + c.w / 2,
                  y: c.y - 16,
                  vx: (Math.random() - 0.5) * 4,
                  vy: -4.5 - Math.random() * 1.5,
                  type: 'equipment',
                  itemData: bossDropItem,
                  rarity: droppedRarity,
                  alive: true,
                  pickupDelay: 0.5
                });
              } else {
                // 3. Standard Chest Drops per User Directives:
                // - 100% Heart (guaranteed, not reduced)
                // - Reduced by 40% for other loot:
                //   - 60% Mist Shard (iron_ore x2) [was 100%]
                //   - 48% Magic Crystal (magic_crystal x1) [was 80%]
                //   - 30% Monster Core (monster_core x1) [was 50%]
                //   - 12% Void Sigil (ancient_rune x1) [was 20%]
                //   - 60% Equipment item [was 100%]: 5% epic, 20% rare, 75% magic
                // - Items scatter widely apart across the platform floor (non-clumped)
                const pendingDrops: LootDrop[] = [];

                // A. Guaranteed Heart (100% chance for every chest)
                pendingDrops.push({
                  id: 'chest_heart_' + Date.now() + Math.random(),
                  x: c.x + c.w / 2,
                  y: c.y - 12,
                  vx: 0,
                  vy: 0,
                  type: 'hp',
                  amount: 1,
                  alive: true,
                  pickupDelay: 0.65
                });

                // B. Resource Drops (-40% chances):
                // 60% Mist Shard (iron_ore) x2
                if (Math.random() < 0.60) {
                  pendingDrops.push({
                    id: 'chest_res_mist_' + Date.now() + Math.random(),
                    x: c.x + c.w / 2,
                    y: c.y - 16,
                    vx: 0,
                    vy: 0,
                    type: 'ingredient',
                    ingredientType: 'iron_ore',
                    amount: 2,
                    alive: true,
                    pickupDelay: 0.65
                  });
                }

                // 48% Magic Crystal (magic_crystal) x1
                if (Math.random() < 0.48) {
                  pendingDrops.push({
                    id: 'chest_res_crys_' + Date.now() + Math.random(),
                    x: c.x + c.w / 2,
                    y: c.y - 16,
                    vx: 0,
                    vy: 0,
                    type: 'ingredient',
                    ingredientType: 'magic_crystal',
                    amount: 1,
                    alive: true,
                    pickupDelay: 0.65
                  });
                }

                // 30% Monster Core (monster_core) x1
                if (Math.random() < 0.30) {
                  pendingDrops.push({
                    id: 'chest_res_core_' + Date.now() + Math.random(),
                    x: c.x + c.w / 2,
                    y: c.y - 16,
                    vx: 0,
                    vy: 0,
                    type: 'ingredient',
                    ingredientType: 'monster_core',
                    amount: 1,
                    alive: true,
                    pickupDelay: 0.65
                  });
                }

                // 12% Void Sigil (ancient_rune) x1
                if (Math.random() < 0.12) {
                  pendingDrops.push({
                    id: 'chest_res_rune_' + Date.now() + Math.random(),
                    x: c.x + c.w / 2,
                    y: c.y - 16,
                    vx: 0,
                    vy: 0,
                    type: 'ingredient',
                    ingredientType: 'ancient_rune',
                    amount: 1,
                    alive: true,
                    pickupDelay: 0.65
                  });
                }

                // C. Equipment Item (-40% overall chance = 60% chance to drop 1 item)
                if (Math.random() < 0.60) {
                  const dungeonLvl = Math.max(1, state.level || 1);
                  const equipRoll = Math.random();
                  let droppedRarity: ItemRarity = 'magic';
                  if (equipRoll < 0.05) {
                    droppedRarity = 'epic'; // 5% epic
                  } else if (equipRoll < 0.05 + 0.20) {
                    droppedRarity = 'rare'; // 20% rare
                  } else {
                    droppedRarity = 'magic'; // 75% magic/green
                  }

                  const equipItem = generateEquipmentDrop(droppedRarity, dungeonLvl);
                  pendingDrops.push({
                    id: 'chest_eq_' + Date.now() + Math.random(),
                    x: c.x + c.w / 2,
                    y: c.y - 16,
                    vx: 0,
                    vy: 0,
                    type: 'equipment',
                    itemData: equipItem,
                    rarity: droppedRarity,
                    alive: true,
                    pickupDelay: 0.65
                  });
                }

                // Smooth wide radial distribution so items scatter far apart (non-clumped)
                const totalDrops = pendingDrops.length;
                pendingDrops.forEach((drop, idx) => {
                  const spreadArc = Math.PI * 0.8; // 144 degree wide arc
                  const baseAngle = -Math.PI / 2;
                  const angle = totalDrops === 1
                    ? (baseAngle + (Math.random() - 0.5) * 0.4)
                    : (baseAngle - spreadArc / 2 + (idx / (totalDrops - 1)) * spreadArc + (Math.random() - 0.5) * 0.15);
                  const speed = 4.5 + Math.random() * 2.5;
                  drop.vx = Math.cos(angle) * speed;
                  drop.vy = Math.sin(angle) * speed - 1.5;
                  drop.x = c.x + c.w / 2 + (idx - (totalDrops - 1) / 2) * 14;
                  state.lootDrops.push(drop);
                });
              }

              for (let j = 0; j < 12; j++) {
                state.particles.push({
                  x: c.x + c.w / 2, y: c.y + c.h / 2,
                  vx: (Math.random() - 0.5) * 14, vy: (Math.random() - 0.5) * 14,
                  life: 0.9, maxLife: 0.9,
                  color: Math.random() > 0.4 ? '#fbbf24' : (Math.random() > 0.5 ? '#ef4444' : '#38bdf8'),
                  size: 4.5
                });
              }
              break;
            }
          }
        });
        state.chests = state.chests.filter(c => !c.opened);

        // Destructible Props (Barrels, Crates, Pots/Urns) breaking - instant, crisp destruction with debris particles just like chests
        if (state.dungeonDecorations && state.dungeonDecorations.length > 0) {
          state.dungeonDecorations.forEach((dec: any) => {
            if (!dec.isDestructible || dec.opened || dec.alive === false) return;
            const propRadius = (dec.w ? dec.w / 2 : 16) + 14;
            for (let pt of bladeCheckPoints) {
              if (Math.hypot(pt.x - dec.x, pt.y - dec.y) < propRadius) {
                dec.opened = true;
                dec.alive = false;
                rebuildObstacleColliders();
                soundManager.playHit(true, weaponRef.current?.type);

                const isWood = dec.subtype === 'barrels' || dec.subtype === 'crate';
                const isPot = dec.subtype === 'pot' || dec.subtype === 'pot2';
                for (let j = 0; j < 12; j++) {
                  let pColor = isWood 
                    ? (Math.random() < 0.5 ? '#b45309' : (Math.random() < 0.5 ? '#78350f' : '#f59e0b'))
                    : (isPot ? (Math.random() < 0.5 ? '#ea580c' : (Math.random() < 0.5 ? '#c2410c' : '#fed7aa'))
                             : (Math.random() < 0.5 ? '#64748b' : '#334155'));
                  state.particles.push({
                    x: dec.x + (Math.random() - 0.5) * 16,
                    y: dec.y + (Math.random() - 0.5) * 16,
                    vx: (Math.random() - 0.5) * 14,
                    vy: (Math.random() - 0.5) * 14 - 2,
                    life: 0.85,
                    maxLife: 0.85,
                    color: pColor,
                    size: Math.random() * 4 + 2.5
                  });
                }
                state.screenShake = Math.max(state.screenShake, 3.0);
                dropMobLoot(dec.x, dec.y, 'prop_' + (dec.subtype || 'crate'));
                break;
              }
            }
          });
          state.dungeonDecorations = state.dungeonDecorations.filter((d: any) => !d.isDestructible || (!d.opened && d.alive !== false));
        }

        // Walls interaction & weapon collision recoil (hits like enemies / clash instead of pushing out)
        let recoiledThisFrame = false;
        
        for (let w of state.walls) {
          if (!w.alive || recoiledThisFrame) continue;
          
          if (Math.abs(w.x - state.player.x) > w.w + 140 || Math.abs(w.y - state.player.y) > w.h + 140) continue;

          let collided = false;
          let hitPt = { x: 0, y: 0 };

          for (let pt of bladeCheckPoints) {
            if (pt.x >= w.x - 2 && pt.x <= w.x + w.w + 2 && pt.y >= w.y - 2 && pt.y <= w.y + w.h + 2) {
              collided = true;
              hitPt = { x: pt.x, y: pt.y };
              break;
            }
          }

          if (collided) {
            // Sword recoil bounce & clash behavior (like hitting an enemy)
            if (state.ropePoints.length > 1) {
              const last = state.ropePoints[state.ropePoints.length - 1];
              const prev = state.ropePoints[state.ropePoints.length - 2];
              const sang = Math.atan2(last.y - prev.y, last.x - prev.x);
              last.x -= Math.cos(sang) * 11;
              last.y -= Math.sin(sang) * 11;
            }
            state.swordLock = getAttackRecoveryTimeSec();
            soundManager.playClash();

            // Sparks / particles on wall clash
            for (let s = 0; s < 6; s++) {
              state.particles.push({
                x: hitPt.x,
                y: hitPt.y,
                vx: (Math.random() - 0.5) * 10,
                vy: (Math.random() - 0.5) * 10,
                life: 0.5,
                maxLife: 0.5,
                color: '#f59e0b',
                size: 3.5
              });
            }

            recoiledThisFrame = true;
            break;
          }
        }
      }

      // --- ENEMIES COMBAT & UPDATE ---
      const playerCenterX = state.player.x + state.player.w / 2;
      const playerCenterY = state.player.y + state.player.h / 2;

      state.enemies.forEach(en => {
        if (!en.alive) return;

        en.stunTimer = Math.max(0, (en.stunTimer || 0) - (step / 60));
        
        // Bleed effect processing ("Рваная рана" - 2.5 сек, раз в 0.5 сек с шансом на крит, стакается)
        if (en.bleedStacks && en.bleedStacks.length > 0) {
          let hasDied = false;
          for (let sIdx = en.bleedStacks.length - 1; sIdx >= 0; sIdx--) {
            const stack = en.bleedStacks[sIdx];
            stack.timer -= dt / 1000;
            stack.tickTimer = (stack.tickTimer || 0) - (dt / 1000);
            if (stack.tickTimer <= 0) {
              stack.tickTimer = 0.5; // Tick once every 0.5 seconds
              
              // Calculate critical strike for this bleed tick based on player's crit chance & crit multiplier
              const { critChance: totalCrit, critMultiplier: critMult } = getPlayerCritStats();
              
              const isCrit = Math.random() < totalCrit;
              let tickDmg = stack.baseTickDamage || 1;
              if (isCrit) {
                tickDmg = Math.round(tickDmg * critMult);
              } else {
                tickDmg = Math.round(tickDmg);
              }
              tickDmg = Math.max(1, tickDmg);

              // Immunity check: Fatty (Pylons), Saw (Explosion), Phantom (Flickering)
              const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
              const isImmuneFatty = en.type === 'fatty' && hasActivePylons;
              const isImmuneSaw = en.type === 'saw' && Boolean(en.isChargingExplosion);
              const isImmuneWhitePhantom = en.type === 'phantom' && Boolean(en.isFlickering);
              
              if (!(isImmuneFatty || isImmuneSaw || isImmuneWhitePhantom)) {
                en.hp -= tickDmg;
                // Vampirism does NOT trigger from bleed damage
                
                state.damageTexts.push({
                  id: 'dmg_bleed_' + Date.now() + Math.random(),
                  text: `🩸 -${tickDmg}`,
                  x: en.x + (Math.random() - 0.5) * 14,
                  y: en.y - 20 - (Math.random() - 0.5) * 10,
                  vx: (Math.random() - 0.5) * (isCrit ? 4 : 2), 
                  vy: isCrit ? -5 : -3,
                  life: isCrit ? 1.2 : 0.8,
                  isCrit: isCrit,
                  color: isCrit ? '#f59e0b' : '#ef4444' // Gold if crit, blood red if normal
                });
              }

              // Blood particles
              const pCount = isCrit ? 6 : 3;
              for(let i = 0; i < pCount; i++) {
                state.particles.push({
                  x: en.x, y: en.y,
                  vx: (Math.random() - 0.5) * (isCrit ? 6 : 4), 
                  vy: (Math.random() - 0.5) * (isCrit ? 6 : 4),
                  life: 0.5, maxLife: 0.5, 
                  color: isCrit ? '#f59e0b' : '#ef4444', 
                  size: isCrit ? 3 : 2
                });
              }

              if (en.hp <= 0 && en.alive) {
                killEnemy(en);
                hasDied = true;
                break;
              }
            }
            if (stack.timer <= 0) {
              en.bleedStacks.splice(sIdx, 1);
            }
          }
          if (hasDied) return;
          en.bleedTimer = en.bleedStacks.length > 0 ? Math.max(...en.bleedStacks.map((s: any) => s.timer)) : 0;
        } else if ((en.bleedTimer || 0) > 0) {
          // Fallback legacy single bleed
          en.bleedTimer -= dt / 1000;
          en.bleedTickTimer = (en.bleedTickTimer || 0) - (dt / 1000);
          if (en.bleedTickTimer <= 0) {
            en.bleedTickTimer = 0.5;
            const { critChance: totalCrit, critMultiplier: critMult } = getPlayerCritStats();
            const isCrit = Math.random() < totalCrit;
            let tickDmg = Math.max(1, Math.round(isCrit ? (en.bleedBaseTickDamage || 1) * critMult : (en.bleedBaseTickDamage || 1)));
            const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
            if (!(en.type === 'fatty' && hasActivePylons)) {
              en.hp -= tickDmg;
              state.damageTexts.push({
                id: 'dmg_bleed_' + Date.now() + Math.random(),
                text: `🩸 -${tickDmg}`,
                x: en.x, y: en.y - 20,
                vx: (Math.random() - 0.5) * 2, vy: -3,
                life: 0.8, isCrit, color: isCrit ? '#f59e0b' : '#ef4444'
              });
            }
            if (en.hp <= 0 && en.alive) {
              killEnemy(en);
              return;
            }
          }
          if (en.bleedTimer <= 0) {
            en.bleedTimer = 0;
            en.bleedDamagePerSec = 0;
            en.bleedBaseTickDamage = 0;
          }
        }

        if (en.stunTimer > 0) {
          en.vx = 0;
          en.vy = 0;
          en.knockVx = 0;
          en.knockVy = 0;
        }

        // Pylons are completely rooted in place (no movement, no knockback)
        if (en.type === 'pylon') {
          en.vx = 0;
          en.vy = 0;
          en.knockVx = 0;
          en.knockVy = 0;
        }

        // --- Handle Dying Fade Out of original White Phantom ---
        if (en.type === 'phantom' && en.isDyingFadeOut) {
          en.vx = 0;
          en.vy = 0;
          en.knockVx = 0;
          en.knockVy = 0;
          en.fadeAlpha = (en.fadeAlpha !== undefined ? en.fadeAlpha : 1.0) - 0.02 * step; // fade out over ~50 frames
          if (en.fadeAlpha <= 0) {
            en.fadeAlpha = 0;
            // Now actually kill it so it splits and dies
            killEnemy(en);
          }
          return; // Skip standard AI, movement, touch damage, sword damage
        }

        const distToPlayer = Math.hypot(playerCenterX - en.x, playerCenterY - en.y);
        if (distToPlayer > 1800 && en.type !== 'fatty') {
          return;
        }

        if ((en.hitCooldown || 0) > 0) {
          en.hitCooldown -= dt / 1000;
          if (en.hitCooldown <= 0) {
            en.hitCooldown = 0;
            en.isStruck = false;
          }
        } else {
          en.isStruck = false;
        }
        if (en.swordCooldown > 0) en.swordCooldown -= step;

        // Apply temporary knockback displacement while preserving base movement velocity (strictly non-pylons)
        if (en.type !== 'pylon' && (en.knockVx || en.knockVy)) {
          en.x += (en.knockVx || 0) * step;
          en.y += (en.knockVy || 0) * step;
          en.knockVx = (en.knockVx || 0) * Math.pow(0.80, step);
          en.knockVy = (en.knockVy || 0) * Math.pow(0.80, step);
          if (Math.abs(en.knockVx) < 0.05) en.knockVx = 0;
          if (Math.abs(en.knockVy) < 0.05) en.knockVy = 0;
        }

        // AI and Movement skip strictly if stunned
        if ((en.stunTimer || 0) <= 0) {
          if (en.type === 'fatty' || en.type === 'sorcerer' || (en.type === 'knight' && (en.state === 'windup' || en.state === 'strike')) || (en.type === 'saw' && en.isChargingExplosion)) {
            en.vx = 0;
            en.vy = 0;
          } else if (en.type === 'phantom') {
            // Phantom updates its 2-axis ball bouncing in the dedicated phantom state machine below
          } else if (en.type === 'knight') {
          // Knight 4-directional maze navigation & pursuit strictly when player is in the same room
          const knightSpeed = 2.4;
          const pInKnightRoom = en.roomBounds
            ? (playerCenterX >= en.roomBounds.minX - 80 && playerCenterX <= en.roomBounds.maxX + 80 &&
               playerCenterY >= en.roomBounds.minY - 80 && playerCenterY <= en.roomBounds.maxY + 80)
            : isPlayerOnEnemyPlatform(en);

          if (pInKnightRoom && distToPlayer < 385) {
            const angToPlayer = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
            en.vx = Math.cos(angToPlayer) * knightSpeed;
            en.vy = Math.sin(angToPlayer) * knightSpeed;
          } else {
            if (!en.vx && !en.vy) {
              en.vx = (Math.random() > 0.5 ? 1.6 : -1.6);
              en.vy = (Math.random() > 0.5 ? 1.4 : -1.4);
            }
          }

          // Knight X movement & wall collision
          const prevKnightX = en.x;
          en.x += ((en.vx || 0) + (en.knockVx || 0)) * step;
          state.walls.forEach(w => {
            if (!w.alive) return;
            // Fast culling check
            if (Math.abs(w.x - en.x) > w.w + 100 || Math.abs(w.y - en.y) > w.h + 100) return;

            if (en.x + en.r > w.x && en.x - en.r < w.x + w.w &&
                en.y + en.r > w.y && en.y - en.r < w.y + w.h) {
              if (prevKnightX + en.r <= w.x + 2) {
                en.x = w.x - en.r;
                en.vx = -Math.abs(en.vx || 1);
                en.knockVx = -Math.abs(en.knockVx || 0);
              } else if (prevKnightX - en.r >= w.x + w.w - 2) {
                en.x = w.x + w.w + en.r;
                en.vx = Math.abs(en.vx || 1);
                en.knockVx = Math.abs(en.knockVx || 0);
              } else {
                const overlapLeft = (en.x + en.r) - w.x;
                const overlapRight = (w.x + w.w) - (en.x - en.r);
                if (overlapLeft < overlapRight) {
                  en.x = w.x - en.r;
                  en.vx = -Math.abs(en.vx || 1);
                  en.knockVx = -Math.abs(en.knockVx || 0);
                } else {
                  en.x = w.x + w.w + en.r;
                  en.vx = Math.abs(en.vx || 1);
                  en.knockVx = Math.abs(en.knockVx || 0);
                }
              }
            }
          });

          obstacleColliders.forEach(obs => {
            if (Math.abs(obs.x - en.x) > obs.w + 100 || Math.abs(obs.y - en.y) > obs.h + 100) return;
            if (en.x + en.r > obs.x && en.x - en.r < obs.x + obs.w &&
                en.y + en.r > obs.y && en.y - en.r < obs.y + obs.h) {
              if (prevKnightX + en.r <= obs.x + 2) {
                en.x = obs.x - en.r;
                en.vx = -Math.abs(en.vx || 1);
                en.knockVx = -Math.abs(en.knockVx || 0);
              } else if (prevKnightX - en.r >= obs.x + obs.w - 2) {
                en.x = obs.x + obs.w + en.r;
                en.vx = Math.abs(en.vx || 1);
                en.knockVx = Math.abs(en.knockVx || 0);
              } else {
                const overlapLeft = (en.x + en.r) - obs.x;
                const overlapRight = (obs.x + obs.w) - (en.x - en.r);
                if (overlapLeft < overlapRight) {
                  en.x = obs.x - en.r;
                  en.vx = -Math.abs(en.vx || 1);
                  en.knockVx = -Math.abs(en.knockVx || 0);
                } else {
                  en.x = obs.x + obs.w + en.r;
                  en.vx = Math.abs(en.vx || 1);
                  en.knockVx = Math.abs(en.knockVx || 0);
                }
              }
            }
          });

          // Knight Y movement & wall collision
          const prevKnightY = en.y;
          en.y += ((en.vy || 0) + (en.knockVy || 0)) * step;
          state.walls.forEach(w => {
            if (!w.alive) return;
            // Fast culling check
            if (Math.abs(w.x - en.x) > w.w + 100 || Math.abs(w.y - en.y) > w.h + 100) return;

            if (en.x + en.r > w.x && en.x - en.r < w.x + w.w &&
                en.y + en.r > w.y && en.y - en.r < w.y + w.h) {
              if (prevKnightY + en.r <= w.y + 2) {
                en.y = w.y - en.r;
                en.vy = -Math.abs(en.vy || 1);
                en.knockVy = -Math.abs(en.knockVy || 0);
              } else if (prevKnightY - en.r >= w.y + w.h - 2) {
                en.y = w.y + w.h + en.r;
                en.vy = Math.abs(en.vy || 1);
                en.knockVy = Math.abs(en.knockVy || 0);
              } else {
                const overlapTop = (en.y + en.r) - w.y;
                const overlapBottom = (w.y + w.h) - (en.y - en.r);
                if (overlapTop < overlapBottom) {
                  en.y = w.y - en.r;
                  en.vy = -Math.abs(en.vy || 1);
                  en.knockVy = -Math.abs(en.knockVy || 0);
                } else {
                  en.y = w.y + w.h + en.r;
                  en.vy = Math.abs(en.vy || 1);
                  en.knockVy = Math.abs(en.knockVy || 0);
                }
              }
            }
          });

          obstacleColliders.forEach(obs => {
            if (Math.abs(obs.x - en.x) > obs.w + 100 || Math.abs(obs.y - en.y) > obs.h + 100) return;
            if (en.x + en.r > obs.x && en.x - en.r < obs.x + obs.w &&
                en.y + en.r > obs.y && en.y - en.r < obs.y + obs.h) {
              if (prevKnightY + en.r <= obs.y + 2) {
                en.y = obs.y - en.r;
                en.vy = -Math.abs(en.vy || 1);
                en.knockVy = -Math.abs(en.knockVy || 0);
              } else if (prevKnightY - en.r >= obs.y + obs.h - 2) {
                en.y = obs.y + obs.h + en.r;
                en.vy = Math.abs(en.vy || 1);
                en.knockVy = Math.abs(en.knockVy || 0);
              } else {
                const overlapTop = (en.y + en.r) - obs.y;
                const overlapBottom = (obs.y + obs.h) - (en.y - en.r);
                if (overlapTop < overlapBottom) {
                  en.y = obs.y - en.r;
                  en.vy = -Math.abs(en.vy || 1);
                  en.knockVy = -Math.abs(en.knockVy || 0);
                } else {
                  en.y = obs.y + obs.h + en.r;
                  en.vy = Math.abs(en.vy || 1);
                  en.knockVy = Math.abs(en.knockVy || 0);
                }
              }
            }
          });

          // Keep knight inside its room boundaries
          if (en.roomBounds) {
            if (en.x - en.r < en.roomBounds.minX) {
              en.x = en.roomBounds.minX + en.r;
              en.vx = Math.abs(en.vx || 1.4);
              en.knockVx = Math.abs(en.knockVx || 0);
            } else if (en.x + en.r > en.roomBounds.maxX) {
              en.x = en.roomBounds.maxX - en.r;
              en.vx = -Math.abs(en.vx || 1.4);
              en.knockVx = -Math.abs(en.knockVx || 0);
            }
            if (en.y - en.r < en.roomBounds.minY) {
              en.y = en.roomBounds.minY + en.r;
              en.vy = Math.abs(en.vy || 1.4);
              en.knockVy = Math.abs(en.knockVy || 0);
            } else if (en.y + en.r > en.roomBounds.maxY) {
              en.y = en.roomBounds.maxY - en.r;
              en.vy = -Math.abs(en.vy || 1.4);
              en.knockVy = -Math.abs(en.knockVy || 0);
            }
          }
        } else if (en.type === 'saw' && en.isSpittingInAir) {
          // Ball flight physics while spat out in air by Fatty
          en.x += (en.spitVx || 0) * step;
          en.y += (en.spitVy || 0) * step;
          en.spitVy = (en.spitVy || 0) + 0.35 * step;
          en.angle += 0.25 * step;

          // Parabolic flight sparks trail
          if (Math.random() < 0.3) {
            state.particles.push({
              x: en.x,
              y: en.y,
              vx: (Math.random() - 0.5) * 2,
              vy: (Math.random() - 0.5) * 2,
              life: 0.2,
              maxLife: 0.2,
              color: en.isRedSaw ? '#ef4444' : '#38bdf8',
              size: 2.5
            });
          }

          const landingY = en.targetLandingY !== undefined ? en.targetLandingY : (en.parent ? (en.parent.y + en.parent.height - 100) : en.y);
          if (en.y >= landingY && (en.spitVy || 0) > 0) {
            en.y = landingY;
            if (en.roomBounds) {
              en.x = Math.max(en.roomBounds.minX + en.r, Math.min(en.roomBounds.maxX - en.r, en.x));
              en.y = Math.max(en.roomBounds.minY + en.r, Math.min(en.roomBounds.maxY - en.r, en.y));
            }
            en.isSpittingInAir = false;

            // Choose random movement vector on landing
            const lvl = Math.max(1, state.level || statsRef.current.level || 1);
            const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;
            const baseSpd = (2.2 + Math.random() * 1.2) * lvlSpeedMult;
            const randAng = Math.random() * Math.PI * 2;
            en.vx = Math.cos(randAng) * baseSpd;
            en.vy = Math.sin(randAng) * baseSpd;

            for (let p = 0; p < 8; p++) {
              state.particles.push({
                x: en.x, y: en.y,
                vx: (Math.random() - 0.5) * 6,
                vy: -Math.random() * 4,
                life: 0.35, maxLife: 0.35,
                color: en.isRedSaw ? '#ef4444' : '#38bdf8',
                size: 3
              });
            }
          }
        } else {
          // Move saw/ice mobs with random vector inside their rooms
          if (!en.vx && !en.vy) {
            const baseSpd = 2.0;
            const randAng = Math.random() * Math.PI * 2;
            en.vx = Math.cos(randAng) * baseSpd;
            en.vy = Math.sin(randAng) * baseSpd;
          }

          // X movement & wall collision
          const prevMobX = en.x;
          en.x += ((en.vx || 0) + (en.knockVx || 0)) * step;
          state.walls.forEach(w => {
            if (!w.alive) return;
            // Fast culling check
            if (Math.abs(w.x - en.x) > w.w + 100 || Math.abs(w.y - en.y) > w.h + 100) return;

            if (en.x + en.r > w.x && en.x - en.r < w.x + w.w &&
                en.y + en.r > w.y && en.y - en.r < w.y + w.h) {
              if (prevMobX + en.r <= w.x + 2) {
                en.x = w.x - en.r;
                en.vx = -Math.abs(en.vx || 1);
                en.knockVx = -Math.abs(en.knockVx || 0);
              } else if (prevMobX - en.r >= w.x + w.w - 2) {
                en.x = w.x + w.w + en.r;
                en.vx = Math.abs(en.vx || 1);
                en.knockVx = Math.abs(en.knockVx || 0);
              } else {
                const overlapLeft = (en.x + en.r) - w.x;
                const overlapRight = (w.x + w.w) - (en.x - en.r);
                if (overlapLeft < overlapRight) {
                  en.x = w.x - en.r;
                  en.vx = -Math.abs(en.vx || 1);
                  en.knockVx = -Math.abs(en.knockVx || 0);
                } else {
                  en.x = w.x + w.w + en.r;
                  en.vx = Math.abs(en.vx || 1);
                  en.knockVx = Math.abs(en.knockVx || 0);
                }
              }
            }
          });

          obstacleColliders.forEach(obs => {
            if (Math.abs(obs.x - en.x) > obs.w + 100 || Math.abs(obs.y - en.y) > obs.h + 100) return;
            if (en.x + en.r > obs.x && en.x - en.r < obs.x + obs.w &&
                en.y + en.r > obs.y && en.y - en.r < obs.y + obs.h) {
              if (prevMobX + en.r <= obs.x + 2) {
                en.x = obs.x - en.r;
                en.vx = -Math.abs(en.vx || 1);
                en.knockVx = -Math.abs(en.knockVx || 0);
              } else if (prevMobX - en.r >= obs.x + obs.w - 2) {
                en.x = obs.x + obs.w + en.r;
                en.vx = Math.abs(en.vx || 1);
                en.knockVx = Math.abs(en.knockVx || 0);
              } else {
                const overlapLeft = (en.x + en.r) - obs.x;
                const overlapRight = (obs.x + obs.w) - (en.x - en.r);
                if (overlapLeft < overlapRight) {
                  en.x = obs.x - en.r;
                  en.vx = -Math.abs(en.vx || 1);
                  en.knockVx = -Math.abs(en.knockVx || 0);
                } else {
                  en.x = obs.x + obs.w + en.r;
                  en.vx = Math.abs(en.vx || 1);
                  en.knockVx = Math.abs(en.knockVx || 0);
                }
              }
            }
          });

          // Y movement & wall collision
          const prevMobY = en.y;
          en.y += ((en.vy || 0) + (en.knockVy || 0)) * step;
          state.walls.forEach(w => {
            if (!w.alive) return;
            // Fast culling check
            if (Math.abs(w.x - en.x) > w.w + 100 || Math.abs(w.y - en.y) > w.h + 100) return;

            if (en.x + en.r > w.x && en.x - en.r < w.x + w.w &&
                en.y + en.r > w.y && en.y - en.r < w.y + w.h) {
              if (prevMobY + en.r <= w.y + 2) {
                en.y = w.y - en.r;
                en.vy = -Math.abs(en.vy || 1);
                en.knockVy = -Math.abs(en.knockVy || 0);
              } else if (prevMobY - en.r >= w.y + w.h - 2) {
                en.y = w.y + w.h + en.r;
                en.vy = Math.abs(en.vy || 1);
                en.knockVy = Math.abs(en.knockVy || 0);
              } else {
                const overlapTop = (en.y + en.r) - w.y;
                const overlapBottom = (w.y + w.h) - (en.y - en.r);
                if (overlapTop < overlapBottom) {
                  en.y = w.y - en.r;
                  en.vy = -Math.abs(en.vy || 1);
                  en.knockVy = -Math.abs(en.knockVy || 0);
                } else {
                  en.y = w.y + w.h + en.r;
                  en.vy = Math.abs(en.vy || 1);
                  en.knockVy = Math.abs(en.knockVy || 0);
                }
              }
            }
          });

          obstacleColliders.forEach(obs => {
            if (Math.abs(obs.x - en.x) > obs.w + 100 || Math.abs(obs.y - en.y) > obs.h + 100) return;
            if (en.x + en.r > obs.x && en.x - en.r < obs.x + obs.w &&
                en.y + en.r > obs.y && en.y - en.r < obs.y + obs.h) {
              if (prevMobY + en.r <= obs.y + 2) {
                en.y = obs.y - en.r;
                en.vy = -Math.abs(en.vy || 1);
                en.knockVy = -Math.abs(en.knockVy || 0);
              } else if (prevMobY - en.r >= obs.y + obs.h - 2) {
                en.y = obs.y + obs.h + en.r;
                en.vy = Math.abs(en.vy || 1);
                en.knockVy = Math.abs(en.knockVy || 0);
              } else {
                const overlapTop = (en.y + en.r) - obs.y;
                const overlapBottom = (obs.y + obs.h) - (en.y - en.r);
                if (overlapTop < overlapBottom) {
                  en.y = obs.y - en.r;
                  en.vy = -Math.abs(en.vy || 1);
                  en.knockVy = -Math.abs(en.knockVy || 0);
                } else {
                  en.y = obs.y + obs.h + en.r;
                  en.vy = Math.abs(en.vy || 1);
                  en.knockVy = Math.abs(en.knockVy || 0);
                }
              }
            }
          });

          // Keep saw/ice mobs strictly inside room boundaries (never enter corridors/passages)
          if (en.roomBounds) {
            if (en.x - en.r < en.roomBounds.minX) {
              en.x = en.roomBounds.minX + en.r;
              en.vx = Math.abs(en.vx || 1.8);
              en.knockVx = Math.abs(en.knockVx || 0);
            } else if (en.x + en.r > en.roomBounds.maxX) {
              en.x = en.roomBounds.maxX - en.r;
              en.vx = -Math.abs(en.vx || 1.8);
              en.knockVx = -Math.abs(en.knockVx || 0);
            }
            if (en.y - en.r < en.roomBounds.minY) {
              en.y = en.roomBounds.minY + en.r;
              en.vy = Math.abs(en.vy || 1.8);
              en.knockVy = Math.abs(en.knockVy || 0);
            } else if (en.y + en.r > en.roomBounds.maxY) {
              en.y = en.roomBounds.maxY - en.r;
              en.vy = -Math.abs(en.vy || 1.8);
              en.knockVy = -Math.abs(en.knockVy || 0);
            }
          }
        }

        // Specific Enemy AI
        if (en.type === 'pylon') {
          en.vx = 0;
          en.vy = 0;
          en.spawnTimer = (en.spawnTimer || 0) + step;
          en.angle = (en.angle || 0) + 0.04 * step;
          if (Math.random() < 0.25) {
            const pAng = Math.random() * Math.PI * 2;
            const pDist = 15 + Math.random() * 20;
            state.particles.push({
              x: en.x + Math.cos(pAng) * pDist,
              y: en.y + Math.sin(pAng) * pDist,
              vx: -Math.cos(pAng) * 1.5,
              vy: -Math.sin(pAng) * 1.5 - 1.0,
              life: 0.35,
              maxLife: 0.35,
              color: Math.random() < 0.5 ? '#c084fc' : '#a855f7',
              size: 3
            });
          }
        }
        if (en.type === 'saw') {
          if (en.isChargingExplosion) {
            en.vx = 0;
            en.vy = 0;
            en.explosionTimer = (en.explosionTimer || 0) + step;
            en.angle += 0.35 * step; // fast spinning while charging
            
            // Gather violent energy particles (spherical energy buildup like Fatty's laser phase)
            if (Math.random() < 0.4) {
              const pAng = Math.random() * Math.PI * 2;
              const pDist = 30 + Math.random() * 40;
              state.particles.push({
                x: en.x + Math.cos(pAng) * pDist,
                y: en.y + Math.sin(pAng) * pDist,
                vx: -Math.cos(pAng) * 4.0,
                vy: -Math.sin(pAng) * 4.0,
                life: 0.3,
                maxLife: 0.3,
                color: Math.random() < 0.5 ? '#ef4444' : '#f97316',
                size: Math.random() * 4 + 2
              });
            }

            if (en.explosionTimer >= (en.maxExplosionTimer || 90)) {
              en.explosionFinished = true;
              en.isChargingExplosion = false;
              
              // Big spherical explosion!
              soundManager.playLoot();
              state.screenShake = 14;
              state.shockwaves.push({
                x: en.x, y: en.y,
                r: 10, maxR: 125,
                color: '#ef4444',
                life: 1, maxLife: 1
              });

              // Check AoE damage to player
              const pDist = Math.hypot(playerCenterX - en.x, playerCenterY - en.y);
              if (pDist <= 125) {
                takeDamage(en.x, getEnemyDamage('saw_explosion'));
              }

              // Fire/plasma explosion particles
              for (let i = 0; i < 18; i++) {
                const ang = Math.random() * Math.PI * 2;
                const spd = 4 + Math.random() * 12;
                state.particles.push({
                  x: en.x, y: en.y,
                  vx: Math.cos(ang) * spd,
                  vy: Math.sin(ang) * spd,
                  life: 0.7, maxLife: 0.7,
                  color: Math.random() < 0.4 ? '#fee2e2' : Math.random() < 0.7 ? '#ef4444' : '#f97316',
                  size: Math.random() * 5 + 3,
                  shape: Math.random() < 0.5 ? 'spark' : 'circle'
                });
              }

              // Finally kill the saw completely
              killEnemy(en);
            }
          } else {
            en.angle += 0.12 * step * Math.sign(en.vx || 1);
          }
        } else if (en.type === 'sorcerer') {
          // Sorcerer Enemy: stays strictly within its spawn room, charges magic, shoots bolt or casts frost nova, and shifts/teleports within the room
          en.facingDir = playerCenterX >= en.x ? 1 : -1;
          const lvl = Math.max(1, state.level || statsRef.current.level || 1);
          const chargeFactor = 1.0 + (lvl - 1) * 0.025;
          const isFrost = !!en.isFrostMage;

          // Always clamp sorcerer strictly inside its spawn room
          if (en.roomBounds) {
            const pad = en.r + 14;
            en.x = Math.max(en.roomBounds.minX + pad, Math.min(en.roomBounds.maxX - pad, en.x));
            en.y = Math.max(en.roomBounds.minY + pad, Math.min(en.roomBounds.maxY - pad, en.y));
          }

          const isPlayerInRoom = en.roomBounds ? (
            playerCenterX >= en.roomBounds.minX - 50 && playerCenterX <= en.roomBounds.maxX + 50 &&
            playerCenterY >= en.roomBounds.minY - 50 && playerCenterY <= en.roomBounds.maxY + 50
          ) : isPlayerOnEnemyPlatform(en);

          if ((isPlayerInRoom || isPlayerOnEnemyPlatform(en)) && distToPlayer < 455) {
            if (en.state === 'idle') {
              if (en.cooldownTimer > 0) {
                en.cooldownTimer -= step;
              } else {
                en.state = 'charging';
                en.shootTimer = 0;
                en.chargeProgress = 0;
              }
            } else if (en.state === 'charging') {
              en.shootTimer += step * chargeFactor;
              en.chargeProgress = Math.min(1.0, en.shootTimer / 37.5);

              // Hovering drift within room during windup
              en.hoverTimer = (en.hoverTimer || 0) + 0.08 * step;
              en.x += Math.cos(en.hoverTimer) * 0.45;
              en.y += Math.sin(en.hoverTimer * 1.4) * 0.35;

              // Swirling magic particles (light blue for frost, purple for normal)
              if (Math.random() < 0.3) {
                const pAng = Math.random() * Math.PI * 2;
                const pDist = 25 + Math.random() * 30;
                state.particles.push({
                  x: en.x + Math.cos(pAng) * pDist,
                  y: en.y + Math.sin(pAng) * pDist,
                  vx: -Math.cos(pAng) * 2.5,
                  vy: -Math.sin(pAng) * 2.5,
                  life: 0.4,
                  maxLife: 0.4,
                  color: isFrost
                    ? (Math.random() < 0.5 ? '#38bdf8' : '#bae6fd')
                    : (Math.random() < 0.5 ? '#c084fc' : '#a855f7'),
                  size: Math.random() * 3 + 2
                });
              }

              if (en.shootTimer >= 37.5) {
                if (isFrost) {
                  // Cast Frost Nova around blue sorcerer: beautiful crystalline frost circle AoE + slow + instant teleport!
                  soundManager.playIceShot();
                  state.shockwaves.push({
                    x: en.x, y: en.y,
                    r: 10, maxR: 135,
                    color: '#38bdf8',
                    life: 1, maxLife: 1,
                    isFrostNova: true
                  });

                  // Frost crystalline particle sparks radiating outward
                  for (let i = 0; i < 15; i++) {
                    const ang = (i / 15) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
                    const spd = 6 + Math.random() * 8;
                    state.particles.push({
                      x: en.x, y: en.y,
                      vx: Math.cos(ang) * spd,
                      vy: Math.sin(ang) * spd,
                      life: 0.65, maxLife: 0.65,
                      color: i % 2 === 0 ? '#bae6fd' : '#38bdf8',
                      size: Math.random() * 4 + 2.5,
                      shape: 'spark'
                    });
                  }

                  // Damage and slow player if caught in Frost Nova
                  const pDist = Math.hypot(playerCenterX - en.x, playerCenterY - en.y);
                  if (pDist <= 135) {
                    takeDamage(en.x, getEnemyDamage('sorcerer_nova'));
                    state.player.slowTimer = Math.max(state.player.slowTimer || 0, 100);
                    state.damageTexts.push({
                      id: 'slow_' + Date.now() + Math.random(),
                      text: 'ЗАМЕДЛЕНИЕ!',
                      x: playerCenterX, y: playerCenterY - 25,
                      vx: 0, vy: -3,
                      life: 1.5,
                      isCrit: true,
                      color: '#38bdf8'
                    });
                  }
                } else {
                  const angleToPlayer = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
                  // Shoot magical purple bolt! (2x slower speed: 8.0)
                  state.iceProjectiles.push({
                    x: en.x,
                    y: en.y,
                    vx: Math.cos(angleToPlayer) * 8.0,
                    vy: Math.sin(angleToPlayer) * 8.0,
                    alive: true,
                    isReflected: false,
                    life: 6.0,
                    isMagicBolt: true
                  });
                  soundManager.playSwing(1.6);
                }

                // Transition to teleporting state to relocate within its spawn room
                en.state = 'teleporting';
                en.teleportTimer = 0;
              }
            } else if (en.state === 'teleporting') {
              en.teleportTimer += step;

              // Burst magic particles around old location
              if (Math.random() < 0.45) {
                state.particles.push({
                  x: en.x + (Math.random() - 0.5) * 30,
                  y: en.y + (Math.random() - 0.5) * 30,
                  vx: (Math.random() - 0.5) * 5,
                  vy: (Math.random() - 0.5) * 5,
                  life: 0.4,
                  maxLife: 0.4,
                  color: isFrost ? '#38bdf8' : '#c084fc',
                  size: Math.random() * 4 + 2
                });
              }

              if (en.teleportTimer >= 22) {
                // Select a teleport destination strictly within the room where the sorcerer was spawned, avoiding walls
                const rb = en.roomBounds || (en.parent ? {
                  minX: en.parent.x,
                  maxX: en.parent.x + en.parent.width,
                  minY: en.parent.y,
                  maxY: en.parent.y + en.parent.height
                } : null);

                let targetX = en.x;
                let targetY = en.y;

                if (rb) {
                  const padding = 55;
                  const minX = rb.minX + padding;
                  const maxX = rb.maxX - padding;
                  const minY = rb.minY + padding;
                  const maxY = rb.maxY - padding;

                  // Find valid candidate points strictly within the room that do not collide with any walls
                  const candidates: { x: number; y: number }[] = [];
                  if (en.floorZones && en.floorZones.length > 0) {
                    for (let attempt = 0; attempt < 35; attempt++) {
                      const z = en.floorZones[Math.floor(Math.random() * en.floorZones.length)];
                      const pad = 24;
                      const cx = z.x + pad + Math.random() * Math.max(10, z.w - pad * 2);
                      const cy = z.y + pad + Math.random() * Math.max(10, z.h - pad * 2);
                      const collidesWithWall = state.walls.some(w => {
                        if (!w.alive) return false;
                        const safetyDist = 28;
                        return cx + safetyDist > w.x && cx - safetyDist < w.x + w.w &&
                               cy + safetyDist > w.y && cy - safetyDist < w.y + w.h;
                      });
                      if (!collidesWithWall) candidates.push({ x: cx, y: cy });
                    }
                  } else {
                    for (let attempt = 0; attempt < 35; attempt++) {
                      const cx = minX + Math.random() * Math.max(20, maxX - minX);
                      const cy = minY + Math.random() * Math.max(20, maxY - minY);

                      // Check collision against all walls (indestructible or destructible)
                      const collidesWithWall = state.walls.some(w => {
                        if (!w.alive) return false;
                        const safetyDist = 32;
                        return cx + safetyDist > w.x && cx - safetyDist < w.x + w.w &&
                               cy + safetyDist > w.y && cy - safetyDist < w.y + w.h;
                      });

                      if (!collidesWithWall) {
                        candidates.push({ x: cx, y: cy });
                      }
                    }
                  }

                  // Prefer candidates that are at least 90px away from current position
                  const farCandidates = candidates.filter(c => Math.hypot(c.x - en.x, c.y - en.y) > 90);
                  const chosenList = farCandidates.length > 0 ? farCandidates : candidates;
                  if (chosenList.length > 0) {
                    const chosen = chosenList[Math.floor(Math.random() * chosenList.length)];
                    targetX = chosen.x;
                    targetY = chosen.y;
                  }
                }

                en.x = targetX;
                en.y = targetY;

                // Clamp to spawn room boundaries
                if (rb) {
                  const pad = en.r + 14;
                  en.x = Math.max(rb.minX + pad, Math.min(rb.maxX - pad, en.x));
                  en.y = Math.max(rb.minY + pad, Math.min(rb.maxY - pad, en.y));
                }

                // Magical burst at new teleport location
                soundManager.playTeleport();
                for (let i = 0; i < 8; i++) {
                  state.particles.push({
                    x: en.x + (Math.random() - 0.5) * 40,
                    y: en.y + (Math.random() - 0.5) * 40,
                    vx: (Math.random() - 0.5) * 7,
                    vy: (Math.random() - 0.5) * 7,
                    life: 0.6,
                    maxLife: 0.6,
                    color: isFrost ? '#38bdf8' : '#c084fc',
                    size: Math.random() * 5 + 2
                  });
                }

                en.state = 'idle';
                en.cooldownTimer = 85 + Math.random() * 60; // cooldown of 1.4 - 2.4 seconds
              }
            }
          } else {
            // Keep counting cooldown but stay idle if player is too far
            if (en.state === 'idle' && en.cooldownTimer > 0) {
              en.cooldownTimer -= step;
            } else if (en.state !== 'idle') {
              en.state = 'idle';
              en.cooldownTimer = 60;
            }
          }
        } else if (en.type === 'ice') {
          en.angle += 0.04 * step;
          
          // Reduced Attack Radius: Only charge and shoot when player is within 315px
          if (distToPlayer < 315) {
            en.shootTimer += step;
            if (en.shootTimer >= 140) {
              en.shootTimer = 0;
              const angleToPlayer = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
              state.iceProjectiles.push({
                x: en.x,
                y: en.y,
                vx: Math.cos(angleToPlayer) * 7.0,
                vy: Math.sin(angleToPlayer) * 7.0,
                alive: true,
                isReflected: false,
                life: 3.5
              });
              soundManager.playSwing(1.8);
            }
          }
        } else if (en.type === 'fatty') {
          // Boss does NOT aggro or attack until player enters the boss room
          const isPlayerInFattyRoom = Boolean(state.fattyArena?.triggered) || (en.parent ? (
            playerCenterX >= en.parent.x + 30 && playerCenterX <= en.parent.x + en.parent.width - 30 &&
            playerCenterY >= en.parent.y + 30 && playerCenterY <= en.parent.y + en.parent.height - 30
          ) : false);

          if (!isPlayerInFattyRoom) {
            // Dormant until player enters room
            en.handsAnim = 0;
            en.shootTimer = 0;
            en.fireballPhase = 'idle';
            en.state = 'idle';
            en.punchPhase = 'idle';
            en.vx = 0;
            en.vy = 0;
            return;
          }

          en.handsAnim = (en.handsAnim || 0) + 0.05 * step;

          // Safe upper walkway check: if player is walking on upper platform safely above Fatty's head
          const isPlayerAboveHead = (state.player.y + state.player.h) <= (en.y - en.r + 20);

          // Body collision with player so player cannot pass through (ignored if safely above head)
          if (!isPlayerAboveHead && Math.hypot(playerCenterX - en.x, playerCenterY - en.y) < en.r + 24) {
            takeDamage(en.x, getEnemyDamage('fatty_body'));
            const pushDir = playerCenterX >= en.x ? 1 : -1;
            state.player.x += pushDir * 12;
            state.player.vx = pushDir * 14;
          }

          // Check HP Thresholds for special Laser state
          const hpRatio = en.hp / en.maxHp;
          if ((hpRatio < 0.70 && !en.triggered70) || (hpRatio < 0.30 && !en.triggered30)) {
            if (hpRatio < 0.70) en.triggered70 = true;
            if (hpRatio < 0.30) en.triggered30 = true;
            en.fattyPhase = 'laser_init';
            en.laserInitTimer = 120; // 2 seconds of smooth wind-up, pylon materialization & shield formation
            en.laserTimer = 0;
            en.laserCyclesCount = 0;
            en.laserAngles = [];
            // Instantly cancel normal attacks and aiming
            en.shootTimer = 0;
            en.fireballPhase = 'idle';
            en.state = 'idle';
            en.punchPhase = 'idle';

            // Spawn 4 Magical Entities ("магические сущности") at the 4 corners of the room
            let roomMinX = en.x - 450;
            let roomMaxX = en.x + 450;
            let roomMinY = en.y - 350;
            let roomMaxY = en.y + 350;
            if (en.parent) {
              roomMinX = en.parent.x + 100;
              roomMaxX = en.parent.x + en.parent.width - 100;
              roomMinY = en.parent.y + 100;
              roomMaxY = en.parent.y + en.parent.height - 100;
            }

            const pylonCoords = [
              { x: roomMinX + 50, y: roomMinY + 50 },
              { x: roomMaxX - 50, y: roomMinY + 50 },
              { x: roomMinX + 50, y: roomMaxY - 50 },
              { x: roomMaxX - 50, y: roomMaxY - 50 }
            ];

            const lvl = Math.max(1, state.level || statsRef.current.level || 1);
            const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
            const pylonHp = Math.round(35 * diffRef.current.hpMultiplier * lvlHpMult);

            pylonCoords.forEach((pos, idx) => {
              state.enemies.push({
                id: 'fatty_pylon_' + Date.now() + '_' + idx + '_' + Math.random(),
                x: pos.x,
                y: pos.y,
                r: 22,
                type: 'pylon',
                name: 'Магическая Сущность',
                hp: pylonHp,
                maxHp: pylonHp,
                alive: true,
                spawnTimer: 0,
                maxSpawnTimer: 90, // 1.5s smooth scale-up & fade-in materialization animation
                angle: Math.random() * Math.PI * 2,
                isStruck: false,
                hitCooldown: 0
              });
            });

            // Visual spawn particles without audio per user request
            for (let k = 0; k < 24; k++) {
              const pAng = Math.random() * Math.PI * 2;
              const pDist = Math.random() * 50;
              state.particles.push({
                x: en.x + Math.cos(pAng) * pDist,
                y: en.y + Math.sin(pAng) * pDist,
                vx: Math.cos(pAng) * 5,
                vy: Math.sin(pAng) * 5,
                life: 0.6, maxLife: 0.6,
                color: '#e9d5ff', size: 4
              });
            }
          }

          const isLaserPhase = en.fattyPhase === 'laser_init' || en.fattyPhase === 'laser_charge' || en.fattyPhase === 'laser_fire';
          state.walls.forEach(w => {
            if (w.isFattyArenaWall) {
              w.targetRetract = (isLaserPhase && en.alive) ? 1 : 0;
            }
          });

          // If all magical entities (pylons) shielding Fatty are destroyed during any laser phase, drop immunity & shield immediately!
          if (isLaserPhase) {
            const livingPylons = state.enemies.filter(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
            if (livingPylons.length === 0) {
              en.fattyPhase = 'flail_spin';
              en.flailSpinTimer = 0;
              en.flailSpinAngle = Math.random() * Math.PI * 2;
              en.flailSpinDir = Math.random() < 0.5 ? 1 : -1;
              en.flailSpinRadius = 50;
              en.flailHitCooldown = 0;
              en.flailGroundBouncesDone = 0;
              en.flailScale = 1.0;
              en.flailTargetScale = 1.0;
              en.shootTimer = 0;
              en.state = 'idle';

              // Forcefield destruction burst
              soundManager.playClash();
              state.screenShake = 16;
              state.shockwaves.push({
                x: en.x, y: en.y - 30,
                r: 10, maxR: 90, color: '#c084fc', life: 0.6, maxLife: 0.6
              });
            }
          }

          const lvl = Math.max(1, state.level || statsRef.current.level || 1);
          const chargeFactor = 1.0 + (lvl - 1) * 0.025;
          // +15% laser rotation speed per difficulty level
          const spinSpeedMult = 1.0 + (lvl - 1) * 0.02;
          // Alternating direction for each of the 3 salvos (salvo 0: clockwise, salvo 1: counter-clockwise, salvo 2: clockwise)
          const salvoDir = ((en.laserCyclesCount || 0) % 2 === 0) ? 1 : -1;
          const salvoSpinRate = 0.0075 * spinSpeedMult * salvoDir;

          if (en.fattyPhase === 'laser_init') {
            en.laserInitTimer = (en.laserInitTimer || 0) - step * chargeFactor;
            // Force normal attacks to remain completely inactive
            en.shootTimer = 0;
            en.fireballPhase = 'idle';
            en.state = 'idle';
            en.punchPhase = 'idle';

            // Energy particles charging around Fatty
            if (Math.random() < 0.075 && state.particles.length < 40) {
              const pAng = Math.random() * Math.PI * 2;
              const pDist = 120 + Math.random() * 30;
              state.particles.push({
                x: en.x + Math.cos(pAng) * pDist,
                y: (en.y - 56) + Math.sin(pAng) * pDist,
                vx: -Math.cos(pAng) * 4.0,
                vy: -Math.sin(pAng) * 4.0,
                life: 0.4,
                maxLife: 0.4,
                color: '#ec4899',
                size: 2.5
              });
            }

            if (en.laserInitTimer <= 0) {
              en.fattyPhase = 'laser_charge';
              en.laserTimer = 0;
              en.laserBaseAngle = en.laserBaseAngle || 0;
              const laserCount = 4; // 4 lasers in a cross
              en.laserAngles = Array.from({ length: laserCount }, (_, i) => (i / laserCount) * Math.PI * 2 + en.laserBaseAngle);
            }
          } else if (en.fattyPhase === 'laser_charge') {
            en.laserTimer = (en.laserTimer || 0) + step * chargeFactor;
            // Pre-rotate targeting rays in the current salvo's spin direction at constant speed
            en.laserBaseAngle = (en.laserBaseAngle || 0) + salvoSpinRate * step;
            const laserCount = 4; // 4 lasers in a cross
            en.laserAngles = Array.from({ length: laserCount }, (_, i) => (i / laserCount) * Math.PI * 2 + en.laserBaseAngle);

            // Generate particles spiraling into his chest/eyes
            if (Math.random() < 0.12 && state.particles.length < 40) {
              const pAng = Math.random() * Math.PI * 2;
              const pDist = 100 + Math.random() * 60;
              state.particles.push({
                x: en.x + Math.cos(pAng) * pDist,
                y: (en.y - 56) + Math.sin(pAng) * pDist,
                vx: -Math.cos(pAng) * 5.5,
                vy: -Math.sin(pAng) * 5.5,
                life: 0.35,
                maxLife: 0.35,
                color: Math.random() < 0.5 ? '#f43f5e' : '#ec4899',
                size: 3
              });
            }

            if (en.laserTimer >= 120) { // 2 seconds completed!
              en.fattyPhase = 'laser_fire';
              en.laserFireTimer = 0;
              en.laserHitCooldown = 0;
              soundManager.playDroneBlast(); // Fire laser salvo
            }
          } else if (en.fattyPhase === 'laser_fire') {
            en.laserFireTimer = (en.laserFireTimer || 0) + step * chargeFactor;
            if (en.laserHitCooldown > 0) en.laserHitCooldown -= step;

            // Rotate lasers smoothly around Fatty in the current salvo's spin direction (no acceleration after aiming)
            en.laserBaseAngle = (en.laserBaseAngle || 0) + salvoSpinRate * step;
            const laserCount = 4; // 4 lasers in a cross
            en.laserAngles = Array.from({ length: laserCount }, (_, i) => (i / laserCount) * Math.PI * 2 + en.laserBaseAngle);

            // Screen shake subtle continuous pulse
            if (state.screenShake < 2) state.screenShake = 2;

            // Collision check: raycast against walls and damage player only along unblocked laser rays
            en.laserAngles.forEach((ang: number) => {
              const dx = Math.cos(ang);
              const dy = Math.sin(ang);
              const beamDist = getLaserHitDistance(en.x, en.y - 56, dx, dy, 1200);

              const px = playerCenterX - en.x;
              const py = playerCenterY - (en.y - 56);
              const dot = px * dx + py * dy;
              if (dot >= 0 && dot <= beamDist) {
                const projX = en.x + dx * dot;
                const projY = (en.y - 56) + dy * dot;
                const dist = Math.hypot(playerCenterX - projX, playerCenterY - projY);
                if (dist < 46 && (!en.laserHitCooldown || en.laserHitCooldown <= 0)) {
                  takeDamage(en.x, getEnemyDamage('eye_laser') * 1.5);
                  en.laserHitCooldown = 18; // Damage tick throttle to allow dodging
                }
              }

              // Hit particles on obstacles
              if (beamDist < 1200 && Math.random() < 0.12) {
                state.particles.push({
                  x: en.x + dx * beamDist,
                  y: (en.y - 56) + dy * beamDist,
                  vx: (Math.random() - 0.5) * 6 - dx * 2,
                  vy: (Math.random() - 0.5) * 6 - dy * 2,
                  life: 0.25, maxLife: 0.25,
                  color: '#f43f5e',
                  size: 2.5
                });
              }
            });

            // 3 times longer firing duration (48 * 3 = 144 ticks ~ 2.4 seconds)
            if (en.laserFireTimer >= 144) {
              const livingPylons = state.enemies.filter(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
              if (livingPylons.length > 0) {
                // Magical Entities are still alive -> Laser phase continues endlessly!
                en.fattyPhase = 'laser_charge';
                en.laserTimer = 0;
                en.laserAngles = Array.from({ length: 4 }, (_, i) => (i / 4) * Math.PI * 2 + en.laserBaseAngle);
              } else {
                // All 4 magical entities destroyed -> Transition to Flail Spin phase!
                en.fattyPhase = 'flail_spin';
                en.flailSpinTimer = 0;
                // Random starting flail rotation position & random spin direction (+1 or -1)
                en.flailSpinAngle = Math.random() * Math.PI * 2;
                en.flailSpinDir = Math.random() < 0.5 ? 1 : -1;
                en.flailSpinRadius = 50;
                en.flailHitCooldown = 0;
                en.flailGroundBouncesDone = 0;
                en.flailScale = 1.0; // Starts at normal scale and inflates to 2x over 2 seconds (120 ticks)
                en.flailTargetScale = 1.0;
                en.shootTimer = 0;
                en.state = 'idle';

                // Forcefield destruction burst
                soundManager.playClash();
                state.screenShake = 16;
                state.shockwaves.push({
                  x: en.x, y: en.y - 30,
                  r: 10, maxR: 90, color: '#c084fc', life: 0.6, maxLife: 0.6
                });
              }
            }
          } else if (en.fattyPhase === 'flail_spin') {
            en.flailSpinTimer = (en.flailSpinTimer || 0) + step;
            en.vx = 0;
            en.vy = 0;
            if (en.flailHitCooldown > 0) en.flailHitCooldown -= step;

            // Maximum radius expanded 1.5x to 510px (covers full arena room)
            const maxFlailRadius = 510;
            const minFlailRadius = 50;
            const dragRadius = 190; // Dragging occurs at larger radius

            const t = en.flailSpinTimer;
            let currentRadius = minFlailRadius;
            let currentAngSpeed = 0.025;
            let isDragging = false;

            if (t < 220) {
              // 1. Acceleration phase duration set to 220 ticks & expanding outward
              const p = t / 220;
              const easeP = p * p;
              currentAngSpeed = 0.025 + easeP * 0.085;
              currentRadius = minFlailRadius + easeP * (maxFlailRadius - minFlailRadius);
              if (Math.random() < 0.08) soundManager.playSwing(1.0 + easeP * 0.8, 1.6);
            } else if (t < 400) {
              // 2. Immediately start shrinking radius upon reaching max radius (at 220 ticks) towards drag radius over 180 ticks
              const p = (t - 220) / 180;
              const easeP = 1 - p * p;
              currentAngSpeed = 0.025 + easeP * 0.085;
              currentRadius = dragRadius + easeP * (maxFlailRadius - dragRadius);
              if (Math.random() < 0.08) soundManager.playSwing(1.0 + easeP * 0.6, 1.5);
              if (state.screenShake < 2) state.screenShake = 2;
            } else if (t < 580) {
              // 3. Low speed & dragging along ground at drag radius (190px), making 3 heavy ground strikes that pop round mobs & bounce
              isDragging = true;
              currentAngSpeed = 0.025;
              currentRadius = dragRadius;

              const dragElapsed = t - 400;
              const bounceTimes = [35, 95, 155];
              bounceTimes.forEach((bTime, bIdx) => {
                if (dragElapsed >= bTime && (en.flailGroundBouncesDone || 0) <= bIdx) {
                  en.flailGroundBouncesDone = bIdx + 1;
                  en.flailImpactBounceTimer = 22; // Trigger 22-tick upward bounce/hop animation
                  soundManager.playMaceHit();
                  soundManager.playClash();
                  soundManager.playWallBump();
                  soundManager.playSpikeRetract(); // Air release / deflation sound
                  state.screenShake = 18;

                  const impactX = en.x + Math.cos(en.flailSpinAngle || 0) * currentRadius;
                  const impactY = en.y + Math.sin(en.flailSpinAngle || 0) * currentRadius + 15;

                  // Ground impact shockwave
                  state.shockwaves.push({
                    x: impactX,
                    y: impactY,
                    r: 10,
                    maxR: 64,
                    color: '#f97316',
                    life: 0.65,
                    maxLife: 0.65
                  });

                  // Ground dirt & spark particles
                  for (let i = 0; i < 24; i++) {
                    const ang = Math.random() * Math.PI * 2;
                    const spd = 3 + Math.random() * 9;
                    state.particles.push({
                      x: impactX,
                      y: impactY,
                      vx: Math.cos(ang) * spd,
                      vy: Math.sin(ang) * spd - 2,
                      life: 0.55,
                      maxLife: 0.55,
                      color: Math.random() < 0.5 ? '#f97316' : '#94a3b8',
                      size: 3.5 + Math.random() * 3.5
                    });
                  }

                  // Steam / air deflation puff particles bursting from mace on strike
                  for (let k = 0; k < 20; k++) {
                    const pAng = Math.random() * Math.PI * 2;
                    const pSpd = 3 + Math.random() * 8;
                    state.particles.push({
                      x: impactX,
                      y: impactY,
                      vx: Math.cos(pAng) * pSpd,
                      vy: Math.sin(pAng) * pSpd - 2,
                      life: 0.5, maxLife: 0.5,
                      color: '#f8fafc',
                      size: 4 + Math.random() * 4
                    });
                  }

                  // Pop out a round saw mob ("круглях") per user request
                  if (Math.random() < 0.70) {
                    const lvl = Math.max(1, state.level || statsRef.current.level || 1);
                    const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
                    const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;
                    const isRed = Math.random() < 0.5;
                    const mobHp = Math.round((isRed ? 22 : 16) * diffRef.current.hpMultiplier * lvlHpMult);
                    const mobR = 20;

                    const poppedMob = {
                      id: 'pop_saw_' + Date.now() + Math.random(),
                      x: impactX + (Math.random() - 0.5) * 15,
                      y: impactY - 10,
                      r: mobR,
                      parent: en.parent,
                      roomBounds: en.parent ? {
                        minX: en.parent.x + 80,
                        maxX: en.parent.x + en.parent.width - 80,
                        minY: en.parent.y + 80,
                        maxY: en.parent.y + en.parent.height - 80
                      } : undefined,
                      vx: 0,
                      vy: 0,
                      spitVx: (Math.random() - 0.5) * (6 + Math.random() * 3) * lvlSpeedMult,
                      spitVy: (-7.5 - Math.random() * 4.5) * lvlSpeedMult,
                      isSpittingInAir: true,
                      targetLandingY: impactY + 15,
                      targetLandingX: impactX + (Math.random() - 0.5) * 60,
                      alive: true,
                      type: 'saw',
                      level: lvl,
                      isRedSaw: isRed,
                      isPopped: true,
                      isChargingExplosion: false,
                      explosionTimer: 0,
                      maxExplosionTimer: Math.max(25, Math.round(90 / (1.0 + (lvl - 1) * 0.03))),
                      explosionFinished: false,
                      angle: 0,
                      hp: mobHp,
                      maxHp: mobHp,
                      isStruck: false,
                      hitCooldown: 0
                    };
                    state.enemies.push(poppedMob);
                    soundManager.playLoot();
                  }
                }
              });
            } else if (t < 650) {
              // 4. Visual Chain Reeling / Pulling mace back to Fatty's chest socket!
              const pullProg = Math.min(1.0, (t - 580) / 70);
              const easePull = pullProg * pullProg;
              currentRadius = dragRadius * (1 - easePull);
              currentAngSpeed = 0.01;
              isDragging = false;

              if (Math.random() < 0.15) {
                soundManager.playSwing(0.8, 1.2);
              }
              if (Math.random() < 0.3) {
                const spX = en.x + Math.cos(en.flailSpinAngle || 0) * currentRadius;
                const spY = en.y + Math.sin(en.flailSpinAngle || 0) * currentRadius;
                state.particles.push({
                  x: spX,
                  y: spY,
                  vx: (Math.random() - 0.5) * 4,
                  vy: -Math.random() * 4,
                  life: 0.25,
                  maxLife: 0.25,
                  color: '#94a3b8',
                  size: 2.5
                });
              }
            } else {
              // 5. Spin & pull complete -> Transition to Magnetism Suction & Jump!
              en.fattyPhase = 'magnetism';
              en.magTimer = 0;
              en.shootTimer = 0;
              en.state = 'idle';
              return;
            }

            // Animate impact bounce hop timer
            if ((en.flailImpactBounceTimer || 0) > 0) {
              en.flailImpactBounceTimer -= step;
              const bProg = Math.max(0, en.flailImpactBounceTimer / 22);
              en.flailBounceY = Math.sin(bProg * Math.PI) * 32; // 32px vertical bounce hop!
            } else {
              en.flailBounceY = 0;
            }

            // Gradual inflation over 2 seconds (120 ticks) when spinning starts:
            if (t <= 120) {
              en.flailTargetScale = 1.0 + (t / 120) * 1.0;
            } else if (en.flailGroundBouncesDone === 1) {
              en.flailTargetScale = 1.667;
            } else if (en.flailGroundBouncesDone === 2) {
              en.flailTargetScale = 1.333;
            } else if ((en.flailGroundBouncesDone || 0) >= 3) {
              en.flailTargetScale = 1.0;
            } else {
              en.flailTargetScale = 2.0;
            }

            en.flailScale = en.flailScale || 1.0;
            en.flailScale += (en.flailTargetScale - en.flailScale) * 0.12 * step;

            en.flailSpinAngle = (en.flailSpinAngle || 0) + currentAngSpeed * step * (en.flailSpinDir || 1);
            en.flailSpinRadius = currentRadius;
            en.flailIsDragging = isDragging;

            const spoolX = en.x;
            const spoolY = en.y + 15;
            const maceX = spoolX + Math.cos(en.flailSpinAngle) * currentRadius;
            const maceY = spoolY + Math.sin(en.flailSpinAngle) * currentRadius;

            // Damage player if hit by spinning flail (takes inflated mace radius into account)
            const currentMaceR = 36 * (en.flailScale || 1.0);
            const distToPlayerMace = Math.hypot(playerCenterX - maceX, playerCenterY - maceY);
            if (distToPlayerMace < currentMaceR + 16 && (!en.flailHitCooldown || en.flailHitCooldown <= 0)) {
              takeDamage(en.x, getEnemyDamage('fatty_punch') * 1.5);
              en.flailHitCooldown = 25;
              const knockAng = en.flailSpinAngle || 0;
              state.player.vx = Math.cos(knockAng) * 16 * (en.flailSpinDir || 1);
              state.player.vy = Math.sin(knockAng) * 16 - 4;
              soundManager.playMaceHit();
            }

            // Friction sparks when dragging on floor or spinning fast
            if (isDragging || currentAngSpeed > 0.08) {
              if (Math.random() < 0.6) {
                state.particles.push({
                  x: maceX,
                  y: maceY + (isDragging ? 10 : 0),
                  vx: -Math.sin(en.flailSpinAngle) * (isDragging ? 5 : 7) + (Math.random() - 0.5) * 4,
                  vy: Math.cos(en.flailSpinAngle) * (isDragging ? 5 : 7) + (Math.random() - 0.5) * 4,
                  life: 0.35,
                  maxLife: 0.35,
                  color: Math.random() < 0.6 ? '#f97316' : '#ef4444',
                  size: 2.8 + Math.random() * 2.2
                });
              }
            }
          } else if (en.fattyPhase === 'magnetism') {
            en.magTimer = (en.magTimer || 0) + step;
            en.vx = 0;
            en.vy = 0;

            // Magnetism pull strength over 270 ticks (peak at 3s, then weakens 2x faster -> ends at 4.5s)
            // Starts gentle, reaches peak at 3s, then weakens
            const magSec = en.magTimer / 60;
            const effectiveMagSec = magSec < 3 ? magSec : 3 + (magSec - 3) * 2;
            let rawPullPower = 0;
            if (effectiveMagSec < 1) {
              rawPullPower = 0.6 + effectiveMagSec * 0.8;
            } else if (effectiveMagSec < 2) {
              rawPullPower = 1.4 + (effectiveMagSec - 1) * 1.4;
            } else if (effectiveMagSec < 3) {
              rawPullPower = 2.8 + (effectiveMagSec - 2) * 1.7;
            } else if (effectiveMagSec < 4) {
              rawPullPower = 4.5 - (effectiveMagSec - 3) * 1.0;
            } else if (effectiveMagSec < 5) {
              rawPullPower = 3.5 - (effectiveMagSec - 4) * 1.5;
            } else {
              rawPullPower = Math.max(0.3, 2.0 - (effectiveMagSec - 5) * 1.5);
            }
            const pullPower = (rawPullPower / 9) * 0.9; // Set to 0.9 per user request (total 10x reduction from original)

            // Apply pull force towards Fatty's center (halved)
            const pAng = Math.atan2(en.y - playerCenterY, en.x - playerCenterX);
            state.player.vx += Math.cos(pAng) * pullPower * 0.8;
            state.player.vy += Math.sin(pAng) * pullPower * 0.8;

            // Suction streams into Fatty's body
            if (Math.random() < 0.6) {
              const rAng = Math.random() * Math.PI * 2;
              const rDist = 120 + Math.random() * 200;
              state.particles.push({
                x: en.x + Math.cos(rAng) * rDist,
                y: en.y + Math.sin(rAng) * rDist,
                vx: -Math.cos(rAng) * (4 + pullPower * 1.2),
                vy: -Math.sin(rAng) * (4 + pullPower * 1.2),
                life: 0.35, maxLife: 0.35,
                color: Math.random() < 0.5 ? '#a855f7' : '#38bdf8',
                size: 2.5 + Math.random() * 2.5
              });
            }

            if (state.screenShake < pullPower * 0.5) {
              state.screenShake = pullPower * 0.5;
            }

            if (en.magTimer >= 270) {
              // Magnetism complete -> 1.5s jump preparation (scaled by level)!
              en.fattyPhase = 'jump_prep';
              en.jumpPrepTimer = 0;
            }
          } else if (en.fattyPhase === 'jump_prep') {
            en.jumpPrepTimer = (en.jumpPrepTimer || 0) + step;
            en.vx = 0;
            en.vy = 0;

            const lvl = en.level || Math.max(1, state.level || statsRef.current.level || 1);
            const maxPrepDuration = Math.max(20, Math.round(90 / (1 + 0.20 * (lvl - 1))));

            const prepRatio = Math.min(1.0, en.jumpPrepTimer / maxPrepDuration);
            if (state.screenShake < prepRatio * 3) {
              state.screenShake = prepRatio * 3;
            }

            // Charging dust/aura particles around Fatty's base
            if (Math.random() < 0.45) {
              const pAng = Math.random() * Math.PI * 2;
              const pDist = 30 + Math.random() * 60;
              state.particles.push({
                x: en.x + Math.cos(pAng) * pDist,
                y: en.y + 60,
                vx: (Math.random() - 0.5) * 4,
                vy: -Math.random() * 4 - 2,
                life: 0.35, maxLife: 0.35,
                color: Math.random() < 0.5 ? '#f97316' : '#ef4444',
                size: 3.5
              });
            }

            if (en.jumpPrepTimer >= maxPrepDuration) {
              // Preparation complete -> Perform Jump!
              en.fattyPhase = 'jump_air';
              en.jumpAirTimer = 0;
              soundManager.playSwing(2.5);
            }
          } else if (en.fattyPhase === 'jump_air') {
            en.jumpAirTimer = (en.jumpAirTimer || 0) + step;
            en.vx = 0;
            en.vy = 0;

            const totalJumpTime = 40; // 40 ticks jump arc
            if (en.jumpAirTimer >= totalJumpTime) {
              // LANDING IMPACT!
              en.fattyPhase = 'normal';
              en.shootTimer = 0;
              en.state = 'idle';
              en.recoveryTimer = 60;

              soundManager.playFattyFall();
              soundManager.playMaceHit();
              state.screenShake = 24;

              // Landing shockwave radius spans to the 4 spiked pillars (~340px)
              const arenaW = en.parent ? en.parent.width : 800;
              const arenaH = en.parent ? en.parent.height : 800;
              const pOffX = arenaW * 0.28;
              const pOffY = arenaH * 0.28;
              const pillarRadius = Math.round(Math.hypot(pOffX, pOffY)); // ~340px

              // Breathtaking Boss Landing Damage Shockwave Halo spanning to the 4 spiked pillars (~340px)
              state.shockwaves.push({
                x: en.x, y: en.y,
                r: 16, maxR: pillarRadius,
                color: '#ef4444', life: 1.25, maxLife: 1.25,
                isFattyLandingHalo: true
              });
              state.shockwaves.push({
                x: en.x, y: en.y,
                r: 12, maxR: pillarRadius * 0.65,
                color: '#f97316', life: 0.9, maxLife: 0.9,
                isFattyLandingHalo: true
              });

              // Ground landing Debris particles (60 radiating particles)
              for (let i = 0; i < 60; i++) {
                const rAng = (i / 60) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
                const rSpd = 5 + Math.random() * 14;
                state.particles.push({
                  x: en.x, y: en.y + 40,
                  vx: Math.cos(rAng) * rSpd,
                  vy: Math.sin(rAng) * rSpd - 3,
                  life: 0.7, maxLife: 0.7,
                  color: Math.random() < 0.4 ? '#ef4444' : (Math.random() < 0.7 ? '#f97316' : '#475569'),
                  size: 3.5 + Math.random() * 4.5
                });
              }

              // Damage player within pillarRadius
              const distToLanding = Math.hypot(playerCenterX - en.x, playerCenterY - en.y);
              if (distToLanding < pillarRadius) {
                takeDamage(en.x, getEnemyDamage('fatty_punch') * 1.8);
                const expAng = Math.atan2(playerCenterY - en.y, playerCenterX - en.x) || -Math.PI * 0.5;
                state.player.vx = Math.cos(expAng) * 18;
                state.player.vy = -12;
              }
            }
          } else if (!en.fattyPhase || en.fattyPhase === 'normal') {
            // NORMAL PHASE (Punching and fireballs)
            const lvl = Math.max(1, state.level || statsRef.current.level || 1);
            const chargeFactor = 1.0 + (lvl - 1) * 0.025;

            // Ranged fireball attack from EYE with prominent aiming and charging phases
            const isFireballActive = en.fireballPhase && en.fireballPhase !== 'idle';
            if (isFireballActive || (isPlayerOnEnemyPlatform(en) && distToPlayer < 1200)) {
              en.shootTimer = (en.shootTimer || 0) + step * chargeFactor;
              const thresholdAim = 110;
              const thresholdLock = 180;
              const eyeX = en.x;
              const eyeY = en.y - 48;

              if (en.shootTimer < thresholdAim) {
                en.fireballPhase = 'aiming';
                en.aimTargetX = playerCenterX;
                en.aimTargetY = playerCenterY;
                en.fireballAngle = Math.atan2(playerCenterY - eyeY, playerCenterX - eyeX);

                // Continuously freeze these in real-time until phase change
                en.lockedFireballX = en.aimTargetX;
                en.lockedFireballY = en.aimTargetY;
                en.lockedFireballAngle = en.fireballAngle;
              } else if (en.shootTimer >= thresholdAim && en.shootTimer < thresholdLock) {
                en.fireballPhase = 'charging'; // Tension/Build-up phase: cannot adjust aim!
                // Emit charging ember particles spiraling towards EYE
                if (Math.random() < 0.25) {
                  const pAng = Math.random() * Math.PI * 2;
                  const pDist = 30 + Math.random() * 40;
                  state.particles.push({
                    x: eyeX + Math.cos(pAng) * pDist,
                    y: eyeY + Math.sin(pAng) * pDist,
                    vx: -Math.cos(pAng) * 3.5,
                    vy: -Math.sin(pAng) * 3.5,
                    life: 0.35,
                    maxLife: 0.35,
                    color: Math.random() < 0.5 ? '#f97316' : '#ef4444',
                    size: 3
                  });
                }
              } else if (en.shootTimer >= thresholdLock) {
                en.shootTimer = 0;
                en.fireballPhase = 'idle';

                // Shoot fireball directly out from the EYE!
                state.iceProjectiles.push({
                  x: eyeX,
                  y: eyeY,
                  startX: eyeX,
                  startY: eyeY,
                  targetX: en.lockedFireballX,
                  targetY: en.lockedFireballY,
                  vx: Math.cos(en.lockedFireballAngle) * 9.0,
                  vy: Math.sin(en.lockedFireballAngle) * 9.0,
                  alive: true,
                  isReflected: false,
                  life: 5.0,
                  isFireball: true
                });
                soundManager.playSwing(1.5);
              }
            } else {
              en.shootTimer = 0;
              en.fireballPhase = 'idle';
            }

            // Melee Spiked Mace Strike with Aiming, Ground Collision, Halfway Stuck & Radial Explosion!
            if (!en.state) en.state = 'idle';

            if (en.state === 'idle') {
              if (en.recoveryTimer > 0) en.recoveryTimer -= step;
              if (isPlayerInFattyRoom && en.recoveryTimer <= 0 && distToPlayer < 750) {
                en.state = 'windup';
                en.windupTimer = 0;
                en.punchPhase = 'aiming';
                en.targetImpactX = playerCenterX;
                en.targetImpactY = playerCenterY;
              }
            } else if (en.state === 'windup') {
              en.windupTimer += step * chargeFactor;
              const thresholdPunchAim = 75;  // Real-time tracking phase
              const thresholdPunchLock = 135; // Lock target & build up tension

              if (en.windupTimer < thresholdPunchAim) {
                en.punchPhase = 'aiming';
                en.targetImpactX = playerCenterX;
                en.targetImpactY = playerCenterY;
                en.lockedPunchAngle = Math.atan2(en.targetImpactY - en.y, en.targetImpactX - en.x);
              } else if (en.windupTimer >= thresholdPunchAim && en.windupTimer < thresholdPunchLock) {
                en.punchPhase = 'charging'; // Target is locked on ground!
              } else if (en.windupTimer >= thresholdPunchLock) {
                en.state = 'strike';
                en.strikeTimer = 0;
                en.punchPhase = 'strike';
                soundManager.playSwing(2.2);
              }
            } else if (en.state === 'strike') {
              en.strikeTimer += step;
              const strikeDuration = 18; // Fast extending strike towards aimed spot
              const strikeProg = Math.min(1.0, en.strikeTimer / strikeDuration);

              const spoolX = en.x;
              const spoolY = en.y + 15;
              const targetX = en.targetImpactX !== undefined ? en.targetImpactX : playerCenterX;
              const targetY = en.targetImpactY !== undefined ? en.targetImpactY : playerCenterY;

              const currentMaceX = spoolX + (targetX - spoolX) * strikeProg;
              const currentMaceY = spoolY + (targetY - spoolY) * strikeProg;

              // Collision check along the extension path
              if (Math.hypot(playerCenterX - currentMaceX, playerCenterY - currentMaceY) < 48) {
                takeDamage(en.x, getEnemyDamage('fatty_punch'));
              }

              // REACHED TARGET POINT -> IMPACT, RADIAL EXPLOSION & STUCK IN GROUND!
              if (strikeProg >= 1.0) {
                en.state = 'stuck';
                en.stuckTimer = 180; // 3 full 60-frame tug cycles (~3 sec)
                en.tugCount = 0;
                en.punchPhase = 'stuck';

                state.screenShake = 22;
                soundManager.playMaceHit();
                soundManager.playClash();

                // 1. VISIBLE EXPANDING SHOCKWAVE AURA RING (matching EXACT 54px damage radius - reduced 2.5x!)
                state.shockwaves.push({
                  x: targetX,
                  y: targetY,
                  r: 8,
                  maxR: 54,
                  color: '#ef4444',
                  life: 0.8,
                  maxLife: 0.8
                });
                state.shockwaves.push({
                  x: targetX,
                  y: targetY,
                  r: 4,
                  maxR: 54,
                  color: '#f97316',
                  life: 0.6,
                  maxLife: 0.6
                });

                // RADIAL DAMAGE (54px radius = 135 / 2.5)
                const distToImpact = Math.hypot(playerCenterX - targetX, playerCenterY - targetY);
                if (distToImpact < 54) {
                  takeDamage(en.x, getEnemyDamage('fatty_punch') * 1.4);
                  const expAng = Math.atan2(playerCenterY - targetY, playerCenterX - targetX) || -Math.PI * 0.5;
                  state.player.vx = Math.cos(expAng) * 16;
                  state.player.vy = -12;
                }

                // RADIAL SHOCKWAVE & EXPLOSION PARTICLES (360 degrees)
                for (let i = 0; i < 36; i++) {
                  const rAng = (i / 36) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
                  const rSpd = 4 + Math.random() * 11;
                  state.particles.push({
                    x: targetX,
                    y: targetY,
                    vx: Math.cos(rAng) * rSpd,
                    vy: Math.sin(rAng) * rSpd - 2,
                    life: 0.6,
                    maxLife: 0.6,
                    color: Math.random() < 0.45 ? '#ef4444' : (Math.random() < 0.75 ? '#f97316' : '#94a3b8'),
                    size: 3.0 + Math.random() * 4.0
                  });
                }
              }
            } else if (en.state === 'stuck') {
              en.stuckTimer -= step;
              const tImpactX = en.targetImpactX !== undefined ? en.targetImpactX : en.x;
              const tImpactY = en.targetImpactY !== undefined ? en.targetImpactY : en.y;

              const elapsed = 180 - Math.max(0, en.stuckTimer);
              const tugIndex = Math.min(2, Math.floor(elapsed / 60)); // 0, 1, 2
              const cycleProgress = (elapsed % 60) / 60; // 0.0 to 1.0

              // Dynamic position of mace head during the 3 tugs
              let maceYOffset = 0;
              if (cycleProgress < 0.45) {
                const liftFactor = Math.sin((cycleProgress / 0.45) * Math.PI);
                maceYOffset = -liftFactor * (20 + tugIndex * 8);
              }
              const currentMaceHeadX = tImpactX;
              const currentMaceHeadY = tImpactY + maceYOffset;

              // Contact damage with the heavy stuck sledgehammer if player approaches/touches it!
              if (Math.hypot(playerCenterX - currentMaceHeadX, playerCenterY - currentMaceHeadY) < 48) {
                takeDamage(currentMaceHeadX, getEnemyDamage('fatty_punch'));
                const repAng = Math.atan2(playerCenterY - currentMaceHeadY, playerCenterX - currentMaceHeadX) || -Math.PI * 0.5;
                state.player.vx = Math.cos(repAng) * 9;
                state.player.vy = -7;
              }

              // Moment mace SNAPS BACK INTO EARTH in each of the 3 tug cycles (cycleProgress >= 0.45)
              if (cycleProgress >= 0.45 && (en.tugCount || 0) <= tugIndex) {
                en.tugCount = tugIndex + 1;
                soundManager.playMaceHit();
                soundManager.playWallBump();
                soundManager.playClash();
                state.screenShake = 12 + tugIndex * 4;

                // 20% chance to pop out a round mob (either fire or regular saw) per user request
                if (Math.random() < 0.20) {
                  const lvl = Math.max(1, state.level || statsRef.current.level || 1);
                  const lvlHpMult = 1.0 + (lvl - 1) * 2.607;
                  const lvlSpeedMult = 1.0 + (lvl - 1) * 0.02;
                  const isRed = (Math.random() < 0.5);
                  const mobHp = Math.round((isRed ? 22 : 16) * diffRef.current.hpMultiplier * lvlHpMult);
                  const mobR = 20;

                  const poppedMob = {
                    id: 'pop_saw_' + Date.now() + Math.random(),
                    x: tImpactX + (Math.random() - 0.5) * 20,
                    y: tImpactY - 10,
                    r: mobR,
                    parent: en.parent,
                    roomBounds: en.parent ? {
                      minX: en.parent.x + 80,
                      maxX: en.parent.x + en.parent.width - 80,
                      minY: en.parent.y + 80,
                      maxY: en.parent.y + en.parent.height - 80
                    } : undefined,
                    vx: 0,
                    vy: 0,
                    spitVx: (Math.random() - 0.5) * (6 + Math.random() * 3) * lvlSpeedMult,
                    spitVy: (-7.5 - Math.random() * 4.5) * lvlSpeedMult, // Parabolic arc upward initial velocity
                    isSpittingInAir: true,
                    targetLandingY: tImpactY + 15,
                    targetLandingX: tImpactX + (Math.random() - 0.5) * 60,
                    alive: true,
                    type: 'saw',
                    level: lvl, // Level matches current game level
                    isRedSaw: isRed,
                    isPopped: true,
                    isChargingExplosion: false,
                    explosionTimer: 0,
                    maxExplosionTimer: Math.max(25, Math.round(90 / (1.0 + (lvl - 1) * 0.03))),
                    explosionFinished: false,
                    angle: 0,
                    hp: mobHp,
                    maxHp: mobHp,
                    isStruck: false,
                    hitCooldown: 0
                  };
                  state.enemies.push(poppedMob);

                  soundManager.playLoot();
                  for (let p = 0; p < 12; p++) {
                    state.particles.push({
                      x: tImpactX,
                      y: tImpactY,
                      vx: (Math.random() - 0.5) * 8,
                      vy: -Math.random() * 8 - 2,
                      life: 0.5, maxLife: 0.5,
                      color: isRed ? '#ef4444' : '#38bdf8',
                      size: 4
                    });
                  }
                }

                // Ground Thud Shockwave
                state.shockwaves.push({
                  x: tImpactX,
                  y: tImpactY,
                  r: 4,
                  maxR: 36 + tugIndex * 10,
                  color: '#f97316',
                  life: 0.45,
                  maxLife: 0.45
                });

                // Flying Rock Fragments & Earth Dust as mace slams back into ground
                for (let i = 0; i < 22; i++) {
                  state.particles.push({
                    x: tImpactX + (Math.random() - 0.5) * 28,
                    y: tImpactY,
                    vx: (Math.random() - 0.5) * 10,
                    vy: -Math.random() * 8 - 2,
                    life: 0.45, maxLife: 0.45,
                    color: Math.random() < 0.4 ? '#ef4444' : (Math.random() < 0.7 ? '#64748b' : '#334155'),
                    size: 3.5 + Math.random() * 2.5
                  });
                }
              }

              // Continuous hot embers while stuck in ground
              if (Math.random() < 0.35) {
                state.particles.push({
                  x: tImpactX + (Math.random() - 0.5) * 36,
                  y: tImpactY + (Math.random() - 0.5) * 12,
                  vx: (Math.random() - 0.5) * 3,
                  vy: -Math.random() * 4 - 1,
                  life: 0.4, maxLife: 0.4, color: Math.random() < 0.5 ? '#ef4444' : '#f97316', size: 3
                });
              }

              if (en.stuckTimer <= 0) {
                en.state = 'recovery';
                en.recoveryTimer = 35; // Fast chain reel-back into spool!
                en.punchPhase = 'idle';
              }
            } else if (en.state === 'recovery') {
              en.recoveryTimer -= step;
              if (en.recoveryTimer <= 0) {
                en.state = 'idle';
              }
            }
          }
        } else if (en.type === 'knight') {
          // Knight sword physics with Frequent Attacks, Full Super-Armor & Complete Standstill during Windup
          if (!en.state) en.state = 'idle';
          if (!en.maxWindup) en.maxWindup = 36;

          const angleToPlayer = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
          const dirToPlayer = playerCenterX >= en.x ? 1 : -1;

          if (en.state === 'idle') {
            if (en.recoveryTimer > 0) en.recoveryTimer -= step;
            const pInKnightRoom = en.roomBounds
              ? (playerCenterX >= en.roomBounds.minX - 80 && playerCenterX <= en.roomBounds.maxX + 80 &&
                 playerCenterY >= en.roomBounds.minY - 80 && playerCenterY <= en.roomBounds.maxY + 80)
              : isPlayerOnEnemyPlatform(en);

            // Knight initiates attack strictly when within actual sword reach of the player ("рыцари начинали именно атаковать только когда достают мечом до игрока")
            const knightSwordReach = 105;
            if (pInKnightRoom && distToPlayer <= knightSwordReach && en.recoveryTimer <= 0) {
              en.state = 'windup';
              en.windupTimer = 0;
              en.vx = 0; // Freeze in place immediately
            }
          } else if (en.state === 'windup') {
            en.windupTimer += step;
            en.vx = 0; // Completely stop in place during windup

            // High tension sparks
            const tension = Math.min(1, en.windupTimer / en.maxWindup);
            if (Math.random() < tension * 0.22) {
              state.particles.push({
                x: en.x + (Math.random() - 0.5) * 24,
                y: en.y - 12 + (Math.random() - 0.5) * 24,
                vx: (Math.random() - 0.5) * 4,
                vy: -Math.random() * 4,
                life: 0.35,
                maxLife: 0.35,
                color: tension > 0.75 ? '#ef4444' : '#f59e0b',
                size: 3
              });
            }

            if (en.windupTimer >= en.maxWindup) {
              en.state = 'strike';
              en.strikeTimer = 0;
              soundManager.playSwing(1.3);
            }
          } else if (en.state === 'strike') {
            en.strikeTimer += step;
            en.vx = 0; // Stay planted in place, no forward sprinting
            if (en.strikeTimer >= 16) {
              en.state = 'recovery';
              en.recoveryTimer = 14; // Very short recovery for rapid consecutive attack readiness
            }
          } else if (en.state === 'recovery') {
            en.recoveryTimer -= step;
            if (en.recoveryTimer <= 0) {
              en.state = 'idle';
            }
          }

          if (en.ropePoints && en.ropePoints.length > 0) {
            en.ropePoints[0].x = en.x;
            en.ropePoints[0].y = en.y;

            let targetKnightAngle = Math.PI * 0.45 * (en.vx >= 0 ? -1 : 1);
            if (en.state === 'windup') {
              // Smooth high pull over shoulder with subtle tension tremor
              const tension = Math.min(1, en.windupTimer / en.maxWindup);
              const jitter = Math.sin(en.windupTimer * 0.7) * tension * 0.15;
              targetKnightAngle = angleToPlayer - dirToPlayer * (Math.PI * 0.8) + jitter;
            } else if (en.state === 'strike') {
              // Powerful strike towards player
              targetKnightAngle = angleToPlayer;
            } else if (en.state === 'recovery') {
              // Lowered resting sword
              targetKnightAngle = Math.PI * 0.5;
            }

            if (en.smoothAngle === undefined) en.smoothAngle = targetKnightAngle;
            let angleDiff = targetKnightAngle - en.smoothAngle;
            while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
            while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;

            const smoothRate = en.state === 'strike' ? 0.38 : (en.state === 'windup' ? 0.08 : 0.12);
            en.smoothAngle += angleDiff * smoothRate * step;

            const kLastP = en.ropePoints[en.ropePoints.length - 1];
            const pullForce = en.state === 'strike' ? 22 : (en.state === 'windup' ? 8.5 : 5.5);
            kLastP.x += Math.cos(en.smoothAngle) * pullForce * step;
            kLastP.y += Math.sin(en.smoothAngle) * pullForce * step;

            for (let i = 1; i < en.ropePoints.length; i++) {
              let kp = en.ropePoints[i];
              let kpvx = (kp.x - kp.oldX) * 0.95;
              let kpvy = (kp.y - kp.oldY) * 0.95;
              kp.oldX = kp.x; kp.oldY = kp.y;
              kp.x += kpvx;
              kp.y += kpvy;
            }

            // Segment constraints (optimized 4 iterations)
            for (let n = 0; n < 4; n++) {
              for (let i = 0; i < en.ropePoints.length - 1; i++) {
                let kp1 = en.ropePoints[i], kp2 = en.ropePoints[i + 1];
                let kdx = kp2.x - kp1.x, kdy = kp2.y - kp1.y;
                let kd = Math.sqrt(kdx * kdx + kdy * kdy) || 0.1;
                let kdiff = (8 - kd) / kd;
                if (i !== 0) { kp1.x -= kdx * kdiff * 0.5; kp1.y -= kdy * kdiff * 0.5; }
                kp2.x += kdx * kdiff * 0.5; kp2.y += kdy * kdiff * 0.5;
              }
            }

            // Knight blade points (only computed when close to player or active strike)
            if (distToPlayer < 200) {
              const kPrevP = en.ropePoints[en.ropePoints.length - 2];
              const kAng = Math.atan2(kLastP.y - kPrevP.y, kLastP.x - kPrevP.x);
              let knightBladePoints: { x: number; y: number }[] = [];
              for (let d = 10; d <= 85; d += 12) {
                knightBladePoints.push({
                  x: kLastP.x + Math.cos(kAng) * d,
                  y: kLastP.y + Math.sin(kAng) * d
                });
              }

              // Check Knight sword hit on player (ONLY during active STRIKE phase!)
              if (en.state === 'strike') {
                for (let kpt of knightBladePoints) {
                  if (Math.hypot(kpt.x - playerCenterX, kpt.y - playerCenterY) < 24) {
                    takeDamage(en.x, getEnemyDamage('knight_sword'));
                    kLastP.x += Math.cos(kAng) * 20;
                    kLastP.y += Math.sin(kAng) * 20;
                    en.state = 'recovery';
                    en.recoveryTimer = 14;
                    break;
                  }
                }
              }

              // Check Sword vs Sword Clash / Parry (ONLY during active STRIKE phase, NEVER interrupt windup!)
              if (state.ropePoints.length > 1 && en.state === 'strike') {
                let clashed = false;
                for (let pt of bladeCheckPoints) {
                  for (let kpt of knightBladePoints) {
                    if (Math.hypot(pt.x - kpt.x, pt.y - kpt.y) < 20) {
                      clashed = true;
                      const playerLast = state.ropePoints[state.ropePoints.length - 1];
                      const playerPrev = state.ropePoints[state.ropePoints.length - 2];
                      const playerAng = Math.atan2(playerLast.y - playerPrev.y, playerLast.x - playerPrev.x);

                      playerLast.x -= Math.cos(playerAng) * 11;
                      playerLast.y -= Math.sin(playerAng) * 11;
                      state.swordLock = getAttackRecoveryTimeSec();

                      kLastP.x += Math.cos(kAng) * 11;
                      kLastP.y += Math.sin(kAng) * 11;
                      en.state = 'recovery';
                      en.recoveryTimer = isFullWindupCut ? 45 : 30;

                      soundManager.playClash();

                      for (let s = 0; s < 2; s++) {
                        state.particles.push({
                          x: (pt.x + kpt.x) / 2, y: (pt.y + kpt.y) / 2,
                          vx: (Math.random() - 0.5) * 14, vy: (Math.random() - 0.5) * 14,
                          life: 0.6, maxLife: 0.6, color: '#fef08a', size: 3.5
                        });
                      }
                      break;
                    }
                  }
                  if (clashed) break;
                }
              }
            }
          }
        } else if (en.type === 'phantom') {
          // Mini clone manifestation after split ("а при раздвоении верни чтобы они пока мерцали разлетались медленно в разные стороны")
          const phantomBounds = {
            minX: en.leftBound ?? (en.roomBounds ? en.roomBounds.minX + 20 : (en.parent ? en.parent.x - 30 : en.x - 120)),
            maxX: en.rightBound ?? (en.roomBounds ? en.roomBounds.maxX - 20 : (en.parent ? en.parent.x + en.parent.width + 30 : en.x + 120)),
            minY: en.topBound ?? (en.roomBounds ? (en.roomBounds.minY ?? en.roomBounds.topY) + 20 : (en.parent ? en.parent.y - 220 : en.y - 100)),
            maxY: en.bottomBound ?? (en.roomBounds ? (en.roomBounds.maxY ?? en.roomBounds.bottomY) - 20 : (en.parent ? en.parent.y + 40 : en.y + 100))
          };

          if (en.isSplitClone && en.isFlickering) {
            en.flickerTimer = (en.flickerTimer || 0) - step;
            // Slowly drift in opposite directions while flickering, cleanly bouncing off walls like circular balls
            bounceCircleAgainstWallsAndObstacles(en, step, phantomBounds);

            en.fadeAlpha = Math.min(1.0, 1.0 - (en.flickerTimer / (en.maxFlickerTimer || 90)));

            if (en.flickerTimer <= 0) {
              en.isFlickering = false;
              en.fadeAlpha = 1.0;
              en.state = 'hover';
              // After full manifestation, smoothly continue into normal patrol
              const moveAng = Math.atan2(en.vy || 1, en.vx || 1);
              const baseSpeed = 1.25 * Math.pow(1.08, (state.level || 1) - 1);
              en.targetVx = Math.cos(moveAng) * baseSpeed;
              en.targetVy = Math.sin(moveAng) * (baseSpeed * 0.75);
            }
          } else if (en.state === 'hover') {
            if ((en.cooldownTimer || 0) > 0) {
              en.cooldownTimer -= step;
            }

            // Smooth gradual acceleration towards chosen vector without any jerks (for both big and mini phantoms)
            if (en.targetVx === undefined || en.targetVy === undefined) {
              const moveAng = Math.random() * Math.PI * 2;
              const lvlMult = Math.pow(1.10, (state.level || 1) - 1);
              const baseSpeed = (en.isSplitClone ? 1.15 : 1.35) * lvlMult;
              en.targetVx = Math.cos(moveAng) * baseSpeed;
              en.targetVy = Math.sin(moveAng) * (baseSpeed * 0.75);
            }

            en.vx += (en.targetVx - en.vx) * 0.035 * step;
            en.vy += (en.targetVy - en.vy) * 0.035 * step;
            
            // 2-axis circular wall bounce like round balls ("как кругляхи")
            bounceCircleAgainstWallsAndObstacles(en, step, phantomBounds);

            // Trigger charge when player is near the phantom or in the room/zone
            const minX = phantomBounds.minX;
            const maxX = phantomBounds.maxX;
            const topY = phantomBounds.minY;
            const botY = phantomBounds.maxY;
            const inRoomBounds = (en.roomBounds || en.leftBound !== undefined)
              ? (playerCenterX >= minX - 84 && playerCenterX <= maxX + 84 &&
                 playerCenterY >= topY - 84 && playerCenterY <= botY + 84)
              : true;
            const pInPhantomZone = inRoomBounds || distToPlayer < 280;

            // Active menacing phantom approach when player is within range
            if (pInPhantomZone && distToPlayer > 98) {
              const angToP = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
              const lvlMult = Math.pow(1.10, (state.level || 1) - 1);
              const patrolSpeed = (en.isSplitClone ? 1.4 : 1.6) * lvlMult;
              en.targetVx = Math.cos(angToP) * patrolSpeed;
              en.targetVy = Math.sin(angToP) * (patrolSpeed * 0.75);
            }

            if (pInPhantomZone && distToPlayer < 266 && (en.cooldownTimer || 0) <= 0) {
              en.state = 'charge';
              en.chargeTimer = 0;
              en.lockedDashAngle = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
            }
          } else if (en.state === 'charge') {
              // Energy Gathering Phase (Нагнетание) - returned to original slower speed
              const lvl = Math.max(1, state.level || statsRef.current.level || 1);
              en.chargeTimer = (en.chargeTimer || 0) + step * (0.85 + (lvl - 1) * 0.03);
              en.vx *= Math.pow(0.82, step);
              en.vy *= Math.pow(0.82, step);

              // Track player direction during early windup
              if (en.chargeTimer < 25) {
                en.lockedDashAngle = Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
              }

              if (Math.random() < 0.12) {
                const pAng = Math.random() * Math.PI * 2;
                const pDist = 30 + Math.random() * 20;
                state.particles.push({
                  x: en.x + Math.cos(pAng) * pDist,
                  y: en.y + Math.sin(pAng) * pDist,
                  vx: -Math.cos(pAng) * 3.5,
                  vy: -Math.sin(pAng) * 3.5,
                  life: 0.35,
                  maxLife: 0.35,
                  color: en.isWhitePhantom ? '#e2e8f0' : (Math.random() < 0.5 ? '#38bdf8' : '#c084fc'),
                  size: Math.random() * 3 + 2.5
                });
              }

              if (en.chargeTimer > 42.0) {
                en.state = 'dash';
                en.dashTimer = 0;
                const angToP = en.lockedDashAngle !== undefined ? en.lockedDashAngle : Math.atan2(playerCenterY - en.y, playerCenterX - en.x);
                const dashMult = en.isSplitClone ? 7.5 : 12.0;
                en.dashVx = Math.cos(angToP) * dashMult;
                en.dashVy = Math.sin(angToP) * dashMult;
                soundManager.playSwing(2.2);
              }
          } else if (en.state === 'dash') {
            // Glowing Ghost Dash (Светится и делает рывок) - bounces off obstacles cleanly
            en.dashTimer = (en.dashTimer || 0) + step;
            const dashObj = { x: en.x, y: en.y, vx: en.dashVx, vy: en.dashVy, r: en.r };
            bounceCircleAgainstWallsAndObstacles(dashObj, step, phantomBounds);
            en.x = dashObj.x;
            en.y = dashObj.y;
            en.dashVx = dashObj.vx;
            en.dashVy = dashObj.vy;

            for (let p = 0; p < 1; p++) {
              state.particles.push({
                x: en.x + (Math.random() - 0.5) * 18,
                y: en.y + (Math.random() - 0.5) * 18,
                vx: -en.dashVx * 0.25 + (Math.random() - 0.5) * 2,
                vy: -en.dashVy * 0.25 + (Math.random() - 0.5) * 2,
                life: 0.45,
                maxLife: 0.45,
                color: en.isWhitePhantom ? '#f8fafc' : (Math.random() < 0.6 ? '#38bdf8' : '#e0f2fe'),
                size: Math.random() * 4 + 3
              });
            }

            const minX = phantomBounds.minX;
            const maxX = phantomBounds.maxX;
            const topY = phantomBounds.minY;
            const botY = phantomBounds.maxY;
            const isOutside = en.x < minX || en.x > maxX || en.y < topY || en.y > botY;

            // After dash completion, big phantoms vanish into the void to relocate and reappear:
            if (!en.isSplitClone) {
              if (en.dashTimer > 20 || isOutside) {
                en.state = 'vanish';
                en.fadeAlpha = 1.0;
                en.dashVx = 0;
                en.dashVy = 0;
                en.vx = 0;
                en.vy = 0;
              }
            } else {
              if (isOutside || en.dashTimer > 20) {
                en.state = 'hover';
                en.cooldownTimer = 40 + Math.random() * 25;
                const moveAng = Math.random() * Math.PI * 2;
                const baseSpeed = 1.15 * Math.pow(1.08, (state.level || 1) - 1);
                en.targetVx = Math.cos(moveAng) * baseSpeed;
                en.targetVy = Math.sin(moveAng) * (baseSpeed * 0.75);
                en.vx = 0;
                en.vy = 0;
              }
            }
          } else if (en.state === 'vanish') {
            // Smoothly fade out when vanishing ("после исчезновения больших призраков всех типов")
            en.fadeAlpha = (en.fadeAlpha !== undefined ? en.fadeAlpha : 1.0) - 0.05 * step;
            en.vx = 0;
            en.vy = 0;

            if (Math.random() < 0.4) {
              state.particles.push({
                x: en.x + (Math.random() - 0.5) * 20,
                y: en.y + (Math.random() - 0.5) * 20,
                vx: (Math.random() - 0.5) * 3,
                vy: -Math.random() * 3,
                life: 0.4, maxLife: 0.4,
                color: en.isWhitePhantom ? '#cbd5e1' : '#c084fc',
                size: Math.random() * 4 + 2
              });
            }

            if (en.fadeAlpha <= 0) {
              en.fadeAlpha = 0;
              // Teleport to a new safe point inside the room/zone, ensuring it never spawns inside a wall or obstacle
              const minX = en.leftBound ?? (en.roomBounds ? en.roomBounds.minX + 40 : (en.parent ? en.parent.x + 30 : en.x - 80));
              const maxX = en.rightBound ?? (en.roomBounds ? en.roomBounds.maxX - 40 : (en.parent ? en.parent.x + en.parent.width - 30 : en.x + 80));
              const topY = en.topBound ?? (en.roomBounds ? (en.roomBounds.minY ?? en.roomBounds.topY) + 40 : (en.parent ? en.parent.y - 180 : en.y - 80));
              const botY = en.bottomBound ?? (en.roomBounds ? (en.roomBounds.maxY ?? en.roomBounds.bottomY) - 40 : (en.parent ? en.parent.y - 40 : en.y + 40));

              const bMinX = Math.min(minX, maxX - 20);
              const bMaxX = Math.max(maxX, minX + 20);
              const bTopY = Math.min(topY, botY - 20);
              const bBotY = Math.max(botY, topY + 20);

              for (let att = 0; att < 20; att++) {
                en.x = bMinX + 10 + Math.random() * Math.max(10, bMaxX - bMinX - 20);
                en.y = bTopY + 10 + Math.random() * Math.max(10, bBotY - bTopY - 20);
                let collides = false;
                for (let i = 0; i < state.walls.length; i++) {
                  const w = state.walls[i];
                  if (!w.alive || (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85)) continue;
                  if (en.x + en.r > w.x && en.x - en.r < w.x + w.w &&
                      en.y + en.r > w.y && en.y - en.r < w.y + w.h) {
                    collides = true; break;
                  }
                }
                if (!collides) {
                  for (let i = 0; i < obstacleColliders.length; i++) {
                    const obs = obstacleColliders[i];
                    if (en.x + en.r > obs.x && en.x - en.r < obs.x + obs.w &&
                        en.y + en.r > obs.y && en.y - en.r < obs.y + obs.h) {
                      collides = true; break;
                    }
                  }
                }
                if (!collides) break;
              }

              en.state = 'reappear';
              en.vx = 0;
              en.vy = 0;
              soundManager.playTeleport();
            }
          } else if (en.state === 'reappear') {
            // Smoothly manifest at the new point, standing still while appearing
            en.fadeAlpha = (en.fadeAlpha !== undefined ? en.fadeAlpha : 0) + 0.045 * step;
            en.vx = 0;
            en.vy = 0;

            if (Math.random() < 0.45) {
              state.particles.push({
                x: en.x + (Math.random() - 0.5) * 30,
                y: en.y + (Math.random() - 0.5) * 30,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                life: 0.4, maxLife: 0.4,
                color: en.isWhitePhantom ? '#f8fafc' : (Math.random() < 0.5 ? '#38bdf8' : '#c084fc'),
                size: Math.random() * 5 + 3
              });
            }

            if (en.fadeAlpha >= 1.0) {
              en.fadeAlpha = 1.0;
              en.state = 'hover';
              en.cooldownTimer = 35 + Math.random() * 25; // Ready to charge soon after appearing

              // Pick a new movement vector and smoothly accelerate from 0 ("они должны выбирать новый вектор движения и плавно набирать скорость")
              const moveAng = Math.random() * Math.PI * 2;
              const lvlSpeedMult = 1.0 + ((state.level || 1) - 1) * 0.02;
              const baseSpeed = 1.35 * lvlSpeedMult;
              en.targetVx = Math.cos(moveAng) * baseSpeed;
              en.targetVy = Math.sin(moveAng) * (baseSpeed * 0.75);
              en.vx = 0;
              en.vy = 0;
            }
          }
        }
      }

      // Damage Player on direct body touch (spat saw mobs in air don't deal damage)
      if (distToPlayer < en.r + 14 && !(en.type === 'saw' && en.isSpittingInAir)) {
          const dmgType = en.type === 'knight' ? 'knight_body' : 
                          en.type === 'ice' ? 'ice_body' : 
                          en.type === 'phantom' ? 'phantom_body' : 
                          en.type === 'sorcerer' ? 'sorcerer_body' : 
                          en.type === 'saw' ? 'saw_body' :
                          'fatty_body';
          takeDamage(en.x, getEnemyDamage(dmgType));
        }

        // Damage Enemy with Player's Sword
        if (state.swordLock <= 0) {
          let isTouchingSword = false;
          for (let pt of bladeCheckPoints) {
            const dx = pt.x - en.x;
            const dy = pt.y - en.y;
            const rSum = en.r + 12;
            if (dx * dx + dy * dy < rSum * rSum) {
              isTouchingSword = true;
              break;
            }
          }

          if (isTouchingSword) {
            if ((en.hitCooldown ?? 0) <= 0) {
              en.isStruck = false;
            }
            const canHit = !en.isStruck && (en.hitCooldown ?? 0) <= 0;
            if (canHit) {
              let { dmg, baseDmg, isCrit } = calculatePlayerHitDamage();
              const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
              const isImmuneFatty = en.type === 'fatty' && hasActivePylons;
              const isImmuneSaw = en.type === 'saw' && Boolean(en.isChargingExplosion);
              const isImmuneWhitePhantom = en.type === 'phantom' && Boolean(en.isFlickering);
              let isImmune = isImmuneFatty || isImmuneSaw || isImmuneWhitePhantom;
              
              // Stun overrides immunity: "Под эффектом стана мобы должны быть уязвимы для атак"
              if ((en.stunTimer || 0) > 0) {
                isImmune = false;
              }

              if (isImmune) {
                en.isStruck = true;
                en.hitCooldown = 0.15;
                soundManager.playHit(false, weaponRef.current?.type);

                state.damageTexts.push({
                  id: 'dmg_' + Date.now() + Math.random(),
                  text: `ИММУНИТЕТ!`,
                  x: en.x, y: en.y,
                  vx: (Math.random() - 0.5) * 4, vy: -7,
                  life: 1.2,
                  isCrit: false,
                  color: '#9ca3af'
                });
              } else {
                // --- AXE RUTHLESSNESS MECHANIC ("Безжалостность") ---
                // чем меньше здоровья у цели, тем больше урон топора.
                // Расчет идет от обычного базового урона (baseDmg) с собственным шансом на крит
                let axeBonusDmg = 0;
                let isAxeCrit = false;
                const curWeapon = weaponRef.current;
                if (curWeapon && curWeapon.type === 'axe') {
                  const maxHp = Math.max(1, en.maxHp || en.hp || 1);
                  const curHp = Math.max(0, en.hp);
                  const missingHpPct = Math.max(0, Math.min(100, ((maxHp - curHp) / maxHp) * 100));

                  const rarity = curWeapon.rarity || 'common';
                  const upLvl = curWeapon.upgradeLevel || 0;
                  const defaultBaseRatio = rarity === 'magic' ? 0.00232375 : rarity === 'rare' ? 0.0038025 : rarity === 'epic' ? 0.0054925 : 0.0012675;
                  const incPerLvl = rarity === 'magic' ? 0.000338 : rarity === 'rare' ? 0.000676 : rarity === 'epic' ? 0.000845 : 0.000169;
                  const ratio = curWeapon.ruthlessnessRatio ?? (defaultBaseRatio + incPerLvl * upLvl);

                  const bonusMultiplier = Math.min(1.30, missingHpPct * ratio);
                  if (bonusMultiplier > 0) {
                    const rawAxeBonus = baseDmg * bonusMultiplier;
                    const { critChance: aCritChance, critMultiplier: aCritMult } = getPlayerCritStats();
                    isAxeCrit = Math.random() < aCritChance;
                    axeBonusDmg = Math.max(1, Math.round(isAxeCrit ? rawAxeBonus * aCritMult : rawAxeBonus));
                    dmg += axeBonusDmg;
                  }
                }

                en.hp -= dmg;
                applyVampirismHealing(dmg, en);
                en.isStruck = true;
                // If enemy is stunned, it is vulnerable (reduced hit cooldown)
                en.hitCooldown = (en.stunTimer || 0) > 0 ? 0.05 : 0.15;
                soundManager.playHit(isCrit, weaponRef.current?.type);

                state.damageTexts.push({
                  id: 'dmg_' + Date.now() + Math.random(),
                  text: `${isCrit ? 'КРИТ! ' : ''}-${dmg}`,
                  x: en.x, y: en.y,
                  vx: (Math.random() - 0.5) * 6, vy: -9,
                  life: 1.4,
                  isCrit,
                  color: isCrit ? '#f59e0b' : '#f43f5e'
                });

                if (axeBonusDmg > 0) {
                  state.damageTexts.push({
                    id: 'dmg_axe_' + Date.now() + Math.random(),
                    text: `🪓 +${axeBonusDmg}`,
                    x: en.x, y: en.y - 36,
                    vx: (Math.random() - 0.5) * 4, vy: -10,
                    life: 1.3,
                    isCrit: isAxeCrit,
                    color: isAxeCrit ? '#f59e0b' : '#f97316'
                  });
                }

                // Trigger Chain Lightning if Trinket is equipped (calculated from base damage)
                triggerChainLightning(en, baseDmg);

                // --- HAMMER STUN & BONUS DAMAGE MECHANIC ---
                // Расчет дополнительного урона от стана молота идет от baseDmg со своим шансом на крит
                if (curWeapon && curWeapon.type === 'hammer') {
                  const rarity = curWeapon.rarity || 'common';
                  const upLvl = curWeapon.upgradeLevel || 0;

                  const defaultBaseChance = rarity === 'magic' ? 0.0504 : rarity === 'rare' ? 0.0756 : rarity === 'epic' ? 0.126 : 0.0252;
                  const chancePerLvl = rarity === 'magic' ? 0.00945 : rarity === 'rare' ? 0.0126 : rarity === 'epic' ? 0.02205 : 0.0063;
                  const stunChance = curWeapon.stunChance ?? (defaultBaseChance + chancePerLvl * upLvl);

                  const defaultBonusRatio = rarity === 'magic' ? 0.65 : rarity === 'rare' ? 0.80 : rarity === 'epic' ? 1.00 : 0.50;
                  const bonusRatio = curWeapon.bonusDamageMultiplier ?? defaultBonusRatio;

                  if (Math.random() < stunChance) {
                    // Stun duration is exactly 2 seconds (bosses 0.2 sec per user instruction)
                    const isBoss = Boolean(en.isBoss || en.type === 'fatty' || en.isDungeonBoss);
                    const finalStunDur = isBoss ? 0.2 : 2.0;
                    en.stunTimer = Math.max(en.stunTimer || 0, finalStunDur);
                    
                    const rawHammerBonus = baseDmg * bonusRatio;
                    const { critChance: hCritChance, critMultiplier: hCritMult } = getPlayerCritStats();
                    const isHammerCrit = Math.random() < hCritChance;
                    const bonusDmg = Math.max(1, Math.round(isHammerCrit ? rawHammerBonus * hCritMult : rawHammerBonus));
                    if (bonusDmg > 0) {
                      en.hp -= bonusDmg;
                      // No vampirism from stun damage per requirement
                      state.damageTexts.push({
                        id: 'dmg_stun_' + Date.now() + Math.random(),
                        text: `💥 +${bonusDmg}`,
                        x: en.x, y: en.y - 22,
                        vx: (Math.random() - 0.5) * 5, vy: -11,
                        life: 1.5,
                        isCrit: isHammerCrit,
                        color: isHammerCrit ? '#f59e0b' : '#fbbf24'
                      });
                    }
                  }
                }

                // --- SPEAR BLEED MECHANIC ("Рваная рана" - 2.5 сек, раз в 0.5 сек, стакается) ---
                // Базовый суммарный урон кровотечения рассчитывается от baseDmg, а каждый тик имеет свой шанс на крит
                if (curWeapon && curWeapon.type === 'spear') {
                  const bChance = curWeapon.bleedChance ?? 0.04;
                  const bRatio = curWeapon.bleedDamageRatio ?? 0.95;
                  if (Math.random() < bChance) {
                    const totalBleedDamage = baseDmg * bRatio;
                    const bleedDuration = 2.5; // 2.5 seconds total
                    const tickInterval = 0.5; // Every 0.5 seconds
                    if (!en.bleedStacks) en.bleedStacks = [];
                    en.bleedStacks.push({
                      id: 'bleed_' + Date.now() + Math.random(),
                      timer: bleedDuration,
                      tickTimer: tickInterval,
                      baseTickDamage: totalBleedDamage / 5
                    });
                    en.bleedTimer = Math.max(...en.bleedStacks.map((s: any) => s.timer));
                    state.damageTexts.push({
                      id: 'dmg_bleed_start_' + Date.now() + Math.random(),
                      text: `🩸`,
                      x: en.x, y: en.y - 65,
                      vx: (Math.random() - 0.5) * 4, vy: -12,
                      life: 1.2,
                      color: '#ef4444'
                    });
                  }
                }
              }

              // Sword recoil bounce & hit cooldown for player weapon on ALL hits (normal and fast rotation)
              if (state.ropePoints.length > 1) {
                const last = state.ropePoints[state.ropePoints.length - 1];
                const prev = state.ropePoints[state.ropePoints.length - 2];
                const sang = Math.atan2(last.y - prev.y, last.x - prev.x);
                last.x -= Math.cos(sang) * 11;
                last.y -= Math.sin(sang) * 11;
              }
              // Double Strike Chance for Blade Weapons (Sword, Rapier, Katana, Greatsword, Dagger) with 1-second CD
              const dsChance = weaponRef.current?.doubleStrikeChance;
              if (dsChance && state.doubleStrikeCdTimer <= 0 && Math.random() < dsChance) {
                state.doubleStrikeCdTimer = 1.0; // 1 second cooldown for double strike
                state.swordLock = 0.05;
                state.damageTexts.push({
                  id: 'dmg_ds_' + Date.now() + Math.random(),
                  text: `⚔️`,
                  x: playerCenterX, y: playerCenterY - 45,
                  vx: (Math.random() - 0.5) * 4, vy: -12,
                  life: 1.2,
                  color: '#38bdf8'
                });
              } else {
                state.swordLock = getAttackRecoveryTimeSec();
              }

              if (en.type !== 'fatty' && en.type !== 'pylon' && !isImmuneSaw) {
                // Directional 2D knockback vector based on player relative position
                const kdx = en.x - playerCenterX;
                const kdy = en.y - playerCenterY;
                const kdist = Math.hypot(kdx, kdy) || 1.0;
                const dirX = kdx / kdist;
                const dirY = kdy / kdist;

                // If knight is in windup or strike, full super armor / poise: complete immunity to knockback & stagger
                if (en.type === 'knight' && (en.state === 'windup' || en.state === 'strike')) {
                  en.knockVx = 0;
                  en.knockVy = 0;
                } else if (en.type === 'phantom' && en.state === 'charge') {
                  // Super armor strictly during phantom charge ("только отключай его во время чарджа призраков")
                  en.knockVx = 0;
                  en.knockVy = 0;
                } else {
                  const force = (en.type === 'knight' ? 4.5 : (en.type === 'phantom' ? 7.5 : 4.0));
                  en.knockVx = dirX * force;
                  en.knockVy = dirY * force * (en.type === 'phantom' ? 0.75 : 1.0);
                }
              }

              // Enemy Death
              if (!isImmune && en.hp <= 0) {
                killEnemy(en);
              }
            }
          } else {
            en.isStruck = false;
          }
        }
      });

      // Helper: Trigger Fireball Impact & Radial Shockwave Explosion ("взрыв с ореолом и искры")
      const triggerFireballExplosion = (expX: number, expY: number) => {
        state.screenShake = Math.max(state.screenShake, 18);
        soundManager.playClash();

        // 1. VISIBLE RADIAL EXPLOSION SHOCKWAVE AURA RING ("взрыв с ореолом")
        state.shockwaves.push({
          x: expX,
          y: expY,
          r: 10,
          maxR: 110,
          color: '#f97316',
          life: 0.8,
          maxLife: 0.8
        });
        state.shockwaves.push({
          x: expX,
          y: expY,
          r: 5,
          maxR: 110,
          color: '#ef4444',
          life: 0.6,
          maxLife: 0.6
        });

        // 2. RADIAL FIREBALL EMBERS & FLYING SPARKS (35 particles)
        for (let i = 0; i < 35; i++) {
          const rAng = (i / 35) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
          const rSpd = 4 + Math.random() * 12;
          state.particles.push({
            x: expX,
            y: expY,
            vx: Math.cos(rAng) * rSpd,
            vy: Math.sin(rAng) * rSpd - 2,
            life: 0.55,
            maxLife: 0.55,
            color: Math.random() < 0.4 ? '#fef08a' : (Math.random() < 0.7 ? '#f97316' : '#dc2626'),
            size: 3.0 + Math.random() * 4.5,
            shape: Math.random() < 0.5 ? 'spark' : undefined
          });
        }

        // 3. AoE Damage & Knockback to Player within 110px radius
        const pDist = Math.hypot(playerCenterX - expX, playerCenterY - expY);
        if (pDist < 110) {
          takeDamage(expX, getEnemyDamage('fatty_fireball'));
          const expAng = Math.atan2(playerCenterY - expY, playerCenterX - expX) || -Math.PI * 0.5;
          state.player.vx = Math.cos(expAng) * 14;
          state.player.vy = -10;
        }
      };

      // --- ICE & MAGIC PROJECTILES & FIREBALLS (Deflection & Wall Collision Mechanics) ---
      state.iceProjectiles.forEach(proj => {
        if (!proj.alive) return;
        proj.x += proj.vx * step;
        proj.y += proj.vy * step;
        proj.life -= 0.016 * step;
        if (proj.life <= 0) proj.alive = false;

        // Fireball Trailing Sparks Emitter
        if (proj.isFireball) {
          for (let spk = 0; spk < 2; spk++) {
            state.particles.push({
              x: proj.x + (Math.random() - 0.5) * 14,
              y: proj.y + (Math.random() - 0.5) * 14,
              vx: -proj.vx * 0.35 + (Math.random() - 0.5) * 5,
              vy: -proj.vy * 0.35 + (Math.random() - 0.5) * 5,
              life: 0.35, maxLife: 0.35,
              color: Math.random() < 0.45 ? '#fef08a' : (Math.random() < 0.75 ? '#f97316' : '#ef4444'),
              size: Math.random() * 3.5 + 1.5,
              shape: 'spark'
            });
          }

          // Check if Fireball reaches aimed ground target point
          if (proj.targetX !== undefined && proj.targetY !== undefined) {
            const distToTarget = Math.hypot(proj.x - proj.targetX, proj.y - proj.targetY);
            const distFromStart = Math.hypot(proj.x - (proj.startX || proj.x), proj.y - (proj.startY || proj.y));
            const targetDistTotal = Math.hypot((proj.targetX - (proj.startX || proj.x)), (proj.targetY - (proj.startY || proj.y)));

            if (distToTarget < 28 || distFromStart >= targetDistTotal) {
              proj.alive = false;
              triggerFireballExplosion(proj.x, proj.y);
              return;
            }
          }
        }

        // Check collision with solid walls / obstacles
        for (let i = 0; i < state.walls.length; i++) {
          const w = state.walls[i];
          if (!w.alive) continue;
          if (Math.abs(w.x - proj.x) > w.w + 50 || Math.abs(w.y - proj.y) > w.h + 50) continue;
          if (w.isBossGate && !w.isClosed) continue;
          if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) continue;

          if (proj.x >= w.x && proj.x <= w.x + w.w && proj.y >= w.y && proj.y <= w.y + w.h) {
            proj.alive = false;
            
            if (proj.isFireball) {
              triggerFireballExplosion(proj.x, proj.y);
              break;
            }

            // Impact particles based on projectile type
            const pColor = proj.isMagicBolt ? '#a855f7' : '#38bdf8';
            for (let s = 0; s < 7; s++) {
              state.particles.push({
                x: proj.x, y: proj.y,
                vx: (Math.random() - 0.5) * 8 - (proj.vx * 0.2),
                vy: (Math.random() - 0.5) * 8 - (proj.vy * 0.2),
                life: 0.35, maxLife: 0.35,
                color: pColor,
                size: Math.random() * 3 + 1.5
              });
            }

            // Destructible wall damage
            if (!w.indestructible) {
              w.hp = (w.hp ?? 40) - 20;
              if (w.hp <= 0) {
                w.alive = false;
                soundManager.playWallBump();
                for (let s = 0; s < 12; s++) {
                  state.particles.push({
                    x: w.x + Math.random() * w.w,
                    y: w.y + Math.random() * w.h,
                    vx: (Math.random() - 0.5) * 8,
                    vy: (Math.random() - 0.5) * 8,
                    life: 0.45, maxLife: 0.45,
                    color: '#64748b',
                    size: 3
                  });
                }
              }
            }
            break;
          }
        }

        // Check collision with altars
        if (state.dungeonDecorations) {
          for (let d = 0; d < state.dungeonDecorations.length; d++) {
            const dec = state.dungeonDecorations[d];
            if (dec.type === 'altar') {
              const axMin = dec.x - 36;
              const axMax = dec.x + 36;
              const ayMin = dec.y - 21;
              const ayMax = dec.y + 31;
              if (proj.x >= axMin && proj.x <= axMax && proj.y >= ayMin && proj.y <= ayMax) {
                proj.alive = false;
                if (proj.isFireball) {
                  triggerFireballExplosion(proj.x, proj.y);
                } else {
                  // Impact particles based on projectile type
                  const pColor = proj.isMagicBolt ? '#a855f7' : '#38bdf8';
                  for (let s = 0; s < 7; s++) {
                    state.particles.push({
                      x: proj.x, y: proj.y,
                      vx: (Math.random() - 0.5) * 8 - (proj.vx * 0.2),
                      vy: (Math.random() - 0.5) * 8 - (proj.vy * 0.2),
                      life: 0.35, maxLife: 0.35,
                      color: pColor,
                      size: Math.random() * 3 + 1.5
                    });
                  }
                }
                break;
              }
            }
          }
        }

        if (!proj.alive) return;

        // Check deflection by player's sword (Fireballs cannot be reflected!)
        if (!proj.isReflected && !proj.isFireball && bladeCheckPoints.length > 0 && state.swordLock <= 0) {
          for (let pt of bladeCheckPoints) {
            if (Math.hypot(pt.x - proj.x, pt.y - proj.y) < 22) {
              proj.isReflected = true;
              soundManager.playClash();

              const last = state.ropePoints[state.ropePoints.length - 1];
              const prev = state.ropePoints[state.ropePoints.length - 2];
              const bladeAng = Math.atan2(last.y - prev.y, last.x - prev.x);

              proj.vx = Math.cos(bladeAng) * 18;
              proj.vy = Math.sin(bladeAng) * 18;

              last.x -= Math.cos(bladeAng) * 7;
              last.y -= Math.sin(bladeAng) * 7;
              state.swordLock = getAttackRecoveryTimeSec();

              for (let s = 0; s < 10; s++) {
                state.particles.push({
                  x: proj.x, y: proj.y,
                  vx: (Math.random() - 0.5) * 12, vy: (Math.random() - 0.5) * 12,
                  life: 0.8, maxLife: 0.8, color: '#38bdf8', size: 4
                });
              }
              break;
            }
          }
        }

        // Damage Enemies if reflected
        if (proj.isReflected) {
          const { dmg: baseDmg } = calculatePlayerHitDamage();
          const reflectDmg = Math.max(1, Math.round(baseDmg * 1.5));

          state.enemies.forEach(en => {
            const dx = en.x - proj.x;
            const dy = proj.y - en.y;
            const rSum = en.r + 14;
            if (en.alive && !en.isDyingFadeOut && dx * dx + dy * dy < rSum * rSum) {
              proj.alive = false;
              const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
              const isImmuneFatty = en.type === 'fatty' && hasActivePylons;
              const isImmuneSaw = en.type === 'saw' && Boolean(en.isChargingExplosion);
              const isImmuneWhitePhantom = en.type === 'phantom' && Boolean(en.isFlickering);
              const isImmune = isImmuneFatty || isImmuneSaw || isImmuneWhitePhantom;

              if (isImmune) {
                soundManager.playHit(false, weaponRef.current?.type);
                state.damageTexts.push({
                  id: 'dmg_' + Date.now() + Math.random(),
                  text: `ИММУНИТЕТ!`,
                  x: en.x, y: en.y,
                  vx: 0, vy: -7,
                  life: 1.2,
                  isCrit: false,
                  color: '#9ca3af'
                });
              } else {
                en.hp -= reflectDmg;
                soundManager.playHit(true, weaponRef.current?.type);

                state.damageTexts.push({
                  id: 'dmg_' + Date.now() + Math.random(),
                  text: `ОТРАЖЕНО! -${reflectDmg}`,
                  x: en.x, y: en.y,
                  vx: 0, vy: -9,
                  life: 1.5,
                  isCrit: true,
                  color: '#38bdf8'
                });

                if (en.hp <= 0) {
                  killEnemy(en);
                }
              }
            }
          });

          state.flyingEyes.forEach(eye => {
            const dx = eye.x - proj.x;
            const dy = proj.y - eye.y;
            const rSum = eye.r + 14;
            if (eye.alive && dx * dx + dy * dy < rSum * rSum) {
              proj.alive = false;
              eye.hp -= reflectDmg;
              soundManager.playHit(true);

              state.damageTexts.push({
                id: 'dmg_' + Date.now() + Math.random(),
                text: `ОТРАЖЕНО! -${reflectDmg}`,
                x: eye.x, y: eye.y,
                vx: 0, vy: -9,
                life: 1.5,
                isCrit: true,
                color: '#38bdf8'
              });

              if (eye.hp <= 0) {
                killFlyingEye(eye);
              }
            }
          });

          state.drones.forEach(drone => {
            const dx = drone.x - proj.x;
            const dy = proj.y - drone.y;
            const rSum = drone.r + 14;
            if (drone.alive && dx * dx + dy * dy < rSum * rSum) {
              proj.alive = false;
              drone.hp -= reflectDmg;
              soundManager.playHit(true);

              state.damageTexts.push({
                id: 'dmg_' + Date.now() + Math.random(),
                text: `ОТРАЖЕНО! -${reflectDmg}`,
                x: drone.x, y: drone.y,
                vx: 0, vy: -9,
                life: 1.5,
                isCrit: true,
                color: '#38bdf8'
              });

              if (drone.hp <= 0) {
                killDrone(drone);
              }
            }
          });
        } else {
          // Damage Player if not reflected (Fireball has a larger collision radius)
          const hitRadius = proj.isFireball ? 60 : 20;
          const dx = playerCenterX - proj.x;
          const dy = playerCenterY - proj.y;
          if (dx * dx + dy * dy < hitRadius * hitRadius) {
            proj.alive = false;
            if (!proj.isFireball && !proj.isMagicBolt) {
              state.player.slowTimer = 90; // Frost slow only for ice projectiles
            }
            takeDamage(proj.x, proj.isMagicBolt ? getEnemyDamage('sorcerer_magic') : (proj.isFireball ? getEnemyDamage('fatty_fireball') : getEnemyDamage('ice_projectile')));
          }
        }
      });
      state.iceProjectiles = state.iceProjectiles.filter(p => p.alive);

      // --- FLYING EYES (Zero-gravity Tentacles & Finite Beam targeting exact point) ---
      state.flyingEyes.forEach(eye => {
        if (!eye.alive) return;
        const distToEye = Math.hypot(playerCenterX - eye.x, playerCenterY - eye.y);
        if (distToEye > 1800) return;

        if (eye.hitCooldown > 0) {
          eye.hitCooldown -= dt / 1000;
          if (eye.hitCooldown <= 0) eye.isStruck = false;
        }

        // Floating movement like round bouncy balls (кругляхи)
        if (!eye.vx && !eye.vy) {
          const moveAngle = Math.random() * Math.PI * 2;
          const eyeSpeed = 1.6;
          eye.vx = Math.cos(moveAngle) * eyeSpeed;
          eye.vy = Math.sin(moveAngle) * eyeSpeed;
        } else if (!eye.vy) {
          eye.vy = (Math.random() > 0.5 ? 1.3 : -1.3);
        }

        const eyeBounds = {
          minX: eye.roomBounds ? eye.roomBounds.minX : (eye.leftBound ?? eye.x - 300),
          maxX: eye.roomBounds ? eye.roomBounds.maxX : (eye.rightBound ?? eye.x + 300),
          minY: eye.roomBounds ? eye.roomBounds.minY : (eye.topBound ?? eye.y - 200),
          maxY: eye.roomBounds ? eye.roomBounds.maxY : (eye.bottomBound ?? eye.y + 200)
        };

        bounceCircleAgainstWallsAndObstacles(eye, step, eyeBounds);

        // 2. ФИЗИКА ЛАПОК у глаз (Сделаем их еще более ленивыми и текучими)
        eye.ribbons.forEach((ribbon, idx) => {
          const leg = ribbon.points;
          const isLeft = idx < 6;
          const vertOffset = (idx % 6) * 6 - 15;

          // ПРИВЯЗКА КОРНЯ: обращаемся строго к первому элементу массива [0]
          leg[0].x = eye.x + (isLeft ? -15 : 15);
          leg[0].y = eye.y + vertOffset;

          // Физика остальных сегментов (начиная с 1)
          for (let i = 1; i < leg.length; i++) {
            let p = leg[i];
            let lvx = (p.x - p.oldX) * 0.92;
            let lvy = (p.y - p.oldY) * 0.92;

            p.oldX = p.x; p.oldY = p.y;

            let driftX = (Math.random() - 0.5) * 0.2;
            let driftY = (Math.random() - 0.5) * 0.2;

            p.x += lvx + driftX;
            p.y += lvy + driftY;

            let pPrev = leg[i - 1];
            let dx = p.x - pPrev.x;
            let dy = p.y - pPrev.y;
            let dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const len = 25; // Длина лап

            if (dist > len) {
              p.x = pPrev.x + (dx / dist) * len;
              p.y = pPrev.y + (dy / dist) * len;
            }
          }
        });

        const lvl = Math.max(1, state.level || statsRef.current.level || 1);
        const chargeFactor = 1.0 + (lvl - 1) * 0.025;

        // Only engage if player is within 350px and on enemy platform
        if (isPlayerOnEnemyPlatform(eye) && distToEye < 350) {
          eye.timer += step * chargeFactor;

          // PHASE 1: Aiming (Прицеливание точно в точку игрока) [0 to 110]
          if (eye.timer < 110) {
            eye.phase = 'aiming';
            eye.targetPointX = playerCenterX;
            eye.targetPointY = playerCenterY;
            const desiredAngle = Math.atan2(eye.targetPointY - eye.y, eye.targetPointX - eye.x);
            let diff = desiredAngle - eye.currentAngle;
            while (diff < -Math.PI) diff += Math.PI * 2;
            while (diff > Math.PI) diff -= Math.PI * 2;
            eye.currentAngle += diff * 0.08 * step;

            // Continuously update lock point during aiming phase
            eye.lockedTargetX = eye.targetPointX;
            eye.lockedTargetY = eye.targetPointY;
            eye.lockedAngle = eye.currentAngle;
            eye.lockedDist = Math.hypot(eye.lockedTargetX - eye.x, eye.lockedTargetY - eye.y);
          } 
          // PHASE 2: Beam Charging & Point Lock (Нагнетание луча в зафиксированную точку) [110 to 160]
          else if (eye.timer >= 110 && eye.timer < 160) {
            eye.phase = 'charging';
            // Point & angle are frozen in place! Player can dodge out of the targeted point.
          }
          // PHASE 3: Laser Blast Firing (Короткий луч точно до зафиксированной точки) [160 to 200]
          else if (eye.timer >= 160 && eye.timer < 200) {
            eye.phase = 'firing';
            if (eye.timer >= 160 && eye.timer < 162) soundManager.playLaser();

            // Laser penetrates through obstacles directly to lockedTarget
            const dx = eye.lockedTargetX - eye.x;
            const dy = eye.lockedTargetY - eye.y;
            const fullDist = Math.hypot(dx, dy) || 1;
            const dirX = dx / fullDist;
            const dirY = dy / fullDist;
            eye.actualLaserDist = fullDist;

            // Damage player: 1) point impact blast with small radius matching visual (26px), 2) beam segment through obstacles
            const px = playerCenterX - eye.x;
            const py = playerCenterY - eye.y;
            const dot = px * dirX + py * dirY;

            let hit = false;
            const distToTargetPoint = Math.hypot(playerCenterX - eye.lockedTargetX, playerCenterY - eye.lockedTargetY);
            if (distToTargetPoint < 26) {
              hit = true;
            } else if (dot >= 0 && dot <= fullDist) {
              const closestX = eye.x + dirX * dot;
              const closestY = eye.y + dirY * dot;
              const distToBeam = Math.hypot(playerCenterX - closestX, playerCenterY - closestY);
              if (distToBeam < 22) {
                hit = true;
              }
            }

            if (hit) {
              takeDamage(eye.x, getEnemyDamage('eye_laser'));
            }
          }
          // PHASE 4: Cooldown & Recovery [200 to 260]
          else if (eye.timer >= 200 && eye.timer < 260) {
            eye.phase = 'cooldown';
          } 
          else {
            eye.timer = 0;
            eye.phase = 'idle';
          }
        } else {
          eye.phase = 'idle';
          eye.timer = 0;
        }

        // Direct body touch damage from flying eye (collision covers entire eyeball)
        if (distToEye < eye.r + 14) {
          takeDamage(eye.x, getEnemyDamage('eye_body'));
        }

        // Damage Flying Eye with Player Sword
        if (state.swordLock <= 0) {
          let isTouchingSword = false;
          for (let pt of bladeCheckPoints) {
            if (Math.hypot(pt.x - eye.x, pt.y - eye.y) < eye.r + 14) {
              isTouchingSword = true;
              break;
            }
          }

          if (isTouchingSword) {
            const canHit = !eye.isStruck && (eye.hitCooldown ?? 0) <= 0;
            if (canHit) {
              let { dmg, baseDmg, isCrit } = calculatePlayerHitDamage();

              let axeBonusDmg = 0;
              let isAxeCrit = false;
              const curWeapon = weaponRef.current;
              if (curWeapon && curWeapon.type === 'axe') {
                const maxHp = Math.max(1, eye.maxHp || eye.hp || 1);
                const curHp = Math.max(0, eye.hp);
                const missingHpPct = Math.max(0, Math.min(100, ((maxHp - curHp) / maxHp) * 100));

                const rarity = curWeapon.rarity || 'common';
                const upLvl = curWeapon.upgradeLevel || 0;
                const defaultBaseRatio = rarity === 'magic' ? 0.0017875 : rarity === 'rare' ? 0.002925 : rarity === 'epic' ? 0.004225 : 0.000975;
                const incPerLvl = rarity === 'magic' ? 0.00026 : rarity === 'rare' ? 0.00052 : rarity === 'epic' ? 0.00065 : 0.00013;
                const ratio = curWeapon.ruthlessnessRatio ?? (defaultBaseRatio + incPerLvl * upLvl);

                const bonusMultiplier = Math.min(1.30, missingHpPct * ratio);
                if (bonusMultiplier > 0) {
                  const rawAxeBonus = baseDmg * bonusMultiplier;
                  const { critChance: aCritChance, critMultiplier: aCritMult } = getPlayerCritStats();
                  isAxeCrit = Math.random() < aCritChance;
                  axeBonusDmg = Math.max(1, Math.round(isAxeCrit ? rawAxeBonus * aCritMult : rawAxeBonus));
                  dmg += axeBonusDmg;
                }
              }

              eye.hp -= dmg;
              applyVampirismHealing(dmg, eye);
              eye.isStruck = true;
              eye.hitCooldown = 0.15;
              soundManager.playHit(isCrit, weaponRef.current?.type);

              // Sword recoil bounce & hit cooldown for player weapon on ALL hits (normal and fast rotation)
              if (state.ropePoints.length > 1) {
                const last = state.ropePoints[state.ropePoints.length - 1];
                const prev = state.ropePoints[state.ropePoints.length - 2];
                const sang = Math.atan2(last.y - prev.y, last.x - prev.x);
                last.x -= Math.cos(sang) * 11;
                last.y -= Math.sin(sang) * 11;
              }
              state.swordLock = getAttackRecoveryTimeSec();

              state.damageTexts.push({
                id: 'dmg_' + Date.now() + Math.random(),
                text: `${isCrit ? 'КРИТ! ' : ''}-${dmg}`,
                x: eye.x, y: eye.y,
                vx: (Math.random() - 0.5) * 6, vy: -10,
                life: 1.5,
                isCrit,
                color: isCrit ? '#f59e0b' : '#f43f5e'
              });

              if (axeBonusDmg > 0) {
                state.damageTexts.push({
                  id: 'dmg_axe_eye_' + Date.now() + Math.random(),
                  text: `🪓 +${axeBonusDmg}`,
                  x: eye.x, y: eye.y - 36,
                  vx: (Math.random() - 0.5) * 4, vy: -10,
                  life: 1.3,
                  isCrit: isAxeCrit,
                  color: isAxeCrit ? '#f59e0b' : '#f97316'
                });
              }

              // --- HAMMER STUN & BONUS DAMAGE ON FLYING EYES ---
              if (curWeapon && curWeapon.type === 'hammer') {
                const rarity = curWeapon.rarity || 'common';
                const upLvl = curWeapon.upgradeLevel || 0;
                const defaultBaseChance = rarity === 'magic' ? 0.0504 : rarity === 'rare' ? 0.0756 : rarity === 'epic' ? 0.126 : 0.0252;
                const chancePerLvl = rarity === 'magic' ? 0.00945 : rarity === 'rare' ? 0.0126 : rarity === 'epic' ? 0.02205 : 0.0063;
                const stunChance = curWeapon.stunChance ?? (defaultBaseChance + chancePerLvl * upLvl);
                const defaultBonusRatio = rarity === 'magic' ? 0.65 : rarity === 'rare' ? 0.80 : rarity === 'epic' ? 1.00 : 0.50;
                const bonusRatio = curWeapon.bonusDamageMultiplier ?? defaultBonusRatio;

                if (Math.random() < stunChance) {
                  const rawHammerBonus = baseDmg * bonusRatio;
                  const { critChance: hCritChance, critMultiplier: hCritMult } = getPlayerCritStats();
                  const isHammerCrit = Math.random() < hCritChance;
                  const bonusDmg = Math.max(1, Math.round(isHammerCrit ? rawHammerBonus * hCritMult : rawHammerBonus));
                  if (bonusDmg > 0) {
                    eye.hp -= bonusDmg;
                    // No vampirism from stun damage
                    state.damageTexts.push({
                      id: 'dmg_stun_eye_' + Date.now() + Math.random(),
                      text: `💥 +${bonusDmg}`,
                      x: eye.x, y: eye.y - 22,
                      vx: (Math.random() - 0.5) * 5, vy: -11,
                      life: 1.5,
                      isCrit: isHammerCrit,
                      color: isHammerCrit ? '#f59e0b' : '#fbbf24'
                    });
                  }
                }
              }

              // Trigger Chain Lightning if Trinket is equipped
              triggerChainLightning(eye, baseDmg);

              if (eye.hp <= 0) {
                killFlyingEye(eye);
              }
            }
          } else {
            eye.isStruck = false;
          }
        }
      });
      state.flyingEyes = state.flyingEyes.filter(e => e.alive);

      // --- LASER DRONES ON PLATFORMS (Dual-side beam with charge-up buildup across platform) ---
      state.drones.forEach(drone => {
        if (!drone.alive) return;
        const distToPlayer = Math.hypot(playerCenterX - drone.x, playerCenterY - drone.y);
        if (distToPlayer > 1800) return;

        if (drone.hitCooldown > 0) {
          drone.hitCooldown -= dt / 1000;
          if (drone.hitCooldown <= 0) drone.isStruck = false;
        }
        drone.rotorAngle += 0.12 * step;

        const lvl = Math.max(1, state.level || statsRef.current.level || 1);
        const chargeFactor = 1.0 + (lvl - 1) * 0.025;

        if (!drone.orientation) {
          drone.orientation = 'horizontal';
          drone.moveDir = Math.random() < 0.5 ? 1 : -1;
        }
        if (drone.spawnX === undefined) drone.spawnX = drone.x;
        if (drone.spawnY === undefined) drone.spawnY = drone.y;

        const moveSpd = (drone.orientation === 'horizontal' ? 0.85 : 0.95) * Math.pow(1.05, lvl - 1);

        // Strictly orthogonal movement at 90 degrees without deviating by a single degree:
        // - If orientation === 'horizontal' (lasers shoot horizontally): levitates vertically (сверху вниз или наоборот), X is locked.
        // - If orientation === 'vertical' (lasers shoot vertically): levitates horizontally (справа налево или наоборот), Y is locked.
        // - When charging or firing: drone stops completely at its exact coordinate, zero movement.
        if (drone.phase === 'idle' || drone.phase === 'cooldown') {
          if (drone.orientation === 'horizontal') {
            // Strictly vertical levitation (90 degrees, pure Y coordinate change)
            const platTop = drone.roomBounds ? drone.roomBounds.minY : (drone.parent.y - 180);
            const platBottom = drone.roomBounds ? drone.roomBounds.maxY : drone.parent.y;
            
            const oldY = drone.y;
            drone.y += (drone.moveDir || 1) * moveSpd * step;

            const hitWall = state.walls.some(w => {
              if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) return false;
              return (
                drone.x + 14 > w.x &&
                drone.x - 14 < w.x + w.w &&
                drone.y + 14 > w.y &&
                drone.y - 14 < w.y + w.h
              );
            }) || obstacleColliders.some(obs => (
              drone.x + 14 > obs.x &&
              drone.x - 14 < obs.x + obs.w &&
              drone.y + 14 > obs.y &&
              drone.y - 14 < obs.y + obs.h
            ));

            if (hitWall) {
              drone.y = oldY;
              drone.moveDir = -(drone.moveDir || 1);
            } else if (drone.y <= platTop + 40) {
              drone.y = platTop + 40;
              drone.moveDir = 1;
            } else if (drone.y >= platBottom - 40) {
              drone.y = platBottom - 40;
              drone.moveDir = -1;
            }
            // Strict trajectory lock: X never drifts
            drone.x = drone.spawnX;
            drone.beamY = drone.y;
          } else {
            // Strictly horizontal levitation (90 degrees, pure X coordinate change)
            const platLeft = drone.roomBounds ? drone.roomBounds.minX : drone.parent.x;
            const platRight = drone.roomBounds ? drone.roomBounds.maxX : (drone.parent.x + drone.parent.width);
            
            const oldX = drone.x;
            drone.x += (drone.moveDir || 1) * moveSpd * step;

            const hitWall = state.walls.some(w => {
              if (w.isFattyArenaWall && (w.retractProgress || 0) >= 0.85) return false;
              return (
                drone.x + 14 > w.x &&
                drone.x - 14 < w.x + w.w &&
                drone.y + 14 > w.y &&
                drone.y - 14 < w.y + w.h
              );
            }) || obstacleColliders.some(obs => (
              drone.x + 14 > obs.x &&
              drone.x - 14 < obs.x + obs.w &&
              drone.y + 14 > obs.y &&
              drone.y - 14 < obs.y + obs.h
            ));

            if (hitWall) {
              drone.x = oldX;
              drone.moveDir = -(drone.moveDir || 1);
            } else if (drone.x <= platLeft + 40) {
              drone.x = platLeft + 40;
              drone.moveDir = 1;
            } else if (drone.x >= platRight - 40) {
              drone.x = platRight - 40;
              drone.moveDir = -1;
            }
            // Strict trajectory lock: Y never drifts
            drone.y = drone.spawnY;
            drone.beamY = drone.y;
          }
        } else {
          // Stationary charging & firing: completely frozen on trajectory
          if (drone.orientation === 'horizontal') {
            drone.x = drone.spawnX;
          } else {
            drone.y = drone.spawnY;
          }
          drone.beamY = drone.y;
        }

        // Compute full room boundary spans independent of obstacles ("прицеливание должно быть от края до края комнаты, независимо от препядствий")
        const platLeft = drone.roomBounds ? drone.roomBounds.minX : (drone.parent ? drone.parent.x : drone.x - 300);
        const platRight = drone.roomBounds ? drone.roomBounds.maxX : (drone.parent ? drone.parent.x + drone.parent.width : drone.x + 300);
        const platTop = drone.roomBounds ? drone.roomBounds.minY : drone.y - 260;
        const platBottom = drone.roomBounds ? drone.roomBounds.maxY : drone.y + 260;

        drone.actualLeft = platLeft;
        drone.actualRight = platRight;
        drone.actualTop = platTop;
        drone.actualBottom = platBottom;

        const pInDroneRoom = drone.roomBounds
          ? (playerCenterX >= drone.roomBounds.minX - 80 && playerCenterX <= drone.roomBounds.maxX + 80 &&
             playerCenterY >= drone.roomBounds.minY - 80 && playerCenterY <= drone.roomBounds.maxY + 80)
          : isPlayerOnEnemyPlatform(drone);

        if (pInDroneRoom && distToPlayer < 525) {
          drone.timer += step * chargeFactor;

          // PHASE 1: Idle (0 to 100)
          if (drone.timer < 100) {
            drone.phase = 'idle';
            drone.chargeProgress = 0;
          }
          // PHASE 2: Charging / Buildup (100 to 170) -> Warning line across full room
          else if (drone.timer >= 100 && drone.timer < 170) {
            drone.phase = 'charging';
            drone.chargeProgress = (drone.timer - 100) / 70;
            if (drone.timer >= 100 && drone.timer < 102) {
              soundManager.playDroneCharge();
            }

            // Energy intake particles
            if (Math.random() < 0.22) {
              const ang = Math.random() * Math.PI * 2;
              const rad = 25 + Math.random() * 20;
              state.particles.push({
                x: drone.x + Math.cos(ang) * rad,
                y: drone.y + Math.sin(ang) * rad,
                vx: -Math.cos(ang) * 2.8,
                vy: -Math.sin(ang) * 2.8,
                life: 0.35,
                maxLife: 0.35,
                color: Math.random() > 0.5 ? '#f97316' : '#ef4444',
                size: 2.5
              });
            }
          }
          // PHASE 3: Firing Dual Platform Lasers (170 to 215)
          else if (drone.timer >= 170 && drone.timer < 215) {
            drone.phase = 'firing';
            if (drone.timer >= 170 && drone.timer < 172) {
              soundManager.playDroneBlast();
            }

            if (drone.orientation === 'vertical') {
              // Active lethal laser does NOT pass through obstacles ("лазер не должен проходить сквозь препядствия")
              const hitDistUp = getLaserHitDistance(drone.x, drone.y, 0, -1, Math.max(0, drone.y - platTop));
              const hitDistDown = getLaserHitDistance(drone.x, drone.y, 0, 1, Math.max(0, platBottom - drone.y));
              drone.laserTop = drone.y - hitDistUp;
              drone.laserBottom = drone.y + hitDistDown;

              if (playerCenterX >= drone.x - 24 && playerCenterX <= drone.x + 24) {
                if (playerCenterY >= drone.laserTop - 8 && playerCenterY <= drone.laserBottom + 8) {
                  takeDamage(drone.x, getEnemyDamage('drone_laser'));
                }
              }

              // Spark particles at actual obstacle hit points
              if (Math.random() < 0.2) {
                state.particles.push({
                  x: drone.x, y: drone.laserTop,
                  vx: (Math.random() - 0.5) * 8, vy: Math.random() * 6,
                  life: 0.3, maxLife: 0.3, color: '#f97316', size: 3
                });
                state.particles.push({
                  x: drone.x, y: drone.laserBottom,
                  vx: (Math.random() - 0.5) * 8, vy: -Math.random() * 6,
                  life: 0.3, maxLife: 0.3, color: '#f97316', size: 3
                });
              }
            } else {
              // Active lethal laser does NOT pass through obstacles
              const hitDistLeft = getLaserHitDistance(drone.x, drone.beamY, -1, 0, Math.max(0, drone.x - platLeft));
              const hitDistRight = getLaserHitDistance(drone.x, drone.beamY, 1, 0, Math.max(0, platRight - drone.x));
              drone.laserLeft = drone.x - hitDistLeft;
              drone.laserRight = drone.x + hitDistRight;

              // Damage player within unhindered obstacle laser segment
              if (playerCenterX >= drone.laserLeft - 8 && playerCenterX <= drone.laserRight + 8) {
                if (Math.abs(playerCenterY - drone.beamY) < 26) {
                  takeDamage(drone.x, getEnemyDamage('drone_laser'));
                }
              }

              // Impact spark emitters at actual obstacle hit points
              if (Math.random() < 0.2) {
                state.particles.push({
                  x: drone.laserLeft, y: drone.beamY,
                  vx: Math.random() * 6, vy: (Math.random() - 0.5) * 8,
                  life: 0.3, maxLife: 0.3, color: '#f97316', size: 3
                });
                state.particles.push({
                  x: drone.laserRight, y: drone.beamY,
                  vx: -Math.random() * 6, vy: (Math.random() - 0.5) * 8,
                  life: 0.3, maxLife: 0.3, color: '#f97316', size: 3
                });
              }
            }
          }
          // PHASE 4: Cooldown (215 to 265)
          else if (drone.timer >= 215 && drone.timer < 265) {
            drone.phase = 'cooldown';
            drone.chargeProgress = 0;
            // Vent smoke
            if (Math.random() < 0.12) {
              state.particles.push({
                x: drone.x + (Math.random() - 0.5) * 12,
                y: drone.y - 12,
                vx: (Math.random() - 0.5) * 2,
                vy: -Math.random() * 3,
                life: 0.5, maxLife: 0.5, color: '#64748b', size: 3
              });
            }
          } else {
            drone.timer = 0;
            drone.phase = 'idle';
          }
        } else {
          drone.phase = 'idle';
          drone.timer = 0;
        }

        // Direct body touch damage from laser drone
        if (distToPlayer < drone.r + 14) {
          takeDamage(drone.x, getEnemyDamage('drone_body'));
        }

        // Damage Laser Drone with Player Sword
        if (state.swordLock <= 0) {
          let isTouchingSword = false;
          for (let pt of bladeCheckPoints) {
            if (Math.hypot(pt.x - drone.x, pt.y - drone.y) < drone.r + 14) {
              isTouchingSword = true;
              break;
            }
          }

          if (isTouchingSword) {
            const canHit = !drone.isStruck && (drone.hitCooldown ?? 0) <= 0;
            if (canHit) {
              let { dmg, baseDmg, isCrit } = calculatePlayerHitDamage();

              let axeBonusDmg = 0;
              let isAxeCrit = false;
              const curWeapon = weaponRef.current;
              if (curWeapon && curWeapon.type === 'axe') {
                const maxHp = Math.max(1, drone.maxHp || drone.hp || 1);
                const curHp = Math.max(0, drone.hp);
                const missingHpPct = Math.max(0, Math.min(100, ((maxHp - curHp) / maxHp) * 100));

                const rarity = curWeapon.rarity || 'common';
                const upLvl = curWeapon.upgradeLevel || 0;
                const defaultBaseRatio = rarity === 'magic' ? 0.001375 : rarity === 'rare' ? 0.00225 : rarity === 'epic' ? 0.00325 : 0.00075;
                const incPerLvl = rarity === 'magic' ? 0.0002 : rarity === 'rare' ? 0.0004 : rarity === 'epic' ? 0.0005 : 0.0001;
                const ratio = curWeapon.ruthlessnessRatio ?? (defaultBaseRatio + incPerLvl * upLvl);

                const bonusMultiplier = Math.min(1.30, missingHpPct * ratio);
                if (bonusMultiplier > 0) {
                  const rawAxeBonus = baseDmg * bonusMultiplier;
                  const { critChance: aCritChance, critMultiplier: aCritMult } = getPlayerCritStats();
                  isAxeCrit = Math.random() < aCritChance;
                  axeBonusDmg = Math.max(1, Math.round(isAxeCrit ? rawAxeBonus * aCritMult : rawAxeBonus));
                  dmg += axeBonusDmg;
                }
              }

              drone.hp -= dmg;
              applyVampirismHealing(dmg, drone);
              drone.isStruck = true;
              drone.hitCooldown = 0.15;
              soundManager.playHit(isCrit, weaponRef.current?.type);

              // Sword recoil bounce & hit cooldown for player weapon on ALL hits (normal and fast rotation)
              if (state.ropePoints.length > 1) {
                const last = state.ropePoints[state.ropePoints.length - 1];
                const prev = state.ropePoints[state.ropePoints.length - 2];
                const sang = Math.atan2(last.y - prev.y, last.x - prev.x);
                last.x -= Math.cos(sang) * 11;
                last.y -= Math.sin(sang) * 11;
              }
              state.swordLock = getAttackRecoveryTimeSec();

              state.damageTexts.push({
                id: 'dmg_' + Date.now() + Math.random(),
                text: `${isCrit ? 'КРИТ! ' : ''}-${dmg}`,
                x: drone.x, y: drone.y,
                vx: (Math.random() - 0.5) * 6, vy: -10,
                life: 1.5,
                isCrit,
                color: isCrit ? '#f59e0b' : '#f43f5e'
              });

              if (axeBonusDmg > 0) {
                state.damageTexts.push({
                  id: 'dmg_axe_drone_' + Date.now() + Math.random(),
                  text: `🪓 +${axeBonusDmg}`,
                  x: drone.x, y: drone.y - 36,
                  vx: (Math.random() - 0.5) * 4, vy: -10,
                  life: 1.3,
                  isCrit: isAxeCrit,
                  color: isAxeCrit ? '#f59e0b' : '#f97316'
                });
              }

              // --- HAMMER STUN & BONUS DAMAGE ON DRONES ---
              if (curWeapon && curWeapon.type === 'hammer') {
                const rarity = curWeapon.rarity || 'common';
                const upLvl = curWeapon.upgradeLevel || 0;
                const defaultBaseChance = rarity === 'magic' ? 0.0504 : rarity === 'rare' ? 0.0756 : rarity === 'epic' ? 0.126 : 0.0252;
                const chancePerLvl = rarity === 'magic' ? 0.00945 : rarity === 'rare' ? 0.0126 : rarity === 'epic' ? 0.02205 : 0.0063;
                const stunChance = curWeapon.stunChance ?? (defaultBaseChance + chancePerLvl * upLvl);
                const defaultBonusRatio = rarity === 'magic' ? 0.65 : rarity === 'rare' ? 0.80 : rarity === 'epic' ? 1.00 : 0.50;
                const bonusRatio = curWeapon.bonusDamageMultiplier ?? defaultBonusRatio;

                if (Math.random() < stunChance) {
                  const rawHammerBonus = baseDmg * bonusRatio;
                  const { critChance: hCritChance, critMultiplier: hCritMult } = getPlayerCritStats();
                  const isHammerCrit = Math.random() < hCritChance;
                  const bonusDmg = Math.max(1, Math.round(isHammerCrit ? rawHammerBonus * hCritMult : rawHammerBonus));
                  if (bonusDmg > 0) {
                    drone.hp -= bonusDmg;
                    // No vampirism from stun damage
                    state.damageTexts.push({
                      id: 'dmg_stun_drone_' + Date.now() + Math.random(),
                      text: `💥 +${bonusDmg}`,
                      x: drone.x, y: drone.y - 22,
                      vx: (Math.random() - 0.5) * 5, vy: -11,
                      life: 1.5,
                      isCrit: isHammerCrit,
                      color: isHammerCrit ? '#f59e0b' : '#fbbf24'
                    });
                  }
                }
              }

              // Trigger Chain Lightning if Trinket is equipped
              triggerChainLightning(drone, baseDmg);

              if (drone.hp <= 0) {
                killDrone(drone);
              }
            }
          } else {
            drone.isStruck = false;
          }
        }
      });
      state.drones = state.drones.filter(d => d.alive);

      // --- HIDDEN & ACTIVE SPIKE TRAPS ---
      state.spikeTraps.forEach(trap => {
        const pCenterX = state.player.x + state.player.w / 2;
        const pFeetY = state.player.y + state.player.h - 8;

        // Player is stepping on the 2x2 trap tile area
        const isPlayerStepping = (
          pCenterX >= trap.x && pCenterX <= trap.x + trap.w &&
          pFeetY >= trap.y && pFeetY <= trap.y + trap.h
        );

        if (trap.state === 'hidden') {
          if (isPlayerStepping) {
            trap.state = 'charging';
            trap.timer = 30; // 0.5s quick warning
            trap.shakeTimer = 30;
            soundManager.playSpikePrepare();

            // Quick initial "pouf" of plaster dust ("эффекты штукатурки только пшик")
            for (let pIdx = 0; pIdx < 12; pIdx++) {
              state.particles.push({
                x: trap.x + trap.w / 2 + (Math.random() - 0.5) * 20,
                y: trap.y + trap.h / 2 + (Math.random() - 0.5) * 20,
                vx: (Math.random() - 0.5) * 3.5,
                vy: (Math.random() - 0.5) * 3.5 - 1.0,
                life: 0.35,
                maxLife: 0.35,
                color: '#f8fafc',
                size: Math.random() * 3 + 1.5
              });
            }
          }
        } else if (trap.state === 'charging') {
          trap.timer -= step;

          if (trap.timer <= 0) {
            trap.state = 'active';
            trap.activeTimer = 180; // active for 3 seconds
            soundManager.playSpikeErupt();

            // Quick eruption burst
            for (let pIdx = 0; pIdx < 16; pIdx++) {
              state.particles.push({
                x: trap.x + Math.random() * trap.w,
                y: trap.y + Math.random() * trap.h,
                vx: (Math.random() - 0.5) * 4,
                vy: -Math.random() * 3 - 1,
                life: 0.5,
                maxLife: 0.5,
                color: '#cbd5e1',
                size: Math.random() * 3 + 1.5
              });
            }
          }
        } else if (trap.state === 'active') {
          if (isPlayerStepping) {
            takeDamage(trap.x + trap.w / 2, getEnemyDamage('spike'), true);
          }
          trap.activeTimer -= step;
          if (trap.activeTimer <= 0) {
            // Instantly hide back into floor with plaster dust burst ("шипы появляются с частицами так же должны и исчезать")
            trap.state = 'hidden';
            soundManager.playSpikeRetract();
            for (let pIdx = 0; pIdx < 16; pIdx++) {
              state.particles.push({
                x: trap.x + Math.random() * trap.w,
                y: trap.y + Math.random() * trap.h,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 3 + 1,
                life: 0.5,
                maxLife: 0.5,
                color: '#cbd5e1',
                size: Math.random() * 3 + 1.5
              });
            }
          }
        }
      });

      // --- FLAME WAVES (Piercing projectile skill logic) ---
      state.flameWaves.forEach(fw => {
        if (!fw.alive) return;
        fw.x += fw.vx * step;
        fw.y += fw.vy * step;
        fw.life -= 0.016 * step;
        if (fw.life <= 0) fw.alive = false;

        // Trailing particles
        for (let p = 0; p < 1; p++) {
          state.particles.push({
            x: fw.x + (Math.random() - 0.5) * 16,
            y: fw.y + (Math.random() - 0.5) * 30,
            vx: -fw.vx * 0.15 + (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 3,
            life: 0.4,
            maxLife: 0.4,
            color: Math.random() < 0.5 ? '#f97316' : '#ef4444',
            size: Math.random() * 3.5 + 2
          });
        }

        const flameRadius = 38;
        const w = weaponRef.current;
        const s = statsRef.current;
        const flameDmg = Math.max(1, Math.round((w.minDamage + w.maxDamage + s.strength * 2) * 1.3));

        if (!fw.hitTimes) fw.hitTimes = new Map<string, number>();
        const now = Date.now();

        state.enemies.forEach(en => {
          if (!en.alive || en.isDyingFadeOut) return;
          const unitId = en.id || ('en_' + Math.round(en.x));
          const lastHit = fw.hitTimes.get(unitId) || 0;
          if (now - lastHit < 500) return;

          if (Math.hypot(en.x - fw.x, en.y - fw.y) < en.r + flameRadius) {
            fw.hitTimes.set(unitId, now);
            const hasActivePylons = state.enemies.some(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
            const isImmuneFatty = en.type === 'fatty' && hasActivePylons;
            const isImmuneSaw = en.type === 'saw' && Boolean(en.isChargingExplosion);
            const isImmuneWhitePhantom = en.type === 'phantom' && Boolean(en.isFlickering);
            const isImmune = isImmuneFatty || isImmuneSaw || isImmuneWhitePhantom;

            if (isImmune) {
              soundManager.playHit(false);
              state.damageTexts.push({
                id: 'flame_' + Date.now() + Math.random(),
                text: `ИММУНИТЕТ!`,
                x: en.x, y: en.y - 10,
                vx: 0, vy: -5,
                life: 1.2,
                isCrit: false,
                color: '#9ca3af'
              });
            } else {
              en.hp -= flameDmg;
              soundManager.playHit(true);
              state.damageTexts.push({
                id: 'flame_' + Date.now() + Math.random(),
                text: `ОГОНЬ! -${flameDmg}`,
                x: en.x, y: en.y - 10,
                vx: 0, vy: -7,
                life: 1.5,
                isCrit: true,
                color: '#f97316'
              });

              if (en.hp <= 0) {
                killEnemy(en);
              }
            }
          }
        });

        state.flyingEyes.forEach(eye => {
          if (!eye.alive) return;
          const unitId = eye.id;
          const lastHit = fw.hitTimes.get(unitId) || 0;
          if (now - lastHit < 500) return;

          if (Math.hypot(eye.x - fw.x, eye.y - fw.y) < eye.r + flameRadius) {
            fw.hitTimes.set(unitId, now);
            eye.hp -= flameDmg;
            soundManager.playHit(true);
            state.damageTexts.push({
              id: 'flame_' + Date.now() + Math.random(),
              text: `ОГОНЬ! -${flameDmg}`,
              x: eye.x, y: eye.y - 10,
              vx: 0, vy: -7,
              life: 1.5,
              isCrit: true,
              color: '#f97316'
            });
            if (eye.hp <= 0) {
              killFlyingEye(eye);
            }
          }
        });

        state.drones.forEach(drone => {
          if (!drone.alive) return;
          const unitId = drone.id;
          const lastHit = fw.hitTimes.get(unitId) || 0;
          if (now - lastHit < 500) return;

          if (Math.hypot(drone.x - fw.x, drone.y - fw.y) < drone.r + flameRadius) {
            fw.hitTimes.set(unitId, now);
            drone.hp -= flameDmg;
            soundManager.playHit(true);
            state.damageTexts.push({
              id: 'flame_' + Date.now() + Math.random(),
              text: `ОГОНЬ! -${flameDmg}`,
              x: drone.x, y: drone.y - 10,
              vx: 0, vy: -7,
              life: 1.5,
              isCrit: true,
              color: '#f97316'
            });
            if (drone.hp <= 0) {
              killDrone(drone);
            }
          }
        });
      });

      // --- DESTRUCTIBLE PROPS FLAME WAVE DESTRUCTION ---
      if (state.dungeonDecorations && state.dungeonDecorations.length > 0 && state.flameWaves && state.flameWaves.length > 0) {
        state.dungeonDecorations.forEach((dec: any) => {
          if (!dec.isDestructible || dec.opened || dec.alive === false) return;
          const propRadius = (dec.w ? dec.w / 2 : 16) + 18;

          state.flameWaves.forEach(fw => {
            if (!fw.alive || !dec.alive || dec.opened) return;
            if (Math.hypot(dec.x - fw.x, dec.y - fw.y) < propRadius + 30) {
              dec.alive = false;
              dec.opened = true;
              rebuildObstacleColliders();
              soundManager.playHit(true);

              const isWood = dec.subtype === 'barrels' || dec.subtype === 'crate';
              const isPot = dec.subtype === 'pot' || dec.subtype === 'pot2';
              for (let i = 0; i < 12; i++) {
                let pColor = isWood 
                  ? (Math.random() < 0.5 ? '#b45309' : (Math.random() < 0.5 ? '#78350f' : '#f59e0b'))
                  : (isPot ? (Math.random() < 0.5 ? '#ea580c' : (Math.random() < 0.5 ? '#c2410c' : '#fed7aa'))
                           : (Math.random() < 0.5 ? '#64748b' : '#334155'));
                state.particles.push({
                  x: dec.x + (Math.random() - 0.5) * 16,
                  y: dec.y + (Math.random() - 0.5) * 16,
                  vx: (Math.random() - 0.5) * 14,
                  vy: (Math.random() - 0.5) * 14 - 2,
                  life: 0.85,
                  maxLife: 0.85,
                  color: pColor,
                  size: Math.random() * 4 + 2.5
                });
              }
              state.screenShake = Math.max(state.screenShake, 3.0);
              dropMobLoot(dec.x, dec.y, 'prop_' + (dec.subtype || 'crate'));
            }
          });
        });
        state.dungeonDecorations = state.dungeonDecorations.filter((d: any) => !d.isDestructible || (!d.opened && d.alive !== false));
      }

      state.cleanupTicks = (state.cleanupTicks || 0) + 1;
      const isCleanupFrame = state.cleanupTicks % 12 === 0;

      if (isCleanupFrame) {
        state.enemies = state.enemies.filter(e => e.alive);
        state.flyingEyes = state.flyingEyes.filter(e => e.alive);
        state.drones = state.drones.filter(e => e.alive);
        state.flameWaves = state.flameWaves.filter(fw => fw.alive);
        if (state.dungeonDecorations) {
          state.dungeonDecorations = state.dungeonDecorations.filter((d: any) => !d.isDestructible || d.alive);
        }
      }

      // --- LOOT DROPS (Gentle Drift & Auto-Pickup without flying upward) ---
      const pCenterX = state.player.x + state.player.w / 2;
      const pCenterY = state.player.y + state.player.h / 2;

      state.lootDrops.forEach(l => {
        if (!l.alive) return;

        // Apply gentle damping
        l.x += l.vx * step;
        l.y += l.vy * step;
        l.vx *= Math.pow(0.88, step);
        l.vy *= Math.pow(0.88, step);

        // Delay timer countdown
        if (l.pickupDelay !== undefined && l.pickupDelay > 0) {
          l.pickupDelay -= (dt / 1000);
        } else {
          // Pickup delay expired: smooth attraction and collection
          const dx = pCenterX - l.x;
          const dy = pCenterY - l.y;
          const distSq = dx * dx + dy * dy;
          if (distSq < 160 * 160) {
            const dist = Math.sqrt(distSq);
            if (dist < 34) {
              // Collected on contact
              collectLootDrop(l);
            } else {
              // Magnetize towards player smoothly
              const angle = Math.atan2(dy, dx);
              const pullSpeed = Math.min(14, (160 - dist) * 0.14 + 5) * step;
              l.x += Math.cos(angle) * pullSpeed;
              l.y += Math.sin(angle) * pullSpeed;
            }
          }
        }
      });
      if (isCleanupFrame) {
        state.lootDrops = state.lootDrops.filter(l => l.alive);
        if (state.lootDrops.length > 50) {
          state.lootDrops.sort((a, b) => {
            const distA = (pCenterX - a.x) * (pCenterX - a.x) + (pCenterY - a.y) * (pCenterY - a.y);
            const distB = (pCenterX - b.x) * (pCenterX - b.x) + (pCenterY - b.y) * (pCenterY - b.y);
            return distA - distB;
          });
          state.lootDrops = state.lootDrops.slice(0, 50);
        }
      }

      // --- PORTAL COUNTDOWN & INTERACTION (Advance to next labyrinth level) ---
      if (state.portal) {
        if (!state.portal.active && (state.portal.countdownTimer || 0) > 0) {
          state.portal.countdownTimer = Math.max(0, (state.portal.countdownTimer || 0) - (dt / 1000));
          state.portal.angle += 0.015 * step;

          // Ambient charging runic sparkles
          if (Math.random() < 0.35) {
            const pAng = Math.random() * Math.PI * 2;
            const pDist = 30 + Math.random() * 25;
            state.particles.push({
              x: state.portal.x + Math.cos(pAng) * pDist,
              y: state.portal.y + Math.sin(pAng) * pDist,
              vx: -Math.cos(pAng) * 1.6,
              vy: -Math.sin(pAng) * 1.6,
              life: 0.5,
              maxLife: 0.5,
              color: Math.random() < 0.5 ? '#38bdf8' : '#c084fc',
              size: 2.5
            });
          }

          if (state.portal.countdownTimer <= 0) {
            state.portal.active = true;
            soundManager.playLoot();
            state.screenShake = 12;
            state.shockwaves.push({
              x: state.portal.x,
              y: state.portal.y,
              r: 10,
              maxR: 90,
              color: '#38bdf8',
              life: 1.2,
              maxLife: 1.2
            });
            state.damageTexts.push({
              id: 'portal_open_' + Date.now(),
              text: '★ ПОРТАЛ НА СЛЕДУЮЩИЙ УРОВЕНЬ ОТКРЫТ! ★',
              x: state.portal.x,
              y: state.portal.y - 45,
              vx: 0,
              vy: -3.5,
              life: 4.0,
              isCrit: true,
              color: '#38bdf8'
            });
          }
        } else if (state.portal.active) {
          state.portal.angle += 0.03 * step;
          const pDist = Math.hypot(pCenterX - state.portal.x, pCenterY - state.portal.y);
          if (pDist < state.portal.r + 20 && !state.isPortalTransitioning) {
            state.isPortalTransitioning = true;
            state.portalTransitionTimer = 0;
            state.controlsEnabled = false;
          }
        }
      }

      if (state.isPortalTransitioning) {
        state.portalTransitionTimer += step;
        state.blackFadeAlpha = Math.min(1.0, state.portalTransitionTimer / 28);
        if (state.portal) {
          state.player.x += (state.portal.x - state.player.w / 2 - state.player.x) * 0.12 * step;
          state.player.y += (state.portal.y - state.player.h / 2 - state.player.y) * 0.12 * step;
          state.player.vx *= 0.85;
          state.player.vy *= 0.85;
        }
        if (state.portalTransitionTimer >= 28) {
          state.isPortalTransitioning = false;
          state.portalTransitionTimer = 0;
          enterPortalToNextLevel();
        }
      }

      // --- CAMERA TRACKING (Smooth 4-directional Centered View in Labyrinth) ---
      const scale = getCameraScale();
      const viewWorldW = canvas.width / scale;
      const viewWorldH = canvas.height / scale;

      const targetCameraX = pCenterX - (viewWorldW * 0.5);
      const targetCameraY = pCenterY - (viewWorldH * 0.5);
      if (state.isMaterializing) {
        // While materializing / loading level, camera stays pinned perfectly in the center over the player
        state.cameraX = targetCameraX;
        state.cameraY = targetCameraY;
      } else {
        state.cameraX += (targetCameraX - state.cameraX) * Math.min(1, 0.08 * step);
        state.cameraY += (targetCameraY - state.cameraY) * Math.min(1, 0.08 * step);
      }

      // --- DISTANCE CALCULATION ---
      const currentDist = Math.max(0, Math.floor((Math.hypot(state.player.x, state.player.y)) / 40));
      if (currentDist > state.distance) {
        state.distance = currentDist;
      }

      // Floating damage & XP texts - Tossed ball physics (jumps up diagonally, decelerates, then falls down like a ball)
      state.damageTexts.forEach(txt => {
        const isGateHint = Boolean(txt.id && typeof txt.id === 'string' && txt.id.startsWith('gate_closed_hint_'));
        if (isGateHint) {
          // Stay completely stationary and fade out slowly
          txt.life -= 0.012 * step;
        } else {
          txt.x += txt.vx * step;
          txt.y += txt.vy * step;
          txt.vx *= Math.pow(0.96, step); // horizontal drag
          txt.vy += 0.35 * step;          // gravity acceleration downward
          txt.life -= 0.018 * step;
        }
      });
      if (isCleanupFrame) {
        state.damageTexts = state.damageTexts.filter(txt => txt.life > 0);
      }

      // Particles Physics & Life Update (Performance Optimized)
      state.particles.forEach(p => {
        p.x += p.vx * step;
        p.y += p.vy * step;
        if (p.gravity) p.vy += p.gravity * step;
        p.vx *= Math.pow(0.96, step);
        p.vy *= Math.pow(0.96, step);
        // Smoothly accelerate decay if too many particles to prevent frame drops
        const decayMult = state.particles.length > 35 ? 2.2 : 1.0;
        p.life -= 0.025 * step * decayMult;
      });
      if (isCleanupFrame) {
        state.particles = state.particles.filter(p => p.life > 0);
        if (state.particles.length > 40) {
          state.particles = state.particles.slice(-40);
        }
      }
      
      // Update Environment Particles (Smoothly drifting floating motes - 4x slower)
      state.envParticles = state.envParticles || [];
      if (Math.random() < 0.02 && state.envParticles.length < 16) {
        state.envParticles.push({
           x: state.cameraX + Math.random() * (canvasRef.current?.width || 800) * 1.5,
           y: state.cameraY + Math.random() * (canvasRef.current?.height || 600) * 1.5,
           vx: (Math.random() - 0.5) * (0.4 / 4),
           vy: (-Math.random() * 0.6 - 0.2) / 4,
           size: Math.random() * 1.8 + 1,
           alpha: 0,
           targetAlpha: Math.random() * 0.4 + 0.15,
           life: 8 + Math.random() * 8
        });
      }
      state.envParticles.forEach((ep: any) => {
         ep.x += (ep.vx / 16) * step;
         ep.y += (ep.vy / 16) * step;
         ep.life -= (step / 60);
         if (ep.alpha < ep.targetAlpha && ep.life > 2) {
             ep.alpha = Math.min(ep.targetAlpha, ep.alpha + (0.015 / 16) * step);
         } else if (ep.life <= 2) {
             ep.alpha = Math.max(0, ep.alpha - (0.02 / 16) * step);
         }
      });
      if (isCleanupFrame) {
        state.envParticles = state.envParticles.filter((ep: any) => ep.life > 0 && ep.alpha > 0);
      }

      // Shockwaves Animation
      state.shockwaves.forEach((s: any) => {
        const speed = s.isFattyLandingHalo ? 0.09 : 0.14;
        const decay = s.isFattyLandingHalo ? 0.022 : 0.035;
        s.r += (s.maxR - s.r) * speed * step;
        s.life -= decay * step;
      });
      if (isCleanupFrame) {
        state.shockwaves = state.shockwaves.filter(s => s.life > 0);
      }

      // Screen Shake Decay
      if (state.screenShake > 0) {
        state.screenShake = Math.max(0, state.screenShake - 0.6 * step);
      }

      // Level Up Golden Light Beams
      state.levelUpBeams.forEach(b => {
        b.timer -= step;
      });
      if (isCleanupFrame) {
        state.levelUpBeams = state.levelUpBeams.filter(b => b.timer > 0);
      }

      // Vampirism Siphon Beams Update (0.15s dynamic red beam anchored to centers)
      state.vampirismBeams.forEach(b => {
        b.timer -= (dt / 1000);
        if (b.target && (b.target.x !== undefined && b.target.y !== undefined)) {
          b.targetX = b.target.x;
          b.targetY = b.target.y;
        }
      });
      state.vampirismBeams = state.vampirismBeams.filter(b => b.timer > 0);

      // Chain Lightning Arcs Update
      state.lightningArcs.forEach(a => {
        a.timer -= (dt / 1000);
      });
      state.lightningArcs = state.lightningArcs.filter(a => a.timer > 0);

      // Level text fade
      if (state.levelText.active) {
        state.levelText.alpha -= 0.015 * step;
        if (state.levelText.alpha <= 0) state.levelText.active = false;
      }

      // Throttle XP, HP, and score sync to prevent React re-renders from lagging game frames (e.g. upon enemy strikes / deaths)
      state.xpSyncTimer = (state.xpSyncTimer || 0) - dt / 1000;
      if (state.pendingXp && (state.xpSyncTimer <= 0 || state.player.hp <= 0)) {
        const xpToSync = state.pendingXp;
        state.pendingXp = 0;
        state.xpSyncTimer = 0.45; // Throttle to ~2-3 times per second
        onUpdateStats(prev => calcLevelUpStats(prev, xpToSync));
      }

      (state as any).hpSyncTimer = ((state as any).hpSyncTimer || 0) - dt / 1000;
      if ((state as any).needsHpSync && ((state as any).hpSyncTimer <= 0 || state.player.hp <= 0)) {
        (state as any).needsHpSync = false;
        (state as any).hpSyncTimer = 0.25; // Throttle HP React sync to 4 times per second max
        const curHp = state.player.hp;
        onUpdateStats(prev => ({ ...prev, hp: curHp }));
      }

      state.scoreSyncTimer = (state.scoreSyncTimer || 0) - dt / 1000;
      if (state.scoreSyncTimer <= 0 && state.mobsKilled !== state.lastSyncedScore) {
        state.scoreSyncTimer = 0.45;
        state.lastSyncedScore = state.mobsKilled;
        onAddScore(state.mobsKilled);
      }

      // Out of bounds safety check for dungeon exploration (scaled with dynamic dungeon bounds)
      const db = state.dungeonBounds || { minX: -1500, maxX: 12000, minY: -1500, maxY: 12000 };
      if (state.player.x < db.minX - 1000 || state.player.x > db.maxX + 1000 ||
          state.player.y < db.minY - 1000 || state.player.y > db.maxY + 1000) {
        state.player.x = state.player.safeX || 150;
        state.player.y = state.player.safeY || 350;
        state.player.vx = 0;
        state.player.vy = 0;
      }
    };

    // --- RENDERING LOOP ---
    const draw = () => {
      const scale = getCameraScale();
      const viewWorldW = canvas.width / scale;
      const viewWorldH = canvas.height / scale;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.imageSmoothingEnabled = false;

      ctx.save();
      ctx.scale(scale, scale);

      // 1. Deep Abyss Void Background (Endless Deep Chasm surrounding the labyrinth)
      if (!state.abyssGrad || state.lastAbyssW !== viewWorldW || state.lastAbyssH !== viewWorldH) {
        const abyssGrad = ctx.createRadialGradient(
          viewWorldW * 0.5, viewWorldH * 0.5, 60,
          viewWorldW * 0.5, viewWorldH * 0.5, Math.max(viewWorldW, viewWorldH) * 0.85
        );
        abyssGrad.addColorStop(0, '#030713');
        abyssGrad.addColorStop(0.55, '#02040a');
        abyssGrad.addColorStop(1, '#000103');
        state.abyssGrad = abyssGrad;
        state.lastAbyssW = viewWorldW;
        state.lastAbyssH = viewWorldH;
      }
      ctx.fillStyle = state.abyssGrad;
      ctx.fillRect(0, 0, viewWorldW, viewWorldH);

      // Deep atmospheric chasm fog bands drifting in the abyss
      const nowSec = performance.now() * 0.001;
      if (state.fogCanvas) {
        for (let f = 0; f < 4; f++) {
          const fogY = ((f * 260 + nowSec * 7) % (viewWorldH + 300)) - 150;
          ctx.drawImage(state.fogCanvas, 0, fogY, viewWorldW, 120);
        }
      }

      // ----------------------------------------------------------------------
      // 2. MULTI-LAYER TOP-DOWN CITADEL BACKGROUND IN THE ABYSS
      // ----------------------------------------------------------------------

      // 2.A DEEP BACKGROUND LAYER (Distant abyssal level, Parallax 0.038 - Desktop only to save mobile draw calls)
      if (!IS_MOBILE) {
        const deepParallax = 0.038;
        const camDeepX = state.cameraX * deepParallax;
        const camDeepY = state.cameraY * deepParallax;

        // Deep Bridges
        if (state.backgroundDeepBridges && state.backgroundDeepBridges.length > 0) {
          state.backgroundDeepBridges.forEach((b: any) => {
            const bx1 = b.x1 - camDeepX;
            const by1 = b.y1 - camDeepY;
            const bx2 = b.x2 - camDeepX;
            const by2 = b.y2 - camDeepY;

            const minBx = Math.min(bx1, bx2) - 30;
            const maxBx = Math.max(bx1, bx2) + 30;
            const minBy = Math.min(by1, by2) - 30;
            const maxBy = Math.max(by1, by2) + 30;
            if (maxBx < 0 || minBx > viewWorldW || maxBy < 0 || minBy > viewWorldH) return;

            const bw = b.width;
            if (b.dir === 'H') {
              const rx = bx1;
              const ry = by1 - bw / 2;
              const rw = bx2 - bx1;
              ctx.fillStyle = '#050914';
              ctx.fillRect(rx, ry, rw, bw);
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(rx, ry, rw, 2);
              ctx.fillRect(rx, ry + bw - 2, rw, 2);
            } else {
              const rx = bx1 - bw / 2;
              const ry = by1;
              const rh = by2 - by1;
              ctx.fillStyle = '#050914';
              ctx.fillRect(rx, ry, bw, rh);
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(rx, ry, 2, rh);
              ctx.fillRect(rx + bw - 2, ry, 2, rh);
            }

            // Deep ember pinprick lights (Sprite blitted)
            if (b.torches) {
              b.torches.forEach((torch: any) => {
                const tx = torch.x - camDeepX;
                const ty = torch.y - camDeepY;
                if (tx < -15 || tx > viewWorldW + 15 || ty < -15 || ty > viewWorldH + 15) return;
                if (state.deepTorchGlowCanvas) {
                  ctx.drawImage(state.deepTorchGlowCanvas, tx - 12, ty - 12, 24, 24);
                }
                ctx.fillStyle = '#7dd3fc';
                ctx.fillRect(tx - 1, ty - 1, 2, 2);
              });
            }
          });
        }

        // Deep Crossroads
        if (state.backgroundDeepCrossroads && state.backgroundDeepCrossroads.length > 0) {
          state.backgroundDeepCrossroads.forEach((cross: any) => {
            const cx = cross.x - camDeepX;
            const cy = cross.y - camDeepY;
            const csize = cross.size;
            if (cx + csize < 0 || cx > viewWorldW || cy + csize < 0 || cy > viewWorldH) return;

            ctx.fillStyle = '#050914';
            ctx.fillRect(cx, cy, csize, csize);
            ctx.strokeStyle = '#0f172a';
            ctx.lineWidth = 1;
            ctx.strokeRect(cx + 1, cy + 1, csize - 2, csize - 2);

            if (cross.torches) {
              cross.torches.forEach((torch: any) => {
                const tx = torch.x - camDeepX;
                const ty = torch.y - camDeepY;
                if (tx < -15 || tx > viewWorldW + 15 || ty < -15 || ty > viewWorldH + 15) return;
                if (state.deepTorchGlowCanvas) {
                  ctx.drawImage(state.deepTorchGlowCanvas, tx - 12, ty - 12, 24, 24);
                }
                ctx.fillStyle = '#7dd3fc';
                ctx.fillRect(tx - 1, ty - 1, 2, 2);
              });
            }
          });
        }

        // Deep Towers
        if (state.backgroundDeepTowers && state.backgroundDeepTowers.length > 0) {
          state.backgroundDeepTowers.forEach((t: any) => {
            const tx = t.x - camDeepX;
            const ty = t.y - camDeepY;
            const tsize = t.size;
            const wt = t.wallThick;
            if (tx + tsize < 0 || tx > viewWorldW || ty + tsize < 0 || ty > viewWorldH) return;

            // Floor
            ctx.fillStyle = '#03050c';
            ctx.fillRect(tx + wt, ty + wt, tsize - wt * 2, tsize - wt * 2);
            // 4 Walls
            ctx.fillStyle = '#0e1628';
            ctx.fillRect(tx, ty, tsize, wt);
            ctx.fillRect(tx, ty + tsize - wt, tsize, wt);
            ctx.fillRect(tx, ty + wt, wt, tsize - wt * 2);
            ctx.fillRect(tx + tsize - wt, ty + wt, wt, tsize - wt * 2);
            ctx.strokeStyle = '#060a14';
            ctx.lineWidth = 1;
            ctx.strokeRect(tx, ty, tsize, tsize);

            if (t.torches) {
              t.torches.forEach((torch: any) => {
                const torchX = torch.x - camDeepX;
                const torchY = torch.y - camDeepY;
                if (torchX < -15 || torchX > viewWorldW + 15 || torchY < -15 || torchY > viewWorldH + 15) return;
                if (state.deepTorchGlowCanvas) {
                  ctx.drawImage(state.deepTorchGlowCanvas, torchX - 12, torchY - 12, 24, 24);
                }
                ctx.fillStyle = '#bae6fd';
                ctx.fillRect(torchX - 1, torchY - 1, 2, 2);
              });
            }
          });
        }

        // Atmospheric Depth Haze between Deep and Mid Layers
        ctx.fillStyle = 'rgba(2, 6, 18, 0.42)';
        ctx.fillRect(0, 0, viewWorldW, viewWorldH);
      }

      // 2.B MID BACKGROUND LAYER: Towers with 4 brick walls & floor, Bridges with Lights, Crossroads (Parallax 0.08)
      const bgParallax = 0.08;
      const camBgX = state.cameraX * bgParallax;
      const camBgY = state.cameraY * bgParallax;

      // 2.1 Bridges with Lights (View from top)
      if (state.backgroundBridges && state.backgroundBridges.length > 0) {
        state.backgroundBridges.forEach(b => {
          const bx1 = b.x1 - camBgX;
          const by1 = b.y1 - camBgY;
          const bx2 = b.x2 - camBgX;
          const by2 = b.y2 - camBgY;

          // Viewport culling
          const minBx = Math.min(bx1, bx2) - 40;
          const maxBx = Math.max(bx1, bx2) + 40;
          const minBy = Math.min(by1, by2) - 40;
          const maxBy = Math.max(by1, by2) + 40;
          if (maxBx < 0 || minBx > viewWorldW || maxBy < 0 || minBy > viewWorldH) return;

          const bw = b.width;
          if (b.dir === 'H') {
            const rx = bx1;
            const ry = by1 - bw / 2;
            const rw = bx2 - bx1;
            const rh = bw;

            // Bridge Floor (dark stone deck)
            ctx.fillStyle = '#0b1329';
            ctx.fillRect(rx, ry, rw, rh);

            // Outer parapet walls (top-down stone edges)
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(rx, ry, rw, 3);
            ctx.fillRect(rx, ry + rh - 3, rw, 3);
          } else {
            const rx = bx1 - bw / 2;
            const ry = by1;
            const rw = bw;
            const rh = by2 - by1;

            // Bridge Floor (dark stone deck)
            ctx.fillStyle = '#0b1329';
            ctx.fillRect(rx, ry, rw, rh);

            // Outer parapet walls
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(rx, ry, 3, rh);
            ctx.fillRect(rx + rw - 3, ry, 3, rh);
          }

          // Lights along bridge parapets ("мосты с огнями") - Blitted
          b.torches.forEach(torch => {
            const tx = torch.x - camBgX;
            const ty = torch.y - camBgY;
            if (tx < -25 || tx > viewWorldW + 25 || ty < -25 || ty > viewWorldH + 25) return;
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(tx - 2, ty - 2, 4, 4);
            ctx.fillStyle = '#ea580c';
            ctx.fillRect(tx - 1, ty - 1, 2, 2);
          });
        });
      }

      // 2.2 Crossroads (Top-down view of bridge cross intersections with corner fires)
      if (state.backgroundCrossroads && state.backgroundCrossroads.length > 0) {
        state.backgroundCrossroads.forEach(cross => {
          const cx = cross.x - camBgX;
          const cy = cross.y - camBgY;
          const csize = cross.size;
          if (cx + csize < 0 || cx > viewWorldW || cy + csize < 0 || cy > viewWorldH) return;

          // Crossroad floor
          ctx.fillStyle = '#0b1329';
          ctx.fillRect(cx, cy, csize, csize);

          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1;
          ctx.strokeRect(cx + 2, cy + 2, csize - 4, csize - 4);

          // Corner lights/torches - Blitted
          cross.torches.forEach(torch => {
            const tx = torch.x - camBgX;
            const ty = torch.y - camBgY;
            if (tx < -25 || tx > viewWorldW + 25 || ty < -25 || ty > viewWorldH + 25) return;
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(tx - 1.5, ty - 1.5, 3, 3);
          });
        });
      }

      // 2.3 Towers (Top-Down View: 4 brick walls with floor, stretched between bridges)
      if (state.backgroundTowers && state.backgroundTowers.length > 0) {
        state.backgroundTowers.forEach(t => {
          const tx = t.x - camBgX;
          const ty = t.y - camBgY;
          const tsize = t.size;
          const wt = t.wallThick;

          if (tx + tsize < 0 || tx > viewWorldW || ty + tsize < 0 || ty > viewWorldH) return;

          if (!t.cachedCanvas) {
            const tc = document.createElement('canvas');
            tc.width = tsize;
            tc.height = tsize;
            const tCtx = tc.getContext('2d');
            if (tCtx) {
              const innerSize = tsize - wt * 2;
              tCtx.fillStyle = t.floorColor || '#070b16';
              tCtx.fillRect(wt, wt, innerSize, innerSize);

              tCtx.strokeStyle = '#0f172a';
              tCtx.lineWidth = 1;
              tCtx.beginPath();
              for (let step = 16; step < innerSize; step += 18) {
                tCtx.moveTo(wt + step, wt);
                tCtx.lineTo(wt + step, wt + innerSize);
                tCtx.moveTo(wt, wt + step);
                tCtx.lineTo(wt + innerSize, wt + step);
              }
              tCtx.stroke();

              tCtx.fillStyle = t.wallColor || '#1e293b';
              tCtx.fillRect(0, 0, tsize, wt);
              tCtx.fillRect(0, tsize - wt, tsize, wt);
              tCtx.fillRect(0, wt, wt, innerSize);
              tCtx.fillRect(tsize - wt, wt, wt, innerSize);

              tCtx.strokeStyle = '#090d16';
              tCtx.lineWidth = 1;
              tCtx.strokeRect(0, 0, tsize, tsize);
              tCtx.strokeRect(wt, wt, innerSize, innerSize);
            }
            t.cachedCanvas = tc;
          }
          ctx.drawImage(t.cachedCanvas, tx, ty);

          // 3. Torches at tower corners - Blitted
          t.torches.forEach(torch => {
            const torchX = torch.x - camBgX;
            const torchY = torch.y - camBgY;
            if (torchX < -25 || torchX > viewWorldW + 25 || torchY < -25 || torchY > viewWorldH + 25) return;
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(torchX - 2, torchY - 2, 4, 4);
            ctx.fillStyle = '#ea580c';
            ctx.fillRect(torchX - 1, torchY - 1, 2, 2);
          });
        });
      }

      // Camera Offset Save (with Screen Shake)
      ctx.save();
      let shakeX = 0;
      let shakeY = 0;
      if (state.screenShake > 0) {
        shakeX = (Math.random() - 0.5) * state.screenShake;
        shakeY = (Math.random() - 0.5) * state.screenShake;
      }
      ctx.translate(-state.cameraX + shakeX, -state.cameraY + shakeY);

      // Environment Ambient Particles (Smooth, non-flickering motes)
      if (state.envParticles && state.envParticles.length > 0) {
        ctx.save();
        for (let i = 0; i < state.envParticles.length; i++) {
          const ep = state.envParticles[i];
          const alpha = Math.max(0, Math.min(1, ep.alpha || 0));
          if (alpha <= 0.01) continue;
          ctx.globalAlpha = alpha;
          ctx.fillStyle = '#67e8f9';
          ctx.beginPath();
          ctx.arc(ep.x, ep.y, ep.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      const pCenterX = state.player.x + state.player.w / 2;
      const pCenterY = state.player.y + state.player.h / 2;

      // 3. Platforms (Floating Fortress rooms suspended above the bottomless abyss)
      state.platforms.forEach(p => {
        if (p.x + p.width < state.cameraX - 100 || p.x > state.cameraX + viewWorldW + 100 ||
            p.y + p.height < state.cameraY - 100 || p.y > state.cameraY + viewWorldH + 100) return;

        const t = getObjTheme(p.x);

        if (!p.isStartFloor) {
          // A. Massive vertical stone cliff edge plunging down toward the abyss
          const cliffHeight = 40;
          if (state.cliffCanvas) {
            ctx.drawImage(state.cliffCanvas, p.x, p.y + p.height, p.width, cliffHeight);
          } else {
            ctx.fillStyle = '#0b1322';
            ctx.fillRect(p.x, p.y + p.height, p.width, cliffHeight);
          }

          // Rocky strata crags along the cliff drop-off (Batched stroke)
          ctx.strokeStyle = '#050a14';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          for (let cx = p.x + 14; cx < p.x + p.width - 12; cx += 28) {
            ctx.moveTo(cx, p.y + p.height);
            ctx.lineTo(cx + (cx % 7 === 0 ? 4 : -3), p.y + p.height + cliffHeight * 0.7);
            ctx.lineTo(cx + (cx % 5 === 0 ? -2 : 3), p.y + p.height + cliffHeight);
          }
          ctx.stroke();

          // B. Deep chasm shadow falling into the darkness of the abyss below
          if (state.shadowCanvas && !p.isDungeonFloor) {
            ctx.drawImage(state.shadowCanvas, p.x - 20, p.y + p.height + cliffHeight, p.width + 40, 65);
          }
        }

        // C. Main Platform Walking Surface Body (Tiled plate 1..11 dungeon floor)
        if (p.isStartFloor) {
          // No visible grey-black backdrop/underlay for preset rooms to respect custom transparency and design elements!
        } else {
          const loadedPlates = gameAssets.plates.filter(img => img && img.complete && img.naturalWidth > 0);
          if (loadedPlates.length > 0) {
            if (!p.cachedFloorCanvas) {
              const pc = document.createElement('canvas');
              pc.width = p.width;
              pc.height = p.height;
              const pCtx = pc.getContext('2d');
              if (pCtx) {
                const tileSize = 64;
                const startCol = Math.floor(p.x / tileSize);
                const endCol = Math.floor((p.x + p.width) / tileSize);
                const startRow = Math.floor(p.y / tileSize);
                const endRow = Math.floor((p.y + p.height) / tileSize);

                const regularPlates = loadedPlates.filter(img => img !== gameAssets.plate11);
                const hasPlate11 = loadedPlates.some(img => img === gameAssets.plate11);
                let plate11Count = 0;
                const maxPlate11PerRoom = 2;

                for (let r = startRow; r <= endRow; r++) {
                  for (let c = startCol; c <= endCol; c++) {
                    const tileX = c * tileSize - p.x;
                    const tileY = r * tileSize - p.y;
                    const seed = Math.sin(c * 12.9898 + r * 78.233 + (p.x * 0.005) * 37.719) * 43758.5453;
                    const randVal = Math.abs(seed - Math.floor(seed));

                    let chosenPlate: HTMLImageElement;
                    if (hasPlate11 && plate11Count < maxPlate11PerRoom && randVal < 0.035) {
                      chosenPlate = gameAssets.plate11!;
                      plate11Count++;
                    } else if (regularPlates.length > 0) {
                      const regIdx = Math.floor(randVal * regularPlates.length) % regularPlates.length;
                      chosenPlate = regularPlates[regIdx];
                    } else {
                      chosenPlate = loadedPlates[0];
                    }
                    pCtx.drawImage(chosenPlate, tileX, tileY, tileSize, tileSize);
                  }
                }
                pCtx.fillStyle = 'rgba(2, 6, 16, 0.38)';
                pCtx.fillRect(0, 0, p.width, p.height);
              }
              p.cachedFloorCanvas = pc;
            }
            ctx.drawImage(p.cachedFloorCanvas, p.x, p.y);
          } else {
            ctx.fillStyle = state.floorPattern || t.platColor || '#111928';
            ctx.fillRect(p.x, p.y, p.width, p.height);
          }
        }

        // Platform perimeter stone framing borders
        if (!p.isStartFloor) {
          ctx.strokeStyle = '#050a15';
          ctx.lineWidth = 2;
          ctx.strokeRect(p.x, p.y, p.width, p.height);

          // Top trim neon edge
          ctx.fillStyle = t.platNeon;
          ctx.fillRect(p.x, p.y, p.width, 3);

          // Bevel highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
          ctx.fillRect(p.x, p.y + 3, p.width, 1.5);
        }
      });

      // 3.8 Procedural Dungeon Props & Decorations (Matching Reference Screenshots)
      // Depth Sorting: Collect foreground occluders (decorations, columns, chests) where player or enemies are walking behind them
      const deferredForegroundObjects = state.deferredForegroundObjects || [];
      deferredForegroundObjects.length = 0;
      const pFeetY = state.player.y + state.player.h;

      // Collect all pedestrian/ground mobile units (Player, Knights, Saws, Ice enemies, Sorcerers, Phantoms, Bosses)
      const groundUnits: Array<{ x: number; feetY: number }> = [
        { x: pCenterX, feetY: pFeetY }
      ];
      if (state.enemies && state.enemies.length > 0) {
        state.enemies.forEach((en: any) => {
          if (!en.alive) return;
          const enRadius = en.r || (en.w ? en.w / 2 : 20);
          const enFeetY = en.y + (en.h ? (en.h / 2) : enRadius);
          groundUnits.push({ x: en.x, feetY: enFeetY });
        });
      }

      const isUnitBehindDec = (uX: number, uFeetY: number, dec: any): boolean => {
        if (dec.type === 'cobweb' || dec.type === 'banner') return false;
        if (dec.type === 'stone_brazier' || dec.type === 'brazier') {
          const bx = dec.x;
          const by = dec.y;
          return uX >= bx - 34 && uX <= bx + 34 && uFeetY <= by + 18;
        }
        if (dec.type === 'tall_torch') {
          const tx = dec.x;
          const ty = dec.y;
          return uX >= tx - 32 && uX <= tx + 32 && uFeetY <= ty + 26;
        }
        if (dec.type === 'altar') {
          const ax = dec.x;
          const ay = dec.y;
          return uX >= ax - 70 && uX <= ax + 70 && uFeetY <= ay + 46;
        }
        if (dec.type === 'shrine') {
          const sx = dec.x;
          const sy = dec.y;
          return uX >= sx - 38 && uX <= sx + 38 && uFeetY <= sy + 34;
        }
        if (dec.type === 'torch' || dec.type === 'banner' || dec.type === 'cobweb') {
          return false;
        }
        if (dec.type === 'prop_cluster') {
          const px = dec.x;
          const py = dec.y;
          if (dec.subtype === 'barrels') {
            return uX >= px - 24 && uX <= px + 50 && uFeetY >= py - 18 && uFeetY <= py + 26;
          } else if (dec.subtype === 'crate') {
            const cx = px + 24;
            const cy = py + 2;
            return uX >= cx - 30 && uX <= cx + 30 && uFeetY >= cy - 18 && uFeetY <= cy + 28;
          } else if (dec.subtype === 'pot' || dec.subtype === 'pot2') {
            const ux = px + 22;
            const uy = py;
            const isPot2 = dec.subtype === 'pot2';
            const halfW = isPot2 ? 34 : 22;
            return uX >= ux - halfW && uX <= ux + halfW && uFeetY >= uy - 18 && uFeetY <= uy + 22;
          } else if (dec.subtype === 'rocks') {
            return uX >= px - 6 && uX <= px + 60 && uFeetY >= py - 18 && uFeetY <= py + 28;
          }
          return uX >= px - 30 && uX <= px + 56 && uFeetY >= py - 18 && uFeetY <= py + 28;
        }
        if (dec.type === 'custom_element' && (dec.isDestructible || dec.layer === 'mid_props' || (dec.assetId && dec.assetId.startsWith('prop_')))) {
          const dw = dec.w || 44;
          const dh = dec.h || 44;
          return uX >= dec.x - 14 && uX <= dec.x + dw + 14 && uFeetY >= dec.y - 14 && uFeetY <= dec.y + dh - 4;
        }
        return false;
      };

      const isAnyUnitBehindDec = (dec: any): boolean => {
        for (let i = 0; i < groundUnits.length; i++) {
          if (isUnitBehindDec(groundUnits[i].x, groundUnits[i].feetY, dec)) return true;
        }
        return false;
      };

      const isAnyUnitBehindChest = (c: any): boolean => {
        const cw = c.w || 54;
        const ch = c.h || 40;
        for (let i = 0; i < groundUnits.length; i++) {
          const uX = groundUnits[i].x;
          const uFeetY = groundUnits[i].feetY;
          if (uX >= c.x - 16 && uX <= c.x + cw + 16 && uFeetY >= c.y - 14 && uFeetY <= c.y + ch + 4) {
            return true;
          }
        }
        return false;
      };

      const isAnyUnitBehindColumn = (w: any): boolean => {
        const colCenterX = w.x + w.w / 2;
        const baseY = w.y + w.h;
        for (let i = 0; i < groundUnits.length; i++) {
          const uX = groundUnits[i].x;
          const uFeetY = groundUnits[i].feetY;
          if (uX >= colCenterX - 38 && uX <= colCenterX + 38 && uFeetY <= baseY + 6) {
            return true;
          }
        }
        return false;
      };

      const getDecBaseY = (dec: any): number => {
        if (dec.type === 'altar') return dec.y + 44;
        if (dec.type === 'tall_torch') return dec.y + 24;
        if (dec.type === 'stone_brazier' || dec.type === 'brazier') return dec.y + 16;
        if (dec.type === 'shrine') return dec.y + 32;
        if (dec.type === 'torch') return dec.y + 8;
        if (dec.type === 'prop_cluster') {
          if (dec.subtype === 'crate') return dec.y + 28;
          if (dec.subtype === 'pot' || dec.subtype === 'pot2') return dec.y + (dec.subtype === 'pot2' ? 26 : 24);
          return dec.y + 26;
        }
        if (dec.type === 'custom_element') {
          return dec.y + (dec.h || 44);
        }
        return dec.y;
      };

      // --- ULTRA-REALISTIC ORGANIC FLUID FIRE RENDERER ---
      const drawRealisticFire = (
        targetCtx: CanvasRenderingContext2D,
        fx: number,
        fy: number,
        scale: number,
        time: number,
        seed: number,
        baseScaleW: number = 1.0,
        scaleH: number = 1.0
      ) => {
        // Animation slowed down by 4x for a majestic, smooth, realistic burning flow
        const t = time * 0.25;
        const sway1 = Math.sin(t * 13 + seed) * 2.2 * scale;
        const sway2 = Math.cos(t * 21 + seed * 1.6) * 1.4 * scale;
        const hPulse = Math.sin(t * 16 + seed * 3.1) * 0.10 + Math.cos(t * 9 + seed) * 0.06;

        const mainH = 26 * scale * scaleH * (1 + hPulse);
        const baseW = 6.8 * scale * baseScaleW;
        const midW = 9.2 * scale;
        const tipX = fx + sway1 + sway2 * 0.35;
        const tipY = fy - mainH;

        // 1. Soft Warm Amber Core Radiant Glow (Pre-rendered fast sprite)
        const flareR = 22 * scale;
        if (state.torchGlowCanvas) {
          targetCtx.drawImage(state.torchGlowCanvas, fx - flareR, (fy - mainH * 0.3) - flareR, flareR * 2, flareR * 2);
        }

        // 2. Outer Fire Plume (Radiant Fiery Orange-Red with undulating smooth organic curves)
        targetCtx.fillStyle = '#ea580c';
        targetCtx.beginPath();
        targetCtx.moveTo(fx - baseW, fy);
        targetCtx.bezierCurveTo(
          fx - midW * 1.35 + Math.sin(t * 15 + seed) * 1.5 * scale,
          fy - mainH * 0.38,
          fx - midW * 0.8 + sway1 * 0.7,
          fy - mainH * 0.76,
          tipX,
          tipY
        );
        targetCtx.bezierCurveTo(
          fx + midW * 0.8 + sway1 * 0.7,
          fy - mainH * 0.76,
          fx + midW * 1.35 + Math.cos(t * 18 + seed) * 1.5 * scale,
          fy - mainH * 0.38,
          fx + baseW,
          fy
        );
        targetCtx.closePath();
        targetCtx.fill();

        // 3. Mid Flame Layer (Vibrant Amber-Yellow to Radiant Gold)
        const midH = mainH * 0.72;
        const midBaseW = baseW * 0.65;
        const midTipX = fx + (sway1 * 0.55);
        const midTipY = fy - midH;

        targetCtx.fillStyle = '#facc15';
        targetCtx.beginPath();
        targetCtx.moveTo(fx - midBaseW, fy);
        targetCtx.bezierCurveTo(
          fx - midW * 0.75 + Math.sin(t * 19 + seed) * 0.9 * scale,
          fy - midH * 0.38,
          fx - midW * 0.35 + sway1 * 0.45,
          fy - midH * 0.74,
          midTipX,
          midTipY
        );
        targetCtx.bezierCurveTo(
          fx + midW * 0.35 + sway1 * 0.45,
          fy - midH * 0.74,
          fx + midW * 0.75 + Math.cos(t * 22 + seed) * 0.9 * scale,
          fy - midH * 0.38,
          fx + midBaseW,
          fy
        );
        targetCtx.closePath();
        targetCtx.fill();

        // 4. Intense Hot Combustion Core (Luminous White-Yellow Teardrop)
        const coreH = mainH * 0.42;
        const coreBaseW = baseW * 0.4;
        const coreTipX = fx + (sway1 * 0.25);
        const coreTipY = fy - coreH;

        targetCtx.fillStyle = '#fef08a';
        targetCtx.beginPath();
        targetCtx.moveTo(fx - coreBaseW, fy);
        targetCtx.quadraticCurveTo(fx - coreBaseW * 1.3, fy - coreH * 0.48, coreTipX, coreTipY);
        targetCtx.quadraticCurveTo(fx + coreBaseW * 1.3, fy - coreH * 0.48, fx + coreBaseW, fy);
        targetCtx.closePath();
        targetCtx.fill();

        // 5. Floating Rising Spark Embers with Turbulence, Shrink, and Alpha Fade
        const emberCount = Math.max(1, Math.round(2 * scale));
        for (let i = 0; i < emberCount; i++) {
          const emberLife = ((t * (22 + i * 7) + seed * 5 + i * 17) % 32) / 32;
          const emberY = fy - (mainH * 0.25) - emberLife * (mainH * 1.5);
          const emberX = fx + Math.sin(t * (16 + i * 5) + i * 2.8) * (5 * scale + emberLife * 9 * scale) + (sway1 * 0.4);
          const emberAlpha = Math.max(0, (1 - emberLife) * 0.92);
          const emberSize = Math.max(0.8, (1 - emberLife * 0.5) * (1.7 * scale));

          targetCtx.fillStyle = i % 2 === 0 ? `rgba(254, 240, 138, ${emberAlpha})` : `rgba(251, 146, 60, ${emberAlpha})`;
          targetCtx.beginPath();
          targetCtx.arc(emberX, emberY, emberSize * 0.5, 0, Math.PI * 2);
          targetCtx.fill();
        }
      };

      const renderSingleDecoration = (dec: any, mode: 'all' | 'shadow' | 'body' = 'all') => {
        if (dec.isDestructible && (dec.alive === false || dec.opened)) return;
        ctx.save();

          if (dec.type === 'cobweb') {
            if (mode === 'shadow') { ctx.restore(); return; }
            // Delicate corner spiderweb
            const cx = dec.x;
            const cy = dec.y;
            const cSize = 42;
            const corner = dec.corner || 'tl';

            ctx.strokeStyle = 'rgba(203, 213, 225, 0.35)';
            ctx.lineWidth = 0.9;
            ctx.beginPath();

            if (corner === 'tl') {
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize, cy);
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize * 0.85, cy + cSize * 0.45);
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize * 0.45, cy + cSize * 0.85);
              ctx.moveTo(cx, cy); ctx.lineTo(cx, cy + cSize);
              // Arcs
              ctx.moveTo(cx + 14, cy); ctx.quadraticCurveTo(cx + 10, cy + 10, cx, cy + 14);
              ctx.moveTo(cx + 28, cy); ctx.quadraticCurveTo(cx + 20, cy + 20, cx, cy + 28);
              ctx.moveTo(cx + cSize, cy); ctx.quadraticCurveTo(cx + 30, cy + 30, cx, cy + cSize);
            } else if (corner === 'tr') {
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize, cy);
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize * 0.85, cy + cSize * 0.45);
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize * 0.45, cy + cSize * 0.85);
              ctx.moveTo(cx, cy); ctx.lineTo(cx, cy + cSize);
              ctx.moveTo(cx - 14, cy); ctx.quadraticCurveTo(cx - 10, cy + 10, cx, cy + 14);
              ctx.moveTo(cx - 28, cy); ctx.quadraticCurveTo(cx - 20, cy + 20, cx, cy + 28);
              ctx.moveTo(cx - cSize, cy); ctx.quadraticCurveTo(cx - 30, cy + 30, cx, cy + cSize);
            } else if (corner === 'bl') {
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize, cy);
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize * 0.85, cy - cSize * 0.45);
              ctx.moveTo(cx, cy); ctx.lineTo(cx + cSize * 0.45, cy - cSize * 0.85);
              ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - cSize);
              ctx.moveTo(cx + 14, cy); ctx.quadraticCurveTo(cx + 10, cy - 10, cx, cy - 14);
              ctx.moveTo(cx + 28, cy); ctx.quadraticCurveTo(cx + 20, cy - 20, cx, cy - 28);
              ctx.moveTo(cx + cSize, cy); ctx.quadraticCurveTo(cx + 30, cy - 30, cx, cy - cSize);
            } else if (corner === 'br') {
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize, cy);
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize * 0.85, cy - cSize * 0.45);
              ctx.moveTo(cx, cy); ctx.lineTo(cx - cSize * 0.45, cy - cSize * 0.85);
              ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - cSize);
              ctx.moveTo(cx - 14, cy); ctx.quadraticCurveTo(cx - 10, cy - 10, cx, cy - 14);
              ctx.moveTo(cx - 28, cy); ctx.quadraticCurveTo(cx - 20, cy - 20, cx, cy - 28);
              ctx.moveTo(cx - cSize, cy); ctx.quadraticCurveTo(cx - 30, cy - 30, cx, cy - cSize);
            }
            ctx.stroke();
          } else if (dec.type === 'banner') {
            if (mode === 'shadow') { ctx.restore(); return; }
            const bx = dec.x;
            const by = dec.y;

            const img = gameAssets.flag;
            const flagH = 58;
            const aspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (32 / 58);
            const flagW = Math.round(flagH * aspect);
            // Raised higher so it mounts directly to the top walls without any artificial yellow bracket
            const drawX = bx - flagW / 2;
            const drawY = by - 16;

            if (img && img.complete && img.naturalWidth > 0) {
              ctx.drawImage(img, drawX, drawY, flagW, flagH);
            } else {
              // Fallback Banner
              ctx.fillStyle = '#b91c1c';
              ctx.beginPath();
              ctx.moveTo(drawX, drawY);
              ctx.lineTo(drawX + flagW, drawY);
              ctx.lineTo(drawX + flagW, drawY + flagH - 10);
              ctx.lineTo(bx, drawY + flagH);
              ctx.lineTo(drawX, drawY + flagH - 10);
              ctx.closePath();
              ctx.fill();
            }
          } else if (dec.type === 'prop_cluster') {
            const px = dec.x;
            const py = dec.y;

            if (dec.subtype === 'barrels') {
              // --- 3D ISOMETRIC SINGLE DUNGEON BARREL (+10% SCALED) ---
              const bx = px + 12;
              const by = py + 2;
              const img = gameAssets.bochka;
              const barrelH = Math.round(52 * 1.10); // 57px (+10%)
              const barrelAspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (48 / 52);
              const barrelW = Math.round(barrelH * barrelAspect);
              const isHit = dec.hitFlash && dec.hitFlash > 0;

              if (mode !== 'body') {
                ctx.save();
                ctx.fillStyle = 'rgba(5, 8, 15, 0.55)';
                ctx.beginPath();
                ctx.ellipse(bx, by + 18, Math.max(18, barrelW * 0.45), 9, 0.1, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = 'rgba(2, 4, 8, 0.65)';
                ctx.beginPath();
                ctx.ellipse(bx, by + 18, Math.max(12, barrelW * 0.3), 5.5, 0.1, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
              }

              if (mode === 'shadow') { ctx.restore(); return; }

              if (img && img.complete && img.naturalWidth > 0) {
                ctx.drawImage(img, bx - barrelW / 2, by - barrelH + 20, barrelW, barrelH);
              } else {
                // Procedural fallback
                ctx.fillStyle = '#78350f';
                ctx.beginPath();
                ctx.ellipse(bx, by + 2, 22, 26, 0, 0, Math.PI * 2);
                ctx.fill();
              }

            } else if (dec.subtype === 'crate') {
              // --- 3D ISOMETRIC WOODEN SHIPPING CRATE (-10% scale) ---
              const cx = px + 20;
              const cy = py + 2;
              const img = gameAssets.yashik;
              const pSize = state.player.w || 35;
              const crateW = Math.round(pSize * 1.35 * 0.90); // Reduced by 10% (~43px)
              const crateAspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : 0.92;
              const crateH = Math.round(crateW / crateAspect);

              if (mode !== 'body') {
                ctx.save();
                const baseW = crateW;
                const baseH = 11;
                const baseX = cx - baseW / 2;
                const baseY = cy + 15 - baseH / 2;

                // Outer soft ambient box shadow matching rectangular flat footprint
                if (!state.shadowCache) state.shadowCache = new Map();
                const shadowKey = `crate-${baseW}-${baseH}`;
                let shadowCanvas = state.shadowCache.get(shadowKey);
                if (!shadowCanvas) {
                  shadowCanvas = document.createElement('canvas');
                  shadowCanvas.width = baseW + 4;
                  shadowCanvas.height = baseH + 4;
                  const scCtx = shadowCanvas.getContext('2d');
                  if (scCtx) {
                    scCtx.fillStyle = 'rgba(5, 8, 15, 0.38)';
                    scCtx.beginPath();
                    if (scCtx.roundRect) {
                      scCtx.roundRect(0, 0, baseW + 4, baseH + 4, [2, 3, 3, 2]);
                    } else {
                      scCtx.rect(0, 0, baseW + 4, baseH + 4);
                    }
                    scCtx.fill();
                    // Dense contact rectangular shadow
                    scCtx.fillStyle = 'rgba(5, 8, 15, 0.70)';
                    scCtx.beginPath();
                    if (scCtx.roundRect) {
                      scCtx.roundRect(2, 3, baseW, baseH - 1, [2, 3, 3, 2]);
                    } else {
                      scCtx.rect(2, 3, baseW, baseH - 1);
                    }
                    scCtx.fill();
                  }
                  state.shadowCache.set(shadowKey, shadowCanvas);
                }
                ctx.drawImage(shadowCanvas, baseX - 2, baseY - 2);

                ctx.restore();
              }

              if (mode === 'shadow') { ctx.restore(); return; }

              if (img && img.complete && img.naturalWidth > 0) {
                ctx.drawImage(img, cx - crateW / 2, cy - crateH + 17, crateW, crateH);
              } else {
                // Fallback procedural box
                ctx.fillStyle = '#92400e';
                ctx.fillRect(cx - crateW / 2, cy - crateH + 17, crateW, crateH);
              }

            } else if (dec.subtype === 'pot' || dec.subtype === 'pot2') {
              // --- 3D ISOMETRIC TERRACOTTA AMPHORA / URN ---
              const ux = px + 22;
              const uy = py + 4;
              const isPot2 = dec.subtype === 'pot2';
              const img = isPot2 ? gameAssets.kuvshin2 : gameAssets.kuvshin;
              // Kuvshin (4 pots) is 20% larger; Kuvshin 2 (big pot) is 30% larger!
              const potH = isPot2 ? Math.round(48 * 1.30) : Math.round(48 * 1.20);
              const potAspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (isPot2 ? (478 / 456) : (44 / 48));
              const potW = Math.round(potH * potAspect);

              if (mode === 'shadow') { ctx.restore(); return; }

              if (img && img.complete && img.naturalWidth > 0) {
                ctx.drawImage(img, ux - potW / 2, uy - potH + 17, potW, potH);
              } else {
                // Fallback pot
                ctx.fillStyle = isPot2 ? '#b45309' : '#ea580c';
                ctx.beginPath();
                ctx.ellipse(ux, uy, Math.round(potW * 0.38), Math.round(potH * 0.42), 0, 0, Math.PI * 2);
                ctx.fill();
              }

            } else if (dec.subtype === 'rocks') {
              // --- 3D ISOMETRIC FACETED SLATE BOULDER CLUSTER (INDESTRUCTIBLE SCENERY) ---
              // Directional Angular Cast Shadow matching faceted rocks
              if (mode !== 'body') {
                ctx.save();
                ctx.fillStyle = 'rgba(5, 8, 15, 0.82)';
                ctx.beginPath();
                ctx.moveTo(px + 2, py + 18);
                ctx.lineTo(px + 18, py + 23);
                ctx.lineTo(px + 30, py + 24);
                ctx.lineTo(px + 44, py + 19);
                ctx.lineTo(px + 50, py + 14);
                ctx.lineTo(px + 48, py + 16);
                ctx.lineTo(px + 30, py + 26);
                ctx.lineTo(px + 2, py + 20);
                ctx.closePath();
                ctx.fill();

                const rockGrad = ctx.createLinearGradient(px + 20, py + 22, px + 64, py + 16);
                rockGrad.addColorStop(0, 'rgba(5, 8, 15, 0.68)');
                rockGrad.addColorStop(0.65, 'rgba(5, 8, 15, 0.28)');
                rockGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
                ctx.fillStyle = rockGrad;
                ctx.beginPath();
                ctx.moveTo(px + 2, py + 19);
                ctx.lineTo(px + 20, py + 24);
                ctx.lineTo(px + 32, py + 25);
                ctx.lineTo(px + 48, py + 20);
                ctx.lineTo(px + 62, py + 16);
                ctx.lineTo(px + 56, py + 11);
                ctx.lineTo(px + 58, py + 6);
                ctx.lineTo(px + 42, py + 5);
                ctx.lineTo(px + 24, py + 9);
                ctx.closePath();
                ctx.fill();
                ctx.restore();
              }

              if (mode === 'shadow') { ctx.restore(); return; }

              // Boulder 1 (Large 3D Faceted Slate Rock)
              // Under-shadow facet
              ctx.fillStyle = '#0f172a';
              ctx.beginPath();
              ctx.moveTo(px + 2, py + 18);
              ctx.lineTo(px + 14, py - 6);
              ctx.lineTo(px + 38, py - 10);
              ctx.lineTo(px + 50, py + 14);
              ctx.lineTo(px + 30, py + 24);
              ctx.closePath();
              ctx.fill();

              // Front-left midtone facet
              ctx.fillStyle = '#1e293b';
              ctx.beginPath();
              ctx.moveTo(px + 2, py + 18);
              ctx.lineTo(px + 14, py - 6);
              ctx.lineTo(px + 26, py + 6);
              ctx.lineTo(px + 30, py + 24);
              ctx.closePath();
              ctx.fill();

              // Top sunlit facet (Ceiling light gleam)
              ctx.fillStyle = '#475569';
              ctx.beginPath();
              ctx.moveTo(px + 14, py - 6);
              ctx.lineTo(px + 38, py - 10);
              ctx.lineTo(px + 26, py + 6);
              ctx.closePath();
              ctx.fill();

              // Front-right shaded facet
              ctx.fillStyle = '#334155';
              ctx.beginPath();
              ctx.moveTo(px + 38, py - 10);
              ctx.lineTo(px + 50, py + 14);
              ctx.lineTo(px + 30, py + 24);
              ctx.lineTo(px + 26, py + 6);
              ctx.closePath();
              ctx.fill();

              // Chiseled razor ridges
              ctx.strokeStyle = '#64748b';
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(px + 14, py - 6); ctx.lineTo(px + 26, py + 6);
              ctx.lineTo(px + 30, py + 24);
              ctx.moveTo(px + 38, py - 10); ctx.lineTo(px + 26, py + 6);
              ctx.stroke();

              // Companion small faceted boulder on the right
              ctx.fillStyle = '#334155';
              ctx.beginPath();
              ctx.moveTo(px + 38, py + 14);
              ctx.lineTo(px + 50, py + 4);
              ctx.lineTo(px + 58, py + 16);
              ctx.lineTo(px + 46, py + 22);
              ctx.closePath();
              ctx.fill();
              ctx.fillStyle = '#64748b';
              ctx.beginPath();
              ctx.moveTo(px + 38, py + 14);
              ctx.lineTo(px + 50, py + 4);
              ctx.lineTo(px + 46, py + 14);
              ctx.closePath();
              ctx.fill();
            }
          } else if (dec.type === 'shrine') {
            // --- 3D ISOMETRIC STONE SARCOPHAGUS ALTAR / SHRINE ---
            const sx = dec.x;
            const sy = dec.y;
            const sw = 50;
            const sh = 32;

            if (mode !== 'body') {
              ctx.save();
              ctx.fillStyle = 'rgba(5, 8, 15, 0.82)';
              ctx.fillRect(sx - sw / 2, sy + sh - 2, sw, 3);

              const shrGrad = ctx.createLinearGradient(sx, sy + sh, sx + sw / 2 + 22, sy + sh + 10);
              shrGrad.addColorStop(0, 'rgba(5, 8, 15, 0.68)');
              shrGrad.addColorStop(0.65, 'rgba(5, 8, 15, 0.26)');
              shrGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
              ctx.fillStyle = shrGrad;
              ctx.beginPath();
              ctx.moveTo(sx - sw / 2 + 6, sy + sh);
              ctx.lineTo(sx + sw / 2, sy + sh);
              ctx.lineTo(sx + sw / 2 + 10, sy + sh - 4);
              ctx.lineTo(sx + sw / 2 + 22, sy + sh + 6);
              ctx.lineTo(sx + sw / 2 + 16, sy + sh + 12);
              ctx.lineTo(sx - sw / 2 + 18, sy + sh + 10);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
            }

            if (mode === 'shadow') { ctx.restore(); return; }

            // 1. Right Side Shaded Depth Face
            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.moveTo(sx + sw / 2, sy + 4);
            ctx.lineTo(sx + sw / 2 + 8, sy - 2);
            ctx.lineTo(sx + sw / 2 + 8, sy + sh - 4);
            ctx.lineTo(sx + sw / 2, sy + sh);
            ctx.closePath();
            ctx.fill();

            // 2. Front Carved Face
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(sx - sw / 2, sy + 4, sw, sh - 4);
            ctx.strokeStyle = '#0f172a';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(sx - sw / 2, sy + 4, sw, sh - 4);

            // 3. Top Stone Slab Lid (Tilted in Isometric perspective)
            ctx.fillStyle = '#334155';
            ctx.beginPath();
            ctx.moveTo(sx - sw / 2, sy + 4);
            ctx.lineTo(sx - sw / 2 + 8, sy - 2);
            ctx.lineTo(sx + sw / 2 + 8, sy - 2);
            ctx.lineTo(sx + sw / 2, sy + 4);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
            ctx.fillRect(sx - sw / 2, sy + 4, sw, 1.5);

            // Carved Arched Alcove on Front
            ctx.fillStyle = '#0f172a';
            ctx.beginPath();
            ctx.arc(sx, sy + 16, 11, Math.PI, 0, false);
            ctx.lineTo(sx + 11, sy + sh - 3);
            ctx.lineTo(sx - 11, sy + sh - 3);
            ctx.closePath();
            ctx.fill();

            // Carved White Skull inside alcove
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(sx - 4.5, sy + 11, 9, 7);
            ctx.fillRect(sx - 3.5, sy + 18, 7, 5);
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(sx - 3.5, sy + 13, 2.5, 2.5);
            ctx.fillRect(sx + 1, sy + 13, 2.5, 2.5);

            // 2 Lit White Candles on Left and Right
            // Left Candle
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(sx - sw / 2 - 6, sy + sh - 16, 4.5, 16);
            drawRealisticFire(ctx, sx - sw / 2 - 4, sy + sh - 16, 0.32, nowSec, sx * 0.3);

            // Right Candle
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(sx + sw / 2 + 2, sy + sh - 16, 4.5, 16);
            drawRealisticFire(ctx, sx + sw / 2 + 4, sy + sh - 16, 0.32, nowSec, sx * 0.7);
          } else if (dec.type === 'torch') {
            if (mode === 'shadow') { ctx.restore(); return; }
            // Wall Torch with Sconce Bracket and Ultra-Realistic Fire Flame using Fakel 3 asset
            const tx = dec.x;
            const ty = dec.y;

            const img = gameAssets.fakel3;
            const torchH = 46;
            const aspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (24 / 46);
            const torchW = Math.round(torchH * aspect);

            // Ambient Warm Radial Light centered on torch head (animation slowed down 8x)
            const flicker = 0.88 + Math.sin(nowSec * 1.25 + tx * 0.3) * 0.12;
            const glowR = (40 / 1.5) * flicker;
            const glowY = ty - torchH * 0.45;

            if (state.torchGlowCanvas) {
              ctx.drawImage(state.torchGlowCanvas, tx - glowR, glowY - glowR, glowR * 2, glowR * 2);
            }

            // 2.5D Floor Tile Illumination Halo projected onto floor tiles below wall torch
            if (state.floorHaloCanvas) {
              const hW = (70 / 1.5) * flicker;
              const hH = (32 / 1.5) * flicker;
              ctx.drawImage(state.floorHaloCanvas, tx - hW, ty + 32 - hH, hW * 2, hH * 2);
            }

            if (img && img.complete && img.naturalWidth > 0) {
              ctx.save();
              ctx.translate(tx, ty);
              ctx.drawImage(img, -torchW / 2, -torchH + 16, torchW, torchH);
              ctx.restore();
            } else {
              // Fallback Iron Bracket Arm for top wall
              ctx.fillStyle = '#334155';
              ctx.fillRect(tx - 2, ty - 3, 4, 8);
              ctx.fillStyle = '#78350f'; // wood torch shaft
              ctx.fillRect(tx - 1.5, ty - 8, 3, 7);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(tx - 4, ty - 9, 8, 3);
            }

            // Realistic Wall Torch Flame (Lowered by 10% for snug mount on torch head)
            drawRealisticFire(ctx, tx, ty - torchH + 20, 0.78, nowSec, tx * 0.4);
          } else if (dec.type === 'stone_brazier') {
            // --- STONE BRAZIER (Using Fakel 1 asset) ---
            const bx = dec.x;
            const by = dec.y;
            const img = gameAssets.fakel1;
            const brzH = 64;
            const aspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (38 / 64);
            const brzW = Math.round(brzH * aspect);

            const flicker = 0.90 + Math.sin(nowSec * 1.375 + bx * 0.35) * 0.10;
            const glowR = (75 / 1.5) * flicker;
            const headY = by - brzH + 16;

            // Ambient Warm Amber Radial Light on Ground & Room (Blitted from pre-rendered sprite)
            if (state.warmGlowCanvas) {
              ctx.drawImage(state.warmGlowCanvas, bx - glowR, headY + 3 - glowR, glowR * 2, glowR * 2);
            }

            // 2.5D Floor Tile Illumination Halo (Blitted from pre-rendered sprite)
            if (state.floorHaloCanvas) {
              const hW = (85 / 1.5) * flicker;
              const hH = (42 / 1.5) * flicker;
              ctx.drawImage(state.floorHaloCanvas, bx - hW, by + 14 - hH, hW * 2, hH * 2);
            }

            // Directional & Contact Cast Shadow (Enlarged for realistic depth)
            if (mode !== 'body') {
              ctx.save();
              ctx.fillStyle = 'rgba(5, 8, 15, 0.88)';
              ctx.fillRect(bx - brzW * 0.48, by + 13, brzW * 0.96, 5);

              const brzGrad = ctx.createLinearGradient(bx, by + 14, bx + 48, by + 36);
              brzGrad.addColorStop(0, 'rgba(5, 8, 15, 0.78)');
              brzGrad.addColorStop(0.55, 'rgba(5, 8, 15, 0.38)');
              brzGrad.addColorStop(0.85, 'rgba(5, 8, 15, 0.14)');
              brzGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
              ctx.fillStyle = brzGrad;
              ctx.beginPath();
              ctx.moveTo(bx - brzW * 0.45, by + 14);
              ctx.lineTo(bx + brzW * 0.45, by + 14);
              ctx.lineTo(bx + 34, by + 24);
              ctx.lineTo(bx + 50, by + 22);
              ctx.lineTo(bx + 46, by + 34);
              ctx.lineTo(bx + 30, by + 38);
              ctx.lineTo(bx - 4, by + 26);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
            }

            if (mode === 'shadow') { ctx.restore(); return; }

            if (img && img.complete && img.naturalWidth > 0) {
              ctx.drawImage(img, bx - brzW / 2, by - brzH + 16, brzW, brzH);
            } else {
              // Fallback stepped stone pedestal base
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(bx - 14, by + 8, 28, 8);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(bx - 13, by + 9, 26, 6);
              ctx.fillStyle = '#334155';
              ctx.fillRect(bx - 12, by + 8, 24, 2);

              // Central stone pillar
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(bx - 10, by - 12, 20, 20);
              ctx.fillStyle = '#334155';
              ctx.fillRect(bx - 9, by - 11, 18, 4);

              // Brazier bowl
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(bx - 12, by - 22, 24, 10);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(bx - 11, by - 21, 22, 8);
            }

            // Realistic Blazing Fire Plume (Lowered by 15% to seat directly into brazier bowl)
            drawRealisticFire(ctx, bx, headY + 5, 1.42, nowSec, bx * 0.6);
          } else if (dec.type === 'tall_torch') {
            // --- TALL GOTHIC PILLAR TORCH (Using Fakel 2 asset) ---
            const tx = dec.x;
            const ty = dec.y;
            const img = gameAssets.fakel2;
            const torchH = 72;
            const aspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (34 / 72);
            const torchW = Math.round(torchH * aspect);

            const flicker = 0.90 + Math.sin(nowSec * 1.5 + tx * 0.4) * 0.10;
            const glowR = (80 / 1.5) * flicker;
            const headY = ty - torchH + 22;

            // Ambient Radiant Light (Blitted from pre-rendered sprite)
            if (state.warmGlowCanvas) {
              ctx.drawImage(state.warmGlowCanvas, tx - glowR, headY + 6 - glowR, glowR * 2, glowR * 2);
            }

            // 2.5D Floor Tile Illumination Halo (Blitted from pre-rendered sprite)
            if (state.floorHaloCanvas) {
              const hW = (80 / 1.5) * flicker;
              const hH = (38 / 1.5) * flicker;
              ctx.drawImage(state.floorHaloCanvas, tx - hW, ty + 16 - hH, hW * 2, hH * 2);
            }

            // Directional Cast Shadow of Tall Column Pillar (Enlarged)
            if (mode !== 'body') {
              ctx.save();
              ctx.fillStyle = 'rgba(5, 8, 15, 0.88)';
              ctx.beginPath();
              ctx.moveTo(tx - torchW * 0.42, ty + 21);
              ctx.lineTo(tx + torchW * 0.42, ty + 21);
              ctx.lineTo(tx + torchW * 0.42 + 2, ty + 25);
              ctx.lineTo(tx - torchW * 0.42 + 2, ty + 25);
              ctx.closePath();
              ctx.fill();

              const tchGrad = ctx.createLinearGradient(tx, ty + 22, tx + 56, ty + 46);
              tchGrad.addColorStop(0, 'rgba(5, 8, 15, 0.82)');
              tchGrad.addColorStop(0.55, 'rgba(5, 8, 15, 0.42)');
              tchGrad.addColorStop(0.85, 'rgba(5, 8, 15, 0.16)');
              tchGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
              ctx.fillStyle = tchGrad;
              ctx.beginPath();
              ctx.moveTo(tx - 7, ty + 22);
              ctx.lineTo(tx + 9, ty + 22);
              ctx.lineTo(tx + 46, ty + 42);
              ctx.lineTo(tx + 58, ty + 38);
              ctx.lineTo(tx + 60, ty + 46);
              ctx.lineTo(tx + 46, ty + 52);
              ctx.lineTo(tx + 30, ty + 46);
              ctx.lineTo(tx - 2, ty + 28);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
            }

            if (mode === 'shadow') { ctx.restore(); return; }

            if (img && img.complete && img.naturalWidth > 0) {
              ctx.drawImage(img, tx - torchW / 2, ty - torchH + 22, torchW, torchH);
            } else {
              // Fallback octagonal stepped base
              ctx.fillStyle = '#0f172a';
              ctx.beginPath();
              ctx.moveTo(tx - 11, ty + 24);
              ctx.lineTo(tx + 11, ty + 24);
              ctx.lineTo(tx + 8, ty + 16);
              ctx.lineTo(tx - 8, ty + 16);
              ctx.closePath();
              ctx.fill();
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(tx - 7, ty + 17, 14, 6);

              // Pillar shaft
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(tx - 5, ty - 10, 10, 26);
              ctx.fillStyle = '#334155';
              ctx.fillRect(tx - 4, ty - 9, 3, 24);

              // Crown
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(tx - 9, ty - 21, 18, 9);
            }

            // Realistic Energetic Tall Fire Plume (flame reduced in size by 20%, base narrowed by ~35%, height +8.15%)
            drawRealisticFire(ctx, tx, headY + 12, 1.056, nowSec, tx * 0.5, 0.65, 1.0815);
          } else if (dec.type === 'altar') {
            // --- ANCIENT RUNIC ALTAR (Using Altar asset, +20% enlarged) ---
            const ax = dec.x;
            const ay = dec.y;

            // Mystical glowing aura on floor (+40% scale)
            const pulse = Math.sin(nowSec * 2.5 + ax * 0.1) * 0.5 + 0.5;
            const glowR = 96 + pulse * 18;
            const grad = ctx.createRadialGradient(ax, ay + 18, 14, ax, ay + 18, glowR);
            grad.addColorStop(0, 'rgba(56, 189, 248, 0.35)');
            grad.addColorStop(0.5, 'rgba(147, 51, 234, 0.16)');
            grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(ax, ay + 18, glowR, 0, Math.PI * 2);
            ctx.fill();

            // Directional Ground Shadow (+40% scale with soft falloff)
            if (mode !== 'body') {
              ctx.save();
              const altarShGrad = ctx.createRadialGradient(ax, ay + 28, 14, ax, ay + 28, 82);
              altarShGrad.addColorStop(0, 'rgba(5, 8, 15, 0.88)');
              altarShGrad.addColorStop(0.65, 'rgba(5, 8, 15, 0.42)');
              altarShGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
              ctx.fillStyle = altarShGrad;
              ctx.beginPath();
              ctx.ellipse(ax, ay + 28, 82, 30, 0, 0, Math.PI * 2);
              ctx.fill();
              ctx.restore();
            }

            if (mode === 'shadow') { ctx.restore(); return; }

            const img = gameAssets.altar;
            const altarH = 115;
            const aspect = (img && img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : (74 / 68);
            const altarW = Math.round(altarH * aspect);

            if (img && img.complete && img.naturalWidth > 0) {
              ctx.drawImage(img, ax - altarW / 2, ay - altarH + 34, altarW, altarH);
            } else {
              // Fallback altar (+40% scale)
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(ax - 58, ay - 30, 116, 62);
              ctx.fillStyle = '#334155';
              ctx.fillRect(ax - 60, ay - 40, 120, 14);
              ctx.fillStyle = '#38bdf8';
              ctx.fillRect(ax - 20, ay - 14, 40, 10);
            }

            // Rising mystical rune sparkles (+40% spread)
            for (let i = 0; i < 5; i++) {
              const sparkOffY = (nowSec * 22 + i * 12 + ax) % 60;
              const sparkX = ax + Math.sin(nowSec * 2 + i * 1.8) * 34;
              const sparkY = ay - 20 - sparkOffY;
              const sparkAlpha = Math.max(0, 1 - sparkOffY / 60);
              ctx.fillStyle = `rgba(56, 189, 248, ${sparkAlpha * 0.85})`;
              ctx.fillRect(sparkX, sparkY, 2.5, 2.5);
            }
          } else if (dec.type === 'baked_image') {
            if (mode === 'shadow') { ctx.restore(); return; }
            if (!dec.imageObj && dec.src) {
              const imgObj = new Image();
              imgObj.src = dec.src;
              dec.imageObj = imgObj;
            }
            if (dec.imageObj && dec.imageObj.complete && dec.imageObj.naturalWidth > 0) {
              ctx.drawImage(dec.imageObj, dec.x, dec.y, dec.w, dec.h);
            }
          } else if (dec.type === 'custom_element') {
            if (mode === 'shadow') { ctx.restore(); return; }
            if (!dec.imageObj && dec.src) {
              const imgObj = new Image();
              let cleanSrc = dec.src;
              try {
                cleanSrc = decodeURIComponent(dec.src);
              } catch (e) {}
              imgObj.src = cleanSrc;
              dec.imageObj = imgObj;
            }
            const isFlameOnly = dec.assetId === 'light_fire_flame' || dec.assetId === 'light_torch_flame' || (dec.assetId && dec.assetId.includes('flame'));
            const isShadow = dec.isShadowSource || (dec.assetId && dec.assetId.startsWith('shadow_'));
            if (isShadow) {
              ctx.save();
              const density = dec.shadowDensity ?? dec.opacity ?? 0.8;
              ctx.globalAlpha = density;
              ctx.fillStyle = '#000000';
              const cx = dec.x + dec.w / 2;
              const cy = dec.y + dec.h / 2;
              ctx.translate(cx, cy);
              if (dec.rotation) ctx.rotate((dec.rotation * Math.PI) / 180);
              if (dec.flipX || dec.flipY) ctx.scale(dec.flipX ? -1 : 1, dec.flipY ? -1 : 1);
              const sw = Math.abs(dec.w * (dec.scaleX || 1));
              const sh = Math.abs(dec.h * (dec.scaleY || 1));
              const shape = dec.shadowShape || 'square';
              const cornerStyle = dec.shadowCorners || 'sharp';
              ctx.beginPath();
              if (shape === 'oval') {
                ctx.ellipse(0, 0, Math.max(1, sw / 2), Math.max(1, sh / 2), 0, 0, Math.PI * 2);
              } else if (cornerStyle === 'sharp') {
                ctx.rect(-sw / 2, -sh / 2, sw, sh);
              } else {
                const r = Math.min(dec.shadowCornerRadius ?? 10, sw / 2, sh / 2);
                if (typeof (ctx as any).roundRect === 'function') {
                  (ctx as any).roundRect(-sw / 2, -sh / 2, sw, sh, r);
                } else {
                  ctx.rect(-sw / 2, -sh / 2, sw, sh);
                }
              }
              ctx.fill();
              ctx.restore();
            } else if (!isFlameOnly && dec.imageObj && dec.imageObj.complete && dec.imageObj.naturalWidth > 0) {
              ctx.save();
              if (dec.opacity !== undefined && dec.opacity < 1) {
                ctx.globalAlpha = dec.opacity;
              }
              const cx = dec.x + dec.w / 2;
              const cy = dec.y + dec.h / 2;
              ctx.translate(cx, cy);
              if (dec.rotation) {
                ctx.rotate((dec.rotation * Math.PI) / 180);
              }
              if (dec.flipX || dec.flipY) {
                ctx.scale(dec.flipX ? -1 : 1, dec.flipY ? -1 : 1);
              }
              ctx.drawImage(dec.imageObj, -dec.w / 2, -dec.h / 2, dec.w, dec.h);
              ctx.restore();
            }
            if (dec.hasFireEffect) {
              drawRealisticFire(ctx, dec.x + dec.w / 2, dec.y + dec.h / 2, dec.fireScale || 0.6, nowSec, dec.x * 0.3);
            }
            if (dec.hasLight && state.warmGlowCanvas) {
              const flicker = dec.lightFlicker ? (0.88 + Math.sin(nowSec * 1.5 + dec.x * 0.3) * 0.12) : 1.0;
              const glowR = ((dec.lightRadius || 80) / 1.5) * flicker;
              ctx.drawImage(state.warmGlowCanvas, dec.x + dec.w / 2 - glowR, dec.y + dec.h / 2 - glowR, glowR * 2, glowR * 2);
            }
          }

          ctx.restore();
      };

      // Helper to identify floor-layer room elements (plates, stone floors, floor shadows)
      const isFloorDecoration = (dec: any): boolean => {
        if (dec.type === 'custom_element') {
          if (dec.layer === 'floor' || dec.layer === 'floor_bg') return true;
          if (dec.assetId && (dec.assetId.startsWith('plate_') || dec.assetId.includes('floor'))) return true;
          if (dec.isShadowSource && !dec.renderAboveHero && dec.layer !== 'front_wall' && dec.layer !== 'foreground') return true;
        }
        return false;
      };

      const visibleDecorations = (state.dungeonDecorations || []).filter(dec => {
        // Large baked room images or custom rooms span the whole room (e.g. 1200x600+)
        // Must check entire bounding box (x .. x+w, y .. y+h) so they don't get cut in half or vanish
        const dw = dec.w || 64;
        const dh = dec.h || 64;
        return (dec.x + dw) >= state.cameraX - 120 && dec.x <= state.cameraX + viewWorldW + 120 &&
               (dec.y + dh) >= state.cameraY - 120 && dec.y <= state.cameraY + viewWorldH + 120;
      });

      // 3.2. Preset Room Floor Tiles & Floor Shadows (Rendered strictly at floor level, under props, chests & traps)
      visibleDecorations.forEach((dec: any) => {
        if (!isFloorDecoration(dec)) return;
        renderSingleDecoration(dec, 'body');
      });

      // 3.5. Floor Spike Traps (64x64 matching floor tiles - layer ABOVE floor tiles, under props and heroes)
      if (state.spikeTraps && state.spikeTraps.length > 0) {
        state.spikeTraps.forEach((trap: any) => {
          const tw = trap.w || 64;
          const th = trap.h || 64;
          if (trap.x + tw < state.cameraX - 100 || trap.x > state.cameraX + viewWorldW + 100 ||
              trap.y + th < state.cameraY - 100 || trap.y > state.cameraY + viewWorldH + 100) return;

          ctx.save();
          let drawTx = trap.x;
          let drawTy = trap.y;
          if (trap.state === 'charging') {
            drawTx += (Math.random() - 0.5) * 3;
            drawTy += (Math.random() - 0.5) * 3;
          }

          // A. Recessed Stone-and-Iron Trap Base Plate (64x64)
          ctx.save();
          // Outer stone rim
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(drawTx, drawTy, tw, th);
          ctx.strokeStyle = '#020617';
          ctx.lineWidth = 2;
          ctx.strokeRect(drawTx, drawTy, tw, th);

          // Inner beveled stone plate
          const pad = 4;
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(drawTx + pad, drawTy + pad, tw - pad * 2, th - pad * 2);
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(drawTx + pad, drawTy + pad, tw - pad * 2, th - pad * 2);

          // Corner metal brackets with rivet studs
          const rivetSize = 3;
          ctx.fillStyle = '#64748b';
          ctx.fillRect(drawTx + pad + 1, drawTy + pad + 1, rivetSize, rivetSize);
          ctx.fillRect(drawTx + tw - pad - 1 - rivetSize, drawTy + pad + 1, rivetSize, rivetSize);
          ctx.fillRect(drawTx + pad + 1, drawTy + th - pad - 1 - rivetSize, rivetSize, rivetSize);
          ctx.fillRect(drawTx + tw - pad - 1 - rivetSize, drawTy + th - pad - 1 - rivetSize, rivetSize, rivetSize);

          // 3x3 Grid of Spike Holes/Slits (each slit is recessed into stone)
          const cols = 3;
          const rows = 3;
          const cellW = (tw - pad * 2) / cols;
          const cellH = (th - pad * 2) / rows;

          for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
              const hx = drawTx + pad + c * cellW + cellW / 2;
              const hy = drawTy + pad + r * cellH + cellH / 2;
              const holeR = 5;

              // Dark recessed hole pit
              ctx.fillStyle = '#020617';
              ctx.beginPath();
              ctx.ellipse(hx, hy, holeR, holeR * 0.7, 0, 0, Math.PI * 2);
              ctx.fill();

              // Iron grommet ring around hole
              ctx.strokeStyle = trap.state === 'charging' ? 'rgba(239, 68, 68, 0.75)' : '#475569';
              ctx.lineWidth = 1;
              ctx.stroke();

              // If charging: glow from within the hole and small emerging tip
              if (trap.state === 'charging') {
                ctx.fillStyle = 'rgba(249, 115, 22, 0.55)';
                ctx.beginPath();
                ctx.ellipse(hx, hy, holeR * 0.6, holeR * 0.4, 0, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = '#94a3b8';
                ctx.beginPath();
                ctx.moveTo(hx, hy - 8);
                ctx.lineTo(hx - 4, hy + 2);
                ctx.lineTo(hx + 4, hy + 2);
                ctx.closePath();
                ctx.fill();
              } else if (trap.state === 'active') {
                // Fully erupted sharp steel 3D isometric spike
                const spikeH = 11; // Spike height in pixels (reduced)
                const baseR = 7;

                // Spike cast shadow at base
                ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
                ctx.beginPath();
                ctx.ellipse(hx + 4, hy + 2, baseR * 1.2, baseR * 0.6, 0, 0, Math.PI * 2);
                ctx.fill();

                // Spike Body: Left Light Facet (shining steel)
                ctx.fillStyle = '#e2e8f0';
                ctx.beginPath();
                ctx.moveTo(hx, hy - spikeH);
                ctx.lineTo(hx - baseR, hy + 2);
                ctx.lineTo(hx, hy + 4);
                ctx.closePath();
                ctx.fill();

                // Spike Body: Right Dark Facet (shaded steel)
                ctx.fillStyle = '#475569';
                ctx.beginPath();
                ctx.moveTo(hx, hy - spikeH);
                ctx.lineTo(hx, hy + 4);
                ctx.lineTo(hx + baseR, hy + 2);
                ctx.closePath();
                ctx.fill();

                // Bright highlight line along the center ridge
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 1.0;
                ctx.beginPath();
                ctx.moveTo(hx, hy - spikeH);
                ctx.lineTo(hx, hy + 4);
                ctx.stroke();
              }
            }
          }
          ctx.restore();
          ctx.restore();
        });
      }

      // Shadows for standing props (excluding floor decorations)
      if (showShadows) {
        visibleDecorations.forEach((dec: any) => {
          if (dec.isDestructible && (dec.alive === false || dec.opened)) return;
          if (dec.type === 'torch' || dec.type === 'banner') return;
          if (isFloorDecoration(dec)) return;

          renderSingleDecoration(dec, 'shadow');
        });
      }

      // 4. Heart Chests (Full 3D Isometric Royal Blue Chest with Heavy Gold Borders & Depth Facets)
      const isPlayerBehindChest = (c: any): boolean => {
        const cw = c.w || 54;
        const ch = c.h || 40;
        return pCenterX >= c.x - 14 && pCenterX <= c.x + cw + 14 && pFeetY >= c.y - 18 && pFeetY <= c.y + ch;
      };

      const renderSingleChest = (c: any, mode: 'all' | 'shadow' | 'body' = 'all') => {
        const cw = c.w || 54;
        const ch = c.h || 40;
        ctx.save();
        ctx.translate(c.x, c.y);

        const img = gameAssets.sunduk;
        const chestW = 49; // Reduced by 15% (was 58)
        const chestH = 50;
        const drawX = (cw - chestW) / 2;
        const drawY = ch - chestH + 4;

        // --- 1. Mystical Cyan/Azure Floor Glow (matching reference visual) ---
        if (mode !== 'body' && !c.opened) {
          ctx.save();
          const pulse = Math.sin(nowSec * 2.5 + c.x * 0.05) * 0.15 + 0.85;
          const glowGrad = ctx.createRadialGradient(
            cw * 0.5, ch * 0.72, 6,
            cw * 0.5, ch * 0.72, 42 * pulse
          );
          glowGrad.addColorStop(0, `rgba(56, 189, 248, ${0.48 * pulse})`);
          glowGrad.addColorStop(0.35, `rgba(14, 165, 233, ${0.35 * pulse})`);
          glowGrad.addColorStop(0.7, `rgba(2, 132, 199, ${0.16 * pulse})`);
          glowGrad.addColorStop(1, 'rgba(2, 132, 199, 0)');

          ctx.fillStyle = glowGrad;
          ctx.beginPath();
          ctx.ellipse(cw * 0.5, ch * 0.72, 40 * pulse, 26 * pulse, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // --- 2. Form-Fitting Non-Round Isometric Rectangular Cast Shadow ---
        if (mode !== 'body') {
          ctx.save();
          const baseX = drawX;
          const baseY = ch - 8;
          const baseW = chestW;
          const baseH = 12;

          // Outer soft ambient box shadow matching rectangular chest footprint
          ctx.fillStyle = 'rgba(5, 8, 15, 0.38)';
          ctx.beginPath();
          if (ctx.roundRect) {
            ctx.roundRect(baseX - 3, baseY - 2, baseW + 6, baseH + 5, [2, 4, 4, 2]);
          } else {
            ctx.rect(baseX - 3, baseY - 2, baseW + 6, baseH + 5);
          }
          ctx.fill();

          // Dense contact rectangular shadow directly along chest bottom edge
          ctx.fillStyle = 'rgba(5, 8, 15, 0.75)';
          ctx.beginPath();
          if (ctx.roundRect) {
            ctx.roundRect(baseX, baseY + 1, baseW, baseH - 1, [2, 3, 3, 2]);
          } else {
            ctx.rect(baseX, baseY + 1, baseW, baseH - 1);
          }
          ctx.fill();
          ctx.restore();
        }

        if (mode === 'shadow') {
          ctx.restore();
          return;
        }

        if (img && img.complete && img.naturalWidth > 0) {
          ctx.save();
          if (c.opened) {
            ctx.globalAlpha = 0.75;
          }
          ctx.drawImage(img, drawX, drawY, chestW, chestH);
          ctx.restore();
        } else {
          // Fallback box
          ctx.fillStyle = '#b45309';
          ctx.fillRect(0, ch * 0.3, cw, ch * 0.7);
        }

        ctx.restore();
      };



      // 5. Walls & Labyrinth Architecture (Clearly bordered on all 4 sides, bright cyan highlight on top edges)
      const renderSingleSpikedColumn = (w: any, needsRetractTransform?: boolean, mode: 'all' | 'shadow' | 'body' = 'all') => {
        const colCenterX = w.x + w.w / 2;
        const baseY = w.y + w.h;
        const colRadius = 11; // slender ~22px diameter shaft, 2x thinner than before!
        const rotSpeed = 12.6; // 3x faster rotation in rad/s (was 4.2)
        const rotAngle = (nowSec * rotSpeed) + (w.x * 0.04 + w.y * 0.02);

        // 1. DIRECTIONAL CAST SHADOW ON GROUND (Mode !== 'body')
        if (mode !== 'body') {
          ctx.save();
          // Stepped plinth base ground contact
          ctx.fillStyle = 'rgba(5, 8, 15, 0.85)';
          ctx.beginPath();
          ctx.moveTo(colCenterX - 18, baseY);
          ctx.lineTo(colCenterX, baseY + 3.5);
          ctx.lineTo(colCenterX + 18, baseY);
          ctx.lineTo(colCenterX + 18, baseY - 2.5);
          ctx.lineTo(colCenterX - 18, baseY - 2.5);
          ctx.closePath();
          ctx.fill();

          // Directional cast shadow of the slender column and 3 tiers of rotating spikes
          const colShGrad = ctx.createLinearGradient(colCenterX, baseY, colCenterX + 38, baseY + 26);
          colShGrad.addColorStop(0, 'rgba(5, 8, 15, 0.70)');
          colShGrad.addColorStop(0.65, 'rgba(5, 8, 15, 0.28)');
          colShGrad.addColorStop(1, 'rgba(5, 8, 15, 0)');
          ctx.fillStyle = colShGrad;
          ctx.beginPath();
          ctx.moveTo(colCenterX - 14, baseY);
          ctx.lineTo(colCenterX + 14, baseY);
          ctx.lineTo(colCenterX + 28, baseY + 12);
          ctx.lineTo(colCenterX + 38, baseY + 22);
          ctx.lineTo(colCenterX + 32, baseY + 28);
          ctx.lineTo(colCenterX + 16, baseY + 24);
          ctx.lineTo(colCenterX - 6, baseY + 10);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }

        if (mode === 'shadow') return;

        const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
        if (needsRetractTransform && isRetracting) {
          const p = Math.min(1, Math.max(0, w.retractProgress || 0));
          ctx.save();
          ctx.beginPath();
          ctx.rect(colCenterX - 36, w.y - 30, 72, w.h + 34);
          ctx.clip();
          ctx.translate(0, p * (w.h + 20));
          ctx.globalAlpha = 1.0 - p * 0.45;
        }

        // 2. STATIONARY STEPPED PEDESTAL BASE (Matching IMG_20260908_130837.png)
        const baseH = 15;
        const plinthTopY = baseY - baseH;

        // Bottom step (wide chamfered stone base)
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.moveTo(colCenterX - 19, baseY);
        ctx.lineTo(colCenterX + 19, baseY);
        ctx.lineTo(colCenterX + 17, baseY - 7);
        ctx.lineTo(colCenterX - 17, baseY - 7);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#1e293b';
        ctx.fillRect(colCenterX - 16, baseY - 6.5, 32, 5.5);

        // Chamfer highlights on bottom step
        ctx.fillStyle = '#334155';
        ctx.fillRect(colCenterX - 16, baseY - 6.5, 12, 1.2);
        ctx.fillStyle = '#475569';
        ctx.fillRect(colCenterX - 17, baseY - 7, 2, 6);
        ctx.fillRect(colCenterX + 15, baseY - 7, 2, 6);

        // Top step block
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(colCenterX - 15, plinthTopY, 30, 8);
        ctx.fillStyle = '#334155';
        ctx.fillRect(colCenterX - 14, plinthTopY, 13, 8); // left lit side
        ctx.fillStyle = '#475569';
        ctx.fillRect(colCenterX - 15, plinthTopY, 30, 1.5); // top bevel rim
        ctx.fillStyle = '#64748b';
        ctx.fillRect(colCenterX - 14, plinthTopY, 12, 1.2);

        // Corner iron plates / rivets
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(colCenterX - 14, plinthTopY + 2, 2.5, 4);
        ctx.fillRect(colCenterX + 11.5, plinthTopY + 2, 2.5, 4);
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(colCenterX - 13.5, plinthTopY + 3, 1.5, 1.5);
        ctx.fillRect(colCenterX + 12, plinthTopY + 3, 1.5, 1.5);

        // Dark recessed socket collar where rotating shaft emerges
        ctx.fillStyle = '#090d16';
        ctx.beginPath();
        ctx.ellipse(colCenterX, plinthTopY + 0.5, colRadius + 1.5, (colRadius + 1.5) * 0.35, 0, 0, Math.PI * 2);
        ctx.fill();

        // 3. 3D ISOMETRIC ROTATING MONOLITHIC HEXAGONAL STONE SHAFT & SPIKES
        const shaftTopY = w.y + 4;
        const shaftH = plinthTopY - shaftTopY;
        const numFaces = 6;
        const isoRatio = 0.35; // 2.5D Isometric Y-foreshortening

        // Calculate 6 vertices of rotating hexagonal prism
        const verts: Array<{ x: number; yOffset: number; angle: number }> = [];
        for (let i = 0; i < numFaces; i++) {
          const a = rotAngle + i * (Math.PI * 2 / numFaces);
          verts.push({
            x: colCenterX + colRadius * Math.sin(a),
            yOffset: colRadius * Math.cos(a) * isoRatio,
            angle: a
          });
        }

        // 3 Tiers of Spikes
        const spikeTiers = [
          shaftTopY + shaftH * 0.18,
          shaftTopY + shaftH * 0.50,
          shaftTopY + shaftH * 0.82
        ];
        const numSpikesPerTier = 4; // 4 orthogonal spikes (90 deg apart)
        const spikeLen = 16;
        const spikeBaseHalf = 3.2;

        // Helper to render a single 3D rotating spike
        const renderSpike = (tierY: number, spikeAngle: number, depth: number) => {
          const dirX = Math.sin(spikeAngle);
          const dirY = Math.cos(spikeAngle);

          const baseCX = colCenterX + colRadius * dirX;
          const baseCY = tierY + colRadius * dirY * isoRatio;
          const tipX = colCenterX + (colRadius + spikeLen) * dirX;
          const tipY = tierY + (colRadius + spikeLen) * dirY * isoRatio;

          // Normal perpendicular to spike direction in horizontal plane (for base width)
          const perpX = -dirY;
          const perpY = dirX * isoRatio;

          // Socket collar
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.ellipse(baseCX, baseCY, 3.5, 3.5 * isoRatio, 0, 0, Math.PI * 2);
          ctx.fill();

          // Determine lighting of spike based on direction relative to light (from top-left)
          // Left-pointing spikes (dirX < 0) get bright highlights, right-pointing get medium/shadow
          const isLeft = dirX < 0;

          // Lower facet (dark shadow steel)
          const shadowGrad = ctx.createLinearGradient(baseCX, baseCY, tipX, tipY);
          shadowGrad.addColorStop(0, '#1e293b');
          shadowGrad.addColorStop(0.7, '#334155');
          shadowGrad.addColorStop(1, '#64748b');
          ctx.fillStyle = shadowGrad;
          ctx.beginPath();
          ctx.moveTo(baseCX - perpX * spikeBaseHalf, baseCY - perpY * spikeBaseHalf);
          ctx.lineTo(tipX, tipY);
          ctx.lineTo(baseCX + perpX * spikeBaseHalf, baseCY + perpY * spikeBaseHalf + 1);
          ctx.closePath();
          ctx.fill();

          // Upper facet (sunlit chrome facet)
          const litGrad = ctx.createLinearGradient(baseCX, baseCY - 4, tipX, tipY);
          if (isLeft) {
            litGrad.addColorStop(0, '#64748b');
            litGrad.addColorStop(0.5, '#cbd5e1');
            litGrad.addColorStop(1, '#ffffff');
          } else {
            litGrad.addColorStop(0, '#334155');
            litGrad.addColorStop(0.6, '#94a3b8');
            litGrad.addColorStop(1, '#f1f5f9');
          }
          ctx.fillStyle = litGrad;
          ctx.beginPath();
          ctx.moveTo(baseCX - perpX * spikeBaseHalf, baseCY - perpY * spikeBaseHalf - 3);
          ctx.lineTo(tipX, tipY);
          ctx.lineTo(baseCX + perpX * spikeBaseHalf, baseCY + perpY * spikeBaseHalf);
          ctx.closePath();
          ctx.fill();

          // Sharp central spine ridge line
          ctx.strokeStyle = isLeft ? '#ffffff' : '#e2e8f0';
          ctx.lineWidth = 0.9;
          ctx.beginPath();
          ctx.moveTo(baseCX, baseCY - 1.5);
          ctx.lineTo(tipX, tipY);
          ctx.stroke();

          // Tip specular glint
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(tipX - 1, tipY - 1, 2, 2);
        };

        // Collect all spikes in this column
        const allSpikes: Array<{ tierY: number; angle: number; depth: number }> = [];
        spikeTiers.forEach(tY => {
          for (let s = 0; s < numSpikesPerTier; s++) {
            const sAngle = rotAngle + s * (Math.PI * 2 / numSpikesPerTier);
            const depth = Math.cos(sAngle); // >0 front, <0 back
            allSpikes.push({ tierY: tY, angle: sAngle, depth });
          }
        });

        // A. RENDER BACK SPIKES (depth <= 0) BEHIND THE SHAFT
        allSpikes.filter(s => s.depth <= 0).forEach(s => {
          renderSpike(s.tierY, s.angle, s.depth);
        });

        // B. RENDER ROTATING HEXAGONAL STONE SHAFT FACES
        // 6 vertical faces
        for (let i = 0; i < numFaces; i++) {
          const nextIdx = (i + 1) % numFaces;
          const v1 = verts[i];
          const v2 = verts[nextIdx];

          const midAngle = rotAngle + (i + 0.5) * (Math.PI * 2 / numFaces);
          const faceNormalY = Math.cos(midAngle);
          const faceNormalX = Math.sin(midAngle);

          // Only render front-facing faces (normal facing towards viewer/camera)
          if (faceNormalY > -0.15) {
            // Light calculation: top-left light (angle ~ -2.2 rad or lx = -0.7, ly = 0.3)
            const lightDot = -0.75 * faceNormalX + 0.35 * faceNormalY;
            const brightness = Math.max(0, Math.min(1, 0.45 + lightDot * 0.45));

            // Stone color interpolation from dark obsidian/slate to sunlit slate-grey
            let faceColor: string;
            if (brightness > 0.65) {
              faceColor = '#38475c'; // sunlit left facet
            } else if (brightness > 0.45) {
              faceColor = '#243245'; // mid-tone facet
            } else if (brightness > 0.25) {
              faceColor = '#172233'; // shaded right facet
            } else {
              faceColor = '#0f172a'; // deep ambient shadow
            }

            ctx.fillStyle = faceColor;
            ctx.beginPath();
            ctx.moveTo(v1.x, shaftTopY + v1.yOffset);
            ctx.lineTo(v2.x, shaftTopY + v2.yOffset);
            ctx.lineTo(v2.x, plinthTopY + v2.yOffset);
            ctx.lineTo(v1.x, plinthTopY + v1.yOffset);
            ctx.closePath();
            ctx.fill();

            // Vertical edge highlight on sunlit side
            if (faceNormalX < 0) {
              ctx.strokeStyle = '#64748b';
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(v1.x, shaftTopY + v1.yOffset);
              ctx.lineTo(v1.x, plinthTopY + v1.yOffset);
              ctx.stroke();
            } else {
              ctx.strokeStyle = '#090d16';
              ctx.lineWidth = 0.8;
              ctx.beginPath();
              ctx.moveTo(v1.x, shaftTopY + v1.yOffset);
              ctx.lineTo(v1.x, plinthTopY + v1.yOffset);
              ctx.stroke();
            }

            // Stone seam crack texture rotating with the face
            if (i % 2 === 0) {
              const crackX = (v1.x + v2.x) * 0.5;
              ctx.strokeStyle = 'rgba(10, 16, 26, 0.65)';
              ctx.lineWidth = 0.9;
              ctx.beginPath();
              ctx.moveTo(crackX - 0.5, shaftTopY + 12);
              ctx.lineTo(crackX + 1.2, shaftTopY + shaftH * 0.4);
              ctx.lineTo(crackX - 0.8, shaftTopY + shaftH * 0.7);
              ctx.stroke();
            }
          }
        }

        // C. RENDER 3 ROTATING IRON COLLAR BANDS ALONG THE SHAFT
        spikeTiers.forEach(tY => {
          ctx.fillStyle = '#0b111b';
          ctx.beginPath();
          ctx.ellipse(colCenterX, tY, colRadius + 1.8, (colRadius + 1.8) * isoRatio, 0, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#334155';
          ctx.beginPath();
          ctx.ellipse(colCenterX, tY - 1, colRadius + 1.5, (colRadius + 1.5) * isoRatio, 0, 0, Math.PI * 2);
          ctx.fill();

          // Chamfer highlight on left
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(colCenterX - 3, tY - 1, (colRadius + 1.2) * 0.7, Math.PI * 0.6, Math.PI * 1.4);
          ctx.stroke();
        });

        // D. RENDER FRONT SPIKES (depth > 0) IN FRONT OF THE SHAFT
        // Sort by depth so furthest comes first
        allSpikes.filter(s => s.depth > 0).sort((a, b) => a.depth - b.depth).forEach(s => {
          renderSpike(s.tierY, s.angle, s.depth);
        });

        // E. 3D ROTATING HEXAGONAL STONE CAPITAL / TOP CAP (Matching IMG_20260908_130837.png)
        const capRadius = colRadius + 2.5; // ~13.5px
        const capH = 8;
        const capTopY = shaftTopY - capH;

        // Calculate 6 cap vertices
        const capVerts: Array<{ x: number; yOffset: number }> = [];
        for (let i = 0; i < numFaces; i++) {
          const a = rotAngle + i * (Math.PI * 2 / numFaces);
          capVerts.push({
            x: colCenterX + capRadius * Math.sin(a),
            yOffset: capRadius * Math.cos(a) * isoRatio
          });
        }

        // Under-cap shadow cast onto shaft
        ctx.fillStyle = 'rgba(5, 8, 15, 0.85)';
        ctx.beginPath();
        ctx.ellipse(colCenterX, shaftTopY + 1.5, colRadius + 1.5, (colRadius + 1.5) * isoRatio, 0, 0, Math.PI * 2);
        ctx.fill();

        // 6 Side facets of the capital
        for (let i = 0; i < numFaces; i++) {
          const nextIdx = (i + 1) % numFaces;
          const v1 = capVerts[i];
          const v2 = capVerts[nextIdx];

          const midAngle = rotAngle + (i + 0.5) * (Math.PI * 2 / numFaces);
          const faceNormalY = Math.cos(midAngle);
          const faceNormalX = Math.sin(midAngle);

          if (faceNormalY > -0.15) {
            const lightDot = -0.75 * faceNormalX + 0.35 * faceNormalY;
            const brightness = Math.max(0, Math.min(1, 0.45 + lightDot * 0.45));

            ctx.fillStyle = brightness > 0.6 ? '#475569' : brightness > 0.4 ? '#334155' : '#1e293b';
            ctx.beginPath();
            ctx.moveTo(v1.x, capTopY + v1.yOffset);
            ctx.lineTo(v2.x, capTopY + v2.yOffset);
            ctx.lineTo(v2.x, shaftTopY + v2.yOffset);
            ctx.lineTo(v1.x, shaftTopY + v1.yOffset);
            ctx.closePath();
            ctx.fill();

            ctx.strokeStyle = faceNormalX < 0 ? '#94a3b8' : '#0f172a';
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(v1.x, capTopY + v1.yOffset);
            ctx.lineTo(v1.x, shaftTopY + v1.yOffset);
            ctx.stroke();
          }
        }

        // Top horizontal/isometric face of the capital
        ctx.fillStyle = '#2d3b4e';
        ctx.beginPath();
        ctx.moveTo(capVerts[0].x, capTopY + capVerts[0].yOffset);
        for (let i = 1; i < numFaces; i++) {
          ctx.lineTo(capVerts[i].x, capTopY + capVerts[i].yOffset);
        }
        ctx.closePath();
        ctx.fill();

        // Top face bevel border highlight
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1.1;
        ctx.stroke();

        // Characteristic vertical split / notch seam across the crown (matching IMG_20260908_130837.png)
        const seamAngle = rotAngle;
        const s1X = colCenterX + capRadius * Math.sin(seamAngle);
        const s1Y = capTopY + capRadius * Math.cos(seamAngle) * isoRatio;
        const s2X = colCenterX - capRadius * Math.sin(seamAngle);
        const s2Y = capTopY - capRadius * Math.cos(seamAngle) * isoRatio;

        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(s1X, s1Y);
        ctx.lineTo(s2X, s2Y);
        ctx.stroke();

        // Downward vertical notch on front edge
        ctx.fillStyle = '#090d16';
        ctx.fillRect(colCenterX - 0.75, capTopY, 1.5, capH);

        if (needsRetractTransform && isRetracting) {
          ctx.restore();
        }
      };

      const renderSingleCornerPillar = (w: any, needsRetractTransform?: boolean, mode: 'all' | 'shadow' | 'body' = 'all') => {
        const px = w.x;
        const py = w.y;
        const pw = w.w;
        const ph = w.h;
        const colCenterX = px + pw / 2;
        const baseY = py + ph;
        const isBack = Boolean(w.isBackPillar);

        // 1. DIRECTIONAL AMBIENT OCCLUSION DROP SHADOW ON FLOOR
        if (mode !== 'body') {
          ctx.save();
          const shadowR = Math.max(pw * 0.75, 24);
          const shGrad = ctx.createRadialGradient(colCenterX, baseY + 6, 2, colCenterX, baseY + 6, shadowR);
          shGrad.addColorStop(0, 'rgba(2, 6, 15, 0.85)');
          shGrad.addColorStop(0.45, 'rgba(2, 6, 15, 0.42)');
          shGrad.addColorStop(1, 'rgba(2, 6, 15, 0)');
          ctx.fillStyle = shGrad;
          ctx.beginPath();
          ctx.ellipse(colCenterX, baseY + 6, shadowR, 14, 0, 0, Math.PI * 2);
          ctx.fill();

          // Soft diagonal cast shadow towards floor
          ctx.fillStyle = 'rgba(2, 6, 15, 0.35)';
          ctx.beginPath();
          ctx.moveTo(px - 2, baseY);
          ctx.lineTo(px + pw + 2, baseY);
          ctx.lineTo(px + pw + 18, baseY + 18);
          ctx.lineTo(px + 8, baseY + 18);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }

        if (mode === 'shadow') return;

        // 2. PILLAR BODY
        const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
        if (needsRetractTransform && isRetracting) {
          const p = Math.min(1, Math.max(0, w.retractProgress || 0));
          ctx.save();
          ctx.beginPath();
          ctx.rect(px - 6, py - 6, pw + 12, ph + 28);
          ctx.clip();
          ctx.translate(0, p * (ph + 24));
          ctx.globalAlpha = 1.0 - p * 0.45;
        }

        if (isBack) {
          // -----------------------------------------------------------------
          // BACK CORNER PILLAR (Matching Reference: Задний угол стены.png)
          // Renders on Layer 1 (under vertical walls).
          // -----------------------------------------------------------------
          const capTopY = py - 4;
          const capH = ph + 6;
          const capPad = 2;
          const capX = px - capPad;
          const capW = pw + capPad * 2;

          // Back column square cap stone
          const backGrad = ctx.createLinearGradient(capX, capTopY, capX + capW, capTopY + capH);
          backGrad.addColorStop(0, '#2b3f56');
          backGrad.addColorStop(0.4, '#1e2c3e');
          backGrad.addColorStop(1, '#111b27');
          ctx.fillStyle = backGrad;
          ctx.fillRect(capX, capTopY, capW, capH);

          // Outer stroke
          ctx.strokeStyle = '#080d16';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(capX, capTopY, capW, capH);

          // Specular rim on top & left edges
          ctx.fillStyle = '#64748b';
          ctx.fillRect(capX + 1, capTopY + 1, capW - 2, 1.6);
          ctx.fillRect(capX + 1, capTopY + 1, 1.6, capH - 2);

          // Cyan specular line
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(capX + 2, capTopY + 2, capW - 4, 1.2);

          // Dark right & bottom shadow edges
          ctx.fillStyle = '#060a12';
          ctx.fillRect(capX + capW - 2, capTopY + 1, 2, capH - 1);
          ctx.fillRect(capX + 1, capTopY + capH - 2, capW - 1, 2);

          // Micro-notch corner details
          ctx.fillStyle = '#060a12';
          ctx.fillRect(capX, capTopY, 2, 2);
          ctx.fillRect(capX + capW - 2, capTopY, 2, 2);
        } else {
          // -----------------------------------------------------------------
          // FRONT CORNER PILLAR (Matching Reference: Лицевой угол стены.png)
          // Renders on Layer 4 (OVER vertical walls AND OVER horizontal walls!).
          // -----------------------------------------------------------------
          const shaftTopY = py + 14;
          const shaftH = ph + 8;
          const shaftBaseY = shaftTopY + shaftH;

          // A. Front Vertical Shaft (Stacked Ashlar stone courses)
          const shaftGrad = ctx.createLinearGradient(px, shaftTopY, px + pw, shaftBaseY);
          shaftGrad.addColorStop(0, '#273a4f');
          shaftGrad.addColorStop(0.35, '#1d2a3c');
          shaftGrad.addColorStop(0.75, '#131e2b');
          shaftGrad.addColorStop(1.0, '#0a121c');
          ctx.fillStyle = shaftGrad;
          ctx.fillRect(px, shaftTopY, pw, shaftH);

          // 2 Heavy Ashlar stone courses on pillar shaft
          const pCourses = 2;
          const pCourseH = shaftH / pCourses;
          for (let r = 0; r < pCourses; r++) {
            const cy = shaftTopY + r * pCourseH;
            // Horizontal mortar groove
            ctx.fillStyle = '#070c14';
            ctx.fillRect(px, cy, pw, 1.4);
            // Brick top bevel highlight
            ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
            ctx.fillRect(px, cy + 1.4, pw, 0.9);

            // Vertical joint dividing into 2 front stones (Matching Лицевой угол стены.png)
            const splitX = px + pw * 0.52;
            ctx.fillStyle = '#070c14';
            ctx.fillRect(splitX, cy + 1.4, 1.4, pCourseH - 1.4);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
            ctx.fillRect(splitX + 1.4, cy + 1.4, 0.8, pCourseH - 1.4);
          }

          // Left vertical light-catching bevel
          ctx.fillStyle = '#64748b';
          ctx.fillRect(px, shaftTopY, 1.6, shaftH);
          ctx.fillStyle = 'rgba(56, 189, 248, 0.55)';
          ctx.fillRect(px + 1, shaftTopY, 0.8, shaftH);

          // Right vertical depth facet (Isometric 3D side visible in Лицевой угол стены.png)
          const facetW = 5;
          ctx.fillStyle = '#090e17';
          ctx.fillRect(px + pw - 1, shaftTopY, facetW, shaftH + 4);
          ctx.fillStyle = '#050810';
          ctx.fillRect(px + pw + facetW - 1.5, shaftTopY, 1.5, shaftH + 4);

          // B. Stone Plinth Base (Цоколь)
          const plinthH = 8;
          const plinthY = shaftBaseY - plinthH;
          const plinthPad = 2;
          const plinthX = px - plinthPad;
          const plinthW = pw + plinthPad * 2;

          const plinthGrad = ctx.createLinearGradient(plinthX, plinthY, plinthX + plinthW, plinthY + plinthH);
          plinthGrad.addColorStop(0, '#223246');
          plinthGrad.addColorStop(0.5, '#172332');
          plinthGrad.addColorStop(1, '#0e1722');
          ctx.fillStyle = plinthGrad;
          ctx.fillRect(plinthX, plinthY, plinthW + 4, plinthH);

          ctx.strokeStyle = '#080d16';
          ctx.lineWidth = 1.2;
          ctx.strokeRect(plinthX, plinthY, plinthW + 4, plinthH);

          // Plinth top highlight & bottom shadow
          ctx.fillStyle = '#64748b';
          ctx.fillRect(plinthX + 1, plinthY + 0.8, plinthW + 2, 1.2);
          ctx.fillStyle = '#05080f';
          ctx.fillRect(plinthX, plinthY + plinthH - 1.2, plinthW + 4, 1.2);

          // C. Elevated Isometric Top Capital / Cap Stone (Matching Лицевой угол стены.png)
          // Rises above horizontal wall cap (py - 6), creating prominent 3D corner crown
          const capTopY = py - 6;
          const capH = 26;
          const capPad = 3;
          const capX = px - capPad;
          const capW = pw + capPad * 2;

          // Shadow cast by capital overhang onto shaft
          ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
          ctx.fillRect(px - 1, capTopY + capH, pw + 2, 4);

          // Lower molding tier
          ctx.fillStyle = '#162232';
          ctx.fillRect(capX + 1, capTopY + capH - 6, capW - 2, 6);
          ctx.strokeStyle = '#080d16';
          ctx.lineWidth = 1;
          ctx.strokeRect(capX + 1, capTopY + capH - 6, capW - 2, 6);

          // Upper capital block (Isometric beveled top + front + right facet)
          const capGrad = ctx.createLinearGradient(capX, capTopY, capX + capW, capTopY + capH);
          capGrad.addColorStop(0, '#364d68');
          capGrad.addColorStop(0.45, '#26374c');
          capGrad.addColorStop(1, '#182535');
          ctx.fillStyle = capGrad;
          ctx.fillRect(capX, capTopY, capW, capH - 4);

          // Right facet on capital (3D depth)
          ctx.fillStyle = '#0a101b';
          ctx.fillRect(capX + capW, capTopY, facetW, capH - 4);
          ctx.strokeStyle = '#060a12';
          ctx.lineWidth = 1;
          ctx.strokeRect(capX + capW, capTopY, facetW, capH - 4);

          // Outer stroke
          ctx.strokeStyle = '#080d16';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(capX, capTopY, capW, capH - 4);

          // Specular glint rims (Matching Лицевой угол стены.png)
          ctx.fillStyle = '#94a3b8';
          ctx.fillRect(capX + 1, capTopY + 1, capW - 2, 1.6);
          ctx.fillRect(capX + 1, capTopY + 1, 1.6, capH - 6);

          ctx.fillStyle = '#38bdf8'; // Glowing cyan highlight
          ctx.fillRect(capX + 2, capTopY + 2.2, capW - 4, 1.2);

          // Inner beveled frame
          ctx.strokeStyle = 'rgba(8, 13, 22, 0.7)';
          ctx.lineWidth = 1;
          ctx.strokeRect(capX + 3.5, capTopY + 3.5, capW - 7, capH - 11);
        }

        if (needsRetractTransform && isRetracting) {
          ctx.restore();
        }
      };

      // -----------------------------------------------------------------
      // HORIZONTAL WALL RENDERING (Matching Reference: Верхний блок горизонтальной стены.png)
      // -----------------------------------------------------------------
      const renderHorizontalWall = (w: any, isRetracting?: boolean) => {
        const wx = w.x;
        const wy = w.y;
        const ww = w.w;
        const wh = w.h;
        if (ww <= 0 || wh <= 0) return;

        // 1. Drop shadow spilling onto floor below front face
        const shadowY = wy + wh;
        const shadowH = 24;
        const shadowGrad = ctx.createLinearGradient(wx, shadowY, wx, shadowY + shadowH);
        shadowGrad.addColorStop(0, 'rgba(2, 6, 15, 0.82)');
        shadowGrad.addColorStop(0.4, 'rgba(2, 6, 15, 0.40)');
        shadowGrad.addColorStop(1, 'rgba(2, 6, 15, 0)');
        ctx.fillStyle = shadowGrad;
        ctx.fillRect(wx - 4, shadowY, ww + 8, shadowH);

        // 2. Front Vertical Ashlar Masonry Face (Visible 2.5D Depth Facet)
        const capH = Math.min(wh, 22);
        const frontY = wy + capH * 0.45;
        const frontFaceH = wh + 18;

        // Front Face Base Gradient
        const frontGrad = ctx.createLinearGradient(wx, frontY, wx, frontY + frontFaceH);
        frontGrad.addColorStop(0, '#27384e');
        frontGrad.addColorStop(0.35, '#1e2c3e');
        frontGrad.addColorStop(0.75, '#15202e');
        frontGrad.addColorStop(1.0, '#0c1420');
        ctx.fillStyle = frontGrad;
        ctx.fillRect(wx, frontY, ww, frontFaceH);

        // Ashlar Brick Courses (large 56px bricks in running bond)
        const brickW = 56;
        const courseCount = Math.max(2, Math.floor(frontFaceH / 14));
        const courseH = frontFaceH / courseCount;

        for (let r = 0; r < courseCount; r++) {
          const cy = frontY + r * courseH;
          const rowOffset = (r % 2) * (brickW / 2);

          // Horizontal mortar groove
          ctx.fillStyle = '#080d15';
          ctx.fillRect(wx, cy, ww, 1.4);

          // Top highlight line for 3D brick bevel
          ctx.fillStyle = r === 0 ? 'rgba(255, 255, 255, 0.16)' : 'rgba(255, 255, 255, 0.09)';
          ctx.fillRect(wx, cy + 1.4, ww, 1.0);

          // Vertical mortar joints
          for (let bx = wx + rowOffset; bx < wx + ww; bx += brickW) {
            if (bx > wx && bx < wx + ww - 1) {
              ctx.fillStyle = '#070c14';
              ctx.fillRect(bx, cy, 1.4, courseH);

              // Vertical brick highlight
              ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
              ctx.fillRect(bx + 1.4, cy + 1, 0.9, courseH - 1);
            }
          }
        }

        // Shadow overhang right under Cap Rim
        ctx.fillStyle = 'rgba(0, 0, 0, 0.58)';
        ctx.fillRect(wx, frontY, ww, 4.0);

        // 3. TOP WALL CAP BLOCKS (Matching exact shape in Верхний блок горизонтальной стены.png)
        const capBlockW = 56;
        for (let bx = wx; bx < wx + ww; bx += capBlockW) {
          const curBlockW = Math.min(capBlockW, wx + ww - bx);
          if (curBlockW <= 0) continue;

          // A. Top Slanted Isometric Plane (wy to wy + 9)
          const topPlaneH = 9;
          const topGrad = ctx.createLinearGradient(bx, wy, bx, wy + topPlaneH);
          topGrad.addColorStop(0, '#2a3d54');
          topGrad.addColorStop(0.5, '#1e2c3e');
          topGrad.addColorStop(1, '#162332');
          ctx.fillStyle = topGrad;
          ctx.fillRect(bx, wy, curBlockW, topPlaneH);

          // Top edge bevel highlight
          ctx.fillStyle = '#4b5e75';
          ctx.fillRect(bx, wy, curBlockW, 1.2);

          // B. SPECULAR CYAN BEVEL LINE (Matching Верхний блок горизонтальной стены.png)
          // Solid crisp cyan-blue horizontal highlight across the cap edge
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(bx + 1.5, wy + topPlaneH - 1.2, curBlockW - 3, 1.8);

          // Subtle stone chipping notches at block corners
          ctx.fillStyle = '#0b121e';
          ctx.fillRect(bx, wy + topPlaneH - 1.2, 1.5, 1.8);
          ctx.fillRect(bx + curBlockW - 1.5, wy + topPlaneH - 1.2, 1.5, 1.8);

          // C. Front Vertical Lip of Cap (wy + 9 to wy + capH)
          const lipH = capH - topPlaneH;
          const lipGrad = ctx.createLinearGradient(bx, wy + topPlaneH, bx, wy + capH);
          lipGrad.addColorStop(0, '#152130');
          lipGrad.addColorStop(0.6, '#0f1824');
          lipGrad.addColorStop(1, '#090e17');
          ctx.fillStyle = lipGrad;
          ctx.fillRect(bx, wy + topPlaneH, curBlockW, lipH);

          // Left edge subtle highlight on cap lip
          ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
          ctx.fillRect(bx, wy + topPlaneH, 1.2, lipH);

          // Dark bottom shadow border on cap
          ctx.fillStyle = '#050810';
          ctx.fillRect(bx, wy + capH - 1.5, curBlockW, 1.5);

          // Vertical mortar groove between adjacent blocks
          if (bx > wx) {
            ctx.fillStyle = '#060a12';
            ctx.fillRect(bx - 1, wy, 2, capH);
          }
        }

        // Outer framing stroke
        ctx.strokeStyle = '#080d16';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(wx, wy, ww, capH);
      };

      // -----------------------------------------------------------------
      // VERTICAL WALL RENDERING (Matching Reference: Верхний блок вертикальной стены.png)
      // -----------------------------------------------------------------
      const renderVerticalWall = (w: any, isRetracting?: boolean) => {
        const wx = w.x;
        const wy = w.y;
        const ww = w.w;
        const wh = w.h;
        if (ww <= 0 || wh <= 0) return;

        // 1. Drop shadow on right floor tiles
        const shadowW = 18;
        const shadowGrad = ctx.createLinearGradient(wx + ww, wy, wx + ww + shadowW, wy);
        shadowGrad.addColorStop(0, 'rgba(2, 6, 15, 0.75)');
        shadowGrad.addColorStop(0.4, 'rgba(2, 6, 15, 0.35)');
        shadowGrad.addColorStop(1, 'rgba(2, 6, 15, 0)');
        ctx.fillStyle = shadowGrad;
        ctx.fillRect(wx + ww, wy - 4, shadowW, wh + 8);

        // 2. Vertical Stack of Stone Blocks (Matching Верхний блок вертикальной стены.png)
        const blockH = 48;
        for (let by = wy; by < wy + wh; by += blockH) {
          const curBlockH = Math.min(blockH, wy + wh - by);
          if (curBlockH <= 0) continue;

          // Body fill: Rich slate blue gradient
          const blockGrad = ctx.createLinearGradient(wx, by, wx + ww, by + curBlockH);
          blockGrad.addColorStop(0, '#27394e');
          blockGrad.addColorStop(0.4, '#1b2737');
          blockGrad.addColorStop(0.85, '#121c28');
          blockGrad.addColorStop(1.0, '#090e17');
          ctx.fillStyle = blockGrad;
          ctx.fillRect(wx, by, ww, curBlockH);

          // Outer stroke
          ctx.strokeStyle = '#060b13';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(wx, by, ww, curBlockH);

          // TOP EDGE: Glowing cyan specular highlight (Matching Верхний блок вертикальной стены.png)
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(wx + 2, by + 1.2, ww - 4, 1.8);

          // LEFT EDGE: Bright cyan-slate highlight
          ctx.fillStyle = '#60a5fa';
          ctx.fillRect(wx + 1.2, by + 2, 1.6, curBlockH - 4);
          ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.fillRect(wx + 2.8, by + 2, 0.8, curBlockH - 4);

          // RIGHT EDGE: Deep dark shadow facet
          ctx.fillStyle = '#080e18';
          ctx.fillRect(wx + ww - 2.2, by + 1, 2.2, curBlockH - 2);

          // BOTTOM EDGE: Deep dark shadow groove
          ctx.fillStyle = '#050810';
          ctx.fillRect(wx + 1, by + curBlockH - 2.2, ww - 2, 2.2);

          // Chipped micro-stone notches on the 4 corners
          ctx.fillStyle = '#050810';
          ctx.fillRect(wx, by, 1.8, 1.8);
          ctx.fillRect(wx + ww - 1.8, by, 1.8, 1.8);
          ctx.fillRect(wx, by + curBlockH - 1.8, 1.8, 1.8);
          ctx.fillRect(wx + ww - 1.8, by + curBlockH - 1.8, 1.8, 1.8);

          // Horizontal mortar gap between consecutive blocks
          if (by > wy) {
            ctx.fillStyle = '#050810';
            ctx.fillRect(wx - 1, by - 1.5, ww + 2, 3);
          }
        }
      };

      // -----------------------------------------------------------------
      // BOSS GATE RENDERING (Врата Исполина)
      // -----------------------------------------------------------------
      const renderBossGate = (w: any, isRetracting?: boolean) => {
        const gx = w.x;
        const gy = w.y;
        const gw = w.w;
        const gh = w.h;
        const isHoriz = gw >= gh;
        const cx = gx + gw / 2;
        const cy = gy + gh / 2;
        const nowMs = performance.now();

        if (w.isClosed) {
          // 1. Deep Floor Recess & Ambient Occlusion Shadow
          ctx.fillStyle = '#060b13';
          ctx.fillRect(gx, gy, gw, gh);

          if (isHoriz) {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.48)';
            ctx.fillRect(gx - 2, gy + gh, gw + 4, 8);
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(gx, gy, gw, 3);
            ctx.fillRect(gx, gy + gh - 3, gw, 3);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
            ctx.fillRect(gx, gy, gw, 1);
          } else {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.48)';
            ctx.fillRect(gx + gw, gy - 2, 8, gh + 4);
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(gx, gy, 3, gh);
            ctx.fillRect(gx + gw - 3, gy, 3, gh);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
            ctx.fillRect(gx, gy, 1, gh);
          }

          // 2. Massive Flanking Armored Gateposts
          const jambSize = 18;
          if (isHoriz) {
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(gx, gy, jambSize, gh);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(gx + jambSize - 4, gy, 4, gh);
            ctx.strokeStyle = '#020617';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(gx, gy, jambSize, gh);

            ctx.fillStyle = '#1e293b';
            ctx.fillRect(gx + gw - jambSize, gy, jambSize, gh);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(gx + gw - jambSize, gy, 4, gh);
            ctx.strokeStyle = '#020617';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(gx + gw - jambSize, gy, jambSize, gh);

            ctx.fillStyle = '#94a3b8';
            ctx.fillRect(gx + 4, gy + 4, 3, 3);
            ctx.fillRect(gx + 4, gy + gh - 7, 3, 3);
            ctx.fillRect(gx + gw - 7, gy + 4, 3, 3);
            ctx.fillRect(gx + gw - 7, gy + gh - 7, 3, 3);
          } else {
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(gx, gy, gw, jambSize);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(gx, gy + jambSize - 4, gw, 4);
            ctx.strokeStyle = '#020617';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(gx, gy, gw, jambSize);

            ctx.fillStyle = '#1e293b';
            ctx.fillRect(gx, gy + gh - jambSize, gw, jambSize);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(gx, gy + gh - jambSize, gw, 4);
            ctx.strokeStyle = '#020617';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(gx, gy + gh - jambSize, gw, jambSize);

            ctx.fillStyle = '#94a3b8';
            ctx.fillRect(gx + 4, gy + 4, 3, 3);
            ctx.fillRect(gx + gw - 7, gy + 4, 3, 3);
            ctx.fillRect(gx + 4, gy + gh - 7, 3, 3);
            ctx.fillRect(gx + gw - 7, gy + gh - 7, 3, 3);
          }

          // 3. Heavy Forged Iron Portcullis Grate
          const pulse = 0.5 + 0.5 * Math.sin(nowMs * 0.0032);
          const innerSpanStart = isHoriz ? (gx + jambSize + 4) : (gy + jambSize + 4);
          const innerSpanEnd = isHoriz ? (gx + gw - jambSize - 4) : (gy + gh - jambSize - 4);
          const barCount = 7;
          const barStep = (innerSpanEnd - innerSpanStart) / (barCount - 1);

          if (isHoriz) {
            for (let i = 0; i < barCount; i++) {
              const bx = Math.round(innerSpanStart + i * barStep);
              ctx.fillStyle = '#04070d';
              ctx.fillRect(bx - 3, gy + 2, 7, gh - 4);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(bx - 2, gy + 2, 5, gh - 4);
              ctx.fillStyle = '#475569';
              ctx.fillRect(bx - 2, gy + 2, 1.5, gh - 4);
              ctx.fillStyle = '#0b101b';
              ctx.fillRect(bx + 1.5, gy + 2, 1.5, gh - 4);

              ctx.fillStyle = '#334155';
              ctx.beginPath();
              ctx.moveTo(bx - 3.5, gy + gh - 4);
              ctx.lineTo(bx + 3.5, gy + gh - 4);
              ctx.lineTo(bx, gy + gh);
              ctx.closePath();
              ctx.fill();
              ctx.strokeStyle = '#0f172a';
              ctx.lineWidth = 1;
              ctx.stroke();
            }

            const beamY1 = gy + Math.round(gh * 0.28);
            const beamY2 = gy + Math.round(gh * 0.72);
            [beamY1, beamY2].forEach(by => {
              ctx.fillStyle = '#070c14';
              ctx.fillRect(gx + jambSize, by - 2.5, gw - jambSize * 2, 5);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(gx + jambSize, by - 2, gw - jambSize * 2, 4);
              ctx.fillStyle = '#64748b';
              ctx.fillRect(gx + jambSize, by - 2, gw - jambSize * 2, 1);

              for (let i = 0; i < barCount; i++) {
                const bx = Math.round(innerSpanStart + i * barStep);
                ctx.fillStyle = '#020617';
                ctx.fillRect(bx - 3.5, by - 3.5, 7, 7);
                ctx.fillStyle = '#94a3b8';
                ctx.fillRect(bx - 2, by - 2, 4, 4);
                ctx.fillStyle = '#f1f5f9';
                ctx.fillRect(bx - 1.5, by - 1.5, 1.5, 1.5);
              }
            });
          } else {
            for (let i = 0; i < barCount; i++) {
              const by = Math.round(innerSpanStart + i * barStep);
              ctx.fillStyle = '#04070d';
              ctx.fillRect(gx + 2, by - 3, gw - 4, 7);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(gx + 2, by - 2, gw - 4, 5);
              ctx.fillStyle = '#475569';
              ctx.fillRect(gx + 2, by - 2, gw - 4, 1.5);
              ctx.fillStyle = '#0b101b';
              ctx.fillRect(gx + 2, by + 1.5, gw - 4, 1.5);

              ctx.fillStyle = '#334155';
              ctx.beginPath();
              ctx.moveTo(gx + gw - 4, by - 3.5);
              ctx.lineTo(gx + gw - 4, by + 3.5);
              ctx.lineTo(gx + gw, by);
              ctx.closePath();
              ctx.fill();
              ctx.strokeStyle = '#0f172a';
              ctx.lineWidth = 1;
              ctx.stroke();
            }

            const beamX1 = gx + Math.round(gw * 0.28);
            const beamX2 = gx + Math.round(gw * 0.72);
            [beamX1, beamX2].forEach(bx => {
              ctx.fillStyle = '#070c14';
              ctx.fillRect(bx - 2.5, gy + jambSize, 5, gh - jambSize * 2);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(bx - 2, gy + jambSize, 4, gh - jambSize * 2);
              ctx.fillStyle = '#64748b';
              ctx.fillRect(bx - 2, gy + jambSize, 1, gh - jambSize * 2);

              for (let i = 0; i < barCount; i++) {
                const by = Math.round(innerSpanStart + i * barStep);
                ctx.fillStyle = '#020617';
                ctx.fillRect(bx - 3.5, by - 3.5, 7, 7);
                ctx.fillStyle = '#94a3b8';
                ctx.fillRect(bx - 2, by - 2, 4, 4);
                ctx.fillStyle = '#f1f5f9';
                ctx.fillRect(bx - 1.5, by - 1.5, 1.5, 1.5);
              }
            });
          }

          // 4. Arcane Sealing Threads across the Gate
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.4 + 0.3 * pulse})`;
          ctx.lineWidth = 1.5;
          ctx.shadowColor = '#ef4444';
          ctx.shadowBlur = getShadowBlur(8 * pulse);
          ctx.beginPath();
          if (isHoriz) {
            ctx.moveTo(gx + jambSize, cy);
            ctx.lineTo(gx + gw - jambSize, cy);
          } else {
            ctx.moveTo(cx, gy + jambSize);
            ctx.lineTo(cx, gy + gh - jambSize);
          }
          ctx.stroke();
          ctx.shadowBlur = 0;

          // 5. Sliding Deadbolt Crossbars
          const boltH = isHoriz ? 8 : Math.min(22, gw - 6);
          const boltW = isHoriz ? Math.min(gw * 0.58, 96) : 8;
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(cx - boltW / 2, cy - boltH / 2, boltW, boltH);
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 1.2;
          ctx.strokeRect(cx - boltW / 2, cy - boltH / 2, boltW, boltH);

          // 6. Central Demonic Boss Medallion (Grand Runic Seal)
          const sealR = 17;
          ctx.save();
          ctx.translate(cx, cy);

          for (let a = 0; a < 8; a++) {
            const ang = (a * Math.PI) / 4;
            ctx.save();
            ctx.rotate(ang);
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(-2, -sealR - 2.5, 4, 4);
            ctx.strokeRect(-2, -sealR - 2.5, 4, 4);
            ctx.restore();
          }

          ctx.beginPath();
          ctx.arc(0, 0, sealR, 0, Math.PI * 2);
          ctx.fillStyle = '#0f172a';
          ctx.fill();
          ctx.strokeStyle = '#475569';
          ctx.lineWidth = 2;
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(0, 0, sealR - 2.5, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.75 + 0.25 * pulse})`;
          ctx.lineWidth = 1.5;
          ctx.shadowColor = '#ef4444';
          ctx.shadowBlur = getShadowBlur(10 + 6 * pulse);
          ctx.stroke();

          const discGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, sealR - 3.5);
          discGrad.addColorStop(0, '#450a0a');
          discGrad.addColorStop(0.7, '#1f0404');
          discGrad.addColorStop(1, '#080101');
          ctx.fillStyle = discGrad;
          ctx.beginPath();
          ctx.arc(0, 0, sealR - 3.5, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = `rgba(254, 202, 202, ${0.45 + 0.3 * pulse})`;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.arc(0, 0, sealR - 6, 0, Math.PI * 2);
          ctx.stroke();

          ctx.strokeStyle = `rgba(254, 226, 226, ${0.85 + 0.15 * pulse})`;
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(-2.5, -4);
          ctx.quadraticCurveTo(-7, -8, -9, -12);
          ctx.quadraticCurveTo(-5, -9, -1, -5);
          ctx.moveTo(2.5, -4);
          ctx.quadraticCurveTo(7, -8, 9, -12);
          ctx.quadraticCurveTo(5, -9, 1, -5);
          ctx.stroke();

          ctx.fillStyle = '#991b1b';
          ctx.beginPath();
          ctx.moveTo(-6, -4.5);
          ctx.lineTo(6, -4.5);
          ctx.lineTo(4.5, 1.5);
          ctx.lineTo(0, 3.5);
          ctx.lineTo(-4.5, 1.5);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = '#fca5a5';
          ctx.lineWidth = 1;
          ctx.stroke();

          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 1.8;
          ctx.shadowColor = '#f97316';
          ctx.shadowBlur = getShadowBlur(6);
          ctx.beginPath();
          ctx.moveTo(-4.5, -1.8);
          ctx.lineTo(-1.8, -0.6);
          ctx.moveTo(4.5, -1.8);
          ctx.lineTo(1.8, -0.6);
          ctx.stroke();

          ctx.restore();
        } else {
          // Open Gate threshold
          ctx.fillStyle = '#0a101d';
          ctx.fillRect(gx, gy, gw, gh);

          ctx.fillStyle = '#1e293b';
          if (isHoriz) {
            ctx.fillRect(gx, gy, gw, 5);
            for (let tx = gx + 8; tx < gx + gw - 8; tx += 16) {
              ctx.beginPath();
              ctx.moveTo(tx - 3, gy + 5);
              ctx.lineTo(tx + 3, gy + 5);
              ctx.lineTo(tx, gy + 8);
              ctx.closePath();
              ctx.fill();
            }
          } else {
            ctx.fillRect(gx, gy, 5, gh);
            for (let ty = gy + 8; ty < gy + gh - 8; ty += 16) {
              ctx.beginPath();
              ctx.moveTo(gx + 5, ty - 3);
              ctx.lineTo(gx + 5, ty + 3);
              ctx.lineTo(gx + 8, ty);
              ctx.closePath();
              ctx.fill();
            }
          }

          ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
          ctx.lineWidth = 2;
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = getShadowBlur(10);
          ctx.strokeRect(gx + 1, gy + 1, gw - 2, gh - 2);
          ctx.shadowBlur = 0;
        }
      };

      // -----------------------------------------------------------------
      // LAYERED 2.5D ISOMETRIC CASTLE WALLS & CORNER COLUMNS (4 Strict Layers)
      // Layer 1: Back Corner Columns (underneath vertical walls)
      // Layer 2: North Horizontal Walls & Vertical Walls (vertical walls overlay back columns!)
      // Layer 3: South Horizontal Walls
      // Layer 4: Front Corner Columns (overlay vertical walls AND horizontal walls!)
      // -----------------------------------------------------------------
      const visibleWalls = state.walls.filter(w => {
        if (!w.alive) return false;
        if (w.isInvisible) return false; // Completely prevent drawing invisible collision walls!
        if (w.x + (w.w || 100) < state.cameraX - 150 || w.x > state.cameraX + viewWorldW + 150 ||
            w.y + (w.h || 100) < state.cameraY - 150 || w.y > state.cameraY + viewWorldH + 150) return false;
        return true;
      });

      // Special Boss Spiked Columns
      visibleWalls.forEach(w => {
        if (w.hasSpikes || w.isSpike) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderSingleSpikedColumn(w, Boolean(isRetracting), 'shadow');
          if (isAnyUnitBehindColumn(w)) {
            deferredForegroundObjects.push({ type: 'column', item: w, baseY: w.y + w.h, isRetracting: Boolean(isRetracting) });
          } else {
            renderSingleSpikedColumn(w, Boolean(isRetracting), 'body');
          }
        }
      });

      // Special Boss Gates
      visibleWalls.forEach(w => {
        if (w.isBossGate && !w.hasSpikes && !w.isSpike) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderBossGate(w, isRetracting);
        }
      });

      // --- LAYER 1: BACK CORNER PILLARS (Underneath vertical walls!) ---
      visibleWalls.forEach(w => {
        const isCorner = Boolean(w.isCornerPillar || (w.w <= 52 && w.h <= 52 && Math.abs(w.w - w.h) <= 12));
        if (isCorner && w.isBackPillar && !w.hasSpikes && !w.isSpike) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderSingleCornerPillar(w, Boolean(isRetracting), 'shadow');
          if (isAnyUnitBehindColumn(w)) {
            deferredForegroundObjects.push({ type: 'corner_pillar', item: w, baseY: w.y + w.h + 16, isRetracting: Boolean(isRetracting) });
          } else {
            renderSingleCornerPillar(w, Boolean(isRetracting), 'body');
          }
        }
      });

      // --- LAYER 2: NORTH HORIZONTAL WALLS & ALL VERTICAL WALLS (Vertical walls draw OVER back pillars!) ---
      visibleWalls.forEach(w => {
        if (w.isCornerPillar || w.isPillar || w.hasSpikes || w.isSpike || w.isBossGate) return;
        const isVert = (w.wallType === 'vert_wall') || (w.w < w.h);
        const isNorth = (w.wallType === 'north_wall') || Boolean(w.isNorth);
        if (isVert) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderVerticalWall(w, isRetracting);
        } else if (isNorth) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderHorizontalWall(w, isRetracting);
        }
      });

      // --- LAYER 3: SOUTH HORIZONTAL WALLS ---
      visibleWalls.forEach(w => {
        if (w.isCornerPillar || w.isPillar || w.hasSpikes || w.isSpike || w.isBossGate) return;
        const isVert = (w.wallType === 'vert_wall') || (w.w < w.h);
        const isNorth = (w.wallType === 'north_wall') || Boolean(w.isNorth);
        if (!isVert && !isNorth) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderHorizontalWall(w, isRetracting);
        }
      });

      // --- LAYER 4: FRONT CORNER PILLARS (Draws OVER vertical walls AND OVER horizontal walls!) ---
      visibleWalls.forEach(w => {
        const isCorner = Boolean(w.isCornerPillar || (w.w <= 52 && w.h <= 52 && Math.abs(w.w - w.h) <= 12));
        if (isCorner && !w.isBackPillar && !w.hasSpikes && !w.isSpike) {
          const isRetracting = Boolean(w.isFattyArenaWall && (w.retractProgress || 0) > 0.005);
          renderSingleCornerPillar(w, Boolean(isRetracting), 'shadow');
          if (isAnyUnitBehindColumn(w)) {
            deferredForegroundObjects.push({ type: 'corner_pillar', item: w, baseY: w.y + w.h + 16, isRetracting: Boolean(isRetracting) });
          } else {
            renderSingleCornerPillar(w, Boolean(isRetracting), 'body');
          }
        }
      });

      // 5b. Wall Torches (Fakel 3) & Banners rendered directly mounted on North Walls
      visibleDecorations.forEach((dec: any) => {
        if (dec.type !== 'torch' && dec.type !== 'banner') return;
        renderSingleDecoration(dec, 'body');
      });

      // 5c.1. Background Environment Decorations & Walls (rendered UNDER pots, crates, chests)
      visibleDecorations.forEach((dec: any) => {
        if (dec.isDestructible && (dec.alive === false || dec.opened)) return;
        if (dec.type === 'torch' || dec.type === 'banner') return;
        if (isFloorDecoration(dec)) return;
        if (dec.isDestructible) return; // interactive props rendered in next pass

        // Baked whole-room image (bakedUnderHeroImage vs bakedAboveHeroImage)
        if (dec.type === 'baked_image') {
          if (dec.renderAboveHero) {
            // Above hero layer: passes behind/underneath, so defer to foreground pass
            deferredForegroundObjects.push({ type: 'dec', item: dec, baseY: dec.y });
            return;
          }
          // Under hero layer: render immediately below hero
          renderSingleDecoration(dec, 'body');
          return;
        }

        // Custom room element layering rule: independent of zIndex
        if (dec.type === 'custom_element') {
          const isAbove = dec.renderAboveHero !== undefined ? dec.renderAboveHero : ((dec.zIndex ?? 0) > 100);
          if (isAbove) {
            // Above hero: hero passes behind it (element covers hero)
            deferredForegroundObjects.push({ type: 'dec', item: dec, baseY: dec.y });
            return;
          }
          // Below hero: hero passes on top of it (element rendered below hero)
          renderSingleDecoration(dec, 'body');
          return;
        }

        if (isAnyUnitBehindDec(dec)) {
          deferredForegroundObjects.push({ type: 'dec', item: dec, baseY: getDecBaseY(dec) });
          return;
        }

        renderSingleDecoration(dec, 'body');
      });

      // 5c.2. Interactive Props, Destructibles (Pots, Crates, Barrels) & Chests (rendered ABOVE background environment elements)
      visibleDecorations.forEach((dec: any) => {
        if (!dec.isDestructible || dec.alive === false || dec.opened) return;

        if (isAnyUnitBehindDec(dec)) {
          deferredForegroundObjects.push({ type: 'dec', item: dec, baseY: getDecBaseY(dec) });
          return;
        }

        renderSingleDecoration(dec, 'body');
      });

      state.chests.forEach((c: any) => {
        const cw = c.w || 54;
        const ch = c.h || 40;
        if (c.x + cw < state.cameraX - 100 || c.x > state.cameraX + viewWorldW + 100 ||
            c.y + ch < state.cameraY - 100 || c.y > state.cameraY + viewWorldH + 100) return;

        renderSingleChest(c, 'shadow');
        if (isAnyUnitBehindChest(c)) {
          deferredForegroundObjects.push({ type: 'chest', item: c, baseY: c.y + ch });
          return;
        }

        renderSingleChest(c, 'body');
      });

      // 6. Enemies
      state.enemies.forEach(en => {
        if (!en.alive) return;
        const enRadius = en.r || 50;
        const cullingMargin = en.type === 'fatty' ? 1500 : 100;
        if (en.x + enRadius < state.cameraX - cullingMargin || en.x - enRadius > state.cameraX + viewWorldW + cullingMargin ||
            en.y + enRadius < state.cameraY - cullingMargin || en.y - enRadius > state.cameraY + viewWorldH + cullingMargin) return;
        ctx.save();
        ctx.translate(en.x, en.y);

        const t = getObjTheme(en.x);
        const angToPlayer = Math.atan2(pCenterY - en.y, pCenterX - en.x);
        const eyeLookX = Math.cos(angToPlayer) * 3.5;
        const eyeLookY = Math.sin(angToPlayer) * 3.5;

        if (en.type === 'pylon') {
          const nowMs = performance.now();
          const rawProg = Math.min(1.0, (en.spawnTimer || 0) / (en.maxSpawnTimer || 90));
          // Smoothstep curve (0.0 -> 1.0)
          const spawnProg = rawProg * rawProg * (3 - 2 * rawProg);
          
          // Soft floor shadow fading in
          ctx.save();
          ctx.globalAlpha = spawnProg;
          ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
          ctx.beginPath();
          ctx.ellipse(0, 24, 18 * spawnProg, 6 * spawnProg, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          ctx.save();
          ctx.globalAlpha = spawnProg;
          ctx.scale(0.3 + spawnProg * 0.7, 0.3 + spawnProg * 0.7);

          // Swirling magic particles as entity materializes from thin air
          if (rawProg < 1.0 && Math.random() < 0.35) {
            const pAng = Math.random() * Math.PI * 2;
            const pDist = 15 + (1 - rawProg) * 35;
            state.particles.push({
              x: en.x + Math.cos(pAng) * pDist,
              y: en.y + Math.sin(pAng) * pDist,
              vx: -Math.cos(pAng) * 2.0,
              vy: -Math.sin(pAng) * 2.0 - 1.0,
              life: 0.4,
              maxLife: 0.4,
              color: Math.random() < 0.5 ? '#c084fc' : '#e9d5ff',
              size: 3 + Math.random() * 2
            });
          }

          // Outer glowing aura
          ctx.shadowColor = '#c084fc';
          ctx.shadowBlur = getShadowBlur(20 * spawnProg);

          // Diamond / Crystal Core
          const pSize = 20;

          // Outer Diamond Shield
          ctx.fillStyle = '#7e22ce';
          ctx.strokeStyle = '#e9d5ff';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(0, -pSize * 1.2);
          ctx.lineTo(pSize, 0);
          ctx.lineTo(0, pSize * 1.2);
          ctx.lineTo(-pSize, 0);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // Inner Radiant Core
          ctx.fillStyle = '#f0abfc';
          ctx.beginPath();
          ctx.arc(0, 0, 9, 0, Math.PI * 2);
          ctx.fill();

          // Orbiting Rune Ring
          const rotAng = en.angle || 0;
          ctx.strokeStyle = '#c084fc';
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.ellipse(0, 0, 26, 10, rotAng, 0, Math.PI * 2);
          ctx.stroke();

          ctx.restore();

          // Energy Tether Beam from Pylon to Fatty (smoothly igniting and glowing)
          const fatty = state.enemies.find(e => e.type === 'fatty' && e.alive);
          if (fatty && spawnProg > 0.08) {
            ctx.save();
            const beamAlpha = (spawnProg - 0.08) / 0.92;
            ctx.globalAlpha = beamAlpha;
            ctx.shadowColor = '#d8b4fe';
            ctx.shadowBlur = getShadowBlur(14 * beamAlpha);

            const dx = fatty.x - en.x;
            const dy = (fatty.y - 56) - en.y;

            // Thick energy tether ray
            const beamW = (2 + beamAlpha * 4.5) + Math.sin(nowMs * 0.015) * 1.5;
            ctx.strokeStyle = `rgba(192, 132, 252, ${0.75 * beamAlpha})`;
            ctx.lineWidth = beamW;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(dx, dy);
            ctx.stroke();

            // Inner bright white/golden core ray
            ctx.strokeStyle = `rgba(254, 240, 138, ${0.9 * beamAlpha})`;
            ctx.lineWidth = Math.max(1, beamW * 0.35);
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(dx, dy);
            ctx.stroke();

            // Traveling energy spark pulse along tether ray into Fatty
            const flowT = (nowMs * 0.002 + (en.x * 0.01)) % 1.0;
            const flowX = dx * flowT;
            const flowY = dy * flowT;
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(flowX, flowY, 4 * beamAlpha, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
          }

          // Draw HP Bar & Number above Pylon
          const barW = 32;
          const barH = 5;
          const barX = -barW / 2;
          const barY = -34;
          const hpRatio = Math.max(0, en.hp / en.maxHp);

          ctx.save();
          ctx.font = 'bold 9px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
          ctx.lineWidth = 2.5;
          ctx.strokeText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);
          ctx.fillStyle = '#ef4444';
          ctx.fillText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);

          ctx.fillStyle = '#0f172a';
          ctx.fillRect(barX, barY, barW, barH);

          ctx.fillStyle = '#ef4444';
          ctx.fillRect(barX, barY, barW * hpRatio, barH);
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.0;
          ctx.strokeRect(barX, barY, barW, barH);
          ctx.restore();
          ctx.restore();
          return;
        }

        if (en.type === 'saw') {
          // --- SAW ENEMY: Heavy Slate Saw / Red Volatile Saw Variant ---
          // Ground soft shadow for saw (enlarged)
          ctx.save();
          ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, en.r * 0.95, en.r * 1.15, 8.5, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          ctx.save();
          ctx.rotate(en.angle);

          const isRed = !!en.isRedSaw;
          const teethColor = isRed ? '#7f1d1d' : (t.sawTeeth || '#1e293b');
          const bevelColor = isRed ? '#991b1b' : '#334155';
          const strokeColor = isRed ? '#ef4444' : '#334155';
          const tipColor = isRed ? '#f87171' : (t.platNeon || '#38bdf8');
          const coreColor = isRed ? '#450a0a' : (t.platColor || '#0f172a');

          // 6 Heavy Steel/Slate Blades (Fewer glowing elements)
          const numSickles = 6;
          for (let i = 0; i < numSickles; i++) {
            ctx.rotate((Math.PI * 2) / numSickles);
            ctx.save();
            
            // Solid dark metallic blade body
            ctx.fillStyle = teethColor;
            ctx.strokeStyle = strokeColor;
            ctx.lineWidth = isRed ? 1.5 : 1.2;
            
            ctx.beginPath();
            ctx.moveTo(0, -en.r * 0.7);
            ctx.quadraticCurveTo(en.r * 0.6, -en.r * 1.2, en.r * 0.2, -en.r * 1.6);
            ctx.quadraticCurveTo(-en.r * 0.1, -en.r * 1.1, -en.r * 0.35, -en.r * 0.75);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Subtle matte bevel edge
            ctx.fillStyle = bevelColor;
            ctx.beginPath();
            ctx.moveTo(0, -en.r * 0.7);
            ctx.quadraticCurveTo(en.r * 0.6, -en.r * 1.2, en.r * 0.2, -en.r * 1.6);
            ctx.quadraticCurveTo(en.r * 0.3, -en.r * 1.25, 0, -en.r * 0.7);
            ctx.closePath();
            ctx.fill();

            // Slightly illuminated tip corner
            ctx.save();
            ctx.shadowColor = tipColor;
            ctx.shadowBlur = getShadowBlur(isRed ? 9 : 5);
            ctx.fillStyle = tipColor;
            ctx.beginPath();
            ctx.arc(en.r * 0.2, -en.r * 1.6, isRed ? 2.8 : 2.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();

            ctx.restore();
          }

          // Main Heavy Stone/Slate Core Body
          ctx.fillStyle = coreColor;
          ctx.beginPath();
          ctx.arc(0, 0, en.r, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = strokeColor;
          ctx.lineWidth = 2.0;
          ctx.stroke();

          // Dark Slate Rivets
          ctx.fillStyle = isRed ? '#ef4444' : '#334155';
          for (let r = 0; r < 6; r++) {
            const rx = Math.cos((r * Math.PI) / 3) * (en.r * 0.72);
            const ry = Math.sin((r * Math.PI) / 3) * (en.r * 0.72);
            ctx.beginPath();
            ctx.arc(rx, ry, 2, 0, Math.PI * 2);
            ctx.fill();
          }

          // Inner Groove Circle
          ctx.strokeStyle = isRed ? '#991b1b' : '#0f172a';
          ctx.lineWidth = 2.0;
          ctx.beginPath();
          ctx.arc(0, 0, en.r * 0.45, 0, Math.PI * 2);
          ctx.stroke();

          ctx.restore();

          // Glowing Cybernetic Eyes for Saws!
          ctx.save();
          const eyeColor = isRed ? '#ef4444' : (t.platNeon || '#ef4444');
          ctx.fillStyle = eyeColor;
          ctx.shadowColor = eyeColor;
          ctx.shadowBlur = getShadowBlur(8);
          const visX = eyeLookX * 0.7;
          const visY = eyeLookY * 0.7;

          ctx.beginPath();
          ctx.ellipse(-5 + visX, -2 + visY, 3, 1.5, -Math.PI / 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.beginPath();
          ctx.ellipse(5 + visX, -2 + visY, 3, 1.5, Math.PI / 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          // Spherical Energy Charge Effect when Red Saw is dying / charging explosion (like Fatty's laser phase!)
          if (en.isChargingExplosion) {
            ctx.save();
            const prog = Math.min(1.0, (en.explosionTimer || 0) / (en.maxExplosionTimer || 90));
            const now = performance.now();
            const pulse = Math.sin(now * 0.04) * 3;
            const sphereR = en.r + 8 + prog * 18 + pulse;

            // Outer spherical plasma glow
            ctx.shadowColor = '#ef4444';
            ctx.shadowBlur = getShadowBlur(24 + prog * 16);
            ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.arc(0, 0, sphereR, 0, Math.PI * 2);
            ctx.stroke();

            // Inner translucent energy sphere
            const sphereGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, sphereR);
            sphereGrad.addColorStop(0, 'rgba(254, 226, 226, 0.75)');
            sphereGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.45)');
            sphereGrad.addColorStop(1, 'rgba(185, 28, 28, 0.15)');
            ctx.fillStyle = sphereGrad;
            ctx.beginPath();
            ctx.arc(0, 0, sphereR, 0, Math.PI * 2);
            ctx.fill();

            // Crackling lightning arcs across sphere
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.8;
            for (let a = 0; a < 3; a++) {
              const aAng = (now * 0.005 + a * 2.1) % (Math.PI * 2);
              ctx.beginPath();
              ctx.arc(0, 0, sphereR * 0.85, aAng, aAng + 0.75);
              ctx.stroke();
            }

            ctx.restore();
          }

        } else if (en.type === 'ice') {
          // --- ICE ENEMY: Highly Detailed Crystalline Frost Prism ---
          // Ground soft shadow for ice prism (enlarged)
          ctx.save();
          ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, en.r * 0.95, en.r * 1.15, 8.5, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          ctx.save();
          ctx.rotate(en.angle);

          // Outer Crystalline Star Spikes
          const numSpikes = 8;
          ctx.fillStyle = t.iceBorder || '#38bdf8';
          for (let s = 0; s < numSpikes; s++) {
            const sAng = (s * Math.PI * 2) / numSpikes;
            ctx.beginPath();
            ctx.moveTo(Math.cos(sAng) * (en.r - 2), Math.sin(sAng) * (en.r - 2));
            ctx.lineTo(Math.cos(sAng + 0.2) * (en.r + 7), Math.sin(sAng + 0.2) * (en.r + 7));
            ctx.lineTo(Math.cos(sAng + 0.4) * (en.r - 2), Math.sin(sAng + 0.4) * (en.r - 2));
            ctx.closePath();
            ctx.fill();
          }

          // Translucent Multi-Faceted Crystal Body
          ctx.fillStyle = t.iceBody || '#0284c7';
          ctx.strokeStyle = t.iceBorder || '#38bdf8';
          ctx.lineWidth = 2.2;

          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const ha = (i * Math.PI) / 3;
            const hx = Math.cos(ha) * en.r;
            const hy = Math.sin(ha) * en.r;
            if (i === 0) ctx.moveTo(hx, hy);
            else ctx.lineTo(hx, hy);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // Refractive Internal Facet Lines & Central Frost Core Rune
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.lineWidth = 1.0;
          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const ha = (i * Math.PI) / 3;
            ctx.moveTo(0, 0);
            ctx.lineTo(Math.cos(ha) * en.r, Math.sin(ha) * en.r);
          }
          ctx.stroke();

          // Specular Glint Reflection Triangles on Facets
          ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
          for (let i = 0; i < 3; i++) {
            const ha1 = (i * 2 * Math.PI) / 3;
            const ha2 = ha1 + Math.PI / 3;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(Math.cos(ha1) * en.r, Math.sin(ha1) * en.r);
            ctx.lineTo(Math.cos(ha2) * en.r, Math.sin(ha2) * en.r);
            ctx.closePath();
            ctx.fill();
          }

          // Floating Orbiting Diamond Shards
          for (let j = 0; j < 4; j++) {
            const oa = (j * Math.PI) / 2 + en.angle * 2.5;
            const ox = Math.cos(oa) * (en.r + 10);
            const oy = Math.sin(oa) * (en.r + 10);
            ctx.fillStyle = '#bae6fd';
            ctx.beginPath();
            ctx.moveTo(ox, oy - 3);
            ctx.lineTo(ox + 2.5, oy);
            ctx.lineTo(ox, oy + 3);
            ctx.lineTo(ox - 2.5, oy);
            ctx.closePath();
            ctx.fill();
          }
          ctx.restore();

          // Sleek Piercing Icy Eye Visor
          ctx.save();
          ctx.shadowColor = '#00f2fe';
          ctx.shadowBlur = getShadowBlur(8);
          ctx.fillStyle = t.iceBorder || '#38bdf8';

          const iVisX = eyeLookX * 0.6;
          const iVisY = eyeLookY * 0.6;

          ctx.beginPath();
          ctx.ellipse(-5 + iVisX, -2 + iVisY, 4, 1.8, -0.1, 0, Math.PI * 2);
          ctx.ellipse(5 + iVisX, -2 + iVisY, 4, 1.8, 0.1, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.beginPath(); ctx.arc(-5 + iVisX, -2 + iVisY, Math.max(0.1, 1), 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(5 + iVisX, -2 + iVisY, Math.max(0.1, 1), 0, Math.PI * 2); ctx.fill();
          ctx.restore();

        } else if (en.type === 'knight') {
          // --- KNIGHT ENEMY: Detailed Obsidian Shadow Knight ---
          
          // Contact shadow on platform (enlarged)
          ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, 17, 24, 7.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Dark Tattered Mantle Cape Silhouette (Flows behind knight)
          ctx.fillStyle = '#020617';
          ctx.beginPath();
          ctx.moveTo(-12, -8);
          ctx.quadraticCurveTo(-18, 4, -15, 18);
          ctx.lineTo(-6, 14);
          ctx.lineTo(0, 17);
          ctx.lineTo(6, 14);
          ctx.lineTo(15, 18);
          ctx.quadraticCurveTo(18, 4, 12, -8);
          ctx.closePath();
          ctx.fill();

          // Obsidian Armor Body (Black Silhouette with crisp plate geometry)
          ctx.fillStyle = '#090d16';
          ctx.beginPath();
          ctx.roundRect(-14, -14, 28, 28, 4);
          ctx.fill();

          // Detailed Spiked Pauldrons (Shoulder Plates)
          ctx.fillStyle = '#1e293b';
          // Left Spiked Pauldron
          ctx.beginPath();
          ctx.moveTo(-14, -14);
          ctx.lineTo(-20, -10);
          ctx.lineTo(-18, 4);
          ctx.lineTo(-14, 2);
          ctx.closePath();
          ctx.fill();
          // Right Spiked Pauldron
          ctx.beginPath();
          ctx.moveTo(14, -14);
          ctx.lineTo(20, -10);
          ctx.lineTo(18, 4);
          ctx.lineTo(14, 2);
          ctx.closePath();
          ctx.fill();

          // Cuirass Plate Lines & Armor Rivets
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(0, -12); ctx.lineTo(0, 12);
          ctx.moveTo(-10, -2); ctx.lineTo(10, -2);
          ctx.stroke();

          // Illuminated side ear guards / wings ("ушки") on helmet sides
          ctx.save();
          const earGlowColor = en.state === 'windup' 
            ? '#f59e0b' 
            : (en.state === 'strike' ? '#ef4444' : (t.knightCrest || '#38bdf8'));

          ctx.fillStyle = earGlowColor;
          ctx.shadowColor = earGlowColor;
          ctx.shadowBlur = getShadowBlur(6);

          // Left ear wing ("ушко")
          ctx.beginPath();
          ctx.moveTo(-13, -8);
          ctx.lineTo(-21, -13);
          ctx.lineTo(-17, -4);
          ctx.closePath();
          ctx.fill();

          // Right ear wing ("ушко")
          ctx.beginPath();
          ctx.moveTo(13, -8);
          ctx.lineTo(21, -13);
          ctx.lineTo(17, -4);
          ctx.closePath();
          ctx.fill();
          ctx.restore();

          // Helm Crest / Plume Silhouette on Greathelm
          ctx.fillStyle = en.state === 'windup' ? '#f59e0b' : en.state === 'strike' ? '#ef4444' : '#334155';
          ctx.beginPath();
          ctx.moveTo(0, -14);
          ctx.quadraticCurveTo(-4, -22, 0, -26);
          ctx.quadraticCurveTo(4, -22, 0, -14);
          ctx.fill();

          // Dynamic Armor Trim / Outline (Glows amber on windup, crimson on strike)
          ctx.strokeStyle = en.state === 'windup' ? '#f59e0b' : (en.state === 'strike' ? '#ef4444' : (t.knightBorder || '#475569'));
          ctx.lineWidth = en.state === 'windup' ? 2 : (en.state === 'strike' ? 2.5 : 1.5);
          ctx.stroke();

          // Razor-Thin Glowing Visor Slit
          const eyeGlowColor = en.state === 'windup' 
            ? '#f59e0b' 
            : (en.state === 'strike' ? '#ef4444' : (t.knightCrest || '#38bdf8'));
          
          ctx.save();
          ctx.fillStyle = eyeGlowColor;
          ctx.shadowColor = eyeGlowColor;
          ctx.shadowBlur = getShadowBlur(en.state === 'windup' || en.state === 'strike' ? 12 : 6);
          
          // Visor slit
          ctx.beginPath();
          ctx.roundRect(-8 + eyeLookX * 0.5, -4 + eyeLookY * 0.3, 16, 2.5, 1.2);
          ctx.fill();
          ctx.restore();

          // Wind-up Tension Warning
          if (en.state === 'windup') {
            const tension = Math.min(1, en.windupTimer / (en.maxWindup || 36));
            ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
            ctx.beginPath();
            ctx.arc(0, 0, Math.max(0.1, 20 + tension * 8), 0, Math.PI * 2);
            ctx.stroke();

            // Tension bar above head
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(-14, -28, 28, 4);
            ctx.fillStyle = tension > 0.8 ? '#ef4444' : '#f59e0b';
            ctx.fillRect(-14, -28, 28 * tension, 4);
          }

          // Knight Sword Arm & Longsword (85px blade length)
          if (en.ropePoints && en.ropePoints.length > 1) {
            ctx.save();
            ctx.translate(-en.x, -en.y);
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.strokeStyle = '#334155';
            ctx.lineWidth = 4.5;
            ctx.moveTo(en.ropePoints[0].x, en.ropePoints[0].y);
            for (let i = 1; i < en.ropePoints.length; i++) ctx.lineTo(en.ropePoints[i].x, en.ropePoints[i].y);
            ctx.stroke();

            const kLast = en.ropePoints[en.ropePoints.length - 1];
            const kPrev = en.ropePoints[en.ropePoints.length - 2];
            const kAng = Math.atan2(kLast.y - kPrev.y, kLast.x - kPrev.x);

            // Shift sword attachment point higher/further along attack direction when striking
            const kAttachOffset = en.state === 'strike' ? 32 : (en.state === 'windup' ? 18 : 6);
            const kAttachX = kLast.x + Math.cos(kAng) * kAttachOffset;
            const kAttachY = kLast.y + Math.sin(kAng) * kAttachOffset;

            ctx.save();
            ctx.translate(kAttachX, kAttachY);
            ctx.rotate(kAng - Math.PI / 2 + Math.PI); // Rotate 180 degrees per requirement

            // Strike phase glow aura
            if (en.state === 'strike') {
              ctx.shadowColor = '#ef4444';
              ctx.shadowBlur = getShadowBlur(14);
            } else if (en.state === 'windup') {
              ctx.shadowColor = '#f59e0b';
              ctx.shadowBlur = getShadowBlur(10);
            }

            const kRarity = en.rarity || 'rare';
            const kSwordImg = getSwordAsset(kRarity, en.id);

            if (kSwordImg && kSwordImg.complete && kSwordImg.naturalWidth > 0) {
              const aspect = kSwordImg.naturalWidth / kSwordImg.naturalHeight || 0.3;
              // Extended length during strike so sword appears longer when attacking
              const totalH = (en.state === 'strike' ? 108 : en.state === 'windup' ? 95 : 85) + 20;
              const swordW = Math.round(totalH * aspect * 1.1);
              ctx.drawImage(kSwordImg, -swordW / 2, -totalH / 2, swordW, totalH);
            } else {
              ctx.fillStyle = '#e2e8f0';
              const bladeH = en.state === 'strike' ? 108 : 84;
              ctx.fillRect(-3, -bladeH / 2, 6, bladeH);
            }
            ctx.shadowBlur = 0;

            ctx.restore();
            ctx.restore();
          }
        } else if (en.type === 'fatty') {
          // --- DRAW FATTY BOSS ("ТОЛСТЯК" CONCEPT ARTWORK DESIGN) ---
          const bodyR = en.r;
          
          ctx.save();

          // Phase-specific spatial transforms and telegraphs
          if (en.fattyPhase === 'jump_prep') {
            const prepTimer = en.jumpPrepTimer || 0;
            const squishX = 1.0 + Math.sin(prepTimer * 0.15) * 0.08;
            const squishY = 1.0 - Math.sin(prepTimer * 0.15) * 0.08;
            ctx.scale(squishX, squishY);

            const lvl = en.level || 1;
            const maxPrepDuration = Math.max(20, Math.round(90 / (1 + 0.20 * (lvl - 1))));

            // Warning ground circle spanning to 4 spiked pillars (~340px) - 50% more transparent aiming indicator!
            ctx.save();
            ctx.globalAlpha = 0.5;
            ctx.strokeStyle = `rgba(239, 68, 68, ${0.4 + (prepTimer / maxPrepDuration) * 0.5})`;
            ctx.lineWidth = 3;
            ctx.setLineDash([12, 6]);
            ctx.beginPath();
            ctx.arc(0, 0, 340, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = `rgba(239, 68, 68, ${0.05 + (prepTimer / maxPrepDuration) * 0.12})`;
            ctx.beginPath();
            ctx.arc(0, 0, 340, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          } else if (en.fattyPhase === 'jump_air') {
            const jumpAirTimer = en.jumpAirTimer || 0;
            const jumpYOffset = -Math.sin((jumpAirTimer / 40) * Math.PI) * 220;
            
            // Ground shadow underneath jump
            const shadowScale = 1 - Math.sin((jumpAirTimer / 40) * Math.PI) * 0.45;
            ctx.save();
            ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
            ctx.beginPath();
            ctx.ellipse(0, 50, bodyR * 1.2 * shadowScale, 20 * shadowScale, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();

            // Translate boss sprite up into air
            ctx.translate(0, jumpYOffset);
          } else if (en.fattyPhase === 'magnetism') {
            // Magnetic field rings converging into Fatty
            const now = performance.now();
            ctx.save();
            for (let m = 0; m < 4; m++) {
              const magRadius = 60 + ((now * 0.15 + m * 70) % 240);
              const magAlpha = Math.max(0, 1 - magRadius / 300) * 0.6;
              ctx.strokeStyle = m % 2 === 0 ? `rgba(168, 85, 247, ${magAlpha})` : `rgba(56, 189, 248, ${magAlpha})`;
              ctx.lineWidth = 2.5;
              ctx.setLineDash([10, 8]);
              ctx.beginPath();
              ctx.arc(0, -48, magRadius, 0, Math.PI * 2);
              ctx.stroke();
            }
            ctx.restore();
          }
          
          // Subtle breathing animation
          const pulseScale = 1.0 + Math.sin(en.handsAnim || 0) * 0.02;
          ctx.scale(pulseScale, 1.0 / pulseScale);

          // Fatty's colors dynamically adapt to the current stage level
          const lvl = gameStateRef.current.level || 1;
          const lvlTier = (lvl - 1) % 5;
          let armorDark = '#0b0f19'; 
          let armorMid = '#1e293b';  
          let armorLight = '#334155'; 
          let strokeColor = '#ef4444';
          let eyeColor = '#f59e0b';

          if (lvlTier === 1) { // Deep Royal Purple
            armorDark = '#120b24';
            armorMid = '#2a1e4d';
            armorLight = '#4c3a8e';
            strokeColor = '#a855f7';
            eyeColor = '#22d3ee';
          } else if (lvlTier === 2) { // Venom toxic green/teal
            armorDark = '#061a12';
            armorMid = '#0f402e';
            armorLight = '#1e7555';
            strokeColor = '#10b981';
            eyeColor = '#f43f5e';
          } else if (lvlTier === 3) { // Frozen frost sapphire
            armorDark = '#051124';
            armorMid = '#0e2b5c';
            armorLight = '#1d54ad';
            strokeColor = '#38bdf8';
            eyeColor = '#fbbf24';
          } else if (lvlTier === 4) { // Scorched ruined bronze
            armorDark = '#210d02';
            armorMid = '#4d2105';
            armorLight = '#8c4211';
            strokeColor = '#f97316';
            eyeColor = '#ec4899';
          }

          // 1. INTENSE RED CRIMSON BASE AURA (Pulsing glowing red aura underneath body)
          const nowMs = performance.now();
          const auraPulse = Math.sin(nowMs * 0.005) * 0.15 + 0.85;
          const auraGrad = ctx.createRadialGradient(0, 10, bodyR * 0.3, 0, 10, bodyR * 1.6);
          auraGrad.addColorStop(0, `rgba(239, 68, 68, ${0.55 * auraPulse})`);
          auraGrad.addColorStop(0.55, `rgba(185, 28, 28, ${0.25 * auraPulse})`);
          auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = auraGrad;
          ctx.beginPath();
          ctx.arc(0, 10, bodyR * 1.6, 0, Math.PI * 2);
          ctx.fill();

          // 2. Heavy Shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, bodyR * 0.9, bodyR * 1.1, bodyR * 0.3, 0, 0, Math.PI * 2);
          ctx.fill();

          // 3. BODY & SHOULDER BACK SPIKES (3 Sharp Metal Spikes on left & 3 on right)
          const spikePositions = [
            { angle: -Math.PI * 0.75, len: 26, w: 10 },
            { angle: -Math.PI * 0.88, len: 30, w: 12 },
            { angle: -Math.PI * 0.62, len: 22, w: 9 },
            { angle: -Math.PI * 0.25, len: 26, w: 10 },
            { angle: -Math.PI * 0.12, len: 30, w: 12 },
            { angle: -Math.PI * 0.38, len: 22, w: 9 }
          ];

          spikePositions.forEach(sp => {
            const sx = Math.cos(sp.angle) * bodyR * 0.92;
            const sy = Math.sin(sp.angle) * bodyR * 0.92;
            const tipX = Math.cos(sp.angle) * (bodyR + sp.len);
            const tipY = Math.sin(sp.angle) * (bodyR + sp.len);
            const perpX = -Math.sin(sp.angle) * sp.w * 0.5;
            const perpY = Math.cos(sp.angle) * sp.w * 0.5;

            ctx.fillStyle = '#cbd5e1';
            ctx.strokeStyle = armorDark;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(sx - perpX, sy - perpY);
            ctx.lineTo(tipX, tipY);
            ctx.lineTo(sx + perpX, sy + perpY);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Spike shadow side
            ctx.fillStyle = armorLight;
            ctx.beginPath();
            ctx.moveTo(sx, sy);
            ctx.lineTo(tipX, tipY);
            ctx.lineTo(sx + perpX, sy + perpY);
            ctx.closePath();
            ctx.fill();
          });

          // 4. Main Armored Shell Body (Massive Obsidian Spherical Chassis)
          ctx.fillStyle = armorDark;
          ctx.beginPath();
          ctx.arc(0, 0, bodyR, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = strokeColor;
          ctx.lineWidth = 3.0;
          ctx.stroke();

          // Layered Heavy Plate Armor Strips
          ctx.fillStyle = armorMid;
          ctx.beginPath();
          ctx.ellipse(0, 24, bodyR * 0.9, bodyR * 0.35, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = armorLight;
          ctx.lineWidth = 1.5;
          ctx.stroke();

          ctx.beginPath();
          ctx.ellipse(0, -10, bodyR * 0.8, bodyR * 0.3, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // 5. SPIKED METALLIC BELT / WAIST BAND (Wide Studded Waist Ring with 5 Diamond Spikes)
          const beltY = 16;
          const beltH = 16;
          ctx.fillStyle = armorMid;
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.ellipse(0, beltY, bodyR * 0.96, beltH, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Belt Studded Diamond Spikes (5 Spikes along belt)
          const beltSpikes = [-0.75, -0.38, 0, 0.38, 0.75];
          beltSpikes.forEach(offset => {
            const bx = offset * bodyR * 0.85;
            const by = beltY + Math.cos(offset * 1.2) * 4;

            ctx.fillStyle = '#cbd5e1';
            ctx.strokeStyle = armorDark;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(bx - 6, by - 4);
            ctx.lineTo(bx, by - 14); // Sharp upward-pointing spike tip
            ctx.lineTo(bx + 6, by - 4);
            ctx.lineTo(bx, by + 6);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Bevel highlight
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.moveTo(bx - 6, by - 4);
            ctx.lineTo(bx, by - 14);
            ctx.lineTo(bx, by + 6);
            ctx.closePath();
            ctx.fill();
          });

          // 6. Head Helmet Dome with Apex Spike Crest
          const headY = -48;
          const headR = bodyR * 0.5;
          ctx.fillStyle = armorMid;
          ctx.beginPath();
          ctx.arc(0, headY, headR, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Top Helmet Crest Apex Spike
          ctx.fillStyle = '#cbd5e1';
          ctx.strokeStyle = armorDark;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(-9, headY - headR + 2);
          ctx.lineTo(0, headY - headR - 26);
          ctx.lineTo(9, headY - headR + 2);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // 7. ICONIC CENTRAL CYCLOPS EYE (MATCHES CONCEPT ARTWORK!)
          const eyeY = headY - 4;
          const eyeR = 14;
          const isEnraged = en.state === 'windup' || en.state === 'strike' || en.state === 'pulling' || en.fattyPhase === 'laser_fire';

          // Eye Socket Rim
          ctx.fillStyle = '#0f172a';
          ctx.strokeStyle = strokeColor;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, eyeY, eyeR + 3, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Eye Crimson Outer Glow
          ctx.save();
          ctx.shadowColor = strokeColor;
          ctx.shadowBlur = getShadowBlur(isEnraged ? 22 : 12);
          
          // Outer Red Iris
          ctx.fillStyle = isEnraged ? '#dc2626' : '#b91c1c';
          ctx.beginPath();
          ctx.arc(0, eyeY, eyeR, 0, Math.PI * 2);
          ctx.fill();

          // Vivid Orange Mid Ring
          ctx.fillStyle = '#f97316';
          ctx.beginPath();
          ctx.arc(0, eyeY, eyeR * 0.65, 0, Math.PI * 2);
          ctx.fill();

          // Hot White-Yellow Core Pupil
          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.arc(0, eyeY, eyeR * 0.35, 0, Math.PI * 2);
          ctx.fill();

          // Vertical Dark Pupil Slit
          ctx.fillStyle = '#450a0a';
          ctx.beginPath();
          ctx.ellipse(0, eyeY, 2.5, eyeR * 0.4, 0, 0, Math.PI * 2);
          ctx.fill();

          // High Specular Reflection Glint
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(-4, eyeY - 4, 3, 0, Math.PI * 2);
          ctx.fill();

          ctx.restore();

          // Fireball Plasma Charge Effects inside EYE socket ("стрелять огнем из глаза")
          if (en.fireballPhase === 'aiming') {
            const aimProg = Math.min(1, (en.shootTimer || 0) / 110);
            ctx.fillStyle = '#f97316';
            ctx.shadowColor = '#ef4444';
            ctx.shadowBlur = getShadowBlur(14);
            ctx.beginPath();
            ctx.arc(0, eyeY, Math.max(0.1, 4 + aimProg * 10), 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          } else if (en.fireballPhase === 'charging') {
            const pulse = Math.sin(performance.now() / 30) * 0.5 + 0.5;
            ctx.fillStyle = '#ffedd5';
            ctx.shadowColor = '#f97316';
            ctx.shadowBlur = getShadowBlur(26);
            ctx.beginPath();
            ctx.arc(0, eyeY, Math.max(0.1, 16 + pulse * 8), 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(0, eyeY, Math.max(0.1, 10 + pulse * 5), 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          }

          // Forcefield Shield Dome around Fatty when Magical Entities (Pylons) are shielding him
          const activePylons = state.enemies.filter(e => e.type === 'pylon' && e.alive && !e.isDyingFadeOut);
          if (activePylons.length > 0 && (en.fattyPhase === 'laser_init' || en.fattyPhase === 'laser_charge' || en.fattyPhase === 'laser_fire')) {
            const avgPylonProg = activePylons.reduce((sum, p) => sum + Math.min(1.0, (p.spawnTimer || 0) / (p.maxSpawnTimer || 90)), 0) / activePylons.length;
            if (avgPylonProg > 0.05) {
              ctx.save();
              const nowMs = performance.now();
              const shieldAlpha = Math.min(1.0, avgPylonProg * 1.1);
              ctx.globalAlpha = shieldAlpha;

              ctx.shadowColor = '#c084fc';
              ctx.shadowBlur = getShadowBlur(26 * shieldAlpha);
              ctx.strokeStyle = `rgba(232, 121, 249, ${0.9 * shieldAlpha})`;
              ctx.lineWidth = 3.5;
              ctx.fillStyle = `rgba(168, 85, 247, ${0.18 * shieldAlpha})`;
              
              const shieldR = (en.r + 10) + avgPylonProg * 18 + Math.sin(nowMs * 0.01) * 3;
              ctx.beginPath();
              ctx.arc(0, -30, shieldR, 0, Math.PI * 2);
              ctx.fill();
              ctx.stroke();

              // Inner Hex / Arc runes
              ctx.strokeStyle = `rgba(253, 224, 71, ${0.65 * shieldAlpha})`;
              ctx.lineWidth = 1.8;
              ctx.beginPath();
              ctx.arc(0, -30, shieldR - 8, nowMs * 0.003, nowMs * 0.003 + Math.PI * 1.5);
              ctx.stroke();

              ctx.restore();
            }
          }

          // --- FATTY BOSS TELEGRAPH & EXTENDING CHAIN WITH SPOOL ---
          // Winch/Chain Spool socket fixed at center bottom under mouth (x = 0, y = 15) regardless of boss orientation
          const spoolX = 0;
          const spoolY = 15;

          const targetWorldX = en.targetImpactX !== undefined ? en.targetImpactX : pCenterX;
          const targetWorldY = en.targetImpactY !== undefined ? en.targetImpactY : pCenterY;
          const relTargetX = targetWorldX - en.x;
          const relTargetY = targetWorldY - en.y;

          // 1. Draw Target Marker Circle & Red Laser Corridor on Ground during Windup & Charging
          if (en.state === 'windup') {
            ctx.save();
            ctx.globalAlpha = 0.5; // 50% more transparent aiming indicator
            const isLocked = en.punchPhase === 'charging';
            const pulse = Math.sin(performance.now() / 25) * 0.5 + 0.5;

            // Aiming beam from chain spool to target
            ctx.strokeStyle = isLocked ? `rgba(239, 68, 68, ${0.85 + pulse * 0.15})` : 'rgba(234, 179, 8, 0.75)';
            ctx.lineWidth = isLocked ? 4 : 2;
            ctx.setLineDash(isLocked ? [] : [8, 4]);
            ctx.beginPath();
            ctx.moveTo(spoolX, spoolY);
            ctx.lineTo(relTargetX, relTargetY);
            ctx.stroke();

            // Target Impact Circle on Ground (Exact 54px radius matching 2.5x reduced damage area)
            ctx.translate(relTargetX, relTargetY);
            ctx.fillStyle = isLocked ? `rgba(239, 68, 68, ${0.25 + pulse * 0.15})` : 'rgba(234, 179, 8, 0.15)';
            ctx.strokeStyle = isLocked ? `rgba(239, 68, 68, ${0.9 + pulse * 0.1})` : 'rgba(234, 179, 8, 0.8)';
            ctx.lineWidth = isLocked ? 3.5 : 2;
            ctx.beginPath();
            ctx.arc(0, 0, 54, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Radial Crosshair ticks matching 54px radius
            for (let c = 0; c < 4; c++) {
              const cAng = (c / 4) * Math.PI * 2;
              ctx.beginPath();
              ctx.moveTo(Math.cos(cAng) * 44, Math.sin(cAng) * 44);
              ctx.lineTo(Math.cos(cAng) * 64, Math.sin(cAng) * 64);
              ctx.stroke();
            }

            ctx.restore();
          }

          // 2. Heavy Metallic Chain helper function ("цепь вместо руки")
          const drawChain = (x1: number, y1: number, x2: number, y2: number) => {
            const dist = Math.hypot(x2 - x1, y2 - y1);
            if (dist < 5) return;
            const angle = Math.atan2(y2 - y1, x2 - x1);
            const linkLength = 15;
            const numLinks = Math.max(1, Math.floor(dist / linkLength));

            ctx.save();
            ctx.translate(x1, y1);
            ctx.rotate(angle);

            for (let i = 0; i < numLinks; i++) {
              const lx = (i + 0.5) * (dist / numLinks);
              const isRotatedLink = i % 2 === 0;

              ctx.save();
              ctx.translate(lx, 0);

              if (isRotatedLink) {
                // Side-view chain link
                ctx.fillStyle = '#334155';
                ctx.strokeStyle = '#94a3b8';
                ctx.lineWidth = 2.5;
                ctx.beginPath();
                ctx.ellipse(0, 0, 9, 5.5, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Inner hole
                ctx.fillStyle = '#0f172a';
                ctx.beginPath();
                ctx.ellipse(0, 0, 4.5, 2.2, 0, 0, Math.PI * 2);
                ctx.fill();
              } else {
                // Front-view chain link
                ctx.fillStyle = '#475569';
                ctx.strokeStyle = '#cbd5e1';
                ctx.lineWidth = 2.5;
                ctx.beginPath();
                ctx.ellipse(0, 0, 5, 9.5, 0, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Red magma core line
                ctx.strokeStyle = '#ef4444';
                ctx.lineWidth = 1.2;
                ctx.beginPath();
                ctx.moveTo(0, -6);
                ctx.lineTo(0, 6);
                ctx.stroke();
              }
              ctx.restore();
            }
            ctx.restore();
          };

          // 3. Chain Spool / Winch Socket helper function ("бухта с цепью по центру под ртом")
          const drawChainSpool = (sx: number, sy: number) => {
            ctx.save();
            ctx.translate(sx, sy);

            // Outer Heavy Iron Housing
            ctx.fillStyle = armorDark;
            ctx.strokeStyle = '#64748b';
            ctx.lineWidth = 3.2;
            ctx.beginPath();
            ctx.arc(0, 0, 20, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Coiled Chain Rings inside spool
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 3.5;
            ctx.setLineDash([5, 4]);
            ctx.beginPath();
            ctx.arc(0, 0, 14, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);

            // Inner Red Glowing Core Hub
            ctx.fillStyle = '#1e293b';
            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Steel Bolts around flange
            for (let b = 0; b < 6; b++) {
              const bAng = (b / 6) * Math.PI * 2;
              ctx.fillStyle = '#94a3b8';
              ctx.beginPath();
              ctx.arc(Math.cos(bAng) * 16.5, Math.sin(bAng) * 16.5, 2, 0, Math.PI * 2);
              ctx.fill();
            }

            ctx.restore();
          };

          // 4. Draw Spiked Mace Head helper function
          const drawSpikedMace = (mx: number, my: number, maceR: number, angle: number, isSwinging: boolean) => {
            ctx.save();
            ctx.translate(mx, my);
            ctx.rotate(angle);

            // Fiery Red Aura around Mace Head
            ctx.shadowColor = strokeColor;
            ctx.shadowBlur = getShadowBlur(isSwinging ? 32 : 18);

            // Outer Obsidian Mace Sphere Base
            ctx.fillStyle = armorDark;
            ctx.beginPath();
            ctx.arc(0, 0, maceR, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = strokeColor;
            ctx.lineWidth = 3.0;
            ctx.stroke();

            // Inner Metallic Bevel Gradient
            const maceGrad = ctx.createRadialGradient(-maceR * 0.3, -maceR * 0.3, maceR * 0.1, 0, 0, maceR);
            maceGrad.addColorStop(0, '#475569');
            maceGrad.addColorStop(0.5, armorMid);
            maceGrad.addColorStop(1, armorDark);
            ctx.fillStyle = maceGrad;
            ctx.beginPath();
            ctx.arc(0, 0, maceR - 2, 0, Math.PI * 2);
            ctx.fill();

            // Fiery Magma Cracks across the Mace Surface
            ctx.strokeStyle = '#f97316';
            ctx.lineWidth = 2.0;
            ctx.beginPath();
            ctx.moveTo(-maceR * 0.6, -maceR * 0.2);
            ctx.lineTo(-maceR * 0.1, 0);
            ctx.lineTo(maceR * 0.4, -maceR * 0.4);
            ctx.moveTo(-maceR * 0.3, maceR * 0.4);
            ctx.lineTo(maceR * 0.2, maceR * 0.1);
            ctx.lineTo(maceR * 0.6, maceR * 0.3);
            ctx.stroke();

            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 1.2;
            ctx.stroke();

            // Metal Band / Rim across Mace Equator with Steel Rivets
            ctx.fillStyle = armorMid;
            ctx.strokeStyle = '#94a3b8';
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.ellipse(0, 0, maceR * 0.98, maceR * 0.32, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Steel Rivets along the band
            const rivetOffsets = [-0.7, -0.35, 0, 0.35, 0.7];
            rivetOffsets.forEach(ro => {
              const rx = ro * maceR * 0.85;
              const ry = Math.cos(ro * 1.2) * (maceR * 0.12);
              ctx.fillStyle = '#e2e8f0';
              ctx.beginPath();
              ctx.arc(rx, ry, 2.5, 0, Math.PI * 2);
              ctx.fill();
            });

            // 10 CONICAL STEEL SPIKES protruding radially around the mace sphere
            const spikeAngles = [
              0, Math.PI * 0.25, Math.PI * 0.5, Math.PI * 0.75,
              Math.PI, -Math.PI * 0.75, -Math.PI * 0.5, -Math.PI * 0.25,
              0.12 * Math.PI, -0.12 * Math.PI
            ];

            spikeAngles.forEach(spAng => {
              const spikeLen = maceR * 0.55;
              const baseW = 10;
              const sx = Math.cos(spAng) * (maceR - 3);
              const sy = Math.sin(spAng) * (maceR - 3);
              const tx = Math.cos(spAng) * (maceR + spikeLen);
              const ty = Math.sin(spAng) * (maceR + spikeLen);
              const px = -Math.sin(spAng) * (baseW * 0.5);
              const py = Math.cos(spAng) * (baseW * 0.5);

              // Red Glowing Root Collar
              ctx.fillStyle = '#ef4444';
              ctx.beginPath();
              ctx.arc(sx, sy, baseW * 0.7, 0, Math.PI * 2);
              ctx.fill();

              // Spike Polygon (Light Side)
              ctx.fillStyle = '#cbd5e1';
              ctx.strokeStyle = armorDark;
              ctx.lineWidth = 1.5;
              ctx.beginPath();
              ctx.moveTo(sx - px, sy - py);
              ctx.lineTo(tx, ty);
              ctx.lineTo(sx + px, sy + px);
              ctx.closePath();
              ctx.fill();
              ctx.stroke();

              // Spike Shaded Side
              ctx.fillStyle = '#475569';
              ctx.beginPath();
              ctx.moveTo(sx, sy);
              ctx.lineTo(tx, ty);
              ctx.lineTo(sx + px, sy + px);
              ctx.closePath();
              ctx.fill();
            });

            ctx.restore();
          };

          if (en.state === 'strike') {
            // Active Extending Chain towards aimed target point!
            const strikeProg = Math.min(1.0, en.strikeTimer / 18);
            const maceX = spoolX + (relTargetX - spoolX) * strikeProg;
            const maceY = spoolY + (relTargetY - spoolY) * strikeProg;
            const chainAng = Math.atan2(maceY - spoolY, maceX - spoolX);

            // Draw chain connecting spool to mace
            drawChain(spoolX, spoolY, maceX, maceY);

            // Draw Spiked Mace at head of chain
            drawSpikedMace(maceX, maceY, 36, chainAng, true);

            // Draw Chain Spool Socket under mouth
            drawChainSpool(spoolX, spoolY);
          } else if (en.state === 'stuck') {
            // Mace is STUCK IN GROUND (Boss tugs 3 times: yields upwards then snaps back down into dirt!)
            const elapsed = 180 - Math.max(0, en.stuckTimer || 0);
            const tugIndex = Math.min(2, Math.floor(elapsed / 60)); // 0, 1, 2
            const cycleProgress = Math.max(0, Math.min(1, (elapsed % 60) / 60));

            let maceYOffset = 0;
            let maceXOffset = 0;

            if (cycleProgress < 0.45) {
              // Mace yields / lifts up out of earth ("вроде поддается")
              const liftFactor = Math.sin((cycleProgress / 0.45) * Math.PI);
              maceYOffset = -liftFactor * (20 + tugIndex * 8);
              maceXOffset = (Math.random() - 0.5) * (2 + tugIndex * 2);
            } else {
              // Mace SNAPS BACK deep into dirt ("обратно засовывалась в землю")
              maceYOffset = 0;
              maceXOffset = (Math.random() - 0.5) * 1.5;
            }

            const now = performance.now();
            const strainFreq = tugIndex === 0 ? 30 : (tugIndex === 1 ? 18 : 10);
            const strainAmp = tugIndex === 0 ? 1.5 : (tugIndex === 1 ? 3.5 : 6.0);
            const jitter = Math.sin(now / strainFreq) * strainAmp;

            // Draw taut strained chain connecting spool to ground impact point
            ctx.save();
            if (tugIndex >= 1) {
              ctx.shadowColor = tugIndex === 2 ? '#ef4444' : '#f97316';
              ctx.shadowBlur = getShadowBlur(16);
            }
            drawChain(spoolX + jitter, spoolY, relTargetX + maceXOffset, relTargetY + maceYOffset);
            ctx.restore();

            // Draw Mace Head yielding & snapping back
            ctx.save();
            ctx.translate(relTargetX, relTargetY);
            drawSpikedMace(maceXOffset, maceYOffset, 36, Math.PI * 0.5 + (tugIndex * 0.15), false);
            ctx.restore();

            // Draw Chain Spool Socket under mouth
            drawChainSpool(spoolX, spoolY);
          } else if (en.state === 'recovery') {
            // Recovery State: Chain winches fast back into the spool!
            const recProg = Math.max(0, (en.recoveryTimer || 0) / 35);
            const maceX = spoolX + (relTargetX - spoolX) * recProg;
            const maceY = spoolY + (relTargetY - spoolY) * recProg;

            drawChain(spoolX, spoolY, maceX, maceY);
            drawSpikedMace(maceX, maceY, 34, Math.atan2(maceY - spoolY, maceX - spoolX), true);
            drawChainSpool(spoolX, spoolY);
          } else if (en.fattyPhase === 'flail_spin') {
            // Spinning Mace Flail on chain with high speed motion trail & ground impact bounce!
            const rad = en.flailSpinRadius || 50;
            const ang = en.flailSpinAngle || 0;
            const bounceY = en.flailBounceY || 0;
            const maceX = spoolX + Math.cos(ang) * rad;
            const maceY = spoolY + Math.sin(ang) * rad - bounceY;
            const chainAng = ang + Math.PI / 2;

            const currentMaceR = 36 * (en.flailScale || 1.0);
            drawChain(spoolX, spoolY, maceX, maceY);
            drawSpikedMace(maceX, maceY, currentMaceR, chainAng, true);
            drawChainSpool(spoolX, spoolY);
          } else if (en.fattyPhase === 'jump_air') {
            // Leaping Airborne State: Hand / chain / mace leaps into the sky together with Fatty!
            const jumpAirTimer = en.jumpAirTimer || 0;
            const airSway = Math.sin(jumpAirTimer * 0.28) * 8;
            const maceY = 46 + Math.cos((jumpAirTimer / 40) * Math.PI) * 10;
            const maceX = airSway;
            const chainAng = Math.atan2(maceY - spoolY, maceX - spoolX);

            drawChain(spoolX, spoolY, maceX, maceY);
            drawSpikedMace(maceX, maceY, 34, chainAng, true);
            drawChainSpool(spoolX, spoolY);
          } else {
            // Idle / Walking State: Mace hangs from chain below body
            const swingX = Math.sin(en.handsAnim || 0) * 14;
            const swingY = 56;
            const chainAng = Math.atan2(swingY - spoolY, swingX - spoolX);

            drawChain(spoolX, spoolY, swingX, swingY);
            drawSpikedMace(swingX, swingY, 32, chainAng, false);
            drawChainSpool(spoolX, spoolY);
          }

          // Highly Visible Point-Based Fireball Aiming & Charging Visuals (Pinpoint Target Reticle, No Long Line)
          if (en.fireballPhase === 'aiming') {
            ctx.save();
            ctx.globalAlpha = 0.75;
            const relTargetX = en.lockedFireballX - en.x;
            const relTargetY = en.lockedFireballY - en.y;

            // Concentric Point Target Reticle with Crosshairs at exact player target point
            const rotAng = performance.now() / 300;
            ctx.save();
            ctx.translate(relTargetX, relTargetY);
            
            // Outer dashed rotating circle
            ctx.strokeStyle = '#f97316';
            ctx.lineWidth = 2;
            ctx.setLineDash([6, 6]);
            ctx.beginPath();
            ctx.arc(0, 0, 22, rotAng, rotAng + Math.PI * 2);
            ctx.stroke();

            // Inner crosshair
            ctx.setLineDash([]);
            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(-10, 0); ctx.lineTo(10, 0);
            ctx.moveTo(0, -10); ctx.lineTo(0, 10);
            ctx.stroke();

            // Center targeting red dot
            ctx.fillStyle = '#f87171';
            ctx.beginPath();
            ctx.arc(0, 0, 3, 0, Math.PI * 2);
            ctx.fill();
            
            // Outer corner brackets [ ]
            const bSize = 14;
            const bDist = 28;
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 2.5;
            // Top-left
            ctx.beginPath(); ctx.moveTo(-bDist, -bDist + bSize); ctx.lineTo(-bDist, -bDist); ctx.lineTo(-bDist + bSize, -bDist); ctx.stroke();
            // Top-right
            ctx.beginPath(); ctx.moveTo(bDist - bSize, -bDist); ctx.lineTo(bDist, -bDist); ctx.lineTo(bDist, -bDist + bSize); ctx.stroke();
            // Bottom-left
            ctx.beginPath(); ctx.moveTo(-bDist, bDist - bSize); ctx.lineTo(-bDist, bDist); ctx.lineTo(-bDist + bSize, bDist); ctx.stroke();
            // Bottom-right
            ctx.beginPath(); ctx.moveTo(bDist - bSize, bDist); ctx.lineTo(bDist, bDist); ctx.lineTo(bDist, bDist - bSize); ctx.stroke();

            ctx.restore();
            ctx.restore();
          } else if (en.fireballPhase === 'charging') {
            ctx.save();
            ctx.globalAlpha = 0.85;
            const relTargetX = en.lockedFireballX - en.x;
            const relTargetY = en.lockedFireballY - en.y;
            const pulse = Math.sin(performance.now() / 35) * 0.5 + 0.5;

            // Point Target LOCKED Warning Reticle (No long line / corridor)
            ctx.save();
            ctx.translate(relTargetX, relTargetY);

            // Outer pulsing danger ring
            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.arc(0, 0, Math.max(0.1, 26 + pulse * 8), 0, Math.PI * 2);
            ctx.stroke();
            
            // Core target danger fill
            ctx.fillStyle = `rgba(239, 68, 68, ${0.25 + pulse * 0.2})`;
            ctx.beginPath();
            ctx.arc(0, 0, 16, 0, Math.PI * 2);
            ctx.fill();

            // Inner crosshair lock
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(-14, 0); ctx.lineTo(14, 0);
            ctx.moveTo(0, -14); ctx.lineTo(0, 14);
            ctx.stroke();

            // Center red dot
            ctx.fillStyle = '#ff2222';
            ctx.beginPath();
            ctx.arc(0, 0, 4, 0, Math.PI * 2);
            ctx.fill();

            // Warning text above the locked point
            ctx.fillStyle = '#fef08a';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'center';
            ctx.shadowColor = '#000';
            ctx.shadowBlur = getShadowBlur(4);
            ctx.fillText('! ВНИМАНИЕ !', 0, -38);
            ctx.shadowBlur = 0;
            ctx.restore();

            ctx.restore();
          }

          // --- DRAW ANIMATED ROTATING SPECIAL HP THRESHOLD LASERS ---
          if ((en.fattyPhase === 'laser_charge' || en.fattyPhase === 'laser_fire') && en.laserAngles) {
            ctx.save();
            ctx.translate(0, -56); // Translate to head/chest energy locus
            const nowMs = performance.now();
            const pulse = Math.sin(nowMs * 0.025) * 2.5;

            // Central energy singularity radius
            let blobRadius = 0;
            if (en.fattyPhase === 'laser_charge') {
               const progress = Math.min(1.0, (en.laserTimer || 0) / 90.0);
               blobRadius = progress * 30;
            } else if (en.fattyPhase === 'laser_fire') {
               blobRadius = 34 + pulse * 2;
            }

            if (en.fattyPhase === 'laser_charge') {
              // Warning tracking beams before discharge (50% more transparent aiming indicator)
              ctx.save();
              ctx.globalAlpha = 0.5;
              const hitLens = (en.laserAngles || []).map((ang: number) =>
                getLaserHitDistance(en.x, en.y - 56, Math.cos(ang), Math.sin(ang), 950)
              );

              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const len = hitLens[idx];
                ctx.moveTo(0, 0);
                ctx.lineTo(Math.cos(ang) * len, Math.sin(ang) * len);
              });
              ctx.strokeStyle = 'rgba(244, 63, 94, 0.28)';
              ctx.lineWidth = 14 + pulse;
              ctx.stroke();

              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const len = hitLens[idx];
                ctx.moveTo(0, 0);
                ctx.lineTo(Math.cos(ang) * len, Math.sin(ang) * len);
              });
              ctx.strokeStyle = '#fde047';
              ctx.lineWidth = 2;
              ctx.stroke();
              
              // Warning text above Fatty
              ctx.fillStyle = '#fde047';
              ctx.font = 'bold 13px sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText('! ВРАЩАТЕЛЬНЫЙ ЛАЗЕР !', 0, -96);
              ctx.restore();
            } else if (en.fattyPhase === 'laser_fire') {
              // --- FULL INTENSITY ROTATING LASER BARRAGE (pre-calculated raycasts) ---
              const hitLens = (en.laserAngles || []).map((ang: number) =>
                getLaserHitDistance(en.x, en.y - 56, Math.cos(ang), Math.sin(ang), 950)
              );

              // Layer 1: Wide Plasma Aura
              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const len = hitLens[idx];
                ctx.moveTo(0, 0);
                ctx.lineTo(Math.cos(ang) * len, Math.sin(ang) * len);
              });
              ctx.strokeStyle = 'rgba(225, 29, 72, 0.38)';
              ctx.lineWidth = 26 + pulse * 2;
              ctx.stroke();

              // Layer 2: Neon Crimson Plasma Beam
              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const len = hitLens[idx];
                ctx.moveTo(0, 0);
                ctx.lineTo(Math.cos(ang) * len, Math.sin(ang) * len);
              });
              ctx.strokeStyle = '#f43f5e';
              ctx.lineWidth = 13 + pulse * 0.5;
              ctx.stroke();

              // Layer 3: Ultra-bright Pure White Core
              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const len = hitLens[idx];
                ctx.moveTo(0, 0);
                ctx.lineTo(Math.cos(ang) * len, Math.sin(ang) * len);
              });
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 4.5;
              ctx.stroke();

              // Layer 4: Rapidly propagating outward plasma pulses along each rotating beam (Batched)
              ctx.fillStyle = '#fef08a';
              const pulseShift = (nowMs * 0.9) % 120;
              ctx.beginPath();
              en.laserAngles.forEach((ang: number, idx: number) => {
                const maxLen = hitLens[idx];
                for (let dist = 45 + pulseShift; dist < maxLen; dist += 120) {
                  const px = Math.cos(ang) * dist;
                  const py = Math.sin(ang) * dist;
                  ctx.moveTo(px + 3.8, py);
                  ctx.arc(px, py, 3.8, 0, Math.PI * 2);
                }
              });
              ctx.fill();
            }

            // Core Singularity Visual at Center
            if (blobRadius > 0) {
               // Outer swirling plasma flare
               const flareGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, blobRadius + 14);
               flareGrad.addColorStop(0, '#ffffff');
               flareGrad.addColorStop(0.35, '#f43f5e');
               flareGrad.addColorStop(0.8, 'rgba(225, 29, 72, 0.4)');
               flareGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
               ctx.fillStyle = flareGrad;
               ctx.beginPath();
               ctx.arc(0, 0, blobRadius + 14, 0, Math.PI * 2);
               ctx.fill();

               // Hot white central core
               ctx.fillStyle = '#ffffff';
               ctx.beginPath();
               ctx.arc(0, 0, blobRadius * 0.45, 0, Math.PI * 2);
               ctx.fill();
            }
            
            ctx.restore();
          }

          ctx.restore();
        } else if (en.type === 'spider') {
          // --- SPIDER ENEMY: Cybernetic Mech Spider ---
          ctx.save();
          
          // Ground soft shadow for spider
          ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
          ctx.beginPath();
          ctx.ellipse(0, 14, 22, 5, 0, 0, Math.PI * 2);
          ctx.fill();

          // 6 Articulated Mechanical Legs
          const legPhase = en.legAnim || 0;
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 2.5;
          
          for (let side = -1; side <= 1; side += 2) {
            for (let l = 0; l < 3; l++) {
              const kneeX = side * (12 + l * 4);
              const kneeY = -8 + Math.cos(legPhase + l) * 4;
              const footX = side * (22 + l * 6);
              const footY = 12;

              ctx.beginPath();
              ctx.moveTo(0, -2);
              ctx.lineTo(kneeX, kneeY);
              ctx.lineTo(footX, footY);
              ctx.stroke();

              // Red glowing joint tip
              ctx.fillStyle = '#ef4444';
              ctx.beginPath();
              ctx.arc(footX, footY, 1.8, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // Body Carapace (Obsidian Hex Chassis)
          ctx.fillStyle = '#0f172a';
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 2.0;
          ctx.beginPath();
          ctx.ellipse(0, -2, 14, 10, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Emerald Eyes Matrix
          ctx.fillStyle = '#10b981';
          ctx.shadowColor = '#10b981';
          ctx.shadowBlur = getShadowBlur(6);
          ctx.beginPath();
          ctx.arc(-5, -4, 2.5, 0, Math.PI * 2);
          ctx.arc(0, -6, 2.5, 0, Math.PI * 2);
          ctx.arc(5, -4, 2.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          ctx.restore();
        } else if (en.type === 'phantom') {
          // --- PHANTOM ENEMY: Spectral Ghost / White Phantom Variant with Faceless Void ---
          ctx.save();
          
          // Ground soft shadow for phantom (lowered further by 40% to clearly show hovering in air)
          ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
          ctx.beginPath();
          ctx.ellipse(0, 34, 18, 4.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Apply fade transparency when vanishing / reappearing / flickering
          let drawAlpha = en.fadeAlpha !== undefined ? Math.max(0, Math.min(1, en.fadeAlpha)) : 1.0;
          if (en.isFlickering) {
            // Flicker effect: alternate between drawAlpha and 0.25 opacity every 80ms
            if (Math.floor(performance.now() / 80) % 2 === 0) {
              drawAlpha = 0.25;
            }
          }
          ctx.globalAlpha = drawAlpha;

          // Split clone scale
          if (en.isSplitClone) {
            ctx.scale(0.65, 0.65);
          }

          const now = performance.now();
          const isDash = en.state === 'dash';
          const isCharge = en.state === 'charge';
          const isWhite = !!en.isWhitePhantom;

          // Direction facing player or movement
          const facingDir = isDash ? Math.sign(en.dashVx || 1) : Math.sign(en.vx || 1);
          if (facingDir !== 0) {
            ctx.scale(facingDir, 1);
          }

          // Dynamic colors
          const pBody = isWhite ? '#f8fafc' : (t.phantomBody || '#0369a1');
          const pBorder = isWhite ? '#ffffff' : (t.phantomBorder || '#38bdf8');
          const pRune = isWhite ? '#ffffff' : (t.phantomRune || '#7dd3fc');

          // Aura & Spectral Glow
          if (isDash) {
            ctx.shadowColor = isWhite ? '#ffffff' : '#e0f2fe';
            ctx.shadowBlur = getShadowBlur(28 + Math.sin(now * 0.03) * 6);
          } else if (isCharge) {
            ctx.shadowColor = isWhite ? '#ffffff' : pBorder;
            ctx.shadowBlur = getShadowBlur(18 + Math.sin(now * 0.05) * 8);
          } else {
            ctx.shadowColor = isWhite ? '#f1f5f9' : pBorder;
            ctx.shadowBlur = getShadowBlur(isWhite ? 14 : 10);
          }

          // Orbiting Spectral Magic Runes
          const runeTime = now * 0.003;
          for (let r = 0; r < 3; r++) {
            const rAng = runeTime + (r * Math.PI * 2) / 3;
            const rx = Math.cos(rAng) * 26;
            const ry = Math.sin(rAng) * 14;

            ctx.fillStyle = isDash ? '#ffffff' : isCharge ? (isWhite ? '#ffffff' : pBorder) : pRune;
            ctx.beginPath();
            ctx.arc(rx, ry, isCharge ? 4.5 : 3.0, 0, Math.PI * 2);
            ctx.fill();
          }

          // Cloak Gradient
          const cloakGrad = ctx.createLinearGradient(0, -22, 0, 24);
          if (isWhite) {
            if (isDash) {
              cloakGrad.addColorStop(0, '#ffffff');
              cloakGrad.addColorStop(0.4, '#f8fafc');
              cloakGrad.addColorStop(1, 'rgba(241, 245, 249, 0.95)');
            } else if (isCharge) {
              cloakGrad.addColorStop(0, '#ffffff');
              cloakGrad.addColorStop(0.5, '#f1f5f9');
              cloakGrad.addColorStop(1, 'rgba(226, 232, 240, 0.9)');
            } else {
              cloakGrad.addColorStop(0, '#ffffff');
              cloakGrad.addColorStop(0.5, '#e2e8f0');
              cloakGrad.addColorStop(1, 'rgba(203, 213, 225, 0.9)');
            }
          } else {
            if (isDash) {
              cloakGrad.addColorStop(0, '#ffffff');
              cloakGrad.addColorStop(0.4, pBorder);
              cloakGrad.addColorStop(1, 'rgba(14, 165, 233, 0.75)');
            } else if (isCharge) {
              cloakGrad.addColorStop(0, pBorder);
              cloakGrad.addColorStop(0.5, pBody);
              cloakGrad.addColorStop(1, 'rgba(15, 23, 42, 0.85)');
            } else {
              cloakGrad.addColorStop(0, pBody);
              cloakGrad.addColorStop(0.5, '#0f172a');
              cloakGrad.addColorStop(1, 'rgba(2, 6, 23, 0.9)');
            }
          }

          ctx.fillStyle = cloakGrad;
          ctx.strokeStyle = isDash ? '#ffffff' : isCharge ? pRune : pBorder;
          ctx.lineWidth = isDash ? 2.5 : 1.8;

          // --- DRAW GHOST CLOAK & HOOD SILHOUETTE ---
          ctx.beginPath();
          // Hood peak
          ctx.moveTo(0, -24);
          // Right shoulder drape
          ctx.quadraticCurveTo(16, -18, 18, -4);
          // Down to right cloak side
          ctx.lineTo(16, 10);

          // Tattered Cloak Tails at bottom
          const tailCount = 4;
          for (let i = tailCount; i >= 0; i--) {
            const tx = -16 + (i * 32) / tailCount;
            const wave = isDash ? -Math.abs(en.dashVx || 10) * 0.8 : Math.sin(now * 0.006 + i * 1.2) * 5;
            const ty = 22 + (i % 2 === 0 ? 6 : 0) + wave;
            ctx.quadraticCurveTo(tx + 4, 14, tx, ty);
          }

          // Left cloak side
          ctx.lineTo(-16, 10);
          // Left shoulder drape
          ctx.quadraticCurveTo(-18, -18, 0, -24);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // Dark Hood Cavity with Pitch Black Faceless Spot (Темное пятно вместо лица)
          ctx.fillStyle = isWhite ? '#090d16' : '#020617';
          ctx.shadowBlur = 0;
          ctx.beginPath();
          ctx.ellipse(2, -10, 10.5, 8.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Inner abyssal hollow depth (Complete faceless void - no eyes)
          ctx.fillStyle = '#000000';
          ctx.beginPath();
          ctx.ellipse(2, -10, 8, 6.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Floating Ghost Sleeves / Mantle Fold
          ctx.fillStyle = isWhite
            ? (isDash ? 'rgba(255, 255, 255, 0.65)' : 'rgba(241, 245, 249, 0.45)')
            : (isDash ? 'rgba(255, 255, 255, 0.4)' : 'rgba(56, 189, 248, 0.25)');
          ctx.beginPath();
          ctx.moveTo(-12, -4);
          ctx.quadraticCurveTo(0, 4, 12, -4);
          ctx.quadraticCurveTo(0, 8, -12, -4);
          ctx.fill();

          ctx.restore();
        } else if (en.type === 'sorcerer') {
          // --- SORCERER ENEMY: Standard Purple Sorcerer / Light Blue Frost Sorcerer Variant ---
          ctx.save();
          
          // Apply fade transparency when teleporting
          let alpha = 1.0;
          if (en.state === 'teleporting') {
            alpha = Math.max(0, 1 - (en.teleportTimer || 0) / 22);
          }
          ctx.globalAlpha = alpha;

          const now = performance.now();
          const isCharge = en.state === 'charging';
          const isFrost = !!en.isFrostMage;

          // Direction facing player or movement
          if (en.facingDir !== 0) {
            ctx.scale(en.facingDir, 1);
          }

          // Ground soft shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
          ctx.beginPath();
          ctx.ellipse(0, 20, 16, 4, 0, 0, Math.PI * 2);
          ctx.fill();

          // Orbiting magic runes/sparks (Light Blue for Frost, Purple for Standard)
          const runeTime = now * 0.003;
          for (let r = 0; r < 3; r++) {
            const rAng = runeTime + (r * Math.PI * 2) / 3;
            const rx = Math.cos(rAng) * 26;
            const ry = Math.sin(rAng) * 14;

            ctx.fillStyle = isFrost
              ? (isCharge ? '#bae6fd' : '#38bdf8')
              : (isCharge ? '#f472b6' : '#c084fc');
            ctx.shadowColor = isFrost ? '#0284c7' : '#a855f7';
            ctx.shadowBlur = getShadowBlur(isCharge ? 14 : 7);
            ctx.beginPath();
            ctx.arc(rx, ry, isCharge ? 4.5 : 3.0, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          }

          // Cloak Gradient (Light Blue for Frost, Purple for Standard)
          const cloakGrad = ctx.createLinearGradient(0, -22, 0, 24);
          if (isFrost) {
            if (isCharge) {
              cloakGrad.addColorStop(0, '#e0f2fe');
              cloakGrad.addColorStop(0.5, '#0284c7');
              cloakGrad.addColorStop(1, '#082f49');
            } else {
              cloakGrad.addColorStop(0, '#38bdf8');
              cloakGrad.addColorStop(0.5, '#0369a1');
              cloakGrad.addColorStop(1, '#0f172a');
            }
          } else {
            if (isCharge) {
              cloakGrad.addColorStop(0, '#d8b4fe');
              cloakGrad.addColorStop(0.5, '#7e22ce');
              cloakGrad.addColorStop(1, '#3b0764');
            } else {
              cloakGrad.addColorStop(0, '#8b5cf6');
              cloakGrad.addColorStop(0.5, '#581c87');
              cloakGrad.addColorStop(1, '#1e1b4b');
            }
          }

          ctx.fillStyle = cloakGrad;
          ctx.strokeStyle = isFrost
            ? (isCharge ? '#bae6fd' : '#38bdf8')
            : (isCharge ? '#f472b6' : '#c084fc');
          ctx.lineWidth = 1.8;
          ctx.shadowColor = isFrost
            ? (isCharge ? '#38bdf8' : '#0284c7')
            : (isCharge ? '#f472b6' : '#a855f7');
          ctx.shadowBlur = getShadowBlur(isCharge ? 18 : 10);

          // --- DRAW WHOLE CLOAK & HOOD SILHOUETTE ---
          ctx.beginPath();
          // Hood peak
          ctx.moveTo(0, -24);
          // Right shoulder drape
          ctx.quadraticCurveTo(16, -18, 18, -4);
          // Down to right cloak side
          ctx.lineTo(16, 12);
          // Smooth curved bottom of the whole cloak
          ctx.quadraticCurveTo(0, 24, -16, 12);
          // Left cloak side
          ctx.lineTo(-16, 12);
          // Left shoulder drape
          ctx.quadraticCurveTo(-18, -18, 0, -24);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // Reset shadows
          ctx.shadowBlur = 0;

          // Dark Hood Cavity with Pitch Black Faceless Spot (Темное пятно вместо лица)
          ctx.fillStyle = '#020617';
          ctx.beginPath();
          ctx.ellipse(2, -10, 10.5, 8.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Inner abyssal hollow depth (Complete faceless void)
          ctx.fillStyle = '#000000';
          ctx.beginPath();
          ctx.ellipse(2, -10, 8, 6.5, 0, 0, Math.PI * 2);
          ctx.fill();

          // Glowing Eyes (Cyan for Frost, Red/Magenta for Standard)
          ctx.fillStyle = isFrost ? '#38bdf8' : '#f43f5e';
          ctx.shadowColor = isFrost ? '#38bdf8' : '#f43f5e';
          ctx.shadowBlur = getShadowBlur(isCharge ? 14 : 7);
          ctx.beginPath();
          ctx.arc(-1, -10, 1.5, 0, Math.PI * 2);
          ctx.arc(5, -10, 1.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // Floating Sleeves / Mantle Fold
          ctx.fillStyle = isFrost
            ? (isCharge ? 'rgba(125, 211, 252, 0.45)' : 'rgba(56, 189, 248, 0.28)')
            : (isCharge ? 'rgba(232, 121, 249, 0.4)' : 'rgba(192, 132, 252, 0.25)');
          ctx.beginPath();
          ctx.moveTo(-12, -4);
          ctx.quadraticCurveTo(0, 4, 12, -4);
          ctx.quadraticCurveTo(0, 8, -12, -4);
          ctx.fill();

          // Summoning Orb / Spherical Energy charging (spell cast effect!)
          if (isCharge) {
            const prog = en.chargeProgress || 0;
            const pulse = Math.sin(performance.now() / 20) * 2;
            const orbX = 0;
            const orbY = -2;
            
            ctx.fillStyle = isFrost ? '#f0f9ff' : '#fdf4ff';
            ctx.shadowColor = isFrost ? '#38bdf8' : '#d8b4fe';
            ctx.shadowBlur = getShadowBlur(18 + pulse * 2);
            ctx.beginPath();
            ctx.arc(orbX, orbY, 4 + prog * 11, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = isFrost ? '#0284c7' : '#a855f7';
            ctx.beginPath();
            ctx.arc(orbX, orbY, 2 + prog * 7, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          }

          ctx.restore();
        }

        // Stun indicator (2.5D Blue spiral)
        if ((en.stunTimer || 0) > 0) {
          ctx.save();
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.5;
          const time = performance.now() / 150;
          const spiralR = 14;
          ctx.beginPath();
          for (let i = 0; i < 30; i++) {
            const angle = i * 0.4 + time;
            const r = (i / 30) * spiralR;
            // Elliptical shape for 2.5D perspective
            const x = Math.cos(angle) * r;
            const y = Math.sin(angle) * (r * 0.4); 
            const yOffset = -en.r - 35 + Math.sin(time * 0.5) * 5;
            if (i === 0) ctx.moveTo(x, y + yOffset);
            else ctx.lineTo(x, y + yOffset);
          }
          ctx.stroke();
          ctx.restore();
        }

        // HP bar & HP number above enemy (Large only for Fatty, standard bar for others)
        if (en.type === 'fatty') {
          const barW = 120;
          const barH = 8;
          const barX = -barW / 2;
          const barY = -en.r - 20;

          // HP Number above Fatty
          ctx.save();
          ctx.font = 'bold 12px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
          ctx.lineWidth = 3;
          ctx.strokeText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);
          ctx.fillStyle = '#ef4444';
          ctx.fillText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);

          // Bar Background
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(barX, barY, barW, barH);

          // Bar Fill (Red)
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(barX, barY, Math.max(0, (en.hp / en.maxHp) * barW), barH);

          // Bar Border
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(barX, barY, barW, barH);
          ctx.restore();
        } else {
          const barW = 40;
          const barH = 5;
          const barX = -barW / 2;
          const barY = -en.r - 12;

          // HP Number above enemy
          ctx.save();
          ctx.font = 'bold 10px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
          ctx.lineWidth = 2.5;
          ctx.strokeText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);
          ctx.fillStyle = '#ef4444';
          ctx.fillText(String(Math.max(0, Math.ceil(en.hp))), 0, barY - 2);

          // Bar Background
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(barX, barY, barW, barH);

          // Bar Fill (Red)
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(barX, barY, Math.max(0, (en.hp / en.maxHp) * barW), barH);

          // Bar Border
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.0;
          ctx.strokeRect(barX, barY, barW, barH);
          ctx.restore();
        }

        ctx.restore();
      });

      // 7. Laser Drones on Platforms
      state.drones.forEach(drone => {
        if (!drone.alive) return;
        const isVert = drone.orientation === 'vertical';
        const platLeft = isVert ? drone.x : (drone.actualLeft ?? (drone.roomBounds ? drone.roomBounds.minX : (drone.parent ? drone.parent.x : drone.x - 300)));
        const platRight = isVert ? drone.x : (drone.actualRight ?? (drone.roomBounds ? drone.roomBounds.maxX : (drone.parent ? drone.parent.x + drone.parent.width : drone.x + 300)));
        const platTop = isVert ? (drone.actualTop ?? (drone.roomBounds ? drone.roomBounds.minY : drone.y - 260)) : drone.y;
        const platBottom = isVert ? (drone.actualBottom ?? (drone.roomBounds ? drone.roomBounds.maxY : drone.y + 260)) : drone.y;

        if (platRight < state.cameraX - 100 || platLeft > state.cameraX + viewWorldW + 100 ||
            platBottom < state.cameraY - 100 || platTop > state.cameraY + viewWorldH + 100) return;
        ctx.save();

        // PHASE 2: Charging Warning Line emitting from rhombus vertices across unblocked platform segment
        const L_tip = drone.r + 3;
        if (drone.phase === 'charging') {
          ctx.save();
          const pulse = Math.sin(performance.now() / 30) * 0.4 + 0.6;
          ctx.strokeStyle = `rgba(249, 115, 22, ${0.5 + drone.chargeProgress * 0.45})`;
          ctx.lineWidth = 2.0 + drone.chargeProgress * 2.5;
          ctx.setLineDash([8, 6]);
          ctx.lineDashOffset = -performance.now() * 0.15;
          ctx.beginPath();
          if (isVert) {
            ctx.moveTo(drone.x, drone.y - L_tip);
            ctx.lineTo(drone.x, platTop);
            ctx.moveTo(drone.x, drone.y + L_tip);
            ctx.lineTo(drone.x, platBottom);
          } else {
            ctx.moveTo(drone.x - L_tip, drone.beamY);
            ctx.lineTo(platLeft, drone.beamY);
            ctx.moveTo(drone.x + L_tip, drone.beamY);
            ctx.lineTo(platRight, drone.beamY);
          }
          ctx.stroke();

          // Charging glow along obstacle/platform edges
          ctx.setLineDash([]);
          ctx.fillStyle = '#f97316';
          if (isVert) {
            ctx.beginPath(); ctx.arc(drone.x, platTop, Math.max(0.1, (5 + drone.chargeProgress * 3) * pulse), 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(drone.x, platBottom, Math.max(0.1, (5 + drone.chargeProgress * 3) * pulse), 0, Math.PI * 2); ctx.fill();
          } else {
            ctx.beginPath(); ctx.arc(platLeft, drone.beamY, Math.max(0.1, (5 + drone.chargeProgress * 3) * pulse), 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(platRight, drone.beamY, Math.max(0.1, (5 + drone.chargeProgress * 3) * pulse), 0, Math.PI * 2); ctx.fill();
          }
          ctx.restore();
        }

        // PHASE 3: Blazing Dual Laser Beams shooting from rhombus vertices (Optimized & High Performance)
        if (drone.phase === 'firing') {
          ctx.save();
          const now = performance.now();
          const pulseW = Math.sin(now * 0.08) * 1.5;

          let beamTop = drone.laserTop;
          let beamBottom = drone.laserBottom;
          let beamLeft = drone.laserLeft;
          let beamRight = drone.laserRight;
          if (isVert) {
            if (beamTop === undefined || beamBottom === undefined) {
              const hitDistUp = getLaserHitDistance(drone.x, drone.y, 0, -1, Math.max(0, drone.y - platTop));
              const hitDistDown = getLaserHitDistance(drone.x, drone.y, 0, 1, Math.max(0, platBottom - drone.y));
              beamTop = drone.y - hitDistUp;
              beamBottom = drone.y + hitDistDown;
            }
          } else {
            if (beamLeft === undefined || beamRight === undefined) {
              const hitDistLeft = getLaserHitDistance(drone.x, drone.beamY, -1, 0, Math.max(0, drone.x - platLeft));
              const hitDistRight = getLaserHitDistance(drone.x, drone.beamY, 1, 0, Math.max(0, platRight - drone.x));
              beamLeft = drone.x - hitDistLeft;
              beamRight = drone.x + hitDistRight;
            }
          }

          // Pass 1: Outer energetic red/orange plasma beam (fast & lightweight, no laggy shadowBlur)
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 11 + pulseW;
          ctx.lineCap = 'round';
          ctx.beginPath();
          if (isVert) {
            ctx.moveTo(drone.x, drone.y - L_tip);
            ctx.lineTo(drone.x, beamTop);
            ctx.moveTo(drone.x, drone.y + L_tip);
            ctx.lineTo(drone.x, beamBottom);
          } else {
            ctx.moveTo(drone.x - L_tip, drone.beamY);
            ctx.lineTo(beamLeft, drone.beamY);
            ctx.moveTo(drone.x + L_tip, drone.beamY);
            ctx.lineTo(beamRight, drone.beamY);
          }
          ctx.stroke();

          // Pass 2: Amber intermediate plasma sheath
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 6 + pulseW * 0.5;
          ctx.beginPath();
          if (isVert) {
            ctx.moveTo(drone.x, drone.y - L_tip);
            ctx.lineTo(drone.x, beamTop);
            ctx.moveTo(drone.x, drone.y + L_tip);
            ctx.lineTo(drone.x, beamBottom);
          } else {
            ctx.moveTo(drone.x - L_tip, drone.beamY);
            ctx.lineTo(beamLeft, drone.beamY);
            ctx.moveTo(drone.x + L_tip, drone.beamY);
            ctx.lineTo(beamRight, drone.beamY);
          }
          ctx.stroke();

          // Pass 3: Inner blinding white-hot laser core
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 3;
          ctx.beginPath();
          if (isVert) {
            ctx.moveTo(drone.x, drone.y - L_tip);
            ctx.lineTo(drone.x, beamTop);
            ctx.moveTo(drone.x, drone.y + L_tip);
            ctx.lineTo(drone.x, beamBottom);
          } else {
            ctx.moveTo(drone.x - L_tip, drone.beamY);
            ctx.lineTo(beamLeft, drone.beamY);
            ctx.moveTo(drone.x + L_tip, drone.beamY);
            ctx.lineTo(beamRight, drone.beamY);
          }
          ctx.stroke();

          // Impact Flares at obstacle hit boundaries
          const flareR = 8 + Math.sin(now * 0.1) * 2;
          ctx.fillStyle = '#ef4444';
          if (isVert) {
            ctx.beginPath(); ctx.arc(drone.x, beamTop, flareR, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(drone.x, beamBottom, flareR, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ffffff';
            ctx.beginPath(); ctx.arc(drone.x, beamTop, 3.5, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(drone.x, beamBottom, 3.5, 0, Math.PI * 2); ctx.fill();
          } else {
            ctx.beginPath(); ctx.arc(beamLeft, drone.beamY, flareR, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(beamRight, drone.beamY, flareR, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#ffffff';
            ctx.beginPath(); ctx.arc(beamLeft, drone.beamY, 3.5, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(beamRight, drone.beamY, 3.5, 0, Math.PI * 2); ctx.fill();
          }
          ctx.restore();
        }

        // Drone Body Hull Rendering: Sleek Stealth Carbon Pod
        ctx.save();
        ctx.translate(drone.x, drone.y);

        // Ground soft shadow under drone
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        ctx.beginPath();
        ctx.ellipse(0, drone.r + 12, 16, 4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Anti-Grav Plasma Energy Ring
        ctx.save();
        ctx.rotate(drone.rotorAngle);
        ctx.strokeStyle = drone.phase === 'firing' ? 'rgba(239, 68, 68, 0.6)' : 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.arc(0, 0, drone.r + 4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        // Equilateral Rhombus Chassis Pod ("дроны сделай равносторонними ромбами")
        // All 4 sides are strictly equal in length: sqrt(L^2 + L^2)
        const L = drone.r + 3;
        ctx.fillStyle = '#090d16';
        ctx.beginPath();
        ctx.moveTo(0, -L);
        ctx.lineTo(L, 0);
        ctx.lineTo(0, L);
        ctx.lineTo(-L, 0);
        ctx.closePath();
        ctx.fill();

        const strokeColor = drone.phase === 'firing' ? '#ef4444' : drone.phase === 'charging' ? '#f97316' : '#38bdf8';
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Directional propulsion ion thruster exhaust on rear side
        if (drone.phase === 'idle' || drone.phase === 'cooldown') {
          ctx.save();
          const thrustGlow = 0.5 + Math.sin(performance.now() * 0.02) * 0.3;
          ctx.fillStyle = `rgba(56, 189, 248, ${thrustGlow})`;
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = getShadowBlur(6);
          if (isVert) {
            // Horizontal movement: exhaust opposite to moveDir
            const exX = drone.moveDir === 1 ? -L : L;
            ctx.beginPath();
            ctx.arc(exX, 0, 3, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Vertical movement: exhaust opposite to moveDir
            const exY = drone.moveDir === 1 ? -L : L;
            ctx.beginPath();
            ctx.arc(0, exY, 3, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }

        // Central High-Tech Optic Scanner Core
        const coreColor = drone.phase === 'firing' 
          ? '#ffffff' 
          : drone.phase === 'charging' 
          ? (Math.floor(Date.now() / 60) % 2 === 0 ? '#ef4444' : '#f97316') 
          : '#38bdf8';
        
        ctx.save();
        ctx.fillStyle = coreColor;
        ctx.shadowColor = coreColor;
        ctx.shadowBlur = getShadowBlur(10);
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Laser Turret Emitters mounted at rhombus vertices
        ctx.fillStyle = '#334155';
        if (isVert) {
          // Vertical laser turrets (top & bottom)
          ctx.fillRect(-3, -L - 3, 6, 4);
          ctx.fillRect(-3, L - 1, 6, 4);
        } else {
          // Horizontal laser turrets (left & right)
          ctx.fillRect(-L - 3, -3, 4, 6);
          ctx.fillRect(L - 1, -3, 4, 6);
        }

        // HP bar & HP number above drone
        ctx.save();
        const dBarW = 32;
        const dBarH = 4;
        const dBarX = -dBarW / 2;
        const dBarY = -drone.r - 10;

        // HP Number above drone
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
        ctx.lineWidth = 2.5;
        ctx.strokeText(String(Math.max(0, Math.ceil(drone.hp))), 0, dBarY - 2);
        ctx.fillStyle = '#ef4444';
        ctx.fillText(String(Math.max(0, Math.ceil(drone.hp))), 0, dBarY - 2);

        // Bar Background
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(dBarX, dBarY, dBarW, dBarH);

        // Bar Fill (Red)
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(dBarX, dBarY, Math.max(0, (drone.hp / drone.maxHp) * dBarW), dBarH);

        // Bar Border
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 1.0;
        ctx.strokeRect(dBarX, dBarY, dBarW, dBarH);
        ctx.restore();

        ctx.restore();
        ctx.restore();
      });

      // 8. Flying Eyes with Zero-Gravity Ribbons & Targeted Finite Laser
      state.flyingEyes.forEach(eye => {
        if (!eye.alive) return;
        if (eye.x + 120 < state.cameraX - 100 || eye.x - 120 > state.cameraX + viewWorldW + 100 ||
            eye.y + 120 < state.cameraY - 100 || eye.y - 120 > state.cameraY + viewWorldH + 100) return;
        ctx.save();
        const t = getObjTheme(eye.x);

        // 8a. Draw Zero-Gravity Silk Ribbons trailing naturally behind
        eye.ribbons.forEach(ribbon => {
          if (ribbon.points.length < 2) return;
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(ribbon.points[0].x, ribbon.points[0].y);
          for (let pIdx = 1; pIdx < ribbon.points.length; pIdx++) {
            const p = ribbon.points[pIdx];
            ctx.lineTo(p.x, p.y);
          }
          ctx.strokeStyle = ribbon.color;
          ctx.lineWidth = ribbon.width;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.stroke();
          ctx.restore();
        });

        // Eyeball Outer Sphere Body: Cybernetic Occult Orb
        ctx.save();
        ctx.translate(eye.x, eye.y);

        // Ground soft shadow (-25% size)
        ctx.fillStyle = 'rgba(0, 0, 0, 0.42)';
        ctx.beginPath();
        ctx.ellipse(0, eye.r + 20, 24, 6, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#0b0f19';
        ctx.beginPath();
        ctx.arc(0, 0, eye.r, 0, Math.PI * 2);
        ctx.fill();

        const eyeBorder = eye.phase === 'firing' ? '#ef4444' : eye.phase === 'charging' ? '#f59e0b' : '#38bdf8';
        ctx.strokeStyle = eyeBorder;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Dark Translucent Iris Lens
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.arc(0, 0, eye.r * 0.65, 0, Math.PI * 2);
        ctx.fill();

        // Eye Pupil & Iris tracking angle
        const activeAngle = (eye.phase === 'charging' || eye.phase === 'firing') ? eye.lockedAngle : eye.currentAngle;
        const pupilOffX = Math.cos(activeAngle) * 5;
        const pupilOffY = Math.sin(activeAngle) * 5;

        const pupilColor = eye.phase === 'firing' ? '#ef4444' : eye.phase === 'charging' ? '#f59e0b' : '#00f2fe';
        ctx.save();
        ctx.fillStyle = pupilColor;
        ctx.shadowColor = pupilColor;
        ctx.shadowBlur = getShadowBlur(8);
        ctx.beginPath();
        ctx.arc(pupilOffX, pupilOffY, 5.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(pupilOffX - 1.5, pupilOffY - 1.5, 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        ctx.restore();

        // PHASE: Charging tracking line ending AT PLAYER'S POINT (Blue / Cyan)
        if (eye.phase === 'charging') {
          ctx.save();
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
          ctx.lineWidth = 2.0;
          ctx.setLineDash([8, 6]);
          ctx.lineDashOffset = -performance.now() * 0.1;
          ctx.beginPath();
          ctx.moveTo(eye.x, eye.y);
          ctx.lineTo(eye.lockedTargetX, eye.lockedTargetY);
          ctx.stroke();

          // Target point reticle with animated rotating crosshair
          ctx.setLineDash([]);
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.75)';
          ctx.beginPath();
          ctx.arc(eye.lockedTargetX, eye.lockedTargetY, 9, 0, Math.PI * 2);
          ctx.stroke();

          const rAng = performance.now() * 0.005;
          ctx.beginPath();
          ctx.moveTo(eye.lockedTargetX + Math.cos(rAng) * 12, eye.lockedTargetY + Math.sin(rAng) * 12);
          ctx.lineTo(eye.lockedTargetX - Math.cos(rAng) * 12, eye.lockedTargetY - Math.sin(rAng) * 12);
          ctx.moveTo(eye.lockedTargetX + Math.sin(rAng) * 12, eye.lockedTargetY - Math.cos(rAng) * 12);
          ctx.lineTo(eye.lockedTargetX - Math.sin(rAng) * 12, eye.lockedTargetY + Math.cos(rAng) * 12);
          ctx.stroke();
          ctx.restore();
        }

        // PHASE 2: Charging Locked Beam (Cyan / Blue)
        if (eye.phase === 'charging') {
          ctx.save();

          // Gathering pulse glow at pupil
          const pulse = Math.sin(performance.now() / 40) * 4;
          ctx.fillStyle = 'rgba(6, 182, 212, 0.85)';
          ctx.shadowColor = '#06b6d4';
          ctx.shadowBlur = getShadowBlur(12);
          ctx.beginPath();
          ctx.arc(eye.x + pupilOffX, eye.y + pupilOffY, Math.max(0.1, 11 + pulse), 0, Math.PI * 2);
          ctx.fill();

          // Warning Line along locked segment to locked point
          ctx.strokeStyle = 'rgba(34, 211, 238, 0.9)';
          ctx.lineWidth = 3.0 + Math.sin(performance.now() * 0.05) * 1.0;
          ctx.setLineDash([12, 6]);
          ctx.lineDashOffset = -performance.now() * 0.2;
          ctx.beginPath();
          ctx.moveTo(eye.x, eye.y);
          ctx.lineTo(eye.lockedTargetX, eye.lockedTargetY);
          ctx.stroke();

          // Pulsing lock reticle at locked point
          ctx.setLineDash([]);
          ctx.strokeStyle = '#06b6d4';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(eye.lockedTargetX, eye.lockedTargetY, Math.max(0.1, 14 + pulse), 0, Math.PI * 2);
          ctx.stroke();

          ctx.restore();
        }

        // PHASE 3: Laser Blast Firing! (Animated Finite Laser Beam - Cyber Blue / Neon Cyan, raycasted to obstacles)
        if (eye.phase === 'firing') {
          ctx.save();
          const now = performance.now();
          const beamPulse = Math.sin(now * 0.09) * 4;

          const dx = eye.lockedTargetX - eye.x;
          const dy = eye.lockedTargetY - eye.y;
          const fullDist = Math.hypot(dx, dy) || 1;
          const dirX = dx / fullDist;
          const dirY = dy / fullDist;
          const endX = eye.lockedTargetX;
          const endY = eye.lockedTargetY;

          // Outer glowing blue beam (No slow shadowBlurs!)
          ctx.strokeStyle = '#2563eb';
          ctx.lineWidth = 18 + beamPulse;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(eye.x, eye.y);
          ctx.lineTo(endX, endY);
          ctx.stroke();

          // Mid Cyan Energy Layer
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 8 + Math.cos(now * 0.07) * 2;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(eye.x, eye.y);
          ctx.lineTo(endX, endY);
          ctx.stroke();

          // Inner blinding white beam core
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(eye.x, eye.y);
          ctx.lineTo(endX, endY);
          ctx.stroke();

          // Simplified Impact Blast Flare at hit point (No shadowBlurs!)
          const impactR = 16 + Math.sin(now * 0.12) * 4;
          ctx.fillStyle = '#06b6d4';
          ctx.beginPath();
          ctx.arc(endX, endY, impactR, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(endX, endY, 7, 0, Math.PI * 2);
          ctx.fill();

          ctx.restore();
        }

        // HP bar & HP number above eye
        ctx.save();
        ctx.translate(eye.x, eye.y);
        const eyeBarW = 40;
        const eyeBarH = 5;
        const eyeBarX = -eyeBarW / 2;
        const eyeBarY = -eye.r - 12;

        // HP Number above eye
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
        ctx.lineWidth = 2.5;
        ctx.strokeText(String(Math.max(0, Math.ceil(eye.hp))), 0, eyeBarY - 2);
        ctx.fillStyle = '#ef4444';
        ctx.fillText(String(Math.max(0, Math.ceil(eye.hp))), 0, eyeBarY - 2);

        // Bar Background
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(eyeBarX, eyeBarY, eyeBarW, eyeBarH);

        // Bar Fill (Red)
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(eyeBarX, eyeBarY, Math.max(0, (eye.hp / eye.maxHp) * eyeBarW), eyeBarH);

        // Bar Border
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 1.0;
        ctx.strokeRect(eyeBarX, eyeBarY, eyeBarW, eyeBarH);
        ctx.restore();

        ctx.restore();
      });

      // 9. Ice Projectiles
      state.iceProjectiles.forEach(proj => {
        if (!proj.alive) return;
        ctx.save();
        ctx.translate(proj.x, proj.y);
        ctx.rotate(Math.atan2(proj.vy, proj.vx));

        if (proj.isMagicBolt) {
          // Magic dark purple bolt
          ctx.fillStyle = proj.isReflected ? '#f5f3ff' : '#8b5cf6';
          ctx.shadowColor = proj.isReflected ? '#c084fc' : '#a855f7';
          ctx.shadowBlur = getShadowBlur(15);
          ctx.beginPath();
          ctx.arc(0, 0, 9, 0, Math.PI * 2);
          ctx.fill();

          // Tail magical particles/sparks behind it
          ctx.fillStyle = '#c084fc';
          ctx.beginPath();
          ctx.moveTo(-4, -6);
          ctx.lineTo(-24, -3 + Math.sin(performance.now() / 25) * 4);
          ctx.lineTo(-10, 0);
          ctx.lineTo(-24, 3 + Math.cos(performance.now() / 25) * 4);
          ctx.lineTo(-4, 6);
          ctx.closePath();
          ctx.fill();

          // Glowing bright core
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(2, 0, 4, 0, Math.PI * 2);
          ctx.fill();
        } else if (proj.isFireball) {
          // --- ULTRA-REALISTIC VOLUMETRIC FIREBALL RENDER ---
          const now = performance.now();
          const time = now * 0.008;

          // 1. Radial Heat & Fire Glow Aura
          ctx.save();
          const auraGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, 38);
          auraGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
          auraGrad.addColorStop(0.25, proj.isReflected ? 'rgba(254, 240, 138, 0.95)' : 'rgba(251, 146, 60, 0.95)');
          auraGrad.addColorStop(0.55, proj.isReflected ? 'rgba(234, 179, 8, 0.7)' : 'rgba(239, 68, 68, 0.7)');
          auraGrad.addColorStop(0.85, proj.isReflected ? 'rgba(202, 138, 4, 0.3)' : 'rgba(185, 28, 28, 0.3)');
          auraGrad.addColorStop(1, 'rgba(185, 28, 28, 0)');

          ctx.fillStyle = auraGrad;
          ctx.beginPath();
          ctx.arc(0, 0, 38, 0, Math.PI * 2);
          ctx.fill();

          // 2. Realistic Flaming Plasma Tail (3 flickering organic fire tongues tapering backwards)
          const tailLen = 70;
          for (let layer = 0; layer < 3; layer++) {
            const lScale = 1 - layer * 0.25;
            const flick1 = Math.sin(time * 4 + layer * 2) * 7;
            const flick2 = Math.cos(time * 5 - layer * 1.5) * 7;

            ctx.fillStyle = layer === 0
              ? (proj.isReflected ? 'rgba(234, 179, 8, 0.55)' : 'rgba(220, 38, 38, 0.55)')
              : (layer === 1
                ? (proj.isReflected ? 'rgba(250, 204, 21, 0.75)' : 'rgba(249, 115, 22, 0.75)')
                : (proj.isReflected ? 'rgba(254, 240, 138, 0.95)' : 'rgba(253, 224, 71, 0.95)'));

            ctx.beginPath();
            ctx.moveTo(8 * lScale, -14 * lScale);
            ctx.quadraticCurveTo(
              -tailLen * 0.4 * lScale, -18 * lScale + flick1,
              -tailLen * lScale, flick2
            );
            ctx.quadraticCurveTo(
              -tailLen * 0.4 * lScale, 18 * lScale - flick1,
              8 * lScale, 14 * lScale
            );
            ctx.closePath();
            ctx.fill();
          }

          // 3. Turbulent Swirling Plasma Fire Blobs
          for (let b = 0; b < 5; b++) {
            const bAng = time * 2.5 + b * (Math.PI * 2 / 5);
            const bDist = 4 + Math.sin(time * 3 + b) * 3;
            const bx = Math.cos(bAng) * bDist;
            const by = Math.sin(bAng) * bDist;
            const bRad = 9 + Math.cos(time * 4 + b * 2) * 3;

            ctx.fillStyle = b % 2 === 0 ? '#facc15' : '#ef4444';
            ctx.beginPath();
            ctx.arc(bx, by, bRad, 0, Math.PI * 2);
            ctx.fill();
          }

          // 4. White-Hot Incandescent Fireball Core
          const coreGrad = ctx.createRadialGradient(3, 0, 0, 3, 0, 15);
          coreGrad.addColorStop(0, '#ffffff');
          coreGrad.addColorStop(0.4, '#fef08a');
          coreGrad.addColorStop(0.8, proj.isReflected ? '#facc15' : '#f97316');
          coreGrad.addColorStop(1, '#ef4444');

          ctx.fillStyle = coreGrad;
          ctx.beginPath();
          ctx.arc(3, 0, 15, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else {
          ctx.fillStyle = proj.isReflected ? '#facc15' : '#38bdf8';
          ctx.beginPath();
          ctx.moveTo(12, 0);
          ctx.lineTo(-8, -6);
          ctx.lineTo(-4, 0);
          ctx.lineTo(-8, 6);
          ctx.closePath();
          ctx.fill();

          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
        ctx.restore();
      });

      // 10. Loot Drops Sitting on Platforms
      state.lootDrops.forEach(l => {
        if (!l.alive) return;
        if (l.x < state.cameraX - 100 || l.x > state.cameraX + viewWorldW + 100 ||
            l.y < state.cameraY - 100 || l.y > state.cameraY + viewWorldH + 100) return;
        ctx.save();
        ctx.translate(l.x, l.y);

        if (l.type === 'hp') {
          // Floating Heart Item with soft shadow & glow
          ctx.fillStyle = 'rgba(0,0,0,0.35)';
          ctx.beginPath();
          ctx.ellipse(0, 10, 7, 2.5, 0, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ef4444';
          ctx.shadowColor = '#f43f5e';
          ctx.shadowBlur = getShadowBlur(10);
          
          ctx.beginPath();
          ctx.moveTo(0, 4);
          ctx.bezierCurveTo(-7, -4, -12, 2, 0, 10);
          ctx.bezierCurveTo(12, 2, 7, -4, 0, 4);
          ctx.fill();
          ctx.shadowBlur = 0;
        } else if (l.type === 'ingredient' && l.ingredientType) {
          const ing = INGREDIENTS[l.ingredientType] || { name: 'Ресурс', color: '#38bdf8', icon: '💎' };
          let img = gameAssets.ing_iron_ore;
          let glowColor = 'rgba(203, 213, 225, 0.95)';
          let auraColor = 'rgba(203, 213, 225, 0.4)';

          if (l.ingredientType === 'magic_crystal') {
            img = gameAssets.ing_magic_crystal;
            glowColor = 'rgba(74, 222, 128, 0.95)';
            auraColor = 'rgba(34, 197, 94, 0.45)';
          } else if (l.ingredientType === 'monster_core') {
            img = gameAssets.ing_monster_core;
            glowColor = 'rgba(56, 189, 248, 0.95)';
            auraColor = 'rgba(6, 182, 212, 0.45)';
          } else if (l.ingredientType === 'ancient_rune' || l.ingredientType === 'fire_essence') {
            img = gameAssets.ing_ancient_rune;
            glowColor = 'rgba(192, 132, 252, 0.95)';
            auraColor = 'rgba(168, 85, 247, 0.45)';
          }

          // Gentle floating / bobbing animation
          const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 3;

          // Platform drop shadow on ground
          ctx.fillStyle = 'rgba(0,0,0,0.5)';
          ctx.beginPath();
          ctx.ellipse(0, 10, 9, 3.5, 0, 0, Math.PI * 2);
          ctx.fill();

          ctx.save();
          ctx.translate(0, bob);

          // Glowing circular aura behind ingredient
          ctx.fillStyle = auraColor;
          ctx.beginPath();
          ctx.arc(0, 0, 16, 0, Math.PI * 2);
          ctx.fill();

          // Render uploaded asset with vivid glow
          if (img && img.complete && img.naturalWidth > 0) {
            ctx.shadowColor = glowColor;
            ctx.shadowBlur = getShadowBlur(14);
            ctx.drawImage(img, -12, -12, 24, 24);
            ctx.shadowBlur = 0;
          } else {
            // High-visibility fallback orb with glow
            ctx.shadowColor = glowColor;
            ctx.shadowBlur = getShadowBlur(12);
            ctx.fillStyle = ing.color;
            ctx.beginPath();
            ctx.arc(0, 0, 10, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            ctx.shadowBlur = 0;
          }

          // Floating item name tag above with crisp fast shadow
          drawGroundNameTag(ctx, ing.name, ing.color, -15);

          ctx.restore();
        } else if (l.type === 'equipment' && l.itemData) {
          const rarity = l.rarity || l.itemData.rarity || 'common';
          const rColor = rarity === 'epic' ? '#c084fc' : rarity === 'rare' ? '#38bdf8' : rarity === 'magic' ? '#4ade80' : '#cbd5e1';
          const glow = rarity === 'epic' ? '#a855f7' : rarity === 'rare' ? '#0284c7' : rarity === 'magic' ? '#22c55e' : '#94a3b8';

          const isHelmet = l.itemData.category === 'helmet' || l.itemData.name?.toLowerCase().includes('шлем') || l.itemData.id?.includes('helmet');
          const isSpear = l.itemData.category === 'weapon' && (l.itemData.weaponData?.type === 'spear' || l.itemData.name?.toLowerCase().includes('копье') || l.itemData.name?.toLowerCase().includes('трезубец') || l.itemData.id?.includes('spear') || l.itemData.id?.includes('trident'));
          const isHammer = l.itemData.category === 'weapon' && (l.itemData.weaponData?.type === 'hammer' || l.itemData.name?.toLowerCase().includes('молот') || l.itemData.id?.includes('hammer'));
          const isAxe = l.itemData.category === 'weapon' && (l.itemData.weaponData?.type === 'axe' || l.itemData.name?.toLowerCase().includes('топор') || l.itemData.id?.includes('axe'));
          const isSword = l.itemData.category === 'weapon' && !isSpear && !isHammer && !isAxe;
          const isChest = l.itemData.category === 'chest' || l.itemData.name?.toLowerCase().includes('нагрудник') || l.itemData.id?.includes('chest');
          const isBracers = l.itemData.category === 'bracers' || l.itemData.name?.toLowerCase().includes('наруч') || l.itemData.id?.includes('bracer');
          const isPants = l.itemData.category === 'pants' || l.itemData.name?.toLowerCase().includes('штан') || l.itemData.id?.includes('pants');
          const isBoots = l.itemData.category === 'boots' || l.itemData.name?.toLowerCase().includes('обув') || l.itemData.name?.toLowerCase().includes('ботинк') || l.itemData.id?.includes('boot');
          const isTrinket = l.itemData.category === 'trinket' || l.itemData.name?.toLowerCase().includes('аксессуар') || l.itemData.name?.toLowerCase().includes('амулет') || l.itemData.id?.includes('trinket');
          const isGloves = l.itemData.category === 'gloves' || l.itemData.name?.toLowerCase().includes('перчат') || l.itemData.id?.includes('gloves') || l.itemData.id?.includes('glove');
          const isRing = l.itemData.category === 'ring' || l.itemData.name?.toLowerCase().includes('кольц') || l.itemData.id?.includes('ring');
          const isBelt = l.itemData.category === 'belt' || l.itemData.name?.toLowerCase().includes('пояс') || l.itemData.id?.includes('belt');
          const isCloak = l.itemData.category === 'cloak' || l.itemData.name?.toLowerCase().includes('плащ') || l.itemData.id?.includes('cloak');

          // Platform drop shadow
          ctx.fillStyle = 'rgba(0,0,0,0.45)';
          ctx.beginPath();
          ctx.ellipse(0, 10, isSpear || isHammer || isAxe || isSword ? 16 : isHelmet || isGloves || isChest ? 14 : 10, isSpear || isHammer || isAxe || isSword ? 5 : isHelmet || isGloves || isChest ? 4.5 : 3.5, 0, 0, Math.PI * 2);
          ctx.fill();

          if (isHelmet) {
            let helmImg = gameAssets.helmet_ground_common;
            if (rarity === 'magic') helmImg = gameAssets.helmet_ground_magic;
            else if (rarity === 'rare') helmImg = gameAssets.helmet_ground_rare;
            else if (rarity === 'epic') helmImg = gameAssets.helmet_ground_epic;

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            // Glowing circular aura behind ground helmet
            drawGroundAura(ctx, rarity, 18);

            if (helmImg && helmImg.complete && helmImg.naturalWidth > 0) {
              const helmAspect = helmImg.naturalWidth / helmImg.naturalHeight || 1;
              const helmH = 26;
              const helmW = Math.round(helmH * helmAspect);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(helmImg, -helmW / 2, -helmH / 2 - 2, helmW, helmH);
              ctx.shadowBlur = 0;
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -18);

            ctx.restore();
          } else if (isSpear) {
            const spearKey = l.id || l.itemData.id || l.itemData.name || 'spear';
            const spearImg = getSpearAsset(rarity, spearKey);

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            // Glowing circular aura behind ground spear
            drawGroundAura(ctx, rarity, 22);

            if (spearImg && spearImg.complete && spearImg.naturalWidth > 0) {
              const spearAspect = spearImg.naturalWidth / spearImg.naturalHeight || 0.16;
              const spearH = 46;
              const spearW = Math.round(spearH * spearAspect);

              ctx.save();
              ctx.rotate(-Math.PI * 0.22);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(spearImg, -spearW / 2, -spearH / 2, spearW, spearH);
              ctx.shadowBlur = 0;
              ctx.restore();
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -22);

            ctx.restore();
          } else if (isHammer) {
            const hammerImg = getHammerAsset(rarity, l.id || l.itemData?.id || l.itemData?.name);

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            drawGroundAura(ctx, rarity, 22);

            if (hammerImg && hammerImg.complete && hammerImg.naturalWidth > 0) {
              const aspect = hammerImg.naturalWidth / hammerImg.naturalHeight || 1;
              const hH = 38;
              const hW = Math.round(hH * aspect);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(hammerImg, -hW / 2, -hH / 2, hW, hH);
              ctx.shadowBlur = 0;
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -22);

            ctx.restore();
          } else if (isSword) {
            const swordImg = getSwordAsset(rarity, l.id || l.itemData?.id || l.itemData?.name);

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            drawGroundAura(ctx, rarity, 22);

            if (swordImg && swordImg.complete && swordImg.naturalWidth > 0) {
              const aspect = swordImg.naturalWidth / swordImg.naturalHeight || 0.3;
              const swordH = 42;
              const swordW = Math.round(swordH * aspect);

              ctx.save();
              ctx.rotate(-Math.PI * 0.22);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(swordImg, -swordW / 2, -swordH / 2, swordW, swordH);
              ctx.shadowBlur = 0;
              ctx.restore();
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -22);

            ctx.restore();
          } else if (isAxe) {
            const axeImg = getAxeAsset(rarity, l.id || l.itemData?.id || l.itemData?.name);

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            drawGroundAura(ctx, rarity, 22);

            if (axeImg && axeImg.complete && axeImg.naturalWidth > 0) {
              const aspect = axeImg.naturalWidth / axeImg.naturalHeight || 0.8;
              const axeH = 42;
              const axeW = Math.round(axeH * aspect);

              ctx.save();
              ctx.rotate(-Math.PI * 0.22);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(axeImg, -axeW / 2, -axeH / 2, axeW, axeH);
              ctx.shadowBlur = 0;
              ctx.restore();
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -22);

            ctx.restore();
          } else if (isGloves || isRing || isBelt || isChest || isBracers || isPants || isBoots || isTrinket || isCloak) {
            let itemImg = gameAssets.gloves_ground_common;
            if (isGloves) {
              itemImg = rarity === 'magic' ? gameAssets.gloves_ground_magic : rarity === 'rare' ? gameAssets.gloves_ground_rare : rarity === 'epic' ? gameAssets.gloves_ground_epic : gameAssets.gloves_ground_common;
            } else if (isRing) {
              itemImg = rarity === 'magic' ? gameAssets.ring_ground_magic : rarity === 'rare' ? gameAssets.ring_ground_rare : rarity === 'epic' ? gameAssets.ring_ground_epic : gameAssets.ring_ground_common;
            } else if (isBelt) {
              itemImg = rarity === 'magic' ? gameAssets.belt_ground_magic : rarity === 'rare' ? gameAssets.belt_ground_rare : rarity === 'epic' ? gameAssets.belt_ground_epic : gameAssets.belt_ground_common;
            } else if (isChest) {
              itemImg = rarity === 'magic' ? gameAssets.chest_ground_magic : rarity === 'rare' ? gameAssets.chest_ground_rare : rarity === 'epic' ? gameAssets.chest_ground_epic : gameAssets.chest_ground_common;
            } else if (isBracers) {
              itemImg = rarity === 'magic' ? gameAssets.bracers_ground_magic : rarity === 'rare' ? gameAssets.bracers_ground_rare : rarity === 'epic' ? gameAssets.bracers_ground_epic : gameAssets.bracers_ground_common;
            } else if (isPants) {
              itemImg = rarity === 'magic' ? gameAssets.pants_ground_magic : rarity === 'rare' ? gameAssets.pants_ground_rare : rarity === 'epic' ? gameAssets.pants_ground_epic : gameAssets.pants_ground_common;
            } else if (isBoots) {
              itemImg = rarity === 'magic' ? gameAssets.boots_ground_magic : rarity === 'rare' ? gameAssets.boots_ground_rare : rarity === 'epic' ? gameAssets.boots_ground_epic : gameAssets.boots_ground_common;
            } else if (isTrinket) {
              itemImg = rarity === 'magic' ? gameAssets.trinket_ground_magic : rarity === 'rare' ? gameAssets.trinket_ground_rare : rarity === 'epic' ? gameAssets.trinket_ground_epic : gameAssets.trinket_ground_common;
            } else if (isCloak) {
              itemImg = rarity === 'magic' ? gameAssets.cloak_ground_magic : rarity === 'rare' ? gameAssets.cloak_ground_rare : rarity === 'epic' ? gameAssets.cloak_ground_epic : gameAssets.cloak_ground_common;
            }

            const bob = Math.sin((Date.now() / 320) + (l.x % 10)) * 2.5;

            ctx.save();
            ctx.translate(0, bob);

            drawGroundAura(ctx, rarity, 16);

            if (itemImg && itemImg.complete && itemImg.naturalWidth > 0) {
              const aspect = itemImg.naturalWidth / itemImg.naturalHeight || 1;
              const itemH = 24;
              const itemW = Math.round(itemH * aspect);
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(14);
              ctx.drawImage(itemImg, -itemW / 2, -itemH / 2, itemW, itemH);
              ctx.shadowBlur = 0;
            } else {
              // Fallback icon
              ctx.shadowColor = glow;
              ctx.shadowBlur = getShadowBlur(12);
              ctx.fillStyle = rColor;
              ctx.beginPath();
              ctx.arc(0, 0, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.shadowBlur = 0;
            }

            // Item Name Tag Floating Above
            drawGroundNameTag(ctx, l.itemData.name, rColor, -16);

            ctx.restore();
          } else {
            // Standard equipment drop fallback (diamond / aura)
            ctx.shadowColor = glow;
            ctx.shadowBlur = getShadowBlur(12);
            ctx.fillStyle = rColor;
            ctx.beginPath();
            ctx.arc(0, 0, 10, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.moveTo(0, -6);
            ctx.lineTo(6, 0);
            ctx.lineTo(0, 6);
            ctx.lineTo(-6, 0);
            ctx.closePath();
            ctx.fill();
            ctx.shadowBlur = 0;

            // Item Name Tag Floating Above
            ctx.fillStyle = rColor;
            ctx.font = 'bold 10px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(l.itemData.name, 0, -14);
          }
        }

        // Interactive Pulse Aura
        const pulse = 1 + Math.sin(performance.now() * 0.006) * 0.15;
        const ringColor = l.type === 'hp' ? '#f43f5e' : l.type === 'ingredient' ? (INGREDIENTS[l.ingredientType!]?.color || '#38bdf8') : (l.itemData?.rarity === 'epic' ? '#c084fc' : l.itemData?.rarity === 'rare' ? '#38bdf8' : '#cbd5e1');

        ctx.strokeStyle = ringColor;
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = 0.5 + Math.sin(performance.now() * 0.006) * 0.25;
        ctx.beginPath();
        ctx.arc(0, 0, 15 * pulse, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1.0;

        ctx.restore();
      });

      // 10.5. Next Level Cosmic Portal & Countdown Seal
      if (state.portal) {
        const port = state.portal;
        ctx.save();
        ctx.translate(port.x, port.y);

        if (port.active) {
          const now = performance.now();
          const pulse = 1 + Math.sin(now * 0.005) * 0.08;
          const pR = port.r * pulse;

          // Ethereal Outer Glow
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = getShadowBlur(25);

          // Outer Swirling Energy Disk
          const grad = ctx.createRadialGradient(0, 0, 8, 0, 0, pR);
          grad.addColorStop(0, '#ffffff');
          grad.addColorStop(0.35, '#38bdf8');
          grad.addColorStop(0.75, '#818cf8');
          grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(0, 0, pR, 0, Math.PI * 2);
          ctx.fill();

          // Rotating Runic Orbit Rings
          ctx.save();
          ctx.rotate(port.angle);
          ctx.strokeStyle = '#67e8f9';
          ctx.lineWidth = 3;
          ctx.setLineDash([14, 8]);
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.85, 0, Math.PI * 2);
          ctx.stroke();

          ctx.rotate(-port.angle * 2.2);
          ctx.strokeStyle = '#c084fc';
          ctx.lineWidth = 2;
          ctx.setLineDash([8, 6]);
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.6, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();

          // Bright Center Core
          ctx.shadowBlur = getShadowBlur(12);
          ctx.shadowColor = '#ffffff';
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.25, 0, Math.PI * 2);
          ctx.fill();

          // Portal Banner Label
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 13px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('🌀 ПОРТАЛ НА УРОВЕНЬ ' + ((state.level || 1) + 1), 0, -pR - 12);
        } else if ((port.countdownTimer || 0) > 0) {
          // Charging Portal Seal with 10s Countdown
          const cd = Math.max(0, port.countdownTimer || 0);
          const maxCd = port.maxCountdown || 10.0;
          const progress = Math.max(0, Math.min(1, 1 - (cd / maxCd)));
          const pR = port.r;

          // Glowing subtle cosmic base
          ctx.shadowColor = '#a855f7';
          ctx.shadowBlur = getShadowBlur(16);
          ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
          ctx.beginPath();
          ctx.arc(0, 0, pR, 0, Math.PI * 2);
          ctx.fill();

          // Background track ring
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.8, 0, Math.PI * 2);
          ctx.stroke();

          // Progress Arc
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 5;
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * progress);
          ctx.stroke();

          // Rotating inner glyph
          ctx.save();
          ctx.rotate(port.angle);
          ctx.strokeStyle = '#c084fc';
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 6]);
          ctx.beginPath();
          ctx.arc(0, 0, pR * 0.55, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();

          // Center Countdown Number
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#fbbf24';
          ctx.font = 'bold 22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${Math.ceil(cd)}`, 0, 0);

          // Label above
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 12px sans-serif';
          ctx.fillText(`⏳ ОТКРЫТИЕ ПОРТАЛА: ${Math.ceil(cd)} сек.`, 0, -pR - 14);
        }

        ctx.restore();
      }

      // 10.7. Boss Direction Guide Arrow (appears after killing all mobs, points to boss gate/chamber, disappears inside)
      if (state.fattyArena && !state.fattyArena.triggered) {
        const remNormal = state.enemies.filter(e => e.alive && e.type !== 'fatty').length;
        const remEyes = state.flyingEyes.filter(e => e.alive).length;
        const remDrones = state.drones.filter(d => d.alive).length;
        const totalRemaining = remNormal + remEyes + remDrones;

        if (totalRemaining === 0) {
          const pCX = state.player.x + state.player.w / 2;
          const pCY = state.player.y + state.player.h / 2;
          const bCX = (state.fattyArena.arenaX + state.fattyArena.arenaEndX) / 2;
          const bCY = (state.fattyArena.arenaY + state.fattyArena.arenaEndY) / 2;
          const distToBoss = Math.hypot(bCX - pCX, bCY - pCY);

          if (distToBoss > 120) {
            const ang = Math.atan2(bCY - pCY, bCX - pCX);
            ctx.save();
            
            // Draw floating arrow around the player's center
            const radius = 60;
            const ax = pCX + Math.cos(ang) * radius;
            const ay = pCY + Math.sin(ang) * radius;

            ctx.translate(ax, ay);
            ctx.rotate(ang);

            // Pulsing scale
            const pulse = 1.0 + Math.sin(performance.now() * 0.007) * 0.15;
            ctx.scale(pulse, pulse);

            // Glowing golden arrowhead pointing towards boss room
            ctx.shadowColor = '#f59e0b';
            ctx.shadowBlur = getShadowBlur(14);
            ctx.fillStyle = '#fbbf24';
            ctx.strokeStyle = '#d97706';
            ctx.lineWidth = 2.0;

            ctx.beginPath();
            ctx.moveTo(12, 0);       // Tip pointing forward
            ctx.lineTo(-8, -8);      // Top back edge
            ctx.lineTo(-4, 0);       // Indented back center
            ctx.lineTo(-8, 8);       // Bottom back edge
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Scurrying navigation trail dots behind the arrow
            ctx.shadowBlur = 0;
            const flow = (performance.now() * 0.05) % 25;
            ctx.fillStyle = 'rgba(251, 191, 36, 0.6)';
            for (let i = 0; i < 3; i++) {
              const dotDist = -12 - i * 12 - flow;
              const size = Math.max(0.5, 3 - i * 0.8);
              ctx.beginPath();
              ctx.arc(dotDist, 0, size, 0, Math.PI * 2);
              ctx.fill();
            }

            ctx.restore();
          }
        }
      }

      // 11. Damage Texts
      if (state.damageTexts.length > 0) {
        ctx.textAlign = 'center';
        state.damageTexts.forEach(txt => {
          if (txt.life <= 0) return;
          if (txt.x < state.cameraX - 50 || txt.x > state.cameraX + viewWorldW + 50 ||
              txt.y < state.cameraY - 50 || txt.y > state.cameraY + viewWorldH + 50) return;
          ctx.globalAlpha = Math.max(0, Math.min(1.0, txt.life / 1.4));
          ctx.fillStyle = txt.color || '#f43f5e';
          ctx.font = `bold ${txt.isCrit ? '22px' : '18px'} sans-serif`;
          ctx.fillText(txt.text, txt.x, txt.y);
        });
        ctx.globalAlpha = 1.0;
      }

      // 11.5. Shockwaves (Standard & Crystalline Frost Nova Ring)
      state.shockwaves.forEach(s => {
        if (s.life <= 0) return;
        const maxR = s.maxR || 80;
        if (s.x + maxR < state.cameraX - 50 || s.x - maxR > state.cameraX + viewWorldW + 50 ||
            s.y + maxR < state.cameraY - 50 || s.y - maxR > state.cameraY + viewWorldH + 50) return;
        ctx.save();
        const alpha = Math.max(0, s.life / (s.maxLife || 1));
        ctx.globalAlpha = alpha;

        if (s.isFattyLandingHalo) {
          // Breathtaking Boss Landing Damage Shockwave Halo spanning to the 4 spiked pillars
          const currR = Math.max(0.1, s.r);
          const prog = Math.max(0, Math.min(1, 1 - alpha));

          // 1. Radiant Glowing Ground Lava/Plasma Field (Expanding translucent fiery disc)
          const haloGrad = ctx.createRadialGradient(s.x, s.y, currR * 0.15, s.x, s.y, currR);
          haloGrad.addColorStop(0, `rgba(254, 240, 138, ${0.45 * alpha})`); // Bright solar yellow center
          haloGrad.addColorStop(0.3, `rgba(249, 115, 22, ${0.35 * alpha})`); // Vivid fiery orange
          haloGrad.addColorStop(0.75, `rgba(239, 68, 68, ${0.22 * alpha})`); // Crimson red
          haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = haloGrad;
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR, 0, Math.PI * 2);
          ctx.fill();

          // 2. Thick Blazing Outer Wave Front (Primary Shockwave Wall with bloom)
          ctx.strokeStyle = `rgba(249, 115, 22, ${0.9 * alpha})`;
          ctx.lineWidth = Math.max(1.5, 6 * alpha);
          ctx.shadowColor = '#ef4444';
          ctx.shadowBlur = getShadowBlur(22 * alpha);
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR, 0, Math.PI * 2);
          ctx.stroke();

          // 3. Hot White-Yellow Core Shock Crest Line
          ctx.strokeStyle = `rgba(255, 255, 255, ${0.85 * alpha})`;
          ctx.lineWidth = Math.max(1, 2.5 * alpha);
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR * 0.96, 0, Math.PI * 2);
          ctx.stroke();

          // 4. Secondary Concentric Seismic Ripples (Inner harmonic dashed ring)
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.75 * alpha})`;
          ctx.lineWidth = Math.max(1, 3 * alpha);
          ctx.setLineDash([14, 8]);
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR * 0.72, -prog * 2, -prog * 2 + Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);

          // 5. Demonic / Titan Runic Shockwave Spikes along the expanding perimeter
          const spikeCount = 16;
          ctx.strokeStyle = `rgba(254, 215, 170, ${0.85 * alpha})`;
          ctx.lineWidth = Math.max(1, 2.2 * alpha);
          for (let sp = 0; sp < spikeCount; sp++) {
            const spAng = (sp / spikeCount) * Math.PI * 2 + prog * 0.6;
            const innerR = currR * 0.86;
            const outerR = currR * (sp % 2 === 0 ? 1.09 : 1.04);
            ctx.beginPath();
            ctx.moveTo(s.x + Math.cos(spAng) * innerR, s.y + Math.sin(spAng) * innerR);
            ctx.lineTo(s.x + Math.cos(spAng) * outerR, s.y + Math.sin(spAng) * outerR);
            ctx.stroke();

            // Radiant diamond spark on alternating spike tips
            if (sp % 2 === 0) {
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(s.x + Math.cos(spAng) * outerR, s.y + Math.sin(spAng) * outerR, 3.2 * alpha, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // 6. Ground Seismic Rupture Rays towards the 4 Spiked Pillars (Quadrant Fissures)
          const pillarRayAngles = [Math.PI * 0.25, Math.PI * 0.75, Math.PI * 1.25, Math.PI * 1.75];
          pillarRayAngles.forEach(ang => {
            ctx.strokeStyle = `rgba(239, 68, 68, ${0.75 * alpha})`;
            ctx.lineWidth = Math.max(1, 3.5 * alpha);
            ctx.beginPath();
            ctx.moveTo(s.x, s.y);
            ctx.lineTo(s.x + Math.cos(ang) * currR, s.y + Math.sin(ang) * currR);
            ctx.stroke();

            // Glowing energy nodes traveling out along the pillar rays
            const nodeDist = currR * 0.88;
            ctx.fillStyle = '#fef08a';
            ctx.beginPath();
            ctx.arc(s.x + Math.cos(ang) * nodeDist, s.y + Math.sin(ang) * nodeDist, 5 * alpha, 0, Math.PI * 2);
            ctx.fill();
          });
          ctx.shadowBlur = 0;
        } else if (s.isFrostNova) {
          // Beautiful Frost Nova Ice Circle with Radial Crystals & Glacial Field
          const currR = Math.max(0.1, s.r);

          // Translucent frosty inner glacial field
          ctx.fillStyle = `rgba(56, 189, 248, ${0.18 * alpha})`;
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR, 0, Math.PI * 2);
          ctx.fill();

          // Outer glowing cyan perimeter ring
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 4 * alpha;
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR, 0, Math.PI * 2);
          ctx.stroke();

          // Inner pure white crystalline ring
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2 * alpha;
          ctx.beginPath();
          ctx.arc(s.x, s.y, currR * 0.92, 0, Math.PI * 2);
          ctx.stroke();

          // Runic radial ice crystal spikes radiating out from center
          const spikes = 12;
          ctx.strokeStyle = '#bae6fd';
          ctx.lineWidth = 2.2 * alpha;
          for (let sp = 0; sp < spikes; sp++) {
            const spAng = (sp / spikes) * Math.PI * 2 + (1 - alpha) * 0.4;
            const innerSpikeR = currR * 0.4;
            const outerSpikeR = currR * (sp % 2 === 0 ? 1.08 : 0.94);
            ctx.beginPath();
            ctx.moveTo(s.x + Math.cos(spAng) * innerSpikeR, s.y + Math.sin(spAng) * innerSpikeR);
            ctx.lineTo(s.x + Math.cos(spAng) * outerSpikeR, s.y + Math.sin(spAng) * outerSpikeR);
            ctx.stroke();

            // Diamond ice crystal at spike tip
            if (sp % 2 === 0) {
              const tipX = s.x + Math.cos(spAng) * outerSpikeR;
              const tipY = s.y + Math.sin(spAng) * outerSpikeR;
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(tipX, tipY, 3.2 * alpha, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        } else {
          ctx.strokeStyle = s.color;
          ctx.lineWidth = 3.5 * s.life;
          ctx.beginPath();
          ctx.arc(s.x, s.y, Math.max(0.1, s.r), 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.restore();
      });

      // 11.6. Particles Rendering (Sparks, Embers & Fragments - Optimized)
      ctx.save();
      ctx.shadowBlur = 0;
      for (let i = 0; i < state.particles.length; i++) {
        const p = state.particles[i];
        if (p.life <= 0) continue;
        if (p.x < state.cameraX - 40 || p.x > state.cameraX + viewWorldW + 40 ||
            p.y < state.cameraY - 40 || p.y > state.cameraY + viewWorldH + 40) continue; // Tight Viewport Culling
        const alpha = Math.max(0, p.life / (p.maxLife || 1));
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;

        if (p.shape === 'spark') {
          const spLen = p.size * (1 + Math.min(3, Math.hypot(p.vx, p.vy) * 0.15));
          const ang = Math.atan2(p.vy, p.vx);
          const cosA = Math.cos(ang);
          const sinA = Math.sin(ang);
          const halfL = spLen * 0.5;
          const halfW = p.size * 0.5;
          ctx.beginPath();
          ctx.moveTo(p.x - halfL * cosA + halfW * sinA, p.y - halfL * sinA - halfW * cosA);
          ctx.lineTo(p.x + halfL * cosA + halfW * sinA, p.y + halfL * sinA - halfW * cosA);
          ctx.lineTo(p.x + halfL * cosA - halfW * sinA, p.y + halfL * sinA + halfW * cosA);
          ctx.lineTo(p.x - halfL * cosA - halfW * sinA, p.y - halfL * sinA + halfW * cosA);
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.beginPath();
          const currentSize = Math.max(0.5, p.size * (0.35 + 0.65 * alpha));
          ctx.arc(p.x, p.y, currentSize, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.restore();

      // 12. Highly Optimized Shortened Sword Slash Trail (Halved length, zero lag)
      if (state.swordTrail.length > 1) {
        ctx.save();
        const currentSpeedNorm = Math.min(1.0, Math.max(0.1, state.swordTipSpeed / 10.0));
        const glowCol = weaponRef.current.glowColor;
        const trailLen = state.swordTrail.length;
        const lastAlpha = state.swordTrail[trailLen - 1]?.alpha || 0.7;

        // Pass 1: Semi-transparent ribbon arc
        ctx.beginPath();
        ctx.moveTo(state.swordTrail[0].baseX, state.swordTrail[0].baseY);
        for (let i = 0; i < trailLen; i++) {
          ctx.lineTo(state.swordTrail[i].tipX, state.swordTrail[i].tipY);
        }
        for (let i = trailLen - 1; i >= 0; i--) {
          ctx.lineTo(state.swordTrail[i].baseX, state.swordTrail[i].baseY);
        }
        ctx.closePath();
        ctx.fillStyle = glowCol;
        ctx.globalAlpha = Math.min(0.45, 0.25 * lastAlpha);
        ctx.fill();

        // Pass 2: Single connected glowing blade tip arc line
        ctx.beginPath();
        ctx.moveTo(state.swordTrail[0].tipX, state.swordTrail[0].tipY);
        for (let i = 1; i < trailLen; i++) {
          ctx.lineTo(state.swordTrail[i].tipX, state.swordTrail[i].tipY);
        }
        ctx.strokeStyle = glowCol;
        ctx.lineWidth = 3.0 + currentSpeedNorm * 3.0;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.globalAlpha = Math.min(0.85, 0.5 * lastAlpha + 0.3 * currentSpeedNorm);
        ctx.stroke();

        ctx.restore();
      }

      // 12.2. Vampirism Dynamic Wavy Red Siphon Beam (0.15s dynamic red energy stream flowing from enemy into player)
      if (state.vampirismBeams.length > 0) {
        ctx.save();
        const px = state.player.x + state.player.w / 2;
        const py = state.player.y + state.player.h / 2;
        const nowMs = performance.now();

        state.vampirismBeams.forEach(beam => {
          if (beam.timer <= 0) return;
          const targetObj = beam.target;
          const tx = targetObj && targetObj.alive !== false && targetObj.x !== undefined ? targetObj.x : beam.targetX;
          const ty = targetObj && targetObj.alive !== false && targetObj.y !== undefined ? targetObj.y : beam.targetY;
          // Vector from target (enemy) to player (so t=0 is enemy, t=1 is player)
          const dx = px - tx;
          const dy = py - ty;
          const dist = Math.hypot(dx, dy);
          if (dist < 3) return;

          const angle = Math.atan2(dy, dx);
          const nx = -Math.sin(angle);
          const ny = Math.cos(angle);
          const alpha = Math.max(0, Math.min(1.0, beam.timer / beam.maxTimer));

          const segments = Math.max(12, Math.min(32, Math.floor(dist / 14)));
          const freq = Math.max(2, Math.floor(dist / 38));
          const wavePhase = (nowMs * 0.045) % (Math.PI * 2);
          const amp = 8.5;

          // Pass 1: Crimson outer energy aura (traveling towards player)
          ctx.beginPath();
          for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const baseLx = tx + dx * t;
            const baseLy = ty + dy * t;
            const envelope = Math.sin(t * Math.PI); // Anchors precisely at centers on both ends
            const waveOffset = Math.sin(t * freq * Math.PI * 2 - wavePhase) * amp * envelope;
            const sx = baseLx + nx * waveOffset;
            const sy = baseLy + ny * waveOffset;
            if (i === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          }
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.4 * alpha})`;
          ctx.lineWidth = 5.5;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.stroke();

          // Pass 2: Vivid glowing red beam core
          ctx.beginPath();
          for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const baseLx = tx + dx * t;
            const baseLy = ty + dy * t;
            const envelope = Math.sin(t * Math.PI);
            const waveOffset = Math.sin(t * freq * Math.PI * 2 - wavePhase) * amp * envelope;
            const sx = baseLx + nx * waveOffset;
            const sy = baseLy + ny * waveOffset;
            if (i === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          }
          ctx.strokeStyle = `rgba(244, 63, 94, ${0.9 * alpha})`;
          ctx.lineWidth = 2.6;
          ctx.stroke();

          // Pass 3: Bright white-pink inner core
          ctx.beginPath();
          for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const baseLx = tx + dx * t;
            const baseLy = ty + dy * t;
            const envelope = Math.sin(t * Math.PI);
            const waveOffset = Math.sin(t * freq * Math.PI * 2 - wavePhase) * amp * envelope;
            const sx = baseLx + nx * waveOffset;
            const sy = baseLy + ny * waveOffset;
            if (i === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          }
          ctx.strokeStyle = `rgba(254, 226, 226, ${0.95 * alpha})`;
          ctx.lineWidth = 1.1;
          ctx.stroke();

          // Pass 4: Siphon globules traveling directly from enemy into player's body
          for (let orbIdx = 0; orbIdx < 3; orbIdx++) {
            const orbT = ((nowMs * 0.0035 + orbIdx * 0.33) % 1);
            const orbBaseX = tx + dx * orbT;
            const orbBaseY = ty + dy * orbT;
            const orbEnv = Math.sin(orbT * Math.PI);
            const orbOffset = Math.sin(orbT * freq * Math.PI * 2 - wavePhase) * amp * orbEnv;
            const ox = orbBaseX + nx * orbOffset;
            const oy = orbBaseY + ny * orbOffset;

            ctx.fillStyle = `rgba(254, 205, 211, ${0.9 * alpha})`;
            ctx.beginPath();
            ctx.arc(ox, oy, 2.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = `rgba(244, 63, 94, ${0.55 * alpha})`;
            ctx.beginPath();
            ctx.arc(ox, oy, 4.5, 0, Math.PI * 2);
            ctx.fill();
          }
        });

        ctx.restore();
      }

      // 12.3. Chain Lightning Arcs (Refined electrifying neon-cyan & white multi-ray plasma discharge)
      if (state.lightningArcs.length > 0) {
        ctx.save();
        state.lightningArcs.forEach(arc => {
          if (arc.timer <= 0) return;
          const alpha = Math.max(0, Math.min(1.0, arc.timer / arc.maxTimer));
          const flicker = 0.84 + Math.random() * 0.16;
          const totalAlpha = alpha * flicker;

          // 1. Draw Sub-branches (Lightning forks branching into air)
          if (arc.branches) {
            arc.branches.forEach(br => {
              if (br.segments.length < 2) return;
              ctx.beginPath();
              ctx.moveTo(br.segments[0].x, br.segments[0].y);
              for (let i = 1; i < br.segments.length; i++) {
                ctx.lineTo(br.segments[i].x, br.segments[i].y);
              }
              // Outer glow
              ctx.strokeStyle = `rgba(0, 240, 255, ${0.40 * totalAlpha * (br.alpha || 1)})`;
              ctx.lineWidth = 2.5 * (br.width || 1);
              ctx.lineCap = 'round';
              ctx.stroke();

              // Inner core
              ctx.strokeStyle = `rgba(255, 255, 255, ${0.80 * totalAlpha * (br.alpha || 1)})`;
              ctx.lineWidth = 1.0 * (br.width || 1);
              ctx.stroke();
            });
          }

          // 2. Draw Secondary Intertwined Lightning Ray
          if (arc.secondaryRays) {
            arc.secondaryRays.forEach(ray => {
              if (ray.length < 2) return;
              ctx.beginPath();
              ctx.moveTo(ray[0].x, ray[0].y);
              for (let i = 1; i < ray.length; i++) {
                ctx.lineTo(ray[i].x, ray[i].y);
              }
              // Outer aura
              ctx.strokeStyle = `rgba(6, 182, 212, ${0.35 * totalAlpha})`;
              ctx.lineWidth = 5.0;
              ctx.lineCap = 'round';
              ctx.lineJoin = 'round';
              ctx.stroke();

              // Plasma streak
              ctx.strokeStyle = `rgba(165, 243, 252, ${0.70 * totalAlpha})`;
              ctx.lineWidth = 2.0;
              ctx.stroke();

              // White center
              ctx.strokeStyle = `rgba(255, 255, 255, ${0.85 * totalAlpha})`;
              ctx.lineWidth = 0.9;
              ctx.stroke();
            });
          }

          // 3. Draw Crisp Main Bolt
          const segs = arc.mainSegments || arc.segments;
          if (segs && segs.length >= 2) {
            // Pass 1: Outer Cyan Glow Aura
            ctx.beginPath();
            ctx.moveTo(segs[0].x, segs[0].y);
            for (let i = 1; i < segs.length; i++) {
              ctx.lineTo(segs[i].x, segs[i].y);
            }
            ctx.strokeStyle = `rgba(0, 240, 255, ${0.48 * totalAlpha})`;
            ctx.lineWidth = 13;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.shadowColor = '#00f0ff';
            ctx.shadowBlur = getShadowBlur(16);
            ctx.stroke();

            // Pass 2: High-voltage Electric Cyan Plasma Beam
            ctx.strokeStyle = `rgba(56, 189, 248, ${0.80 * totalAlpha})`;
            ctx.lineWidth = 6.5;
            ctx.shadowBlur = getShadowBlur(8);
            ctx.stroke();

            // Pass 3: Radiant Sky Blue Core
            ctx.strokeStyle = `rgba(186, 230, 253, ${0.90 * totalAlpha})`;
            ctx.lineWidth = 3.2;
            ctx.stroke();

            // Pass 4: Blinding White Plasma Center
            ctx.strokeStyle = `rgba(255, 255, 255, ${1.0 * totalAlpha})`;
            ctx.lineWidth = 1.6;
            ctx.shadowBlur = 0;
            ctx.stroke();
          }

          // 4. Source and Target Electric Plasma Spheres / Discharge Nodes
          [ { x: arc.x1, y: arc.y1, r: 8 }, { x: arc.x2, y: arc.y2, r: 10 } ].forEach(node => {
            const grad = ctx.createRadialGradient(node.x, node.y, 1, node.x, node.y, node.r * (0.8 + 0.2 * totalAlpha));
            grad.addColorStop(0, `rgba(255, 255, 255, ${0.90 * totalAlpha})`);
            grad.addColorStop(0.35, `rgba(56, 189, 248, ${0.75 * totalAlpha})`);
            grad.addColorStop(0.7, `rgba(0, 240, 255, ${0.35 * totalAlpha})`);
            grad.addColorStop(1, `rgba(0, 240, 255, 0)`);
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(node.x, node.y, node.r * (0.8 + 0.2 * totalAlpha), 0, Math.PI * 2);
            ctx.fill();
          });
        });
        ctx.restore();
      }

      // 12.5. Flame Waves Rendering
      state.flameWaves.forEach(fw => {
        if (!fw.alive) return;
        ctx.save();
        ctx.translate(fw.x, fw.y);

        const dir = fw.vx >= 0 ? 1 : -1;
        ctx.scale(dir, 1);

        // Outer Blazing Flame Crescent Arc
        ctx.fillStyle = '#f97316';
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = getShadowBlur(24);
        ctx.beginPath();
        ctx.arc(0, 0, 36, -Math.PI * 0.42, Math.PI * 0.42);
        ctx.quadraticCurveTo(-18, 0, 0, -Math.PI * 0.42);
        ctx.fill();

        // Inner White-Hot Flame Core
        ctx.fillStyle = '#fef08a';
        ctx.shadowColor = '#f97316';
        ctx.shadowBlur = getShadowBlur(12);
        ctx.beginPath();
        ctx.arc(5, 0, 20, -Math.PI * 0.35, Math.PI * 0.35);
        ctx.quadraticCurveTo(-6, 0, 5, -Math.PI * 0.35);
        ctx.fill();

        ctx.restore();
      });

      // 13. Player & Equipped Sword
      let swordAngle = 0;
      if (state.player.alive && state.ropePoints.length > 1) {
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 12;
        ctx.moveTo(state.ropePoints[0].x, state.ropePoints[0].y);
        for (let i = 1; i < state.ropePoints.length; i++) ctx.lineTo(state.ropePoints[i].x, state.ropePoints[i].y);
        ctx.stroke();

        const last = state.ropePoints[state.ropePoints.length - 1];
        const prev = state.ropePoints[state.ropePoints.length - 2];
        swordAngle = Math.atan2(last.y - prev.y, last.x - prev.x);

        ctx.save();
        ctx.translate(last.x, last.y);
        ctx.rotate(swordAngle - Math.PI / 2);

        const wLen = weaponRef.current?.length || 18;
        const wType = weaponRef.current?.type || 'fist';
        const isUnarmed = !weaponRef.current || wType === 'fist';
        const wColor = weaponRef.current?.color || '#38bdf8';
        const wGlow = weaponRef.current?.glowColor || '#0284c7';

        if (isUnarmed) {
          // --- BARE FIST (Кулачок на конце руки) ---
          const isSlowed = state.player.slowTimer > 0;
          const bodyColor = isSlowed ? '#38bdf8' : '#f43f5e';
          const shadowKnuckleColor = isSlowed ? '#0284c7' : '#e11d48';
          const creaseColor = isSlowed ? '#0369a1' : '#9f1239';
          const thumbColor = isSlowed ? '#7dd3fc' : '#fb7185';

          // 1. Wrist Cuff / Wrap
          ctx.fillStyle = shadowKnuckleColor;
          ctx.beginPath();
          ctx.roundRect(-6.5, -4, 13, 5, 2);
          ctx.fill();

          // 2. Main Clenched Fist Body (Palm / Back of Hand)
          ctx.fillStyle = bodyColor;
          ctx.beginPath();
          ctx.roundRect(-7.5, 0, 15, 12, 3);
          ctx.fill();

          // 3. Four Rounded Knuckles across front strike face
          ctx.fillStyle = shadowKnuckleColor;
          // Pinky knuckle
          ctx.beginPath();
          ctx.arc(-5.2, 11, 2.2, 0, Math.PI * 2);
          ctx.fill();
          // Ring finger knuckle
          ctx.beginPath();
          ctx.arc(-1.7, 12.2, 2.5, 0, Math.PI * 2);
          ctx.fill();
          // Middle finger knuckle
          ctx.beginPath();
          ctx.arc(1.7, 12.2, 2.5, 0, Math.PI * 2);
          ctx.fill();
          // Index finger knuckle
          ctx.beginPath();
          ctx.arc(5.2, 11, 2.2, 0, Math.PI * 2);
          ctx.fill();

          // 4. Folded Thumb across the side
          ctx.fillStyle = thumbColor;
          ctx.beginPath();
          ctx.ellipse(-5.2, 4.5, 3.0, 4.5, -0.4, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = shadowKnuckleColor;
          ctx.lineWidth = 1.0;
          ctx.stroke();

          // 5. Knuckle Creases / Finger divider lines
          ctx.strokeStyle = creaseColor;
          ctx.lineWidth = 1.0;
          ctx.beginPath();
          ctx.moveTo(-3.5, 4);
          ctx.lineTo(-3.5, 10);
          ctx.moveTo(0, 4);
          ctx.lineTo(0, 10.5);
          ctx.moveTo(3.5, 4);
          ctx.lineTo(3.5, 10);
          ctx.stroke();

          // 6. Highlight Glint Reflections on middle knuckles
          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.beginPath();
          ctx.arc(-1.7, 11.2, 1.0, 0, Math.PI * 2);
          ctx.arc(1.7, 11.2, 1.0, 0, Math.PI * 2);
          ctx.fill();

          ctx.shadowBlur = 0;
          ctx.restore();
        } else {
          // --- EQUIPPED WEAPON RENDERING ---
          // Outer elemental aura
          ctx.shadowColor = wGlow;
          ctx.shadowBlur = getShadowBlur(12);

          // 1. Handle & Pommel (common base with type variations)
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(-3.5, -18, 7, 18); // Handle grip

        // Leather grip wrap lines
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1;
        for (let gy = -16; gy < 0; gy += 4) {
          ctx.beginPath();
          ctx.moveTo(-3.5, gy);
          ctx.lineTo(3.5, gy + 2);
          ctx.stroke();
        }

        // Ornate Gemmed Pommel
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, -20, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 1;
        ctx.stroke();

        if (wType === 'axe') {
          const rarity = weaponRef.current?.rarity || 'common';
          const weaponKey = weaponRef.current?.id || weaponRef.current?.name || 'player_axe';
          const axeImg = getAxeAsset(rarity, weaponKey);

          ctx.save();
          ctx.translate(0, ((wLen - 16) / 2) * 0.9);
          ctx.rotate(Math.PI); // Rotate 180 degrees per requirement
          ctx.shadowColor = wGlow;
          ctx.shadowBlur = getShadowBlur(12);
          if (axeImg && axeImg.complete && axeImg.naturalWidth > 0) {
            const aspect = axeImg.naturalWidth / axeImg.naturalHeight || 0.8;
            const totalH = (wLen + 20) * 0.9; // 10% smaller axe in hand
            const axeW = Math.round(totalH * aspect * 1.1);
            ctx.drawImage(axeImg, -axeW / 2, -totalH / 2, axeW, totalH);
          } else {
            ctx.fillStyle = wColor;
            ctx.fillRect(-5.4, (-wLen / 2) * 0.9, 10.8, wLen * 0.9);
          }
          ctx.shadowBlur = 0;
          ctx.restore();

        } else if (wType === 'hammer') {
          const rarity = weaponRef.current?.rarity || 'common';
          const weaponKey = weaponRef.current?.id || weaponRef.current?.name || 'player_hammer';
          const hammerImg = getHammerAsset(rarity, weaponKey);

          ctx.save();
          ctx.translate(0, ((wLen - 12) / 2) * 0.9);
          ctx.rotate(Math.PI); // Rotate 180 degrees per requirement
          ctx.shadowColor = wGlow;
          ctx.shadowBlur = getShadowBlur(12);
          if (hammerImg && hammerImg.complete && hammerImg.naturalWidth > 0) {
            const aspect = hammerImg.naturalWidth / hammerImg.naturalHeight || 1;
            const totalH = (wLen + 20) * 0.9; // 10% smaller hammer in hand
            const hammerW = Math.round(totalH * aspect * 1.1);
            ctx.drawImage(hammerImg, -hammerW / 2, -totalH / 2, hammerW, totalH);
          } else {
            ctx.fillStyle = wColor;
            ctx.fillRect(-5.4, (-wLen / 2) * 0.9, 10.8, wLen * 0.9);
          }
          ctx.shadowBlur = 0;
          ctx.restore();

        } else if (wType === 'spear') {
          const rarity = weaponRef.current?.rarity || 'common';
          const weaponKey = weaponRef.current?.id || weaponRef.current?.name || 'player_spear';
          const spearImg = getSpearAsset(rarity, weaponKey);

          ctx.save();
          ctx.translate(0, (wLen - 16) / 2);
          ctx.scale(1, -1);
          ctx.shadowColor = wGlow;
          ctx.shadowBlur = getShadowBlur(12);
          if (spearImg && spearImg.complete && spearImg.naturalWidth > 0) {
            const aspect = spearImg.naturalWidth / spearImg.naturalHeight || 0.16;
            const totalH = wLen + 32;
            const spearW = Math.round(totalH * aspect * 1.12 * 0.90); // 10% thinner spear in hand
            ctx.drawImage(spearImg, -spearW / 2, -totalH / 2, spearW, totalH);
          } else {
            ctx.fillStyle = wColor;
            ctx.fillRect(-2.7, -wLen/2, 5.4, wLen);
          }
          ctx.shadowBlur = 0;
          ctx.restore();

        } else {
          // All swords, greatswords, katanas, rapiers, daggers, etc.
          const rarity = weaponRef.current?.rarity || 'common';
          const weaponKey = weaponRef.current?.id || weaponRef.current?.name || 'player_sword';
          const swordImg = getSwordAsset(rarity, weaponKey);

          ctx.save();
          ctx.translate(0, (wLen - 16) / 2);
          ctx.rotate(Math.PI); // Rotate 180 degrees per requirement
          ctx.shadowColor = wGlow;
          ctx.shadowBlur = getShadowBlur(12);
          if (swordImg && swordImg.complete && swordImg.naturalWidth > 0) {
            const aspect = swordImg.naturalWidth / swordImg.naturalHeight || 0.3;
            const totalH = wLen + 20;
            const swordW = Math.round(totalH * aspect * 1.1);
            ctx.drawImage(swordImg, -swordW / 2, -totalH / 2, swordW, totalH);
          } else {
            ctx.fillStyle = wColor;
            ctx.fillRect(-4, -wLen/2, 8, wLen);
          }
          ctx.shadowBlur = 0;
          ctx.restore();
        }

        // Elemental Particle Emitter along blade tip/edges
        if (Math.random() < 0.175) {
          const randY = 10 + Math.random() * (wLen - 10);
          const pColor = weaponRef.current.element === 'fire' ? '#f97316'
            : weaponRef.current.element === 'ice' ? '#38bdf8'
            : weaponRef.current.element === 'wind' ? '#a7f3d0'
            : weaponRef.current.element === 'chaos' ? '#c084fc'
            : '#fef08a';

          state.particles.push({
            x: last.x + Math.cos(swordAngle) * randY + (Math.random() - 0.5) * 6,
            y: last.y + Math.sin(swordAngle) * randY + (Math.random() - 0.5) * 6,
            vx: (Math.random() - 0.5) * 3,
            vy: (Math.random() - 0.5) * 3,
            life: 0.4,
            maxLife: 0.4,
            color: pColor,
            size: Math.random() * 2.5 + 1.5
          });
        }

        ctx.shadowBlur = 0;
        ctx.restore();
        }
      }

      // 14. Highly Detailed Player Character with Eyes Tracking Movement Direction (if alive)
      if (state.player.alive) {
        // Player Ground Drop Shadow
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(state.player.x + state.player.w / 2, state.player.y + state.player.h, state.player.w * 0.7, 5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        ctx.save();
        ctx.translate(state.player.x + state.player.w / 2, state.player.y + state.player.h / 2);
        ctx.rotate(state.player.angle);

        if (state.player.invincible > 0 && Math.floor(Date.now() / 100) % 2 === 0) ctx.globalAlpha = 0.4;

        // Determine gaze direction strictly based on player motion / keys (not sword)
        const lookDirX = Math.abs(state.player.vx) > 0.3 
          ? Math.sign(state.player.vx) 
          : (state.keys.right ? 1 : state.keys.left ? -1 : 1);
        const lookDirY = state.player.vy < -1.5 ? -0.8 : (state.player.vy > 1.5 ? 0.8 : 0);

        // Main Body
        ctx.fillStyle = state.player.slowTimer > 0 ? '#38bdf8' : '#f43f5e';
        ctx.fillRect(-state.player.w / 2, -state.player.h / 2, state.player.w, state.player.h);

        // --- EXPRESSIVE EYES LOOKING IN DIRECTION OF MOVEMENT ---
        const eyeBaseY = -2;
        const eyeSpacing = 6;
        const eyeOffsetX = lookDirX * 3.2;
        const eyeOffsetY = lookDirY * 2.2;

        // Eye White Sclera (Left & Right)
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(-eyeSpacing + (lookDirX * 1.5), eyeBaseY, 4.5, 4, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(eyeSpacing + (lookDirX * 1.5), eyeBaseY, 4.5, 4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Eye Pupils looking actively in movement / aim direction
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(-eyeSpacing + eyeOffsetX, eyeBaseY + eyeOffsetY, 2.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(eyeSpacing + eyeOffsetX, eyeBaseY + eyeOffsetY, 2.2, 0, Math.PI * 2);
        ctx.fill();

        // Glint specular reflections
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-eyeSpacing + eyeOffsetX - 0.7, eyeBaseY + eyeOffsetY - 0.7, 0.9, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(eyeSpacing + eyeOffsetX - 0.7, eyeBaseY + eyeOffsetY - 0.7, 0.9, 0, Math.PI * 2);
        ctx.fill();

        // Aegis Shield Active Barrier Aura
        const aegisSkill = skillsRef.current.find(s => s.id === 'aegis_shield');
        if (aegisSkill && aegisSkill.isActive) {
          ctx.strokeStyle = '#34d399';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(0, 0, 34, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.restore(); // Restore Player translation

        // Draw Health Bar & HP Number above player's head (identical to enemy health bar)
        ctx.save();
        const pBarW = 40;
        const pBarH = 5;
        const pBarX = state.player.x + state.player.w / 2 - pBarW / 2;
        const pBarY = state.player.y - 12;
        const playerHpPct = Math.min(1, Math.max(0, state.player.hp / state.player.maxHp));

        // HP Number text above player bar
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
        ctx.lineWidth = 2.5;
        ctx.strokeText(String(Math.max(0, Math.ceil(state.player.hp))), state.player.x + state.player.w / 2, pBarY - 2);
        ctx.fillStyle = '#ef4444';
        ctx.fillText(String(Math.max(0, Math.ceil(state.player.hp))), state.player.x + state.player.w / 2, pBarY - 2);

        // Bar Background
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(pBarX, pBarY, pBarW, pBarH);

        // Bar Fill (Red)
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(pBarX, pBarY, playerHpPct * pBarW, pBarH);

        // Bar Border
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 1.0;
        ctx.strokeRect(pBarX, pBarY, pBarW, pBarH);
        ctx.restore();
      }

      // 14c. 2.5D Isometric Foreground Occluders (Rendered in front of Player when walking behind decorations/columns/chests)
      if (deferredForegroundObjects.length > 0) {
        deferredForegroundObjects.sort((a, b) => {
          const zA = a.item?.zIndex;
          const zB = b.item?.zIndex;
          if (zA !== undefined && zB !== undefined) return zA - zB;
          return a.baseY - b.baseY;
        });
        deferredForegroundObjects.forEach(obj => {
          if (obj.type === 'dec') {
            renderSingleDecoration(obj.item, 'body');
          } else if (obj.type === 'chest') {
            renderSingleChest(obj.item, 'body');
          } else if (obj.type === 'column') {
            renderSingleSpikedColumn(obj.item, obj.isRetracting, 'body');
          } else if (obj.type === 'corner_pillar') {
            renderSingleCornerPillar(obj.item, obj.isRetracting, 'body');
          }
        });
      }

      // 14b. Yellow Pillar of Light for Level-Up (Extends straight up to the heavens)
      state.levelUpBeams.forEach(beam => {
        if (beam.timer <= 0) return;
        ctx.save();
        const prog = beam.timer / beam.maxTimer; // 1 -> 0
        const alpha = Math.sin(prog * Math.PI); // Smooth surge in and out

        const beamW = 54 + (1 - prog) * 20;
        const beamH = 1400;
        const bottomY = beam.y;
        const topY = bottomY - beamH;

        // Outer ambient golden radiance
        const outerGrad = ctx.createLinearGradient(beam.x - beamW * 1.5, 0, beam.x + beamW * 1.5, 0);
        outerGrad.addColorStop(0, 'rgba(234, 179, 8, 0)');
        outerGrad.addColorStop(0.3, `rgba(234, 179, 8, ${alpha * 0.35})`);
        outerGrad.addColorStop(0.5, `rgba(250, 204, 21, ${alpha * 0.6})`);
        outerGrad.addColorStop(0.7, `rgba(234, 179, 8, ${alpha * 0.35})`);
        outerGrad.addColorStop(1, 'rgba(234, 179, 8, 0)');

        ctx.fillStyle = outerGrad;
        ctx.fillRect(beam.x - beamW * 1.5, topY, beamW * 3, beamH);

        // Inner intense radiant golden-white core pillar
        const coreGrad = ctx.createLinearGradient(beam.x - beamW * 0.5, 0, beam.x + beamW * 0.5, 0);
        coreGrad.addColorStop(0, 'rgba(250, 204, 21, 0)');
        coreGrad.addColorStop(0.2, `rgba(253, 224, 71, ${alpha * 0.85})`);
        coreGrad.addColorStop(0.5, `rgba(255, 255, 255, ${alpha * 0.98})`);
        coreGrad.addColorStop(0.8, `rgba(253, 224, 71, ${alpha * 0.85})`);
        coreGrad.addColorStop(1, 'rgba(250, 204, 21, 0)');

        ctx.fillStyle = coreGrad;
        ctx.fillRect(beam.x - beamW * 0.5, topY, beamW, beamH);

        // Expanding Ground Runic Golden Shockwave Rings
        const ringRadius = (1 - prog) * 90;
        ctx.strokeStyle = `rgba(254, 240, 138, ${alpha * 0.85})`;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.ellipse(beam.x, bottomY, ringRadius, ringRadius * 0.35, 0, 0, Math.PI * 2);
        ctx.stroke();

        const ringRadius2 = ((1 - prog) * 125) % 90;
        ctx.strokeStyle = `rgba(250, 204, 21, ${alpha * 0.55})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(beam.x, bottomY, ringRadius2, ringRadius2 * 0.35, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.restore();
      });

      // --- SCENE-WIDE VOLUMETRIC GOD RAYS (Half as many: spacing 640) ---
      ctx.save();
      const nowMs = performance.now();
      const startX = Math.floor((state.cameraX - 300) / 640) * 640;
      const endX = state.cameraX + viewWorldW + 300;

      for (let worldX = startX; worldX < endX; worldX += 640) {
        const seed = Math.abs(Math.sin(worldX * 0.05) * 10000) % 100;
        const topX = worldX + (seed % 140);
        const topY = state.cameraY - 100;
        const bottomY = state.cameraY + viewWorldH + 200;
        const slantX = topX + 140 + (seed % 60);
        const beamW = 110 + (seed % 70);

        const pulseAlpha = 0.08 + Math.sin(nowMs * 0.0012 + seed) * 0.028;

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(topX - beamW * 0.3, topY);
        ctx.lineTo(topX + beamW * 0.3, topY);
        ctx.lineTo(slantX + beamW * 0.8, bottomY);
        ctx.lineTo(slantX - beamW * 0.8, bottomY);
        ctx.closePath();

        const isGold = (seed % 2 === 0);
        const colorRgb = isGold ? '254, 240, 138' : '224, 231, 255'; // Celestial gold or spectral blue

        const rayGrad = ctx.createLinearGradient(topX, topY, slantX, bottomY);
        rayGrad.addColorStop(0, `rgba(${colorRgb}, ${pulseAlpha * 1.9})`);
        rayGrad.addColorStop(0.35, `rgba(${colorRgb}, ${pulseAlpha * 1.4})`);
        rayGrad.addColorStop(0.7, `rgba(${colorRgb}, ${pulseAlpha * 0.5})`);
        rayGrad.addColorStop(1, `rgba(${colorRgb}, 0.0)`);

        ctx.fillStyle = rayGrad;
        ctx.fill();

        // Drifting dust motes in light beam across the scene (4x slower)
        for (let m = 0; m < 4; m++) {
          const moteT = ((nowMs * 0.0000625 + seed * 0.15 + m * 0.25) % 1.0);
          const moteX = topX + (slantX - topX) * moteT + (Math.sin(moteT * Math.PI * 4 + m) * 16);
          const moteY = topY + (bottomY - topY) * moteT;
          const moteAlpha = Math.sin(moteT * Math.PI) * pulseAlpha * 3.5;

          ctx.fillStyle = `rgba(255, 255, 255, ${moteAlpha})`;
          ctx.beginPath();
          ctx.arc(moteX, moteY, 1.9, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }
      ctx.restore();

      ctx.restore(); // Restore Camera

      // 15. Level Overlay Text Banner (e.g. "Уровень 1" glowing banner fading out)
      if (state.levelText.active && state.levelText.alpha > 0) {
        ctx.save();
        const bannerAlpha = Math.min(1.0, state.levelText.alpha);
        ctx.globalAlpha = bannerAlpha;

        const midX = viewWorldW / 2;
        const midY = viewWorldH * 0.28;

        // Dark translucent backing strip
        const bannerW = 440;
        const bannerH = 74;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(midX - bannerW / 2, midY - bannerH / 2, bannerW, bannerH);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.strokeRect(midX - bannerW / 2, midY - bannerH / 2, bannerW, bannerH);

        ctx.font = '900 28px system-ui, -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = getShadowBlur(20);
        ctx.fillStyle = '#ffffff';
        ctx.fillText(state.levelText.msg.toUpperCase(), midX, midY);

        ctx.shadowBlur = 0;
        ctx.restore();
      }

      // Black Fade & Materialization Overlay (Topmost full-screen pure black transition)
      if (state.blackFadeAlpha > 0) {
        ctx.save();
        ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(1.0, state.blackFadeAlpha)})`;
        ctx.fillRect(-20, -20, viewWorldW + 40, viewWorldH + 40);
        ctx.restore();
      }

      ctx.restore(); // Restore global camera zoom scale
    };

    let isDrawingPaused = false;
    const frame = (time: number) => {
      let dt = time - lastTime;
      if (dt > 100) dt = 100;
      lastTime = time;

      if (!isPausedRef.current) {
        update(dt);
        draw();
        isDrawingPaused = false;
      } else {
        // While game is paused / inventory open, render exactly once to freeze the scene, then idle
        if (!isDrawingPaused) {
          update(0);
          draw();
          isDrawingPaused = true;
        }
      }
      animationFrameId = requestAnimationFrame(frame);
    };

    animationFrameId = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);

  // Dynamic Floating Joystick touch listeners (Direct DOM Ref updates)
  const handleTouchStartMove = (e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    if (!touch) return;

    // Check if player clicked/tapped on dropped loot to pick it up
    if (collectLootRef.current(touch.clientX, touch.clientY)) {
      return;
    }

    gameStateRef.current.touchIds.move = touch.identifier;

    const minX = 64;
    const maxX = Math.max(minX + 20, (window.innerWidth / 2) - 30);
    const minY = 64;
    const maxY = Math.max(minY + 20, window.innerHeight - 64);

    const clampedBaseX = Math.max(minX, Math.min(maxX, touch.clientX));
    const clampedBaseY = Math.max(minY, Math.min(maxY, touch.clientY));

    moveOriginRef.current = { x: clampedBaseX, y: clampedBaseY };

    let dx = touch.clientX - clampedBaseX;
    let dy = touch.clientY - clampedBaseY;
    const dist = Math.hypot(dx, dy);
    const maxRadius = 45;
    const clampedDist = Math.min(maxRadius, dist);
    const ang = Math.atan2(dy, dx);
    const stickX = Math.cos(ang) * clampedDist;
    const stickY = Math.sin(ang) * clampedDist;

    gameStateRef.current.keys.left = dx < -14;
    gameStateRef.current.keys.right = dx > 14;
    gameStateRef.current.keys.down = dy > 24;
    gameStateRef.current.keys.up = dy < -16;

    updateMoveStickUI(true, clampedBaseX, clampedBaseY, stickX, stickY);
  };

  const handleTouchMoveJoystick = (e: React.TouchEvent) => {
    e.preventDefault();
    let touch: React.Touch | undefined;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === gameStateRef.current.touchIds.move) {
        touch = e.touches[i];
        break;
      }
    }
    if (!touch) return;

    let dx = touch.clientX - moveOriginRef.current.x;
    let dy = touch.clientY - moveOriginRef.current.y;
    const dist = Math.hypot(dx, dy);
    const maxRadius = 45;
    const clampedDist = Math.min(maxRadius, dist);
    const ang = Math.atan2(dy, dx);
    const stickX = Math.cos(ang) * clampedDist;
    const stickY = Math.sin(ang) * clampedDist;

    const isUp = dy < -16;
    const wasUp = gameStateRef.current.keys.up;

    gameStateRef.current.keys.left = dx < -14;
    gameStateRef.current.keys.right = dx > 14;
    gameStateRef.current.keys.down = dy > 24;
    gameStateRef.current.keys.up = isUp;

    if (wasUp && !isUp && gameStateRef.current.player.vy < 0) {
      gameStateRef.current.player.vy = Math.max(gameStateRef.current.player.vy * 0.35, -2);
    }

    updateMoveStickUI(true, moveOriginRef.current.x, moveOriginRef.current.y, stickX, stickY);
  };

  const handleTouchEndMove = (e: React.TouchEvent) => {
    let touch: React.Touch | undefined;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === gameStateRef.current.touchIds.move) {
        touch = e.changedTouches[i];
        break;
      }
    }
    if (!touch && e.touches.length > 0) {
      for (let i = 0; i < e.touches.length; i++) {
        if (e.touches[i].identifier === gameStateRef.current.touchIds.move) return;
      }
    }
    if (gameStateRef.current.player.vy < 0) {
      gameStateRef.current.player.vy = Math.max(gameStateRef.current.player.vy * 0.35, -2);
    }
    gameStateRef.current.touchIds.move = null;
    gameStateRef.current.keys.left = false;
    gameStateRef.current.keys.right = false;
    gameStateRef.current.keys.up = false;
    gameStateRef.current.keys.down = false;
    updateMoveStickUI(false, 0, 0, 0, 0);
  };

  const handleTouchStartSword = (e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    if (!touch) return;

    // Check if player clicked/tapped on dropped loot to pick it up
    if (collectLootRef.current(touch.clientX, touch.clientY)) {
      return;
    }

    gameStateRef.current.touchIds.sword = touch.identifier;

    const minX = Math.min(window.innerWidth - 64, (window.innerWidth / 2) + 30);
    const maxX = window.innerWidth - 64;
    const minY = 64;
    const maxY = Math.max(minY + 20, window.innerHeight - 64);

    const clampedBaseX = Math.max(minX, Math.min(maxX, touch.clientX));
    const clampedBaseY = Math.max(minY, Math.min(maxY, touch.clientY));

    swordOriginRef.current = { x: clampedBaseX, y: clampedBaseY };

    let dx = touch.clientX - clampedBaseX;
    let dy = touch.clientY - clampedBaseY;
    const dist = Math.hypot(dx, dy);
    const maxRadius = 45;
    const clampedDist = Math.min(maxRadius, dist);
    const ang = Math.atan2(dy, dx);
    const stickX = Math.cos(ang) * clampedDist;
    const stickY = Math.sin(ang) * clampedDist;

    if (dist > 6) {
      gameStateRef.current.isJoystickActive = true;
      gameStateRef.current.isSwordMoving = true;
      gameStateRef.current.targetSwordAngle = ang;
    }
    updateSwordStickUI(true, clampedBaseX, clampedBaseY, stickX, stickY, ang);
  };

  const handleTouchMoveSword = (e: React.TouchEvent) => {
    e.preventDefault();
    let touch: React.Touch | undefined;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === gameStateRef.current.touchIds.sword) {
        touch = e.touches[i];
        break;
      }
    }
    if (!touch) return;

    let dx = touch.clientX - swordOriginRef.current.x;
    let dy = touch.clientY - swordOriginRef.current.y;
    const dist = Math.hypot(dx, dy);
    const maxRadius = 45;
    const clampedDist = Math.min(maxRadius, dist);
    const ang = Math.atan2(dy, dx);
    const stickX = Math.cos(ang) * clampedDist;
    const stickY = Math.sin(ang) * clampedDist;

    if (dist > 6) {
      gameStateRef.current.isJoystickActive = true;
      gameStateRef.current.isSwordMoving = true;
      gameStateRef.current.targetSwordAngle = ang;
    }
    updateSwordStickUI(true, swordOriginRef.current.x, swordOriginRef.current.y, stickX, stickY, ang);
  };

  const handleTouchEndSword = (e: React.TouchEvent) => {
    let touch: React.Touch | undefined;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === gameStateRef.current.touchIds.sword) {
        touch = e.changedTouches[i];
        break;
      }
    }
    if (!touch && e.touches.length > 0) {
      for (let i = 0; i < e.touches.length; i++) {
        if (e.touches[i].identifier === gameStateRef.current.touchIds.sword) return;
      }
    }
    gameStateRef.current.touchIds.sword = null;
    gameStateRef.current.isJoystickActive = false;
    gameStateRef.current.isSwordMoving = false;
    updateSwordStickUI(false, 0, 0, 0, 0, 0);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      <canvas ref={canvasRef} className="block w-full h-full cursor-crosshair" />

      {/* Full-Screen Left & Right Touch Capture Zones for 100% reliable tap detection */}
      <div className="absolute inset-0 z-20 pointer-events-auto touch-none flex">
        {/* Left Touch Capture Zone (Movement) */}
        <div
          onTouchStart={handleTouchStartMove}
          onTouchMove={handleTouchMoveJoystick}
          onTouchEnd={handleTouchEndMove}
          onTouchCancel={handleTouchEndMove}
          className="w-1/2 h-full select-none"
        />

        {/* Right Touch Capture Zone (Sword Aim) */}
        <div
          onTouchStart={handleTouchStartSword}
          onTouchMove={handleTouchMoveSword}
          onTouchEnd={handleTouchEndSword}
          onTouchCancel={handleTouchEndSword}
          className="w-1/2 h-full select-none"
        />
      </div>

      {/* Dynamic Floating Visual Joysticks (Ref-driven, zero React re-render) */}
      <div className="absolute inset-0 pointer-events-none select-none z-20 overflow-hidden">
        {/* Left Movement Joystick */}
        <div
          ref={moveBaseRef}
          className="w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none transition-all duration-75 flex items-center justify-center absolute bottom-3.5 left-3.5 sm:bottom-6 sm:left-6 bg-slate-950/70 border-2 border-slate-700/60 shadow-lg"
          title="Джойстик передвижения"
        >
          {/* Subtle Directional Notches on Base */}
          <div className="absolute inset-0 rounded-full pointer-events-none opacity-40">
            <span className="absolute top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-slate-300" />
            <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-slate-300" />
            <span className="absolute left-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-slate-300" />
            <span className="absolute right-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-slate-300" />
          </div>

          {/* Dynamic Animated Thumbstick Knob */}
          <div
            ref={moveKnobRef}
            className="w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center transition-shadow bg-gradient-to-br from-slate-700/90 to-slate-800/90 border border-slate-500/60 shadow-md text-slate-400"
          >
            <span className="text-[9px] font-black tracking-wider uppercase drop-shadow select-none">
              БЕГ
            </span>
          </div>
        </div>

        {/* Right Sword Aim Joystick */}
        <div
          ref={swordBaseRef}
          className="w-28 h-28 sm:w-32 sm:h-32 rounded-full pointer-events-none transition-all duration-75 flex items-center justify-center absolute bottom-3.5 right-3.5 sm:bottom-6 sm:right-6 bg-slate-950/70 border-2 border-slate-700/60 shadow-lg"
          title="Джойстик меча"
        >
          {/* Subtle Directional Notches on Base */}
          <div className="absolute inset-0 rounded-full pointer-events-none opacity-40">
            <span className="absolute top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span className="absolute left-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span className="absolute right-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-400" />
          </div>

          {/* Dynamic Animated Thumbstick Knob */}
          <div
            ref={swordKnobRef}
            className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full pointer-events-none flex flex-col items-center justify-center transition-shadow bg-gradient-to-br from-slate-700/90 to-slate-800/90 border border-slate-500/60 shadow-md text-slate-400"
          >
            <span className="text-[9px] font-black tracking-wider uppercase drop-shadow select-none">
              МЕЧ
            </span>
            <div 
              ref={swordPointerRef}
              style={{ display: 'none' }}
              className="absolute inset-0 flex items-center justify-end pr-1 pointer-events-none"
            >
              <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_6px_#fff]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
