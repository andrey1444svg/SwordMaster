import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  CharacterStats, 
  ResourceInventory, 
  InventoryItem, 
  EquipmentState, 
  EquipmentSlotType,
  IngredientType,
  ItemRarity
} from '../types/game';
import { EQUIPMENT_SLOT_META, INGREDIENTS } from '../utils/gameDefaults';
import { soundManager } from '../utils/audio';
import { 
  X, 
  Plus, 
  Shield, 
  Zap, 
  Flame, 
  Sparkles, 
  Swords, 
  Heart, 
  Hammer, 
  ArrowRightLeft, 
  Check, 
  TrendingUp,
  PackageOpen,
  Wrench
} from 'lucide-react';
import { ResourceIcon, SlotSilhouetteIcon, GameItemIcon } from './GameIcons';
import { 
  getItemUpgradeCost, 
  countResourceInInventory, 
  upgradeItemStats 
} from '../utils/lootGenerator';

interface InventoryModalProps {
  isOpen?: boolean;
  stats: CharacterStats;
  resources: ResourceInventory;
  equipment: EquipmentState;
  inventory: (InventoryItem | null)[];
  onClose: () => void;
  onUpgradeStat: (statKey: 'strength' | 'agility' | 'endurance' | 'intelligence') => void;
  onEquipItem: (item: InventoryItem, targetSlot?: EquipmentSlotType) => void;
  onUnequipItem: (slot: EquipmentSlotType) => void;
  onMoveItem: (fromIndex: number, toIndex: number) => void;
  onSalvageItem: (item: InventoryItem, source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }) => void;
  onUpgradeItem?: (item: InventoryItem, source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }) => void;
  onOpenTesterArmory?: () => void;
}

export const getRarityTheme = (rarity: ItemRarity) => {
  switch (rarity) {
    case 'epic':
      return {
        border: 'border-[#c084fc] shadow-[0_0_12px_rgba(192,132,252,0.5)]',
        bg: 'bg-[#c084fc]/20',
        text: 'text-purple-300',
        glow: 'shadow-purple-500/40',
        badge: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
        name: 'Эпический'
      };
    case 'rare':
      return {
        border: 'border-[#00f0ff] shadow-[0_0_12px_rgba(0,240,255,0.5)]',
        bg: 'bg-[#00f0ff]/20',
        text: 'text-[#00f0ff]',
        glow: 'shadow-cyan-500/40',
        badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
        name: 'Редкий'
      };
    case 'magic':
      return {
        border: 'border-[#22c55e] shadow-[0_0_12px_rgba(34,197,94,0.5)]',
        bg: 'bg-[#22c55e]/20',
        text: 'text-emerald-300',
        glow: 'shadow-emerald-500/40',
        badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        name: 'Магический'
      };
    default:
      return {
        border: 'border-[#cbd5e1] shadow-[0_0_10px_rgba(203,213,225,0.3)]',
        bg: 'bg-slate-800/40',
        text: 'text-slate-200',
        glow: 'shadow-slate-500/20',
        badge: 'bg-slate-700/40 text-slate-300 border-slate-600',
        name: 'Обычный'
      };
  }
};

// Rarity-based Cell Styling: Neon glow & background exclusively reflect item rarity
export const getItemCellClass = (item: InventoryItem | null) => {
  if (!item) {
    return 'border border-[#0c2246] bg-[#030d24]/60 shadow-none hover:border-cyan-500/50';
  }

  // Specialized vibrant glow for the 4 in-game ingredient assets
  if (item.isResource || item.category === 'resource') {
    if (item.resourceType === 'iron_ore' || item.name?.includes('Осколок мглы')) {
      return 'border-2 border-slate-300/80 bg-slate-400/20 shadow-[0_0_8px_rgba(203,213,225,0.45)] text-slate-100';
    }
    if (item.resourceType === 'magic_crystal' || item.name?.includes('Магический кристалл')) {
      return 'border-2 border-[#22c55e] bg-[#22c55e]/25 shadow-[0_0_8px_rgba(34,197,94,0.45)] text-emerald-300';
    }
    if (item.resourceType === 'monster_core' || item.name?.includes('Ядро монстра')) {
      return 'border-2 border-[#00f0ff] bg-[#00f0ff]/25 shadow-[0_0_8px_rgba(0,240,255,0.45)] text-cyan-300';
    }
    if (item.resourceType === 'ancient_rune' || item.resourceType === 'fire_essence' || item.name?.includes('Печать пустоты')) {
      return 'border-2 border-[#c084fc] bg-[#c084fc]/25 shadow-[0_0_8px_rgba(192,132,252,0.45)] text-purple-300';
    }
  }

  // 1. Magic (магическое: светло-зеленоватый фон и зеленый неон)
  if (item.rarity === 'magic') {
    return 'border-2 border-[#22c55e] bg-[#22c55e]/20 shadow-[0_0_8px_rgba(34,197,94,0.45)] text-emerald-300';
  }

  // 2. Rare (редкое: голубоватый фон и синий неон)
  if (item.rarity === 'rare') {
    return 'border-2 border-[#00f0ff] bg-[#00f0ff]/20 shadow-[0_0_8px_rgba(0,240,255,0.45)] text-cyan-300';
  }

  // 3. Epic (эпическое: светло-фиолетовый фон и фиолетовый неон)
  if (item.rarity === 'epic') {
    return 'border-2 border-[#c084fc] bg-[#c084fc]/20 shadow-[0_0_8px_rgba(192,132,252,0.45)] text-purple-300';
  }

  // 4. Common (обычное: без неона вообще и без фона)
  return 'border border-[#1a3460] bg-[#04122d] shadow-none hover:border-slate-400';
};

type SingleModalView = 
  | { type: 'item'; item: InventoryItem; source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType } }
  | { type: 'empty_slot'; slot: EquipmentSlotType }
  | { type: 'stats' }
  | null;

export const InventoryModal = React.memo<InventoryModalProps>(({
  isOpen = true,
  stats,
  equipment,
  inventory,
  onClose,
  onUpgradeStat,
  onEquipItem,
  onUnequipItem,
  onMoveItem,
  onSalvageItem,
  onSalvageMultiple,
  onUpgradeItem,
  onOpenTesterArmory
}) => {
  // STRICT SINGLE POPUP STATE: Exactly ONE or ZERO modals can be open
  const [modalView, setModalView] = useState<SingleModalView>(null);

  // Reset internal popups when closed
  useEffect(() => {
    if (!isOpen) {
      setModalView(null);
    }
  }, [isOpen]);

  // Universal Touch + Mouse Drag & Drop (GPU Hardware-Accelerated & 0 React Re-renders)
  const [draggedGhostItem, setDraggedGhostItem] = useState<InventoryItem | null>(null);
  const dragGhostRef = useRef<HTMLDivElement | null>(null);
  const lastHoveredSlotElRef = useRef<HTMLElement | null>(null);
  const sourceSlotElRef = useRef<HTMLElement | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Time tracker to prevent trailing synthetic clicks from instantly closing popups
  const modalOpenedTimeRef = useRef<number>(0);

  // Drag session reference
  const dragSessionRef = useRef<{
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType };
    sourceId: string;
    item: InventoryItem;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
    startTime: number;
    isDragging: boolean;
    timer: number;
  } | null>(null);

  // Hovered slot reference for reliable drop target detection
  const hoveredSlotRef = useRef<{
    id: string;
    type: 'equipment' | 'inventory';
    key: string;
  } | null>(null);

  // Stable references for state & callbacks
  const equipmentRef = useRef(equipment);
  equipmentRef.current = equipment;
  const inventoryRef = useRef(inventory);
  inventoryRef.current = inventory;
  const onEquipItemRef = useRef(onEquipItem);
  onEquipItemRef.current = onEquipItem;
  const onUnequipItemRef = useRef(onUnequipItem);
  onUnequipItemRef.current = onUnequipItem;
  const onMoveItemRef = useRef(onMoveItem);
  onMoveItemRef.current = onMoveItem;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Calculate totals from equipment
  const equippedList = Object.values(equipment).filter(Boolean) as InventoryItem[];
  const totalEquipArmor = equippedList.reduce((sum, item) => sum + (item.stats.armor || 0), 0);
  const totalEquipDmgMin = equippedList.reduce((sum, item) => sum + (item.stats.damageMin || 0), 0);
  const totalEquipDmgMax = equippedList.reduce((sum, item) => sum + (item.stats.damageMax || 0), 0);

  const bonusStrTotal = equippedList.reduce((sum, item) => sum + (item.stats.strength || 0), 0);
  const bonusAgiTotal = equippedList.reduce((sum, item) => sum + (item.stats.agility || 0), 0);
  const bonusEndTotal = equippedList.reduce((sum, item) => sum + (item.stats.endurance || 0), 0);
  const bonusIntTotal = equippedList.reduce((sum, item) => sum + (item.stats.intelligence || 0), 0);

  const totalStr = stats.strength + bonusStrTotal;
  const totalAgi = stats.agility + bonusAgiTotal;
  const totalEnd = stats.endurance + bonusEndTotal;
  const totalInt = stats.intelligence + bonusIntTotal;

  // Overall effective combat stats
  const equippedWeapon = equipment.weapon?.weaponData;
  const baseWepCrit = equippedWeapon ? (equippedWeapon.critChance || 0) : 0.02;
  const minDamage = stats.minDamage ?? (Math.round((3 + totalEquipDmgMin + totalStr * 1.0) * 10) / 10);
  const maxDamage = stats.maxDamage ?? (Math.round((3 + totalEquipDmgMax + totalStr * 1.0) * 10) / 10);
  const effectiveCrit = Math.round((baseWepCrit + (stats.critChanceBonus || 0)) * 1000) / 10;
  const baseWepCritMult = equippedWeapon ? (equippedWeapon.critMultiplier || 1.25) : 1.25;
  const effectiveCritDmg = Math.round((baseWepCritMult + totalAgi * 0.0017) * 1000) / 10;

  // Armor Damage Reduction (halved): 5 armor = 0.67%, 10 armor = 1.33% -> 0.133% per armor point
  const damageReductionPercent = Math.min(85, Math.round((totalEquipArmor * (0.2 / 1.5)) * 10) / 10);

  // Attack recovery speed percentage bonus from gloves & gear
  const totalRecoverySpeedBonus = equippedList.reduce((sum, item) => {
    return sum + ((item.stats && item.stats.attackRecoverySpeed) || item.attackRecoverySpeed || 0);
  }, 0);
  const effectiveRecoverySec = Math.max(0.05, Math.round(0.50 * (1 - Math.min(87, totalRecoverySpeedBonus) / 100) * 100) / 100);

  // Resource Counts for footer strip
  const resourceCounts = {
    iron_ore: countResourceInInventory(inventory, 'iron_ore'),
    magic_crystal: countResourceInInventory(inventory, 'magic_crystal'),
    monster_core: countResourceInInventory(inventory, 'monster_core'),
    ancient_rune: countResourceInInventory(inventory, 'ancient_rune'),
    fire_essence: countResourceInInventory(inventory, 'fire_essence')
  };

  // Equipment slots: 3 compact columns × 5 rows
  const equipCol1: EquipmentSlotType[] = ['weapon', 'helmet', 'cloak'];
  const equipCol2: EquipmentSlotType[] = ['chest', 'bracers', 'gloves', 'belt', 'pants'];
  const equipCol3: EquipmentSlotType[] = ['boots', 'ring1', 'ring2', 'trinket1', 'trinket2'];

  // Global Pointer Event Listeners for Touch + Mouse Drag & Drop (Zero Latency GPU Transform)
  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      const session = dragSessionRef.current;
      if (!session) return;

      session.currentX = e.clientX;
      session.currentY = e.clientY;

      const dist = Math.hypot(e.clientX - session.startX, e.clientY - session.startY);

      // If user drags intentionally (> 3px) before timer, immediately activate drag with 0 latency
      if (!session.isDragging && dist > 3) {
        window.clearTimeout(session.timer);
        session.isDragging = true;
        setDraggedGhostItem(session.item);
        
        const srcEl = document.querySelector(`[data-slot-id="${session.sourceId}"]`) as HTMLElement | null;
        if (srcEl) {
          srcEl.classList.add('slot-drag-source');
          sourceSlotElRef.current = srcEl;
        }

        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try { navigator.vibrate(25); } catch {}
        }
      }

      if (session.isDragging) {
        // Direct GPU Transform update: centered perfectly under the cursor!
        if (dragGhostRef.current) {
          dragGhostRef.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0) translate(-50%, -50%)`;
        }

        // Find drop slot element under pointer
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const slotEl = el?.closest('[data-slot-id]') as HTMLElement | null;
        
        if (slotEl !== lastHoveredSlotElRef.current) {
          if (lastHoveredSlotElRef.current) {
            lastHoveredSlotElRef.current.classList.remove('slot-drag-over');
          }
          if (slotEl) {
            slotEl.classList.add('slot-drag-over');
            const targetId = slotEl.getAttribute('data-slot-id') || '';
            const slotType = slotEl.getAttribute('data-slot-type') as 'equipment' | 'inventory';
            const slotKey = slotEl.getAttribute('data-slot-key') || '';
            hoveredSlotRef.current = { id: targetId, type: slotType, key: slotKey };
          } else {
            hoveredSlotRef.current = null;
          }
          lastHoveredSlotElRef.current = slotEl;
        }
      }
    };

    const handlePointerUp = (e: PointerEvent) => {
      const session = dragSessionRef.current;
      if (!session) return;

      window.clearTimeout(session.timer);
      const elapsed = Date.now() - session.startTime;

      // Clean up DOM classes and ghost
      if (lastHoveredSlotElRef.current) {
        lastHoveredSlotElRef.current.classList.remove('slot-drag-over');
        lastHoveredSlotElRef.current = null;
      }
      if (sourceSlotElRef.current) {
        sourceSlotElRef.current.classList.remove('slot-drag-source');
        sourceSlotElRef.current = null;
      }
      setDraggedGhostItem(null);

      if (session.isDragging || elapsed >= 280) {
        // Drop on target slot
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const slotEl = el?.closest('[data-slot-id]') as HTMLElement | null;
        const target = (slotEl ? {
          id: slotEl.getAttribute('data-slot-id') || '',
          type: slotEl.getAttribute('data-slot-type') as 'equipment' | 'inventory',
          key: slotEl.getAttribute('data-slot-key') || ''
        } : null) || hoveredSlotRef.current;

        if (target) {
          const { type: slotType, key: targetKey } = target;

          if (slotType === 'equipment' && targetKey) {
            const targetSlot = targetKey as EquipmentSlotType;
            const targetMeta = EQUIPMENT_SLOT_META[targetSlot];

            if (session.source.type === 'inventory') {
              const item = session.item;
              if (item.isResource) {
                showToast('Ресурсы нельзя экипировать!');
              } else if (item.category === targetMeta.category) {
                onEquipItemRef.current(item, targetSlot);
                soundManager.playEquip();
                showToast(`Надето: ${item.name}`);
              } else {
                showToast(`Не подходит в слот ${targetMeta.label}!`);
              }
            } else if (session.source.type === 'equipment') {
              // Swap or move equipment slots
              const fromSlot = session.source.slot;
              if (fromSlot !== targetSlot) {
                const metaFrom = EQUIPMENT_SLOT_META[fromSlot];
                if (metaFrom.category === targetMeta.category) {
                  const currentEq = equipmentRef.current;
                  const targetItem = currentEq[targetSlot];
                  onEquipItemRef.current(session.item, targetSlot);
                  if (targetItem) {
                    onEquipItemRef.current(targetItem, fromSlot);
                  } else {
                    onUnequipItemRef.current(fromSlot);
                  }
                  soundManager.playEquip();
                  showToast(`Перемещено в слот ${targetMeta.label}`);
                } else {
                  showToast(`Не подходит в слот ${targetMeta.label}!`);
                }
              }
            }
          } else if (slotType === 'inventory' && targetKey !== null && targetKey !== '') {
            const targetIdx = parseInt(targetKey, 10);
            if (session.source.type === 'inventory') {
              if (session.source.index !== targetIdx) {
                onMoveItemRef.current(session.source.index, targetIdx);
                soundManager.playEquip();
              }
            } else if (session.source.type === 'equipment') {
              onUnequipItemRef.current(session.source.slot);
              soundManager.playEquip();
              showToast(`Снято: ${session.item.name}`);
            }
          }
        }
      } else {
        // Short tap (< 0.28s) without drag: Open Item Inspection Tooltip / Modal
        modalOpenedTimeRef.current = Date.now();
        setModalView({
          type: 'item',
          item: session.item,
          source: session.source
        });
      }

      dragSessionRef.current = null;
      hoveredSlotRef.current = null;
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
    };
  }, []);

  // Universal pointer down handler: holds for > 0.28s to drag, short-tap (< 0.28s) for inspection
  const startDragSession = (
    e: React.PointerEvent,
    item: InventoryItem,
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType },
    sourceId: string
  ) => {
    if (e.button !== 0) return;

    if (dragSessionRef.current) {
      window.clearTimeout(dragSessionRef.current.timer);
      dragSessionRef.current = null;
    }

    const startX = e.clientX;
    const startY = e.clientY;

    const timer = window.setTimeout(() => {
      const session = dragSessionRef.current;
      if (!session) return;
      // Held for > 0.28 seconds: grab item!
      session.isDragging = true;
      setDraggedGhostItem(session.item);
      
      const srcEl = document.querySelector(`[data-slot-id="${session.sourceId}"]`) as HTMLElement | null;
      if (srcEl) {
        srcEl.classList.add('slot-drag-source');
        sourceSlotElRef.current = srcEl;
      }
      
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(30); } catch {}
      }
    }, 280);

    dragSessionRef.current = {
      source,
      sourceId,
      item,
      startX,
      startY,
      currentX: startX,
      currentY: startY,
      startTime: Date.now(),
      isDragging: false,
      timer
    };
  };

  // Start pointer interaction on an equipment slot
  const startEquipPointer = (e: React.PointerEvent, slotKey: EquipmentSlotType) => {
    const item = equipment[slotKey];
    const targetId = `equip_${slotKey}`;
    if (item) {
      startDragSession(e, item, { type: 'equipment', slot: slotKey }, targetId);
    } else {
      // Empty slot tap (< 0.3s): open candidate equipment modal
      modalOpenedTimeRef.current = Date.now();
      setModalView({ type: 'empty_slot', slot: slotKey });
    }
  };

  // Start pointer interaction on an inventory slot
  const startInvPointer = (e: React.PointerEvent, index: number) => {
    const item = inventory[index];
    const targetId = `inv_${index}`;
    if (item) {
      startDragSession(e, item, { type: 'inventory', index }, targetId);
    }
  };

  // Upgrade item handler in single modal
  const handleUpgradeClick = (
    item: InventoryItem,
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }
  ) => {
    if (onUpgradeItem) {
      onUpgradeItem(item, source);
      const nextUpgraded = upgradeItemStats(item);
      setModalView({ type: 'item', item: nextUpgraded, source });
      showToast(`Улучшено: ${item.name} (+1 Ур.)!`);
    }
  };

  // Salvage item handler in single modal
  const handleSalvageClick = (
    item: InventoryItem,
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }
  ) => {
    onSalvageItem(item, source);
    setModalView(null);
    showToast(`Разобрано: ${item.name}!`);
  };

  // Helper to render an equipment slot box with octagonal frame matching exact rarity neon rules
  const renderEquipSlot = (slotKey: EquipmentSlotType) => {
    const item = equipment[slotKey];
    const meta = EQUIPMENT_SLOT_META[slotKey];
    if (!meta) return null;

    const targetId = `equip_${slotKey}`;

    let strokeColor = '#0f3460';
    let fillColor = '#020a1d';
    let glowClass = 'shadow-none';

    if (item) {
      if (item.rarity === 'magic') {
        strokeColor = '#22c55e';
        fillColor = '#042413';
        glowClass = 'shadow-[0_0_12px_rgba(34,197,94,0.6)]';
      } else if (item.rarity === 'rare') {
        strokeColor = '#00f0ff';
        fillColor = '#03213b';
        glowClass = 'shadow-[0_0_12px_rgba(0,240,255,0.6)]';
      } else if (item.rarity === 'epic') {
        strokeColor = '#c084fc';
        fillColor = '#1d0b33';
        glowClass = 'shadow-[0_0_12px_rgba(192,132,252,0.6)]';
      } else {
        // Common (обычное)
        strokeColor = '#475569';
        fillColor = '#04112e';
        glowClass = 'shadow-none';
      }
    }

    return (
      <div
        key={slotKey}
        id={`slot_${slotKey}`}
        data-slot-id={targetId}
        data-slot-type="equipment"
        data-slot-key={slotKey}
        onPointerDown={e => startEquipPointer(e, slotKey)}
        style={{ touchAction: 'none' }}
        title={`${meta.label}${item ? `: ${item.name} (Ур. ${item.level})` : ' (Пусто - нажмите для выбора)'}`}
        className={`group relative w-[28px] h-[28px] sm:w-[32px] sm:h-[32px] rounded-lg flex items-center justify-center transition-transform duration-75 select-none cursor-pointer shrink-0 hover:scale-105 ${glowClass}`}
      >
        {/* Octagonal SVG Background Frame */}
        <svg viewBox="0 0 48 48" className="absolute inset-0 w-full h-full pointer-events-none">
          <polygon 
            points="14,2 34,2 46,14 46,34 34,46 14,46 2,34 2,14" 
            fill={fillColor} 
            stroke={strokeColor} 
            strokeWidth="1.5" 
          />
          <polygon 
            points="15,4 33,4 44,15 44,33 33,44 15,44 4,33 4,15" 
            fill="none" 
            stroke={strokeColor} 
            strokeOpacity="0.35" 
            strokeWidth="1" 
          />
        </svg>

        {/* Item Icon or Empty Slot Silhouette */}
        <div className="relative z-10 flex items-center justify-center w-full h-full p-0.5">
          {item ? (
            <>
              <GameItemIcon item={item} className="w-4 h-4 sm:w-4.5 sm:h-4.5 pointer-events-none drop-shadow" />
              {item.level > 1 && (
                <span className="absolute bottom-0 right-0 px-0.5 rounded bg-slate-950/95 border border-amber-500/80 text-[6.5px] font-black text-amber-300 leading-none pointer-events-none z-20">
                  +{item.level - 1}
                </span>
              )}
            </>
          ) : (
            <SlotSilhouetteIcon slotKey={slotKey} className="w-5 h-5 sm:w-5.5 sm:h-5.5 pointer-events-none" />
          )}
        </div>
      </div>
    );
  };

  return (
    <div 
      className={`fixed inset-0 z-50 items-center justify-center p-1 sm:p-2 bg-[#02050e]/95 select-none ${isOpen ? 'flex' : 'hidden'}`}
      style={{ display: isOpen ? 'flex' : 'none' }}
    >
      
      {/* Floating Drag Ghost (Portaled directly to document.body to prevent backdrop-filter / container transform offsets) */}
      {draggedGhostItem && typeof document !== 'undefined' && createPortal(
        <div 
          ref={dragGhostRef}
          style={{
            position: 'fixed',
            left: 0,
            top: 0,
            transform: `translate3d(${dragSessionRef.current?.currentX ?? -9999}px, ${dragSessionRef.current?.currentY ?? -9999}px, 0) translate(-50%, -50%)`
          }}
          className="pointer-events-none z-[999999] flex flex-col items-center gap-1 scale-110 drop-shadow-2xl will-change-transform select-none"
        >
          <div className="w-11 h-11 rounded-xl bg-[#041230] border-2 border-[#00f0ff] shadow-[0_0_25px_rgba(0,240,255,0.85)] flex items-center justify-center ring-4 ring-cyan-500/40">
            <GameItemIcon item={draggedGhostItem} className="w-7 h-7 pointer-events-none" />
          </div>
          <div className="px-2.5 py-0.5 rounded-full bg-slate-950/95 border border-cyan-500/70 text-[10px] font-black text-cyan-200 whitespace-nowrap shadow-lg">
            {draggedGhostItem.name}
          </div>
        </div>,
        document.body
      )}

      {/* Main Container: Sci-Fi / Fantasy Dark Blue Metallic UI Frame (Scaled ~20% smaller max-w-3xl) */}
      <div className="relative w-full max-w-2xl sm:max-w-3xl bg-[#03091e]/95 border-2 border-[#0f3b7d] rounded-2xl shadow-2xl shadow-cyan-950/50 flex flex-col overflow-hidden text-slate-100 max-h-[90vh]">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-2.5 py-1 bg-gradient-to-r from-[#030d2a] via-[#061845] to-[#030d2a] border-b-2 border-[#0f3b7d] relative shadow-md">
          {/* Class crest & XP */}
          <div className="flex items-center gap-2">
            {/* Hexagon Crest */}
            <div className="relative w-7 h-7 flex items-center justify-center">
              <div className="absolute inset-0 bg-cyan-500/20 rounded-lg rotate-45 border border-cyan-400 shadow-[0_0_10px_rgba(0,240,255,0.4)]" />
              <Swords className="w-3.5 h-3.5 text-cyan-300 relative z-10" />
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black uppercase tracking-wider text-white drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]">
                МЕЧНИК
              </span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-[#072454] border border-[#00f0ff]/60 text-[#00f0ff] font-extrabold shadow-inner">
                Ур. {stats.level}
              </span>
              <div className="flex items-center gap-1 text-[9px] text-slate-300 ml-1">
                <span className="font-bold">XP: <strong className="text-cyan-200">{stats.xp}/{stats.maxXp}</strong></span>
                <div className="w-16 h-1.5 bg-[#041233] border border-[#0d3670] rounded-full overflow-hidden p-0.5">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 via-indigo-400 to-purple-400 rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(192,132,252,0.8)]"
                    style={{ width: `${Math.min(100, (stats.xp / stats.maxXp) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* "Характеристики" Button (Gold if statPoints > 0, Blue default if 0) */}
            <button
              id="btn_open_stats"
              onClick={() => {
                modalOpenedTimeRef.current = Date.now();
                setModalView({ type: 'stats' });
              }}
              className={
                stats.statPoints > 0
                  ? "relative px-2 py-0.5 rounded-lg bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 border border-amber-300 text-slate-950 font-black text-[10px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow-[0_0_10px_rgba(245,158,11,0.5)] animate-pulse"
                  : "relative px-2 py-0.5 rounded-lg bg-[#072454] hover:bg-[#0a3275] border border-cyan-500/60 text-cyan-200 hover:text-white font-black text-[10px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow"
              }
              title="Характеристики героя"
            >
              <Plus className={`w-3 h-3 stroke-[3] ${stats.statPoints > 0 ? 'text-slate-950' : 'text-cyan-300'}`} />
              <span className="tracking-wide">
                Характеристики{stats.statPoints > 0 ? ` (${stats.statPoints})` : ''}
              </span>
            </button>

            {/* Tester Armory Button */}
            {onOpenTesterArmory && (
              <button
                onClick={onOpenTesterArmory}
                className="relative px-2 py-0.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 shadow-[0_0_10px_rgba(245,158,11,0.4)]"
                title="Арсенал Тестировщика"
              >
                <Wrench className="w-3 h-3 text-slate-950" />
                <span className="tracking-wide font-black">Тестировщик</span>
              </button>
            )}

            {/* Glowing Diamond Close Button */}
            <button
              onClick={onClose}
              className="relative w-6 h-6 rounded-lg bg-[#07193d] hover:bg-rose-950/80 border border-cyan-500/60 hover:border-rose-500 text-cyan-200 hover:text-rose-300 flex items-center justify-center transition-all cursor-pointer"
              title="Закрыть окно"
            >
              <X className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          </div>
        </div>

        {/* Temporary Notification Toast */}
        {toastMessage && (
          <div className="absolute top-9 left-1/2 -translate-x-1/2 z-40 px-2.5 py-0.5 bg-[#030e2e]/95 border-2 border-[#00f0ff] text-cyan-200 rounded-xl shadow-[0_0_20px_rgba(0,240,255,0.4)] text-[10px] font-bold flex items-center gap-1 animate-fade-in pointer-events-none">
            <Check className="w-3 h-3 text-[#00f0ff]" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Main Content Area: Equipment on Left + Backpack on Right (Equal height matching) */}
        <div className="p-1.5 sm:p-2 flex flex-row gap-2 sm:gap-3 items-stretch justify-center overflow-y-auto">
          
          {/* ======================================================== */}
          {/* LEFT: EQUIPMENT PANEL WITH EVENLY DISTRIBUTED SLOTS      */}
          {/* ======================================================== */}
          <div className="relative bg-[#020817]/85 border-2 border-[#0d346c] rounded-2xl p-1.5 sm:p-2 flex flex-col justify-between items-center shrink-0 shadow-[0_0_25px_rgba(0,180,255,0.12)] w-[260px]">
            
            {/* Header: Shield + Title + Counter */}
            <div className="w-full flex items-center justify-between mb-1 px-1 border-b border-[#0d346c] pb-0.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-cyan-200 flex items-center gap-1">
                <Shield className="w-3 h-3 text-[#00f0ff]" />
                ЭКИПИРОВКА
              </span>
              <span className="text-[10px] text-cyan-400 font-bold">
                {equippedList.length}/13
              </span>
            </div>

            {/* Top Helmet Slot pulled up above the main even rows */}
            <div className="relative z-30 flex flex-col items-center mb-0.5 pointer-events-auto">
              <span className="text-[7.5px] font-extrabold text-cyan-300 uppercase leading-none mb-0.5 border-b border-cyan-400/50 px-1">
                Шлем
              </span>
              {renderEquipSlot('helmet')}
            </div>

            {/* Container with Even Rows of Slots & Hero Mannequin Silhouette Background */}
            <div className="relative w-full flex-1 flex items-center justify-between z-10 gap-0.5 px-[2px] pt-[2px] mx-0 -mt-[49px] pointer-events-none">
              {/* Central Glowing Hero Mannequin SVG in Background */}
              <div className="absolute inset-0 flex items-center justify-center opacity-25 pointer-events-none z-0">
                <svg viewBox="0 0 180 240" className="h-full w-auto" fill="none">
                  {/* Hero Muscular Body Silhouette */}
                  <g stroke="#00d2ff" strokeWidth="1.2" fill="#03122c" fillOpacity="0.9">
                    <path d="M 90 20 C 98 20 104 26 104 36 C 104 46 98 52 90 52 C 82 52 76 46 76 36 C 76 26 82 20 90 20 Z" />
                    <path d="M 85 52 L 80 62 L 100 62 L 95 52 Z" />
                    <path d="M 70 62 Q 90 56 110 62 Q 130 72 138 88 L 122 96 L 108 80 L 90 82 L 72 80 L 58 96 L 42 88 Q 50 72 70 62 Z" />
                    <path d="M 72 80 Q 90 86 108 80 L 104 112 L 90 115 L 76 112 Z" />
                    <path d="M 42 88 Q 34 108 32 130 L 44 132 Q 48 112 58 96 Z" />
                    <path d="M 32 133 Q 26 160 24 185 L 36 185 Q 38 162 44 135 Z" />
                    <path d="M 138 88 Q 146 108 148 130 L 136 132 Q 132 112 122 96 Z" />
                    <path d="M 148 133 Q 154 160 156 185 L 144 185 Q 142 162 136 135 Z" />
                    <path d="M 76 112 L 104 112 L 100 148 L 80 148 Z" />
                    <path d="M 72 149 L 108 149 L 105 165 L 75 165 Z" stroke="#00f0ff" strokeWidth="1.8" fill="#061c48" />
                    <path d="M 75 167 L 88 167 L 86 215 L 65 215 Z" />
                    <path d="M 105 167 L 92 167 L 94 215 L 115 215 Z" />
                    <path d="M 65 217 L 86 217 L 82 238 L 52 238 Z" stroke="#00f0ff" strokeWidth="1.5" />
                    <path d="M 115 217 L 94 217 L 98 238 L 128 238 Z" stroke="#00f0ff" strokeWidth="1.5" />
                  </g>
                </svg>
              </div>

              {/* LEFT EVEN SLOTS COLUMN (Weapon, Cloak, Chest, Bracers, Gloves, Belt) */}
              <div className="flex flex-col gap-0.5 z-10 flex-1 justify-between pointer-events-auto">
                <div className="flex items-center gap-1">
                  {renderEquipSlot('weapon')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px]">Оружие</span>
                </div>
                <div className="flex items-center gap-1">
                  {renderEquipSlot('cloak')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[24px]">Плащ</span>
                </div>
                <div className="flex items-center gap-1">
                  {renderEquipSlot('chest')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[24px]">Нагрудник</span>
                </div>
                <div className="flex items-center gap-1">
                  {renderEquipSlot('bracers')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[24px]">Наручи</span>
                </div>
                <div className="flex items-center gap-1">
                  {renderEquipSlot('gloves')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[24px]">Перчатки</span>
                </div>
                <div className="flex items-center gap-1">
                  {renderEquipSlot('belt')}
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[24px]">Пояс</span>
                </div>
              </div>

              {/* RIGHT EVEN SLOTS COLUMN (Pants, Boots, Ring1, Ring2, Trinket1, Trinket2) */}
              <div className="flex flex-col gap-0.5 z-10 flex-1 justify-between items-end pointer-events-auto">
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Штаны</span>
                  {renderEquipSlot('pants')}
                </div>
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Ботинки</span>
                  {renderEquipSlot('boots')}
                </div>
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Кольцо</span>
                  {renderEquipSlot('ring1')}
                </div>
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Кольцо</span>
                  {renderEquipSlot('ring2')}
                </div>
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Аксессуар</span>
                  {renderEquipSlot('trinket1')}
                </div>
                <div className="flex items-center justify-end gap-1">
                  <span className="text-[8px] font-extrabold text-cyan-200 uppercase tracking-tight border-b border-cyan-400/50 pb-0.5 min-w-[32px] text-right">Аксессуар</span>
                  {renderEquipSlot('trinket2')}
                </div>
              </div>
            </div>

            <div className="mt-1 text-[8px] text-slate-400 font-medium text-center">
              Зажмите для переноса
            </div>
          </div>

          {/* ======================================================== */}
          {/* RIGHT: 30-SLOT INVENTORY (6 COLUMNS × 5 ROWS, COMPACT)   */}
          {/* ======================================================== */}
          <div className="bg-[#020817]/80 border-2 border-[#0d346c] rounded-2xl p-1.5 sm:p-2 flex flex-col justify-between items-center shrink-0 shadow-[0_0_25px_rgba(0,180,255,0.1)] w-[260px]">
            
            {/* Header: Arrows + Title + Counter */}
            <div className="w-full flex items-center justify-between mb-1 px-1 border-b border-[#0d346c] pb-0.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-cyan-200 flex items-center gap-1">
                <ArrowRightLeft className="w-3 h-3 text-[#00f0ff]" />
                РЮКЗАК
              </span>
              <span className="text-[10px] text-cyan-400 font-bold">
                {inventory.filter(Boolean).length}/30 ячеек
              </span>
            </div>

            <div className="flex gap-2 mb-2">
              <button 
                onClick={() => onSalvageMultiple('common')}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-[10px] text-slate-200 py-1 rounded"
              >
                Распылить обычные
              </button>
              <button 
                onClick={() => onSalvageMultiple('magic')}
                className="flex-1 bg-green-900 hover:bg-green-800 text-[10px] text-green-100 py-1 rounded"
              >
                Распылить магические
              </button>
            </div>
            {/* 6 Columns × 5 Rows Grid (30 Cells - Reduced to w-7 h-7 sm:w-8 sm:h-8) */}
            <div className="grid grid-cols-6 gap-1 w-[240px]">
              {inventory.map((item, idx) => {
                const targetId = `inv_${idx}`;

                return (
                  <div
                    key={idx}
                    id={`inv_slot_${idx}`}
                    data-slot-id={targetId}
                    data-slot-type="inventory"
                    data-slot-key={idx}
                    onPointerDown={e => startInvPointer(e, idx)}
                    style={{ touchAction: 'none' }}
                    title={item ? `${item.name}${item.quantity ? ` (x${item.quantity})` : ''}` : 'Пустая ячейка'}
                    className={`group relative w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-transform duration-75 select-none cursor-pointer ${getItemCellClass(item)}`}
                  >
                    {item ? (
                      <>
                        <GameItemIcon item={item} className="w-4.5 h-4.5 pointer-events-none" />
                        
                        {item.level > 1 && !item.isResource && (
                          <span className="absolute -bottom-1 -right-1 px-0.5 rounded bg-slate-950/95 border border-slate-700 text-[6.5px] font-black text-amber-300 leading-none pointer-events-none z-30 shadow">
                            +{item.level - 1}
                          </span>
                        )}

                        {/* Quantity overlay badge for ingredients / stackable items at bottom-right e.g. x17, x22, x1 */}
                        {(item.quantity !== undefined && item.quantity > 0) || item.isResource || item.category === 'resource' ? (
                          <span className="absolute -bottom-1 -right-1 px-1 py-0.5 rounded bg-slate-950/95 border border-cyan-400/80 text-[8px] sm:text-[8.5px] font-black text-amber-300 leading-none pointer-events-none z-30 shadow-md shadow-slate-950 whitespace-nowrap">
                            x{item.quantity || 1}
                          </span>
                        ) : null}
                      </>
                    ) : (
                      /* Center Diamond Rune Watermark for Empty Cells */
                      <span className="text-cyan-900/40 text-[9px] font-black select-none pointer-events-none">
                        ♦
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mt-1 text-[8px] text-slate-400 font-medium text-center">
              ⓘ Тап (&lt;0.3с) — свойства • Зажатие (&gt;0.3с) — перенос
            </div>
          </div>

        </div>

        {/* Bottom Bar: Stats on Left (Matching Reference) */}
        <div className="px-2.5 py-1 bg-[#02081a] border-t-2 border-[#0f3b7d] flex items-center justify-between gap-2 text-[10px] font-bold">
          
          {/* Quick Combat Stats */}
          <div className="flex items-center gap-2.5">
            {/* HP */}
            <span className="flex items-center gap-1 text-rose-400">
              <Heart className="w-3 h-3 text-rose-500 fill-rose-500/20" />
              <span>{Math.ceil(stats.hp)} / {stats.maxHp} HP</span>
            </span>

            {/* Armor */}
            <span className="flex items-center gap-1 text-cyan-300">
              <Shield className="w-3 h-3 text-cyan-400 fill-cyan-400/20" />
              <span>Броня: {totalEquipArmor} (-{damageReductionPercent}%)</span>
            </span>

            {/* Damage */}
            <span className="flex items-center gap-1 text-amber-300">
              <Swords className="w-3.5 h-3.5 text-amber-400" />
              <span>Урон: {minDamage}–{maxDamage}</span>
            </span>

            {/* Crit */}
            <span className="flex items-center gap-1 text-amber-200">
              <Zap className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400/20" />
              <span>Крит: {effectiveCrit}% ({effectiveCritDmg}%)</span>
            </span>
          </div>

        </div>

        {/* ======================================================== */}
        {/* STRICTLY SINGLE POPUP CONTAINER (NO OVERLAPPING MODALS)  */}
        {/* ======================================================== */}
        {modalView && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-2 bg-slate-950/90 animate-fade-in"
            onClick={() => {
              if (Date.now() - modalOpenedTimeRef.current < 350) return;
              setModalView(null);
            }}
          >
            <div 
              className="relative w-full max-w-sm bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-3 flex flex-col gap-2.5 max-h-[90vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >

              {/* 1. ITEM INSPECTION MODAL */}
              {modalView.type === 'item' && (() => {
                const { item, source } = modalView;
                const rTheme = getRarityTheme(item.rarity);
                const isEquipped = source.type === 'equipment';

                return (
                  <>
                    <div className="flex items-start justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-lg border flex items-center justify-center ${rTheme.border} ${rTheme.bg}`}>
                          <GameItemIcon item={item} className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className={`text-xs font-black ${rTheme.text} flex items-center gap-1.5`}>
                            <span>{item.name}</span>
                            {(item.isResource || (item.quantity && item.quantity > 0)) && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 border border-amber-400/60 text-amber-300 font-extrabold text-[9px]">
                                x{item.quantity || 1}
                              </span>
                            )}
                          </h3>
                          <div className="flex items-center gap-2 text-[9px] text-slate-400">
                            <span className={`px-1 rounded border text-[8px] font-bold ${rTheme.badge}`}>
                              {rTheme.name}
                            </span>
                            <span>•</span>
                            <span>Уровень {item.level}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => setModalView(null)}
                        className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {!item.isResource && (
                      <div className="grid grid-cols-2 gap-1.5 p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-[11px]">
                        {item.stats.damageMin !== undefined && (
                          <div className="flex items-center justify-between text-rose-300 font-semibold">
                            <span>Урон:</span>
                            <span>{item.stats.damageMin} – {item.stats.damageMax}</span>
                          </div>
                        )}
                        {item.stats.armor !== undefined && item.stats.armor > 0 && (
                          <div className="flex items-center justify-between text-sky-300 font-semibold">
                            <span>Броня:</span>
                            <span>+{item.stats.armor}</span>
                          </div>
                        )}
                        {item.stats.strength !== undefined && item.stats.strength > 0 && (
                          <div className="flex items-center justify-between text-rose-400 font-semibold">
                            <span>Сила:</span>
                            <span>+{item.stats.strength}</span>
                          </div>
                        )}
                        {item.stats.agility !== undefined && item.stats.agility > 0 && (
                          <div className="flex items-center justify-between text-amber-400 font-semibold">
                            <span>Ловкость:</span>
                            <span>+{item.stats.agility}</span>
                          </div>
                        )}
                        {item.stats.endurance !== undefined && item.stats.endurance > 0 && (
                          <div className="flex items-center justify-between text-emerald-400 font-semibold">
                            <span>Выносливость:</span>
                            <span>+{item.stats.endurance}</span>
                          </div>
                        )}
                        {item.stats.intelligence !== undefined && item.stats.intelligence > 0 && (
                          <div className="flex items-center justify-between text-indigo-400 font-semibold">
                            <span>Интеллект:</span>
                            <span>+{item.stats.intelligence}</span>
                          </div>
                        )}
                        {item.stats.hp !== undefined && item.stats.hp > 0 && (
                          <div className="flex items-center justify-between text-emerald-300 font-semibold">
                            <span>Здоровье:</span>
                            <span>+{item.stats.hp} ХП</span>
                          </div>
                        )}
                        {item.stats.critChance !== undefined && (item.stats.critChance * 100) > 0 && (
                          <div className="flex items-center justify-between text-amber-300 font-semibold">
                            <span>Крит. шанс:</span>
                            <span>+{(item.stats.critChance * 100).toFixed(1).replace(/\.0$/, '')}%</span>
                          </div>
                        )}
                        {item.stats.speed !== undefined && item.stats.speed > 0 && (
                          <div className="flex items-center justify-between text-teal-300 font-semibold">
                            <span>Скорость:</span>
                            <span>+{item.stats.speed}</span>
                          </div>
                        )}
                        {(item.category === 'gloves' || item.stats.attackRecoverySpeed !== undefined || item.attackRecoverySpeed !== undefined) && (() => {
                          const recBonus = item.stats.attackRecoverySpeed ?? item.attackRecoverySpeed ?? 0;
                          const recSec = Math.max(0.05, Math.round(0.50 * (1 - recBonus / 100) * 100) / 100);
                          return (
                            <div className="col-span-2 flex items-center justify-between text-teal-300 font-bold bg-teal-950/40 px-2 py-1 rounded border border-teal-500/40 shadow-[0_0_8px_rgba(20,184,166,0.3)]">
                              <span className="flex items-center gap-1">⏱ Скорость восстановления:</span>
                              <span>-{recBonus}% ({recSec.toFixed(2)} сек.)</span>
                            </div>
                          );
                        })()}
                        {item.stats.vampirism !== undefined && item.stats.vampirism > 0 && (
                          <div className="flex items-center justify-between text-rose-400 font-bold animate-pulse">
                            <span>Вампиризм:</span>
                            <span>+{Number(item.stats.vampirism.toFixed(2))}%</span>
                          </div>
                        )}
                        {item.weaponData?.stunChance !== undefined && item.weaponData.stunChance > 0 && (
                          <div className="col-span-2 flex flex-col gap-1 p-1.5 rounded bg-yellow-950/30 border border-yellow-700/50">
                            <div className="flex items-center justify-between text-yellow-300 font-bold text-[10px]">
                              <span>⚡ Оглушение:</span>
                              <span>{Math.round(item.weaponData.stunChance * 100)}% шанс</span>
                            </div>
                            <div className="flex items-center justify-between text-yellow-100 text-[10px]">
                              <span>Длительность:</span>
                              <span>{item.weaponData.stunDurationMin}–{item.weaponData.stunDurationMax} сек.</span>
                            </div>
                            {item.weaponData.bonusDamageMultiplier !== undefined && (
                              <div className="flex items-center justify-between text-yellow-100 text-[10px]">
                                <span>Доп. урон:</span>
                                <span>+{Math.round(item.weaponData.bonusDamageMultiplier * 100)}%</span>
                              </div>
                            )}
                          </div>
                        )}
                        {item.weaponData?.doubleStrikeChance !== undefined && item.weaponData.doubleStrikeChance > 0 && (
                          <div className="col-span-2 flex items-center justify-between text-sky-300 font-bold bg-sky-950/40 px-2 py-1 rounded border border-sky-500/40 shadow-[0_0_8px_rgba(56,189,248,0.4)]">
                            <span className="flex items-center gap-1">⚡ Двойной удар:</span>
                            <span>{Math.round(item.weaponData.doubleStrikeChance * 100)}% шанс</span>
                          </div>
                        )}
                        {(item.stats.chainLightningChance !== undefined || item.chainLightningChance !== undefined) && (
                          <div className="col-span-2 flex items-center justify-between text-cyan-300 font-bold bg-cyan-950/40 px-2 py-1 rounded border border-cyan-500/40 shadow-[0_0_8px_rgba(0,240,255,0.4)]">
                            <span className="flex items-center gap-1">⚡ Цепная молния:</span>
                            <span>
                              {Math.round(((item.stats.chainLightningChance ?? item.chainLightningChance) || 0.25) * 100)}% шанс
                              {' • '}
                              {Math.round(((item.stats.chainLightningDamageRatio ?? item.chainLightningDamageRatio) || 0.65) * 100)}% ур.
                            </span>
                          </div>
                        )}
                        {item.weaponData?.bleedChance !== undefined && item.weaponData.bleedChance > 0 && (
                          <div className="col-span-2 flex items-center justify-between text-orange-400 font-bold bg-orange-950/30 px-2 py-1 rounded border border-orange-500/50 shadow-[0_0_8px_rgba(249,115,22,0.3)]">
                            <span className="flex items-center gap-1">🩸 Рваная рана:</span>
                            <span>
                              {Math.round(item.weaponData.bleedChance * 1000) / 10}% шанс
                              {' • '}
                              {Math.round((item.weaponData.bleedDamageRatio || 0.95) * 100)}% ур.
                            </span>
                          </div>
                        )}
                        {item.weaponData?.ruthlessnessRatio !== undefined && item.weaponData.ruthlessnessRatio > 0 && (
                          <div className="col-span-2 flex flex-col gap-0.5 p-1.5 rounded bg-orange-950/40 border border-orange-500/50 shadow-[0_0_8px_rgba(249,115,22,0.3)]">
                            <div className="flex items-center justify-between text-orange-300 font-bold text-[10px]">
                              <span className="flex items-center gap-1">🪓 Безжалостность:</span>
                              <span>+{Math.round(item.weaponData.ruthlessnessRatio * 10000) / 100}% за 1% нед. HP</span>
                            </div>
                            <div className="text-orange-200/80 text-[9px] leading-tight">
                              Чем меньше HP у цели, тем больше урон (до +{Math.round(item.weaponData.ruthlessnessRatio * 10000)}% урона).
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="text-[11px] text-slate-300 leading-snug p-2 rounded bg-slate-800/30 italic">
                      {item.description}
                    </div>

                    {/* Forge / Upgrade Section */}
                    {!item.isResource && item.level < 10 && (
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-slate-200 flex items-center gap-1">
                            <Hammer className="w-3 h-3 text-amber-400" />
                            Кузница: Улучшение
                          </span>
                          <span className="text-emerald-400 font-bold text-[10px]">
                            → Ур. {item.level + 1}
                          </span>
                        </div>

                        {(() => {
                          const costs = getItemUpgradeCost(item);
                          let canAfford = true;

                          return (
                            <div className="flex flex-col gap-1.5">
                              <div className="flex flex-wrap gap-1.5 text-[10px]">
                                {Object.entries(costs).map(([resKey, needed]) => {
                                  if (!needed) return null;
                                  const type = resKey as IngredientType;
                                  const available = countResourceInInventory(inventory, type);
                                  const hasEnough = available >= needed;
                                  if (!hasEnough) canAfford = false;

                                  return (
                                    <div 
                                      key={type} 
                                      className={`px-1.5 py-0.5 rounded border flex items-center gap-1 ${
                                        hasEnough 
                                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                                          : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                                      }`}
                                    >
                                      <ResourceIcon type={type} className="w-4 h-4" />
                                      <span className="font-bold">
                                        {available}/{needed}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>

                              <button
                                disabled={!canAfford}
                                onClick={() => handleUpgradeClick(item, source)}
                                className={`w-full py-1 rounded-lg font-bold text-[11px] flex items-center justify-center gap-1 shadow cursor-pointer transition-all ${
                                  canAfford 
                                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20' 
                                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                                }`}
                              >
                                <TrendingUp className="w-3 h-3" />
                                {canAfford ? 'Улучшить предмет' : 'Не хватает ресурсов'}
                              </button>
                            </div>
                          );
                        })()}
                      </div>
                    )}

                    {/* Actions: Equip, Unequip, Salvage */}
                    <div className="flex items-center gap-2 pt-1 border-t border-slate-800">
                      {!isEquipped && !item.isResource && (
                        <button
                          onClick={() => {
                            onEquipItem(item);
                            setModalView(null);
                            showToast(`Надето: ${item.name}`);
                          }}
                          className="flex-1 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow cursor-pointer transition-colors"
                        >
                          Надеть
                        </button>
                      )}

                      {isEquipped && (
                        <button
                          onClick={() => {
                            onUnequipItem(source.slot as EquipmentSlotType);
                            setModalView(null);
                            showToast(`Снято: ${item.name}`);
                          }}
                          className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs cursor-pointer transition-colors"
                        >
                          Снять в рюкзак
                        </button>
                      )}

                      {!item.isResource && (
                        <button
                          onClick={() => handleSalvageClick(item, source)}
                          className="px-3 py-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 font-bold text-xs cursor-pointer transition-colors"
                          title="Разобрать предмет на руду и материалы"
                        >
                          Разобрать
                        </button>
                      )}
                    </div>
                  </>
                );
              })()}

              {/* 2. EMPTY EQUIPMENT SLOT SELECTION MODAL */}
              {modalView.type === 'empty_slot' && (() => {
                const targetSlot = modalView.slot;
                const meta = EQUIPMENT_SLOT_META[targetSlot];
                const candidates = inventory
                  .map((item, idx) => ({ item, index: idx }))
                  .filter(({ item }) => item && !item.isResource && item.category === meta.category);

                return (
                  <>
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2">
                        <SlotSilhouetteIcon slotKey={targetSlot} className="w-5 h-5 pointer-events-none" />
                        <span className="font-bold text-xs text-slate-100">
                          Слот: {meta.label}
                        </span>
                      </div>
                      <button
                        onClick={() => setModalView(null)}
                        className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex flex-col gap-1.5 max-h-56 overflow-y-auto pr-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Подходящие вещи в рюкзаке:
                      </span>

                      {candidates.length === 0 ? (
                        <div className="p-4 rounded-lg bg-slate-950/50 border border-slate-800 text-center text-xs text-slate-500 flex flex-col items-center gap-1.5">
                          <PackageOpen className="w-6 h-6 text-slate-600" />
                          <span>В рюкзаке нет подходящих предметов для этого слота.</span>
                        </div>
                      ) : (
                        candidates.map(({ item }) => {
                          if (!item) return null;
                          const rTheme = getRarityTheme(item.rarity);

                          return (
                            <div
                              key={item.id}
                              className={`p-2 rounded-lg border flex items-center justify-between transition-colors ${rTheme.border} ${rTheme.bg}`}
                            >
                              <div className="flex items-center gap-2">
                                <GameItemIcon item={item} className="w-6 h-6" />
                                <div>
                                  <div className={`text-xs font-bold ${rTheme.text}`}>
                                    {item.name}
                                  </div>
                                  <div className="text-[9px] text-slate-400">
                                    Ур. {item.level}
                                    {item.stats.damageMin !== undefined && ` • ${item.stats.damageMin}-${item.stats.damageMax} урон`}
                                    {item.stats.armor !== undefined && ` • +${item.stats.armor} броня`}
                                    {item.stats.hp !== undefined && ` • +${item.stats.hp} ХП`}
                                    {item.stats.vampirism !== undefined && ` • +${Number(item.stats.vampirism.toFixed(2))}% вампиризм`}
                                    {(item.category === 'gloves' || item.stats.attackRecoverySpeed !== undefined || item.attackRecoverySpeed !== undefined) && (
                                      ` • -${item.stats.attackRecoverySpeed ?? item.attackRecoverySpeed ?? 0}% скор. (${Math.max(0.05, Math.round(0.50 * (1 - ((item.stats.attackRecoverySpeed ?? item.attackRecoverySpeed) || 0) / 100) * 100) / 100).toFixed(2)}сек.)`
                                    )}
                                  </div>
                                </div>
                              </div>

                              <button
                                onClick={() => {
                                  onEquipItem(item, targetSlot);
                                  setModalView(null);
                                  showToast(`Надето: ${item.name}`);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-[11px] cursor-pointer shadow transition-colors"
                              >
                                Надеть
                              </button>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </>
                );
              })()}

              {/* 3. CHARACTER STATS MODAL */}
              {modalView.type === 'stats' && (
                <>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-md bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
                        <Plus className="w-3.5 h-3.5 text-amber-400" />
                      </div>
                      <div>
                        <h3 className="font-bold text-xs text-slate-100">
                          Характеристики Героя
                        </h3>
                        <span className="text-[10px] text-slate-400">
                          Свободных очков: <strong className="text-amber-300 font-black">{stats.statPoints}</strong>
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => setModalView(null)}
                      className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    {/* Strength */}
                    <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-slate-200 flex items-center gap-1">
                          <Flame className="w-3 h-3 text-rose-400" />
                          Сила
                        </div>
                        <div className="text-[9px] text-slate-400">+0.5 урона</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-rose-300">
                          {totalStr}
                          {bonusStrTotal > 0 && <span className="text-[10px] text-sky-400 font-normal ml-0.5">(+{bonusStrTotal})</span>}
                        </span>
                        {stats.statPoints > 0 && (
                          <button
                            onClick={() => onUpgradeStat('strength')}
                            className="w-5 h-5 rounded bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center font-bold text-xs cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Agility */}
                    <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-slate-200 flex items-center gap-1">
                          <Zap className="w-3 h-3 text-amber-400" />
                          Ловкость
                        </div>
                        <div className="text-[9px] text-slate-400">+0.15% крит, +0.17% кр.урон</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-amber-300">
                          {totalAgi}
                          {bonusAgiTotal > 0 && <span className="text-[10px] text-sky-400 font-normal ml-0.5">(+{bonusAgiTotal})</span>}
                        </span>
                        {stats.statPoints > 0 && (
                          <button
                            onClick={() => onUpgradeStat('agility')}
                            className="w-5 h-5 rounded bg-amber-600 hover:bg-amber-500 text-white flex items-center justify-center font-bold text-xs cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Endurance */}
                    <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-slate-200 flex items-center gap-1">
                          <Heart className="w-3 h-3 text-emerald-400" />
                          Выносливость
                        </div>
                        <div className="text-[9px] text-slate-400">+3 макс. ХП</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-emerald-300">
                          {totalEnd}
                          {bonusEndTotal > 0 && <span className="text-[10px] text-sky-400 font-normal ml-0.5">(+{bonusEndTotal})</span>}
                        </span>
                        {stats.statPoints > 0 && (
                          <button
                            onClick={() => onUpgradeStat('endurance')}
                            className="w-5 h-5 rounded bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center font-bold text-xs cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Intelligence */}
                    <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-slate-200 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-indigo-400" />
                          Интеллект
                        </div>
                        <div className="text-[9px] text-slate-400">+3 макс. маны</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-indigo-300">
                          {totalInt}
                          {bonusIntTotal > 0 && <span className="text-[10px] text-sky-400 font-normal ml-0.5">(+{bonusIntTotal})</span>}
                        </span>
                        {stats.statPoints > 0 && (
                          <button
                            onClick={() => onUpgradeStat('intelligence')}
                            className="w-5 h-5 rounded bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center font-bold text-xs cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-[10px] grid grid-cols-2 gap-1.5">
                    <div className="text-rose-300">Урон: <strong className="text-slate-100">{minDamage}–{maxDamage}</strong></div>
                    <div className="text-sky-300">Броня: <strong className="text-slate-100">{totalEquipArmor} (-{damageReductionPercent}%)</strong></div>
                    <div className="text-amber-300">Крит: <strong className="text-slate-100">{effectiveCrit}% ({effectiveCritDmg}%)</strong></div>
                    <div className="text-emerald-300">ХП: <strong className="text-slate-100">{Math.ceil(stats.hp)} / {stats.maxHp}</strong></div>
                    <div className="text-teal-300 col-span-2 border-t border-slate-900 pt-1 mt-0.5 flex justify-between font-semibold">
                      <span>Восстановление (Скорость):</span>
                      <strong className="text-teal-200">{effectiveRecoverySec.toFixed(2)} сек. {totalRecoverySpeedBonus > 0 ? `(-${totalRecoverySpeedBonus}%)` : ''}</strong>
                    </div>
                    {stats.vampirism !== undefined && stats.vampirism > 0 && (
                      <div className="text-rose-400 col-span-2 border-t border-slate-900 pt-1 mt-0.5 flex justify-between">
                        <span>Вампиризм:</span>
                        <strong className="text-rose-200">+{Number(stats.vampirism.toFixed(2))}%</strong>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => setModalView(null)}
                    className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer transition-colors"
                  >
                    Вернуться к инвентарю
                  </button>
                </>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
});
