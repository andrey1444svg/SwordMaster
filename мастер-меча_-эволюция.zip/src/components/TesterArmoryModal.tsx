import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Wrench, 
  Shield, 
  Sparkles, 
  Search, 
  Check, 
  Zap, 
  Flame, 
  Droplet, 
  Hammer, 
  ShieldAlert,
  Package,
  Crosshair,
  Crown
} from 'lucide-react';
import { 
  InventoryItem, 
  EquipmentState, 
  EquipmentSlotType, 
  EquipmentCategory, 
  ItemRarity, 
  WeaponType, 
  IngredientType,
  ResourceInventory
} from '../types/game';
import { 
  createTesterEquipmentItem, 
  WEAPON_NAMES_BY_TYPE, 
  ITEM_NAMES, 
  createResourceItem 
} from '../utils/lootGenerator';
import { GameItemIcon } from './GameIcons';
import { soundManager } from '../utils/audio';
import { BOSSES_LIST } from './StartScreen';

interface TesterArmoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  equipment: EquipmentState;
  onEquipItem: (item: InventoryItem, targetSlot?: EquipmentSlotType) => void;
  onAddItem: (item: InventoryItem) => void;
  onAddResources?: (resources: Partial<ResourceInventory>) => void;
  onStartGameWithBoss?: (bossId: string, level: number) => void;
  onStartGameAtLevel?: (level: number) => void;
  onStartGame?: () => void;
}

type MainCategoryFilter = 'all' | EquipmentCategory | 'resource';

export const TesterArmoryModal: React.FC<TesterArmoryModalProps> = ({
  isOpen,
  onClose,
  equipment,
  onEquipItem,
  onAddItem,
  onAddResources,
  onStartGameWithBoss,
  onStartGameAtLevel,
  onStartGame
}) => {
  const [activeTab, setActiveTab] = useState<'armory' | 'teleport'>('armory');
  const [selectedCategory, setSelectedCategory] = useState<MainCategoryFilter>('weapon');
  const [selectedWeaponType, setSelectedWeaponType] = useState<WeaponType | 'all'>('all');
  const [selectedRarity, setSelectedRarity] = useState<ItemRarity | 'all'>('epic');
  const [selectedLevel, setSelectedLevel] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Teleportation Tab States
  const [teleportDungeonLevel, setTeleportDungeonLevel] = useState<number>(1);
  const [teleportBossLevel, setTeleportBossLevel] = useState<number>(1);
  const [selectedBossId, setSelectedBossId] = useState<string>('fatty');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 1800);
  };

  const categories: { id: MainCategoryFilter; label: string; icon: string }[] = [
    { id: 'weapon', label: 'Оружие', icon: 'Sword' },
    { id: 'helmet', label: 'Шлемы', icon: 'HardHat' },
    { id: 'chest', label: 'Нагрудники', icon: 'Shirt' },
    { id: 'pants', label: 'Поножи', icon: 'Footprints' },
    { id: 'boots', label: 'Сапоги', icon: 'Sparkle' },
    { id: 'gloves', label: 'Перчатки', icon: 'Hand' },
    { id: 'bracers', label: 'Наручи', icon: 'Watch' },
    { id: 'belt', label: 'Пояса', icon: 'Minimize2' },
    { id: 'cloak', label: 'Плащи', icon: 'Wind' },
    { id: 'ring', label: 'Кольца', icon: 'CircleDot' },
    { id: 'trinket', label: 'Амулеты', icon: 'Sparkles' },
    { id: 'resource', label: 'Ресурсы', icon: 'iron_ore' },
    { id: 'all', label: 'Все предметы', icon: 'Package' }
  ];

  const weaponTypes: { id: WeaponType | 'all'; label: string }[] = [
    { id: 'all', label: 'Все типы' },
    { id: 'sword', label: 'Мечи' },
    { id: 'katana', label: 'Катаны' },
    { id: 'axe', label: 'Топоры' },
    { id: 'hammer', label: 'Молоты' },
    { id: 'spear', label: 'Копья' },
    { id: 'greatsword', label: 'Двуручники' },
    { id: 'rapier', label: 'Рапиры' },
    { id: 'dagger', label: 'Кинжалы' },
    { id: 'fist', label: 'Кулаки' }
  ];

  const rarities: { id: ItemRarity | 'all'; label: string; color: string; bg: string }[] = [
    { id: 'all', label: 'Все редкости', color: 'text-slate-300', bg: 'bg-slate-800' },
    { id: 'common', label: 'Обычное', color: 'text-slate-200', bg: 'bg-slate-700' },
    { id: 'magic', label: 'Магическое', color: 'text-emerald-400', bg: 'bg-emerald-950/60 border-emerald-500/40' },
    { id: 'rare', label: 'Редкое', color: 'text-sky-400', bg: 'bg-sky-950/60 border-sky-500/40' },
    { id: 'epic', label: 'Эпическое', color: 'text-purple-400', bg: 'bg-purple-950/60 border-purple-500/40' }
  ];

  // Generate catalog of items based on filter
  const itemsCatalog = useMemo(() => {
    const list: InventoryItem[] = [];
    const targetRarities: ItemRarity[] = selectedRarity === 'all' 
      ? ['common', 'magic', 'rare', 'epic'] 
      : [selectedRarity];

    // 1. Weapons
    if (selectedCategory === 'weapon' || selectedCategory === 'all') {
      const targetWTypes: WeaponType[] = selectedWeaponType === 'all'
        ? ['sword', 'katana', 'axe', 'hammer', 'spear', 'greatsword', 'rapier', 'dagger', 'fist']
        : [selectedWeaponType];

      targetWTypes.forEach(wType => {
        targetRarities.forEach(rar => {
          const names = WEAPON_NAMES_BY_TYPE[wType]?.[rar] || [];
          names.forEach(name => {
            list.push(createTesterEquipmentItem({
              category: 'weapon',
              weaponType: wType,
              name,
              rarity: rar,
              level: selectedLevel
            }));
          });
        });
      });
    }

    // 2. Armor & Accessories
    const armorCats: Exclude<EquipmentCategory, 'weapon'>[] = [
      'helmet', 'chest', 'pants', 'boots', 'gloves', 'bracers', 'belt', 'cloak', 'ring', 'trinket'
    ];

    armorCats.forEach(cat => {
      if (selectedCategory === cat || selectedCategory === 'all') {
        targetRarities.forEach(rar => {
          const names = ITEM_NAMES[cat]?.[rar] || [];
          names.forEach(name => {
            list.push(createTesterEquipmentItem({
              category: cat,
              name,
              rarity: rar,
              level: selectedLevel
            }));
          });
        });
      }
    });

    // 3. Resources
    if (selectedCategory === 'resource' || selectedCategory === 'all') {
      const resTypes: IngredientType[] = ['iron_ore', 'magic_crystal', 'monster_core', 'ancient_rune', 'fire_essence'];
      resTypes.forEach(rType => {
        list.push(createResourceItem(rType, 50));
      });
    }

    // Filter by search query if present
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return list.filter(item => 
        item.name.toLowerCase().includes(q) || 
        item.description.toLowerCase().includes(q) ||
        (item.weaponData?.type && item.weaponData.type.toLowerCase().includes(q))
      );
    }

    return list;
  }, [selectedCategory, selectedWeaponType, selectedRarity, selectedLevel, searchQuery]);

  // Presets Handlers
  const handleApplyPreset = (presetType: string) => {
    soundManager.playEquip();
    if (presetType === 'axe_berserk') {
      const axeItem = createTesterEquipmentItem({ category: 'weapon', weaponType: 'axe', name: 'Огненная Секира Дракона', rarity: 'epic', level: 10 });
      const helm = createTesterEquipmentItem({ category: 'helmet', name: 'Шлем Драконьего Владыки', rarity: 'epic', level: 10 });
      const chest = createTesterEquipmentItem({ category: 'chest', name: 'Доспех Драконьей Чешуи', rarity: 'epic', level: 10 });
      const gloves = createTesterEquipmentItem({ category: 'gloves', name: 'Перчатки Пламени', rarity: 'epic', level: 10 });
      const boots = createTesterEquipmentItem({ category: 'boots', name: 'Сапоги Разрушителя', rarity: 'epic', level: 10 });
      const ring = createTesterEquipmentItem({ category: 'ring', name: 'Перстень Абсолюта', rarity: 'epic', level: 10 });
      const amulet = createTesterEquipmentItem({ category: 'trinket', name: 'Осколок Вечности', rarity: 'epic', level: 10 });

      onEquipItem(axeItem, 'weapon');
      onEquipItem(helm, 'helmet');
      onEquipItem(chest, 'chest');
      onEquipItem(gloves, 'gloves');
      onEquipItem(boots, 'boots');
      onEquipItem(ring, 'ring1');
      onEquipItem(amulet, 'trinket1');
      showToast('Надет сет: Берсерк с Секирой +10');
    } else if (presetType === 'lightning_master') {
      const wep = createTesterEquipmentItem({ category: 'weapon', weaponType: 'katana', name: 'Катана Бури', rarity: 'epic', level: 10 });
      const amulet1 = createTesterEquipmentItem({ category: 'trinket', name: 'Амулет Цепной Молнии', rarity: 'epic', level: 10 });
      const amulet2 = createTesterEquipmentItem({ category: 'trinket', name: 'Амулет Цепной Молнии', rarity: 'epic', level: 10 });
      const ring1 = createTesterEquipmentItem({ category: 'ring', name: 'Перстень Абсолюта', rarity: 'epic', level: 10 });
      const cloak = createTesterEquipmentItem({ category: 'cloak', name: 'Мантия Бури', rarity: 'epic', level: 10 });

      onEquipItem(wep, 'weapon');
      onEquipItem(amulet1, 'trinket1');
      onEquipItem(amulet2, 'trinket2');
      onEquipItem(ring1, 'ring1');
      onEquipItem(cloak, 'cloak');
      showToast('Надет сет: Повелитель Молний +10');
    } else if (presetType === 'hammer_crusher') {
      const wep = createTesterEquipmentItem({ category: 'weapon', weaponType: 'hammer', name: 'Титановый Сокрушитель', rarity: 'epic', level: 10 });
      const helm = createTesterEquipmentItem({ category: 'helmet', name: 'Венец Титана', rarity: 'epic', level: 10 });
      const chest = createTesterEquipmentItem({ category: 'chest', name: 'Латы Титана', rarity: 'epic', level: 10 });
      const bracers = createTesterEquipmentItem({ category: 'bracers', name: 'Оковы Титана', rarity: 'epic', level: 10 });

      onEquipItem(wep, 'weapon');
      onEquipItem(helm, 'helmet');
      onEquipItem(chest, 'chest');
      onEquipItem(bracers, 'bracers');
      showToast('Надет сет: Сокрушитель с Молотом +10');
    } else if (presetType === 'spear_bleeder') {
      const wep = createTesterEquipmentItem({ category: 'weapon', weaponType: 'spear', name: 'Копье Небес', rarity: 'epic', level: 10 });
      const gloves = createTesterEquipmentItem({ category: 'gloves', name: 'Ловкие Рукавицы', rarity: 'epic', level: 10 });
      const boots = createTesterEquipmentItem({ category: 'boots', name: 'Поступь Ветра', rarity: 'epic', level: 10 });

      onEquipItem(wep, 'weapon');
      onEquipItem(gloves, 'gloves');
      onEquipItem(boots, 'boots');
      showToast('Надет сет: Копейщик Крови +10');
    } else if (presetType === 'vampire_lord') {
      const wep = createTesterEquipmentItem({ category: 'weapon', weaponType: 'dagger', name: 'Клыки Вампира', rarity: 'epic', level: 10 });
      const ring1 = createTesterEquipmentItem({ category: 'ring', name: 'Кольцо Вампира', rarity: 'epic', level: 10 });
      const ring2 = createTesterEquipmentItem({ category: 'ring', name: 'Кольцо Вампира', rarity: 'epic', level: 10 });

      onEquipItem(wep, 'weapon');
      onEquipItem(ring1, 'ring1');
      onEquipItem(ring2, 'ring2');
      showToast('Надет сет: Вампир-Дуэлянт +10');
    } else if (presetType === 'max_resources') {
      if (onAddResources) {
        onAddResources({
          iron_ore: 99,
          magic_crystal: 99,
          monster_core: 99,
          ancient_rune: 99,
          fire_essence: 99
        });
      }
      onAddItem(createResourceItem('iron_ore', 99));
      onAddItem(createResourceItem('magic_crystal', 99));
      onAddItem(createResourceItem('monster_core', 99));
      onAddItem(createResourceItem('ancient_rune', 99));
      onAddItem(createResourceItem('fire_essence', 99));
      showToast('Выдано: +99 всех ресурсов для кузницы');
    }
  };

  const handleEquipDirectly = (item: InventoryItem) => {
    soundManager.playEquip();
    onEquipItem(item);
    showToast(`Надето: ${item.name} +${item.level}`);
  };

  const handleAddToInventory = (item: InventoryItem) => {
    soundManager.playLoot();
    onAddItem(item);
    showToast(`Добавлено в инвентарь: ${item.name}`);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-sm select-none">
        <motion.div
          initial={{ scale: 0.94, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.94, opacity: 0, y: 15 }}
          className="relative w-full max-w-6xl h-[92vh] flex flex-col bg-slate-950 rounded-2xl border-2 border-amber-500/70 shadow-[0_0_60px_rgba(245,158,11,0.3)] overflow-hidden text-slate-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 sm:px-6 py-3 border-b border-slate-800 bg-slate-900/90">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 
                    style={{ fontFamily: "'Russo One', sans-serif" }}
                    className="text-base sm:text-lg font-black text-amber-300 uppercase tracking-wide"
                  >
                    АРСЕНАЛ ТЕСТИРОВЩИКА
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                    ITEM SPAWNER & TEST SUITE
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Мгновенно наденьте любой предмет игры или добавьте в инвентарь с настройкой уровня заточки (+0..+10)
                </p>
              </div>
            </div>

            {/* Header Action Buttons */}
            <div className="flex items-center gap-2">
              {onStartGame && (
                <button
                  onClick={onStartGame}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>В ИГРУ</span>
                </button>
              )}
              {onStartGameWithBoss && (
                <button
                  onClick={() => onStartGameWithBoss('fatty', teleportBossLevel)}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-rose-900/50 transition-all cursor-pointer"
                >
                  <Crosshair className="w-4 h-4" />
                  <span>К БОССУ</span>
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Top Mode Navigation Tabs */}
          <div className="flex items-center gap-2 px-4 sm:px-6 pt-2 pb-0 bg-slate-900 border-b border-slate-800">
            <button
              onClick={() => setActiveTab('armory')}
              className={`px-4 py-2 rounded-t-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'armory'
                  ? 'bg-amber-500 text-slate-950 border-t-2 border-x border-amber-400 shadow-lg'
                  : 'bg-slate-950/80 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Wrench className="w-4 h-4" />
              <span>Предметы и Арсенал</span>
            </button>
            <button
              onClick={() => setActiveTab('teleport')}
              className={`px-4 py-2 rounded-t-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'teleport'
                  ? 'bg-amber-500 text-slate-950 border-t-2 border-x border-amber-400 shadow-lg'
                  : 'bg-slate-950/80 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Crosshair className="w-4 h-4" />
              <span>Уровни и Боссы</span>
            </button>
          </div>

          {activeTab === 'teleport' ? (
            /* TELEPORTATION TAB VIEW */
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6 custom-scrollbar bg-slate-900/30">
              {/* 1. Dungeon Level Teleportation Card */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border-2 border-sky-500/50 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40">
                      <Zap className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 style={{ fontFamily: "'Russo One', sans-serif" }} className="text-base sm:text-lg font-black text-sky-300 uppercase">
                        ТЕЛЕПОРТАЦИЯ НА ЛЮБОЙ УРОВЕНЬ
                      </h4>
                      <p className="text-xs text-slate-400">
                        Мгновенный переход на выбранный номер уровня лабиринта с генерацией залов и врагов под этот уровень.
                      </p>
                    </div>
                  </div>
                  <span className="text-xs sm:text-sm font-mono font-black px-3 py-1 bg-sky-500/20 text-sky-300 rounded-xl border border-sky-500/40">
                    Уровень: {teleportDungeonLevel}
                  </span>
                </div>

                {/* Level Controls & Quick Buttons */}
                <div className="flex flex-wrap items-center gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-xs font-bold text-slate-300">Номер уровня:</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setTeleportDungeonLevel(prev => Math.max(1, prev - 10))}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      -10
                    </button>
                    <button
                      onClick={() => setTeleportDungeonLevel(prev => Math.max(1, prev - 1))}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      -1
                    </button>
                    <input
                      type="number"
                      min={1}
                      max={999}
                      value={teleportDungeonLevel}
                      onChange={(e) => setTeleportDungeonLevel(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-center text-sm font-mono font-black text-amber-300 focus:outline-none focus:border-amber-500"
                    />
                    <button
                      onClick={() => setTeleportDungeonLevel(prev => prev + 1)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      +1
                    </button>
                    <button
                      onClick={() => setTeleportDungeonLevel(prev => prev + 10)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      +10
                    </button>
                  </div>

                  <div className="h-4 w-px bg-slate-800 hidden sm:block" />

                  <div className="flex items-center gap-1 overflow-x-auto">
                    {[1, 2, 3, 5, 10, 15, 20, 50, 100].map(lvl => (
                      <button
                        key={lvl}
                        onClick={() => setTeleportDungeonLevel(lvl)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                          teleportDungeonLevel === lvl
                            ? 'bg-sky-500 text-slate-950 font-black shadow-md'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        Ур.{lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (onStartGameAtLevel) {
                      onStartGameAtLevel(teleportDungeonLevel);
                    } else if (onStartGame) {
                      onStartGame();
                    }
                    onClose();
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>ТЕЛЕПОРТИРОВАТЬСЯ НА УРОВЕНЬ {teleportDungeonLevel}</span>
                </button>
              </div>

              {/* 2. Boss Arena Teleportation Card */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border-2 border-rose-500/50 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40">
                      <Flame className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 style={{ fontFamily: "'Russo One', sans-serif" }} className="text-base sm:text-lg font-black text-rose-300 uppercase">
                        АРЕНА БОССОВ ЛЮБОГО УРОВНЯ
                      </h4>
                      <p className="text-xs text-slate-400">
                        Выберите любого босса и установите нужный уровень сложности для мгновенного перемещения на арену.
                      </p>
                    </div>
                  </div>
                  <span className="text-xs sm:text-sm font-mono font-black px-3 py-1 bg-rose-500/20 text-rose-300 rounded-xl border border-rose-500/40">
                    Уровень сложности: {teleportBossLevel}
                  </span>
                </div>

                {/* Boss Selection Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {BOSSES_LIST.map((boss) => {
                    const BossIcon = boss.icon;
                    const isSelected = selectedBossId === boss.id;
                    return (
                      <button
                        key={boss.id}
                        type="button"
                        onClick={() => setSelectedBossId(boss.id)}
                        className={`p-3 rounded-xl border-2 text-left transition-all cursor-pointer ${
                          isSelected 
                            ? 'border-amber-400 bg-rose-950/60 shadow-lg ring-2 ring-amber-400/50' 
                            : 'border-slate-800 bg-slate-950/80 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <div className={`p-1.5 rounded-lg bg-gradient-to-br ${boss.color} text-white`}>
                            <BossIcon className="w-4 h-4" />
                          </div>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${boss.badgeColor}`}>
                            {boss.difficulty}
                          </span>
                        </div>
                        <h5 style={{ fontFamily: "'Russo One', sans-serif" }} className="text-xs font-black text-white uppercase">
                          {boss.name}
                        </h5>
                        <p className="text-[10px] text-amber-300 font-semibold mb-1">
                          {boss.title}
                        </p>
                        <p className="text-[10px] text-slate-400 line-clamp-2">
                          {boss.description}
                        </p>
                      </button>
                    );
                  })}
                </div>

                {/* Boss Level Controls & Quick Buttons */}
                <div className="flex flex-wrap items-center gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-xs font-bold text-slate-300">Уровень сложности босса:</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setTeleportBossLevel(prev => Math.max(1, prev - 5))}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      -5
                    </button>
                    <button
                      onClick={() => setTeleportBossLevel(prev => Math.max(1, prev - 1))}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      -1
                    </button>
                    <input
                      type="number"
                      min={1}
                      max={999}
                      value={teleportBossLevel}
                      onChange={(e) => setTeleportBossLevel(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-center text-sm font-mono font-black text-rose-300 focus:outline-none focus:border-rose-500"
                    />
                    <button
                      onClick={() => setTeleportBossLevel(prev => prev + 1)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      +1
                    </button>
                    <button
                      onClick={() => setTeleportBossLevel(prev => prev + 5)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                    >
                      +5
                    </button>
                  </div>

                  <div className="h-4 w-px bg-slate-800 hidden sm:block" />

                  <div className="flex items-center gap-1 overflow-x-auto">
                    {[1, 2, 3, 5, 10, 15, 20, 50, 100].map(lvl => (
                      <button
                        key={lvl}
                        onClick={() => setTeleportBossLevel(lvl)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                          teleportBossLevel === lvl
                            ? 'bg-rose-500 text-white font-black shadow-md'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        Босс Ур.{lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (onStartGameWithBoss) {
                      onStartGameWithBoss(selectedBossId, teleportBossLevel);
                    }
                    onClose();
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-amber-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-950/50 cursor-pointer"
                >
                  <Crosshair className="w-4 h-4" />
                  <span>ТЕЛЕПОРТИРОВАТЬСЯ К БОССУ {BOSSES_LIST.find(b => b.id === selectedBossId)?.name || 'БОСС'} (УР. {teleportBossLevel})</span>
                </button>
              </div>
            </div>
          ) : (
            /* ARMORY TAB VIEW */
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden">

          {/* Quick Preset Sets Bar */}
          <div className="flex items-center gap-2 px-4 sm:px-6 py-2 bg-slate-900/60 border-b border-slate-800/80 overflow-x-auto custom-scrollbar">
            <span className="text-[11px] font-bold text-amber-400 shrink-0 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> Быстрые наборы:
            </span>
            <button
              onClick={() => handleApplyPreset('axe_berserk')}
              className="px-2.5 py-1 rounded-lg bg-orange-950/60 hover:bg-orange-900/80 border border-orange-500/40 text-orange-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              🪓 Берсерк (Топор +10)
            </button>
            <button
              onClick={() => handleApplyPreset('lightning_master')}
              className="px-2.5 py-1 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/40 text-cyan-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              ⚡ Маг Молний (+10)
            </button>
            <button
              onClick={() => handleApplyPreset('hammer_crusher')}
              className="px-2.5 py-1 rounded-lg bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/40 text-amber-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              🔨 Сокрушитель (Молот +10)
            </button>
            <button
              onClick={() => handleApplyPreset('spear_bleeder')}
              className="px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/40 text-rose-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              🩸 Копейщик Крови (+10)
            </button>
            <button
              onClick={() => handleApplyPreset('vampire_lord')}
              className="px-2.5 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/40 text-purple-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              🧛 Вампир-Дуэлянт (+10)
            </button>
            <button
              onClick={() => handleApplyPreset('max_resources')}
              className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              💎 Ресурсы x99
            </button>
          </div>

          {/* Filters Bar: Level & Rarity & Search */}
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-2.5 bg-slate-900/40 border-b border-slate-800">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px] max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Поиск предмета или эффекта..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>

            {/* Rarity Selector */}
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-[11px] font-bold text-slate-400 mr-1">Редкость:</span>
              {rarities.map(r => (
                <button
                  key={r.id}
                  onClick={() => setSelectedRarity(r.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                    selectedRarity === r.id
                      ? `${r.bg} ${r.color} shadow-md`
                      : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>

            {/* Upgrade Level Selector */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <span className="text-[11px] font-bold text-amber-300 px-2">Заточка:</span>
              {[0, 1, 2, 3, 5, 7, 10].map(lvl => (
                <button
                  key={lvl}
                  onClick={() => setSelectedLevel(lvl)}
                  className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black transition-all cursor-pointer ${
                    selectedLevel === lvl
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/40'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  +{lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Main Layout: Left Category Tabs + Right Grid */}
          <div className="flex flex-1 overflow-hidden">
            {/* Left Category Sidebar */}
            <div className="w-44 sm:w-52 border-r border-slate-800 bg-slate-950/80 p-2 sm:p-3 overflow-y-auto space-y-1 custom-scrollbar shrink-0">
              <div className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1">
                Категории
              </div>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    if (cat.id !== 'weapon') setSelectedWeaponType('all');
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                      : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <span className="truncate">{cat.label}</span>
                </button>
              ))}

              {/* Subcategories if weapon selected */}
              {selectedCategory === 'weapon' && (
                <div className="pt-3 border-t border-slate-800/80 space-y-1">
                  <div className="text-[10px] font-bold text-amber-400 uppercase px-2 py-1">
                    Типы оружия
                  </div>
                  {weaponTypes.map(wType => (
                    <button
                      key={wType.id}
                      onClick={() => setSelectedWeaponType(wType.id)}
                      className={`w-full flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        selectedWeaponType === wType.id
                          ? 'bg-amber-500/30 text-amber-200 border border-amber-500/50 font-bold'
                          : 'text-slate-400 hover:bg-slate-900/60 hover:text-slate-200'
                      }`}
                    >
                      {wType.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Right Items Grid */}
            <div className="flex-1 p-3 sm:p-4 overflow-y-auto custom-scrollbar bg-slate-900/20">
              {itemsCatalog.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 py-12">
                  <Package className="w-12 h-12 mb-2 stroke-1" />
                  <p className="text-sm font-semibold">Предметы не найдены</p>
                  <p className="text-xs text-slate-600">Попробуйте изменить параметры фильтра или поисковый запрос</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {itemsCatalog.map((item, idx) => {
                    const rarityColor = 
                      item.rarity === 'epic' ? 'border-purple-500/50 bg-purple-950/20 text-purple-300' :
                      item.rarity === 'rare' ? 'border-sky-500/50 bg-sky-950/20 text-sky-300' :
                      item.rarity === 'magic' ? 'border-emerald-500/50 bg-emerald-950/20 text-emerald-300' :
                      'border-slate-700 bg-slate-900/40 text-slate-300';

                    const isEquipped = (Object.values(equipment) as (InventoryItem | null)[]).some(
                      eq => eq?.name === item.name
                    );

                    return (
                      <motion.div
                        key={`${item.id}_${idx}`}
                        whileHover={{ y: -2 }}
                        className={`relative flex flex-col justify-between p-3.5 rounded-xl border-2 transition-all ${rarityColor} bg-slate-950/90 shadow-md`}
                      >
                        <div>
                          {/* Item Top Row */}
                          <div className="flex items-start gap-3 mb-2.5">
                            <div className="relative shrink-0 w-12 h-12 rounded-xl bg-slate-900 border border-slate-700/80 flex items-center justify-center p-1 shadow-inner">
                              <GameItemIcon item={item} size={36} />
                              {item.level > 0 && (
                                <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.2 bg-amber-500 text-slate-950 font-mono font-black text-[10px] rounded-full shadow">
                                  +{item.level}
                                </span>
                              )}
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-1">
                                <h4 className="text-xs font-black text-white truncate">
                                  {item.name}
                                </h4>
                                {isEquipped && (
                                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold shrink-0">
                                    НАДЕТО
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-400 capitalize">
                                {item.category === 'weapon' ? (item.weaponData?.type || 'Оружие') : item.category} • {item.rarity}
                              </p>
                            </div>
                          </div>

                          {/* Stats Preview Pills */}
                          <div className="flex flex-wrap gap-1 mb-2 text-[10px]">
                            {item.stats.damageMin !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-red-950/60 border border-red-500/40 text-red-300 font-bold">
                                Урон: {item.stats.damageMin}-{item.stats.damageMax}
                              </span>
                            )}
                            {item.stats.armor !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-500/40 text-blue-300 font-bold">
                                Броня: +{item.stats.armor}
                              </span>
                            )}
                            {item.stats.hp !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-rose-950/60 border border-rose-500/40 text-rose-300 font-bold">
                                ХП: +{item.stats.hp}
                              </span>
                            )}
                            {item.stats.critChance !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300 font-bold">
                                Крит: +{(item.stats.critChance * 100).toFixed(1).replace(/\.0$/, '')}%
                              </span>
                            )}
                            {item.stats.vampirism !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-rose-950/60 border border-rose-500/40 text-rose-300 font-bold">
                                Вампиризм: +{Number((item.stats.vampirism || 0).toFixed(2))}%
                              </span>
                            )}
                            {item.stats.strength !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-orange-950/60 border border-orange-500/40 text-orange-300 font-bold">
                                СИЛ: +{item.stats.strength}
                              </span>
                            )}
                            {item.stats.agility !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-bold">
                                ЛОВ: +{item.stats.agility}
                              </span>
                            )}
                            {item.stats.attackRecoverySpeed !== undefined && (
                              <span className="px-1.5 py-0.5 rounded bg-teal-950/60 border border-teal-500/40 text-teal-300 font-bold">
                                Скор. атаки: +{item.stats.attackRecoverySpeed}%
                              </span>
                            )}
                          </div>

                          {/* Unique Effect / Description */}
                          {item.description && (
                            <p className="text-[10px] text-amber-300/90 leading-tight mb-3 line-clamp-2 bg-slate-900/70 p-1.5 rounded-lg border border-slate-800">
                              {item.description}
                            </p>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                          {item.category !== 'resource' && (
                            <button
                              onClick={() => handleEquipDirectly(item)}
                              className="flex-1 py-1.5 px-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-md shadow-amber-500/20"
                            >
                              <Zap className="w-3.5 h-3.5" />
                              <span>НАДЕТЬ</span>
                            </button>
                          )}
                          <button
                            onClick={() => handleAddToInventory(item)}
                            className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1 ${
                              item.category === 'resource'
                                ? 'flex-1 bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                            }`}
                          >
                            <Package className="w-3.5 h-3.5" />
                            <span>В ИНВЕНТАРЬ</span>
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

          {/* Footer Toast Alert */}
          <AnimatePresence>
            {toastMessage && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-2xl flex items-center gap-2 z-50 pointer-events-none"
              >
                <Check className="w-4 h-4" />
                <span>{toastMessage}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
