import React, { useRef, useEffect, useState, useCallback, useLayoutEffect } from 'react';
import { CustomRoomData, LayerType, ROOM_TYPE_CONFIGS, RoomType, RoomElement, isElementAboveHero } from '../../types/roomEditor';
import { X, Play, RefreshCw, ZoomIn, ZoomOut } from 'lucide-react';
import { isTorchElement, getTorchConfig, drawTorchFlame, drawRoomLightingPass, isShadowZone, renderSeamlessShadows } from '../../utils/torchEffects';

interface PlaytestModalProps {
  room: CustomRoomData;
  onClose: () => void;
}

export const PlaytestModal: React.FC<PlaytestModalProps> = ({ room, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [zoomLevel, setZoomLevel] = useState<number>(1.0);

  // Virtual Joystick state & refs for mobile character movement
  const joystickVectorRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickKnob, setJoystickKnob] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState<boolean>(false);
  const joystickTouchIdRef = useRef<number | null>(null);

  // Asset image cache
  const imagesRef = useRef<Map<string, HTMLImageElement>>(new Map());

  // Keyboard input tracking
  const keysRef = useRef<{ [key: string]: boolean }>({});

  // Player state: exact 35x35 dimensions from the game (unsquished, 1:1 aspect ratio)
  const spawnX = room.spawnPoint?.x ?? 400;
  const spawnY = room.spawnPoint?.y ?? 300;

  const playerRef = useRef({
    x: spawnX,
    y: spawnY,
    vx: 0,
    vy: 0,
    w: 35, // Exact in-game dimensions
    h: 35,
    facing: 'down' as 'left' | 'right' | 'up' | 'down'
  });

  // Always reset player exactly to spawn point whenever room or spawnPoint changes
  useEffect(() => {
    playerRef.current.x = room.spawnPoint?.x ?? 400;
    playerRef.current.y = room.spawnPoint?.y ?? 300;
    playerRef.current.vx = 0;
    playerRef.current.vy = 0;
  }, [room.spawnPoint]);

  // Preload asset textures
  useEffect(() => {
    room.elements.forEach(el => {
      if (el.src && !imagesRef.current.has(el.src)) {
        const img = new Image();
        img.src = el.src;
        imagesRef.current.set(el.src, img);
      }
    });
  }, [room.elements]);

  // Synchronize canvas size to avoid any squishing / distortion
  const syncCanvasSize = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const dpr = window.devicePixelRatio || 1;
    const targetW = Math.round(rect.width * dpr);
    const targetH = Math.round(rect.height * dpr);

    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }
    const cssW = `${Math.round(rect.width)}px`;
    const cssH = `${Math.round(rect.height)}px`;
    if (canvas.style.width !== cssW) canvas.style.width = cssW;
    if (canvas.style.height !== cssH) canvas.style.height = cssH;
  }, []);

  useLayoutEffect(() => {
    syncCanvasSize();
    const container = containerRef.current;
    if (!container) return;
    const ro = new ResizeObserver(() => syncCanvasSize());
    ro.observe(container);
    return () => ro.disconnect();
  }, [syncCanvasSize]);

  // Keyboard listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;

      if (e.code === 'KeyR') {
        // Reset player to spawn point
        playerRef.current.x = room.spawnPoint?.x ?? 400;
        playerRef.current.y = room.spawnPoint?.y ?? 300;
        playerRef.current.vx = 0;
        playerRef.current.vy = 0;
      }
      if (e.code === 'Escape') {
        onClose();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [room.spawnPoint, onClose]);

  // Main game & render loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = Math.min(0.05, (currentTime - lastTime) / 1000);
      lastTime = currentTime;

      const p = playerRef.current;

      // 1. Walking input (WASD / Arrow keys OR Virtual Joystick for mobile/touch)
      let moveX = 0;
      let moveY = 0;

      if (keysRef.current['KeyW'] || keysRef.current['ArrowUp']) moveY -= 1;
      if (keysRef.current['KeyS'] || keysRef.current['ArrowDown']) moveY += 1;
      if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) moveX -= 1;
      if (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) moveX += 1;

      if (moveX !== 0 && moveY !== 0) {
        moveX *= 0.7071;
        moveY *= 0.7071;
      }

      // Add or override with joystick input if engaged
      const jx = joystickVectorRef.current.x;
      const jy = joystickVectorRef.current.y;
      const jMag = Math.hypot(jx, jy);
      if (jMag > 0.05) {
        moveX = jx;
        moveY = jy;
      }

      if (Math.abs(moveX) > 0.05 || Math.abs(moveY) > 0.05) {
        if (Math.abs(moveX) >= Math.abs(moveY)) {
          p.facing = moveX > 0 ? 'right' : 'left';
        } else {
          p.facing = moveY > 0 ? 'down' : 'up';
        }
      }

      const walkSpeed = 260; // px/sec
      p.vx = moveX * walkSpeed;
      p.vy = moveY * walkSpeed;

      // 2. Collision checking with Room Collision Boxes
      const solidBoxes = (room.collisionBoxes || []).filter(cb => cb.enabled && (cb.type === 'wall' || cb.type === 'hazard'));
      const halfW = p.w / 2;
      const halfH = p.h / 2;

      // X Axis movement & collision
      const nextX = p.x + p.vx * dt;
      let canMoveX = true;
      for (const box of solidBoxes) {
        if (
          nextX + halfW > box.x &&
          nextX - halfW < box.x + box.w &&
          p.y + halfH > box.y &&
          p.y - halfH < box.y + box.h
        ) {
          canMoveX = false;
          break;
        }
      }
      if (canMoveX) p.x = nextX;

      // Y Axis movement & collision
      const nextY = p.y + p.vy * dt;
      let canMoveY = true;
      for (const box of solidBoxes) {
        if (
          p.x + halfW > box.x &&
          p.x - halfW < box.x + box.w &&
          nextY + halfH > box.y &&
          nextY - halfH < box.y + box.h
        ) {
          canMoveY = false;
          break;
        }
      }
      if (canMoveY) p.y = nextY;

      // Render frame
      renderFrame(currentTime / 1000);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [room, zoomLevel, syncCanvasSize]);

  // Render Frame
  const renderFrame = (timeSec: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    syncCanvasSize();

    const p = playerRef.current;
    const dpr = window.devicePixelRatio || 1;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.scale(dpr, dpr);

    const viewW = canvas.width / dpr;
    const viewH = canvas.height / dpr;

    // Camera Calculation: Strictly centered on the character (spawn point)
    ctx.translate(viewW / 2, viewH / 2);
    ctx.scale(zoomLevel, zoomLevel);
    ctx.translate(-p.x, -p.y);

    // Helper to draw an element
    const renderElement = (el: RoomElement) => {
      ctx.save();
      ctx.translate(el.x + el.w / 2, el.y + el.h / 2);
      ctx.rotate((el.rotation * Math.PI) / 180);
      ctx.scale(
        (el.scaleX || 1) * (el.flipX ? -1 : 1),
        (el.scaleY || 1) * (el.flipY ? -1 : 1)
      );
      ctx.globalAlpha = el.opacity ?? 1;

      const isFlameOnly = el.assetId === 'light_fire_flame' || el.assetId === 'light_torch_flame' || (el.assetId && el.assetId.includes('flame'));
      const isShadow = isShadowZone(el);
      if (!isFlameOnly && !isShadow) {
        const img = imagesRef.current.get(el.src);
        if (img && img.complete) {
          ctx.drawImage(img, -el.w / 2, -el.h / 2, el.w, el.h);
        } else {
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(-el.w / 2, -el.h / 2, el.w, el.h);
        }
      }
      ctx.restore();

      // Animated Torch Flames
      const hasFire = el.hasFireEffect ?? isTorchElement(el.assetId, el.name);
      if (hasFire && el.visible !== false) {
        const config = getTorchConfig(el.assetId);
        const cx = el.x + el.w / 2;
        const cy = el.y + el.h / 2;
        const rad = ((el.rotation || 0) * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);

        const effH = el.h * (el.scaleY || 1);
        const localAnchorY = (effH / 2) * (config.anchorOffsetYRatio * 2);
        const localAnchorX = 0;

        const fx = cx + localAnchorX * cos - localAnchorY * sin;
        const fy = cy + localAnchorX * sin + localAnchorY * cos;

        const flameScale = config.scale * Math.max(0.4, (Math.abs(el.scaleX || 1) + Math.abs(el.scaleY || 1)) / 2) * (el.fireScale || 1);
        const seed = Math.abs((el.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) * 1.618) % 100);

        drawTorchFlame(ctx, fx, fy, flameScale, timeSec, seed, config.baseWidthScale, el.opacity ?? 1);
      }
    };

    // If no floor plate elements are generated yet, render drawn floor zones as floor base
    const hasFloorElements = room.elements.some(el => el.layer === 'floor_bg' || el.assetId.startsWith('plate_'));
    if (!hasFloorElements && room.floorZones && room.floorZones.length > 0) {
      ctx.save();
      ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
      room.floorZones.forEach(z => {
        ctx.fillRect(z.x, z.y, z.w, z.h);
      });
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2 / zoomLevel;
      room.floorZones.forEach(z => {
        ctx.strokeRect(z.x, z.y, z.w, z.h);
      });
      ctx.restore();
    }

    // Sort elements strictly by zIndex & independent hero placement
    const sorted = [...room.elements]
      .filter(el => el.visible !== false)
      .sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));

    // Elements below hero: hero walks on top of them (rendered below hero)
    const backElements = sorted.filter(el => !isElementAboveHero(el));
    // Elements above hero: hero walks behind them (rendered above hero, foreground)
    const frontElements = sorted.filter(el => isElementAboveHero(el));

    // Helper to render an ordered list of elements with SEAMLESS UNION MERGING for shadows
    const renderElementList = (els: RoomElement[]) => {
      let i = 0;
      while (i < els.length) {
        if (isShadowZone(els[i])) {
          const shadowRun: RoomElement[] = [];
          while (i < els.length && isShadowZone(els[i])) {
            shadowRun.push(els[i]);
            i++;
          }
          renderSeamlessShadows(ctx, shadowRun, 1.0, 0, 0);
        } else {
          renderElement(els[i]);
          i++;
        }
      }
    };

    // 1. Render Back Elements (below hero)
    renderElementList(backElements);

    // 2. Render Character
    // Ground Drop Shadow
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(p.x, p.y + p.h / 2, p.w * 0.7, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Main Hero Body (Exact in-game representation: solid 35x35 square with eyes tracking movement)
    ctx.save();
    ctx.translate(p.x, p.y);

    // Body block (35x35 crisp square, identical to GameCanvas)
    ctx.fillStyle = '#f43f5e';
    ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);

    // Expressive Eyes looking in direction of movement
    const lookDirX = p.facing === 'right' ? 1 : p.facing === 'left' ? -1 : 0;
    const lookDirY = p.facing === 'down' ? 1 : p.facing === 'up' ? -1 : 0;
    const eyeBaseY = -2;
    const eyeSpacing = 6;
    const eyeOffsetX = lookDirX * 3.2;
    const eyeOffsetY = lookDirY * 2.2;

    // Eye Whites
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(-eyeSpacing + (lookDirX * 1.5), eyeBaseY, 4.5, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(eyeSpacing + (lookDirX * 1.5), eyeBaseY, 4.5, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eye Pupils
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(-eyeSpacing + eyeOffsetX, eyeBaseY + eyeOffsetY, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(eyeSpacing + eyeOffsetX, eyeBaseY + eyeOffsetY, 2.2, 0, Math.PI * 2);
    ctx.fill();

    // Glint reflections
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-eyeSpacing + eyeOffsetX - 0.7, eyeBaseY + eyeOffsetY - 0.7, 0.9, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(eyeSpacing + eyeOffsetX - 0.7, eyeBaseY + eyeOffsetY - 0.7, 0.9, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    // 3. Render Front Elements (Foreground, front walls over the player)
    renderElementList(frontElements);

    // 4. Dynamic Lighting pass strictly clipped to floor zones (NO arbitrary square backdrop)
    if (room.floorZones && room.floorZones.length > 0 && room.lighting?.enableLighting && (room.lighting?.ambientDarkness ?? 0) > 0.01) {
      const minX = Math.min(...room.floorZones.map(z => z.x));
      const minY = Math.min(...room.floorZones.map(z => z.y));
      const maxX = Math.max(...room.floorZones.map(z => z.x + z.w));
      const maxY = Math.max(...room.floorZones.map(z => z.y + z.h));
      const rw = Math.max(32, maxX - minX);
      const rh = Math.max(32, maxY - minY);

      ctx.save();
      ctx.beginPath();
      room.floorZones.forEach(z => ctx.rect(z.x, z.y, z.w, z.h));
      ctx.clip();

      drawRoomLightingPass(ctx, rw, rh, room.elements, room.lighting, timeSec, zoomLevel, [], true, minX, minY);
      ctx.restore();
    }

    ctx.restore();
  };

  // Virtual Joystick logic for touch / mobile
  const updateJoystickPosition = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const maxRadius = 40; // stick range limit

    let stickX = dx;
    let stickY = dy;
    if (dist > maxRadius) {
      stickX = (dx / dist) * maxRadius;
      stickY = (dy / dist) * maxRadius;
    }

    setJoystickKnob({ x: stickX, y: stickY });

    const normX = stickX / maxRadius;
    const normY = stickY / maxRadius;
    const normDist = Math.hypot(normX, normY);

    if (normDist < 0.12) {
      joystickVectorRef.current = { x: 0, y: 0 };
    } else {
      joystickVectorRef.current = { x: normX, y: normY };
    }
  };

  const handleJoystickStart = (clientX: number, clientY: number) => {
    setIsJoystickActive(true);
    updateJoystickPosition(clientX, clientY);
  };

  const handleJoystickEnd = () => {
    setIsJoystickActive(false);
    joystickTouchIdRef.current = null;
    setJoystickKnob({ x: 0, y: 0 });
    joystickVectorRef.current = { x: 0, y: 0 };
  };

  const onJoystickTouchStart = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      joystickTouchIdRef.current = touch.identifier;
      handleJoystickStart(touch.clientX, touch.clientY);
    }
  };

  const onJoystickTouchMove = (e: React.TouchEvent) => {
    e.stopPropagation();
    for (let i = 0; i < e.touches.length; i++) {
      const touch = e.touches[i];
      if (touch.identifier === joystickTouchIdRef.current) {
        updateJoystickPosition(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const onJoystickTouchEnd = (e: React.TouchEvent) => {
    e.stopPropagation();
    handleJoystickEnd();
  };

  const onJoystickMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    handleJoystickStart(e.clientX, e.clientY);

    const onMouseMove = (ev: MouseEvent) => {
      updateJoystickPosition(ev.clientX, ev.clientY);
    };
    const onMouseUp = () => {
      handleJoystickEnd();
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  const effectiveType: RoomType = room.roomType || (room.isBossRoom ? 'boss' : 'normal');
  const cfg = ROOM_TYPE_CONFIGS[effectiveType] || ROOM_TYPE_CONFIGS.normal;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-2 sm:p-5 select-none animate-fadeIn">
      {/* Top Header Bar - scrollable on mobile */}
      <div className="w-full max-w-6xl bg-slate-900 border border-slate-800 rounded-t-2xl p-3 flex items-center justify-between gap-3 shadow-2xl overflow-x-auto scrollbar-thin shrink-0 [touch-action:pan-x] [-webkit-overflow-scrolling:touch] flex-nowrap">
        <div className="flex items-center gap-3 shrink-0 flex-nowrap">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/40 shadow-inner shrink-0">
            <Play className="w-4 h-4 fill-emerald-400" />
          </div>
          <div className="shrink-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-white uppercase tracking-wider">{room.name}</h2>
              <span className={`px-2 py-0.5 rounded-md ${cfg.badgeBg} ${cfg.badgeText} border ${cfg.badgeBorder} text-[10px] font-bold uppercase`}>
                {cfg.title}
              </span>
              <span className="hidden sm:inline px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold uppercase">
                Проверка масштаба и слоев
              </span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
              <span>Джойстик / WASD</span>
              <span>•</span>
              <span>R: на спавн</span>
              <span>•</span>
              <span>Esc: закрыть</span>
            </p>
          </div>
        </div>

        {/* View Controls & Close */}
        <div className="flex items-center gap-2 shrink-0 flex-nowrap">
          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 shrink-0">
            <button
              onClick={() => setZoomLevel(prev => Math.max(0.4, prev - 0.2))}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Уменьшить масштаб"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoomLevel(1.0)}
              className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold text-sky-400 hover:bg-slate-800 transition-colors cursor-pointer"
              title="Масштаб 100% (как в игре)"
            >
              {Math.round(zoomLevel * 100)}%
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.min(2.5, prev + 0.2))}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Увеличить масштаб"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => {
              playerRef.current.x = room.spawnPoint?.x ?? 400;
              playerRef.current.y = room.spawnPoint?.y ?? 300;
              playerRef.current.vx = 0;
              playerRef.current.vy = 0;
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition-colors border border-slate-700 shrink-0"
            title="Вернуть героя на точку спавна"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">На спавн</span>
          </button>

          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer transition-colors shadow-md shrink-0"
          >
            <X className="w-4 h-4" />
            <span>ВЫЙТИ</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Viewport Container */}
      <div 
        ref={containerRef}
        className="w-full max-w-6xl h-[80vh] bg-slate-950 border-x border-b border-slate-800 rounded-b-2xl overflow-hidden flex items-center justify-center relative shadow-2xl"
      >
        <canvas
          ref={canvasRef}
          className="block"
        />

        {/* Virtual Joystick for Mobile Character Movement */}
        <div className="absolute bottom-5 left-5 z-40 select-none flex flex-col items-center">
          <div
            ref={joystickBaseRef}
            onTouchStart={onJoystickTouchStart}
            onTouchMove={onJoystickTouchMove}
            onTouchEnd={onJoystickTouchEnd}
            onTouchCancel={onJoystickTouchEnd}
            onMouseDown={onJoystickMouseDown}
            className={`relative w-28 h-28 rounded-full border-2 transition-colors cursor-grab active:cursor-grabbing flex items-center justify-center shadow-2xl backdrop-blur-md select-none [touch-action:none] ${
              isJoystickActive
                ? 'bg-emerald-950/70 border-emerald-400 shadow-emerald-900/60'
                : 'bg-slate-900/80 border-slate-600 hover:border-slate-400 shadow-black/80'
            }`}
            title="Джойстик передвижения героя (тяните пальцем или мышью)"
          >
            {/* Cardinal Direction Hints */}
            <div className="absolute top-1 text-[10px] font-bold text-slate-500 pointer-events-none select-none">▲</div>
            <div className="absolute bottom-1 text-[10px] font-bold text-slate-500 pointer-events-none select-none">▼</div>
            <div className="absolute left-1 text-[10px] font-bold text-slate-500 pointer-events-none select-none">◀</div>
            <div className="absolute right-1 text-[10px] font-bold text-slate-500 pointer-events-none select-none">▶</div>

            {/* Subtle inner guide ring */}
            <div className="w-14 h-14 rounded-full border border-dashed border-slate-600/40 pointer-events-none" />

            {/* Inner Moving Stick Knob */}
            <div
              className={`absolute w-12 h-12 rounded-full shadow-lg flex items-center justify-center pointer-events-none transition-transform duration-75 border-2 ${
                isJoystickActive
                  ? 'bg-gradient-to-br from-emerald-400 to-teal-600 border-emerald-200 shadow-emerald-500/50 scale-105'
                  : 'bg-gradient-to-br from-slate-700 to-slate-800 border-slate-500/80 shadow-black/60'
              }`}
              style={{
                transform: `translate(${joystickKnob.x}px, ${joystickKnob.y}px)`
              }}
            >
              <div className={`w-3.5 h-3.5 rounded-full ${isJoystickActive ? 'bg-white shadow' : 'bg-slate-400'}`} />
            </div>
          </div>
          <span className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-wider pointer-events-none drop-shadow">
            Джойстик
          </span>
        </div>

        {/* Quick Reset on Mobile (bottom right floating button) */}
        <div className="absolute bottom-5 right-5 z-40 flex flex-col gap-2 items-end">
          <button
            onClick={() => {
              playerRef.current.x = room.spawnPoint?.x ?? 400;
              playerRef.current.y = room.spawnPoint?.y ?? 300;
              playerRef.current.vx = 0;
              playerRef.current.vy = 0;
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-sky-400 font-bold text-xs shadow-xl backdrop-blur active:scale-95 transition-all cursor-pointer"
            title="Вернуть героя на точку спавна"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>На спавн</span>
          </button>
        </div>

        {/* Desktop Quick Controls hint */}
        <div className="hidden md:block absolute top-4 left-4 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 text-[11px] text-slate-300 space-y-1 backdrop-blur pointer-events-none">
          <div className="flex items-center gap-2">
            <span className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px] text-sky-400">WASD / Джойстик</span>
            <span>Ходьба героя</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px] text-sky-400">R</span>
            <span>Сброс на спавн</span>
          </div>
        </div>
      </div>
    </div>
  );
};
