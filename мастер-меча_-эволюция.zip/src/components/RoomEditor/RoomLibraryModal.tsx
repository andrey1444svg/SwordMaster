import React, { useRef, useState } from 'react';
import { CustomRoomData, RoomType, ROOM_TYPE_CONFIGS } from '../../types/roomEditor';
import { 
  Folder, 
  X, 
  Plus, 
  Play, 
  Edit3, 
  Trash2, 
  Download, 
  Upload, 
  Copy, 
  Layers, 
  Shield, 
  Compass,
  GitCommit,
  Crown,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { roomStorage } from '../../utils/roomStorage';

interface RoomLibraryModalProps {
  rooms: CustomRoomData[];
  currentRoomId: string;
  onSelectRoom: (room: CustomRoomData) => void;
  onCreateNewRoom: (roomType?: RoomType) => void;
  onDuplicateRoom: (room: CustomRoomData) => void;
  onDeleteRoom: (id: string) => void;
  onPlaytestRoom: (room: CustomRoomData) => void;
  onImportRoom: (room: CustomRoomData) => void;
  onClose: () => void;
}

export const RoomLibraryModal: React.FC<RoomLibraryModalProps> = ({
  rooms,
  currentRoomId,
  onSelectRoom,
  onCreateNewRoom,
  onDuplicateRoom,
  onDeleteRoom,
  onPlaytestRoom,
  onImportRoom,
  onClose
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [filterType, setFilterType] = useState<'all' | RoomType>('all');
  const [importNotification, setImportNotification] = useState<string | null>(null);
  const [showNewRoomPicker, setShowNewRoomPicker] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const content = evt.target?.result as string;
      const imported = roomStorage.importRoomFromJson(content);
      if (imported) {
        onImportRoom(imported);
        setImportNotification(`Комната «${imported.name}» успешно импортирована!`);
        setTimeout(() => setImportNotification(null), 3000);
      }
    };
    reader.readAsText(file);
  };

  const getEffectiveRoomType = (room: CustomRoomData): RoomType => {
    if (room.roomType) return room.roomType;
    if (room.isBossRoom) return 'boss';
    return 'normal';
  };

  const filtered = rooms.filter(r => {
    if (filterType === 'all') return true;
    return getEffectiveRoomType(r) === filterType;
  });

  const getRoomTypeBadge = (room: CustomRoomData) => {
    const type = getEffectiveRoomType(room);
    const config = ROOM_TYPE_CONFIGS[type] || ROOM_TYPE_CONFIGS.normal;

    let Icon = Shield;
    if (type === 'start') Icon = Compass;
    else if (type === 'bridge') Icon = GitCommit;
    else if (type === 'boss') Icon = Crown;

    return (
      <span className={`px-2 py-0.5 rounded-md ${config.badgeBg} ${config.badgeText} border ${config.badgeBorder} text-[10px] font-bold uppercase flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        <span>{config.shortLabel}</span>
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fade-in">
      <div className="w-full max-w-4xl max-h-[88vh] bg-slate-900 border-2 border-sky-500/50 rounded-2xl shadow-2xl shadow-sky-950/90 flex flex-col overflow-hidden text-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-950/90 overflow-x-auto scrollbar-thin shrink-0 [touch-action:pan-x] [-webkit-overflow-scrolling:touch] flex-nowrap">
          <div className="flex items-center gap-3 shrink-0">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40 shrink-0">
              <Folder className="w-5 h-5" />
            </div>
            <div className="shrink-0">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">Папка комнат подземелья</h2>
              <p className="text-xs text-slate-400">Каталог комнат по типам: стартовые, мосты, обычные и боссы</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Import JSON */}
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              className="hidden"
              onChange={handleFileUpload}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold text-xs cursor-pointer border border-slate-700 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Импорт JSON</span>
            </button>

            {/* New Room Button / Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNewRoomPicker(!showNewRoomPicker)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider cursor-pointer shadow-md shadow-sky-950 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Создать комнату ▾</span>
              </button>

              {showNewRoomPicker && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-slate-950 border border-slate-700 rounded-xl shadow-2xl py-1.5 z-50 text-xs">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Выберите тип комнаты
                  </div>
                  <button
                    onClick={() => {
                      onCreateNewRoom('start');
                      setShowNewRoomPicker(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-800 text-emerald-300 flex items-center gap-2 font-medium"
                  >
                    <Compass className="w-4 h-4" />
                    <span>Стартовая комната</span>
                  </button>
                  <button
                    onClick={() => {
                      onCreateNewRoom('bridge');
                      setShowNewRoomPicker(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-800 text-amber-300 flex items-center gap-2 font-medium"
                  >
                    <GitCommit className="w-4 h-4" />
                    <span>Промежуточный мост</span>
                  </button>
                  <button
                    onClick={() => {
                      onCreateNewRoom('normal');
                      setShowNewRoomPicker(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-800 text-sky-300 flex items-center gap-2 font-medium"
                  >
                    <Shield className="w-4 h-4" />
                    <span>Обычная комната</span>
                  </button>
                  <button
                    onClick={() => {
                      onCreateNewRoom('boss');
                      setShowNewRoomPicker(false);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-800 text-rose-300 flex items-center gap-2 font-medium"
                  >
                    <Crown className="w-4 h-4" />
                    <span>Комната с боссом</span>
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notification Banner */}
        {importNotification && (
          <div className="bg-emerald-950/80 border-b border-emerald-500/50 px-4 py-2 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{importNotification}</span>
          </div>
        )}

        {/* Filter Tabs by Room Type */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-950/60 border-b border-slate-800 text-xs overflow-x-auto scrollbar-thin shrink-0 [touch-action:pan-x] [-webkit-overflow-scrolling:touch]">
          <span className="text-slate-500 font-bold uppercase text-[10px] mr-1 shrink-0">Тип:</span>
          {[
            { id: 'all', label: `Все (${rooms.length})`, icon: Folder },
            { id: 'start', label: 'Стартовые', icon: Compass, color: 'text-emerald-400' },
            { id: 'bridge', label: 'Мосты / Переходы', icon: GitCommit, color: 'text-amber-400' },
            { id: 'normal', label: 'Обычные', icon: Shield, color: 'text-sky-400' },
            { id: 'boss', label: 'Боссы', icon: Crown, color: 'text-rose-400' }
          ].map(f => {
            const Icon = f.icon;
            const isSelected = filterType === f.id;
            return (
              <button
                key={f.id}
                onClick={() => setFilterType(f.id as any)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shrink-0 ${
                  isSelected
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-950'
                    : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : f.color || 'text-slate-400'}`} />
                <span>{f.label}</span>
              </button>
            );
          })}
        </div>

        {/* Room List Grid */}
        <div className="flex-1 overflow-y-auto overflow-x-auto p-4 custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filtered.map(room => {
              const isCurrent = room.id === currentRoomId;
              const effectiveType = getEffectiveRoomType(room);
              const typeCfg = ROOM_TYPE_CONFIGS[effectiveType] || ROOM_TYPE_CONFIGS.normal;

              return (
                <div
                  key={room.id}
                  className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between ${
                    isCurrent
                      ? 'bg-sky-950/40 border-sky-500 shadow-lg shadow-sky-950/60'
                      : 'bg-slate-950/70 hover:bg-slate-800/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    {/* Top Row: Title & Badge */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="min-w-0 flex-1">
                        <h3 className="text-sm font-bold text-white truncate">{room.name}</h3>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          Размер: {room.width}x{room.height} px • Сетка {room.gridSize || 32}px
                        </p>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {getRoomTypeBadge(room)}
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-3 py-1.5 px-2.5 bg-slate-900/90 rounded-xl text-[11px] text-slate-300 border border-slate-800/80 mb-3">
                      <div className="flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-sky-400" />
                        <span>{room.elements?.length || 0} блоков</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Shield className="w-3.5 h-3.5 text-red-400" />
                        <span>{room.collisionBoxes?.length || 0} коллизий</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onSelectRoom(room)}
                        className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Открыть</span>
                      </button>

                      <button
                        onClick={() => onPlaytestRoom(room)}
                        className="px-2.5 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors border border-emerald-500/40"
                      >
                        <Play className="w-3 h-3" />
                        <span>Тест</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onDuplicateRoom(room)}
                        title="Дублировать комнату"
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => roomStorage.exportRoomToFile(room)}
                        title="Экспорт в .json файл"
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 cursor-pointer transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteRoom(room.id)}
                        title="Удалить комнату"
                        className="p-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 cursor-pointer transition-colors border border-rose-800/40"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 text-slate-500 text-xs">
              В этой категории нет комнат
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
