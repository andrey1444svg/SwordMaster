import React from 'react';
import { RoomElement, LayerType, isElementAboveHero } from '../../types/roomEditor';
import { isTorchElement, isLightEmitter, isShadowZone } from '../../utils/torchEffects';
import { useScrollClickBlocker } from '../../utils/useScrollClickBlocker';
import { 
  Layers, 
  RotateCw, 
  Maximize2, 
  Sliders, 
  Copy, 
  Trash2, 
  Eye, 
  EyeOff, 
  FlipHorizontal, 
  FlipVertical,
  Shield,
  ArrowUp,
  ArrowDown,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Move,
  Flame,
  Sun,
  Moon,
  Sparkles,
  Zap,
  Circle,
  Square,
  User,
  X
} from 'lucide-react';

interface ElementPropertiesPanelProps {
  selectedElements: RoomElement[];
  onUpdateElement: (id: string, updates: Partial<RoomElement>) => void;
  onUpdateMultipleElements: (ids: string[], updates: Partial<RoomElement>) => void;
  onDuplicateElement: (id: string) => void;
  onDuplicateMultipleElements: (ids: string[]) => void;
  onDeleteElement: (id: string) => void;
  onDeleteMultipleElements: (ids: string[]) => void;
  onAddAutoCollision: (el: RoomElement) => void;
  onClose?: () => void;
  panelScale?: number;
}

const LIGHT_COLOR_PRESETS = [
  { label: '🔥 Огонь', color: '#ff9d3b' },
  { label: '🟡 Золото', color: '#fbbf24' },
  { label: '🔵 Магия', color: '#38bdf8' },
  { label: '🟢 Изумруд', color: '#34d399' },
  { label: '🔴 Рубин', color: '#f43f5e' },
  { label: '🟣 Аметист', color: '#c084fc' },
  { label: '⚪ Белый', color: '#ffffff' }
];

export const ElementPropertiesPanel: React.FC<ElementPropertiesPanelProps> = ({
  selectedElements,
  onUpdateElement,
  onUpdateMultipleElements,
  onDuplicateElement,
  onDuplicateMultipleElements,
  onDeleteElement,
  onDeleteMultipleElements,
  onAddAutoCollision,
  onClose,
  panelScale = 1.0
}) => {
  const scrollBlocker = useScrollClickBlocker();

  if (selectedElements.length === 0) {
    return (
      <div 
        {...scrollBlocker}
        className="w-full h-full bg-slate-900/95 p-4 flex flex-col items-center justify-center text-center text-slate-500 select-none overflow-x-auto overflow-y-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]"
        style={panelScale !== 1.0 ? { transform: `scale(${panelScale})`, transformOrigin: 'top left', width: `${100 / panelScale}%`, height: `${100 / panelScale}%` } : undefined}
      >
        <Sliders className="w-8 h-8 mb-2 opacity-40 text-slate-400" />
        <p className="text-xs font-semibold text-slate-400">Объект не выбран</p>
        <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
          Нажмите на блок для выбора или удерживайте 0.3 сек для перетаскивания.
        </p>
        {onClose && (
          <button
            onClick={onClose}
            className="mt-4 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 cursor-pointer"
          >
            Скрыть панель
          </button>
        )}
      </div>
    );
  }

  const layers: { id: LayerType; label: string; desc: string }[] = [
    { id: 'floor_bg', label: '1. Фон пола', desc: 'Плиты и нижнее покрытие' },
    { id: 'back_wall', label: '2. Задние стены', desc: 'Стены и задние углы' },
    { id: 'mid_props', label: '3. Предметы', desc: 'Сундуки, алтари, декор' },
    { id: 'front_wall', label: '4. Передние стены', desc: 'Передние стены и колонны' },
    { id: 'foreground', label: '5. Передний план', desc: 'Навесы и верхние арки' }
  ];

  // If multiple elements selected
  if (selectedElements.length > 1) {
    const ids = selectedElements.map(e => e.id);
    const allVisible = selectedElements.every(e => e.visible !== false);

    return (
      <div 
        {...scrollBlocker}
        className="w-full h-full bg-slate-900/95 flex flex-col select-none text-slate-200 text-xs overflow-y-auto overflow-x-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]"
        style={panelScale !== 1.0 ? { transform: `scale(${panelScale})`, transformOrigin: 'top left', width: `${100 / panelScale}%`, height: `${100 / panelScale}%` } : undefined}
      >
        {/* Header */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-sky-950/20 shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-sky-300">Группа объектов</h3>
              <span className="text-[10px] text-slate-400 font-mono">Выбрано: {selectedElements.length} шт.</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              title={allVisible ? 'Скрыть все' : 'Показать все'}
              onClick={() => onUpdateMultipleElements(ids, { visible: !allVisible })}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                !allVisible ? 'bg-rose-500/20 border-rose-500/40 text-rose-400' : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
              }`}
            >
              {!allVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                title="Свернуть"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        <div className="p-3 space-y-4 flex-1">
          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onDuplicateMultipleElements(ids)}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sky-300 hover:text-sky-200 font-semibold cursor-pointer transition-colors text-[11px]"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Клонировать ({selectedElements.length})</span>
            </button>
            <button
              onClick={() => onDeleteMultipleElements(ids)}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 font-semibold cursor-pointer transition-colors text-[11px]"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Удалить все</span>
            </button>
          </div>

          {/* Group Placement Relative to Hero */}
          <div className="space-y-1.5 p-2.5 bg-slate-950/70 rounded-lg border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>Относительно героя</span>
              </label>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => onUpdateMultipleElements(ids, { renderAboveHero: false })}
                className="py-1.5 px-2 rounded-md text-[10px] font-bold bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 cursor-pointer text-center"
              >
                Все под героя
              </button>
              <button
                onClick={() => onUpdateMultipleElements(ids, { renderAboveHero: true })}
                className="py-1.5 px-2 rounded-md text-[10px] font-bold bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-700/50 cursor-pointer text-center"
              >
                Все над героем
              </button>
            </div>
            <p className="text-[9.5px] text-slate-400">Работает независимо от Z-Index: определяет, ходит ли герой поверх объектов или позади них.</p>
          </div>

          {/* Group Z-Index Assignment */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                <span>Z-Index группы (порядок)</span>
              </label>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const currentMin = Math.min(...selectedElements.map(e => e.zIndex || 0));
                  const nextVal = currentMin - 1;
                  onUpdateMultipleElements(ids, { zIndex: nextVal });
                }}
                className="p-1.5 bg-slate-950 border border-slate-700 hover:border-slate-600 rounded-lg text-slate-300 cursor-pointer"
                title="-1 Z-Index для группы"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
              <input
                type="number"
                placeholder="Задать Z-Index"
                onChange={e => {
                  const val = Number(e.target.value) || 0;
                  onUpdateMultipleElements(ids, { zIndex: val });
                }}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-lg py-1 px-2 text-center text-slate-100 font-mono font-bold focus:outline-none"
              />
              <button
                onClick={() => {
                  const currentMax = Math.max(...selectedElements.map(e => e.zIndex || 0));
                  const nextVal = currentMax + 1;
                  onUpdateMultipleElements(ids, { zIndex: nextVal });
                }}
                className="p-1.5 bg-slate-950 border border-slate-700 hover:border-slate-600 rounded-lg text-slate-300 cursor-pointer"
                title="+1 Z-Index для группы"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Group Rotation */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <RotateCw className="w-3.5 h-3.5 text-sky-400" />
              <span>Поворот группы</span>
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[0, 90, 180, 270].map(deg => (
                <button
                  key={deg}
                  onClick={() => onUpdateMultipleElements(ids, { rotation: deg })}
                  className="py-1.5 bg-slate-950 border border-slate-800 hover:border-sky-500 rounded text-[11px] font-mono font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  {deg}°
                </button>
              ))}
            </div>
          </div>

          {/* Group Fire & Light Toggle */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>Освещение для группы</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onUpdateMultipleElements(ids, { hasLight: true, hasFireEffect: true })}
                className="py-1.5 bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 rounded text-[11px] font-bold text-amber-300 transition-colors cursor-pointer flex items-center justify-center gap-1"
              >
                <Sun className="w-3 h-3" />
                <span>Вкл. свет</span>
              </button>
              <button
                onClick={() => onUpdateMultipleElements(ids, { hasLight: false })}
                className="py-1.5 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded text-[11px] text-slate-400 transition-colors cursor-pointer"
              >
                Выкл. свет
              </button>
            </div>
            {/* Group light colors */}
            <div className="flex items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-400">Цвет:</span>
              <div className="flex items-center gap-1 flex-1">
                {LIGHT_COLOR_PRESETS.slice(0, 5).map(p => (
                  <button
                    key={p.color}
                    onClick={() => onUpdateMultipleElements(ids, { hasLight: true, lightColor: p.color })}
                    className="w-4 h-4 rounded-full border border-slate-700 hover:scale-125 transition-transform cursor-pointer"
                    style={{ backgroundColor: p.color }}
                    title={p.label}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Group Shadows */}
          {selectedElements.some(e => isShadowZone(e) || e.isShadowSource) && (
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span>Тени в группе</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateMultipleElements(ids, { shadowCorners: 'sharp' })}
                  className="py-1.5 bg-indigo-950/40 border border-indigo-700/50 hover:bg-indigo-900/60 rounded text-[11px] font-bold text-indigo-300 transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <Square className="w-3 h-3" />
                  <span>Острые углы (90°)</span>
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateMultipleElements(ids, { shadowCorners: 'rounded', shadowCornerRadius: 10 })}
                  className="py-1.5 bg-indigo-950/40 border border-indigo-700/50 hover:bg-indigo-900/60 rounded text-[11px] font-bold text-indigo-300 transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <Circle className="w-3 h-3" />
                  <span>Закруглить</span>
                </button>
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>Общая прозрачность для слияния:</span>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  {[0.25, 0.5, 0.75, 0.9].map(pVal => (
                    <button
                      key={pVal}
                      type="button"
                      onClick={() => onUpdateMultipleElements(ids, { shadowDensity: pVal, opacity: pVal })}
                      className="py-1 text-[10px] font-mono font-bold rounded bg-slate-900 text-indigo-300 border border-slate-800 hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                    >
                      {Math.round(pVal * 100)}%
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* List of items in group */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Элементы в выделении:
            </label>
            <div className="max-h-48 overflow-y-auto space-y-1 custom-scrollbar">
              {selectedElements.map((el, i) => (
                <div key={`${el.id}_${i}`} className="flex items-center gap-2 p-1.5 bg-slate-950/70 rounded-md border border-slate-800 text-[11px]">
                  {el.src ? (
                    <img src={el.src} alt="" className="w-5 h-5 object-contain bg-slate-900 rounded p-0.5" />
                  ) : (
                    <div className="w-5 h-5 bg-slate-900 rounded p-0.5 flex items-center justify-center text-[9px]">📦</div>
                  )}
                  <span className="truncate flex-1 text-slate-300">{el.name}</span>
                  <span className="text-[9px] font-mono text-slate-500">{Math.round(el.x)}, {Math.round(el.y)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const element = selectedElements[0];

  return (
    <div 
      {...scrollBlocker}
      className="w-full h-full bg-slate-900/95 flex flex-col select-none text-slate-200 text-xs overflow-y-auto overflow-x-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]"
      style={panelScale !== 1.0 ? { transform: `scale(${panelScale})`, transformOrigin: 'top left', width: `${100 / panelScale}%`, height: `${100 / panelScale}%` } : undefined}
    >
      {/* Header */}
      <div className="p-3 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          {element.src ? (
            <img src={element.src} alt={element.name} className="w-7 h-7 object-contain bg-slate-950 p-1 rounded border border-slate-700" />
          ) : (
            <div className="w-7 h-7 bg-slate-950 p-1 rounded border border-slate-700 flex items-center justify-center text-[10px]">📦</div>
          )}
          <div>
            <h3 className="text-xs font-bold text-slate-100 truncate max-w-[150px]">{element.name}</h3>
            <span className="text-[10px] text-sky-400 font-mono">ID: {element.id.slice(0, 10)}</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            title={element.visible !== false ? 'Скрыть' : 'Показать'}
            onClick={() => onUpdateElement(element.id, { visible: element.visible === false })}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              element.visible === false ? 'bg-rose-500/20 border-rose-500/40 text-rose-400' : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            {element.visible === false ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              title="Свернуть"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      <div className="p-3 space-y-4 flex-1">
        {/* Transform: Position X, Y */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Координаты (X / Y)</label>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center bg-slate-950 border border-slate-700 rounded-lg px-2 py-1">
              <span className="text-slate-500 mr-1.5 text-[10px] font-mono">X:</span>
              <input
                type="number"
                value={Math.round(element.x)}
                onChange={e => onUpdateElement(element.id, { x: Number(e.target.value) || 0 })}
                className="w-full bg-transparent text-slate-100 focus:outline-none font-mono"
              />
            </div>
            <div className="flex items-center bg-slate-950 border border-slate-700 rounded-lg px-2 py-1">
              <span className="text-slate-500 mr-1.5 text-[10px] font-mono">Y:</span>
              <input
                type="number"
                value={Math.round(element.y)}
                onChange={e => onUpdateElement(element.id, { y: Number(e.target.value) || 0 })}
                className="w-full bg-transparent text-slate-100 focus:outline-none font-mono"
              />
            </div>
          </div>
        </div>

        {/* Transform: Size W, H */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Размеры (Ш / В)</label>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center bg-slate-950 border border-slate-700 rounded-lg px-2 py-1">
              <span className="text-slate-500 mr-1.5 text-[10px] font-mono">W:</span>
              <input
                type="number"
                min="8"
                max="1024"
                value={Math.round(element.w)}
                onChange={e => onUpdateElement(element.id, { w: Math.max(8, Number(e.target.value) || 8) })}
                className="w-full bg-transparent text-slate-100 focus:outline-none font-mono"
              />
            </div>
            <div className="flex items-center bg-slate-950 border border-slate-700 rounded-lg px-2 py-1">
              <span className="text-slate-500 mr-1.5 text-[10px] font-mono">H:</span>
              <input
                type="number"
                min="8"
                max="1024"
                value={Math.round(element.h)}
                onChange={e => onUpdateElement(element.id, { h: Math.max(8, Number(e.target.value) || 8) })}
                className="w-full bg-transparent text-slate-100 focus:outline-none font-mono"
              />
            </div>
          </div>
        </div>

        {/* Scaling (ScaleX, ScaleY) */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Масштаб (Scale)</span>
            <span className="font-mono text-sky-400">{Math.round((element.scaleX || 1) * 100)}%</span>
          </label>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="0.25"
              max="3"
              step="0.05"
              value={element.scaleX || 1}
              onChange={e => {
                const val = parseFloat(e.target.value);
                onUpdateElement(element.id, { scaleX: val, scaleY: val });
              }}
              className="flex-1 accent-sky-500 cursor-pointer"
            />
            <div className="flex gap-1">
              <button
                onClick={() => onUpdateElement(element.id, { scaleX: 1, scaleY: 1 })}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[10px] text-slate-300 font-mono"
              >
                100%
              </button>
            </div>
          </div>
        </div>

        {/* Rotation */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <RotateCw className="w-3.5 h-3.5 text-sky-400" />
              <span>Поворот (Угол)</span>
            </label>
            <span className="font-mono text-sky-400 font-bold">{element.rotation || 0}°</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[0, 90, 180, 270].map(deg => (
              <button
                key={deg}
                onClick={() => onUpdateElement(element.id, { rotation: deg })}
                className={`py-1.5 rounded text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  (element.rotation || 0) === deg
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-950/60'
                    : 'bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                {deg}°
              </button>
            ))}
          </div>
          <input
            type="range"
            min="0"
            max="355"
            step="5"
            value={element.rotation || 0}
            onChange={e => onUpdateElement(element.id, { rotation: Number(e.target.value) })}
            className="w-full accent-sky-500 cursor-pointer mt-1"
          />
        </div>

        {/* Flip & Opacity */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Отражение и прозрачность</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onUpdateElement(element.id, { flipX: !element.flipX })}
              className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer ${
                element.flipX ? 'bg-sky-500/20 border-sky-500/50 text-sky-300' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              <FlipHorizontal className="w-3.5 h-3.5" />
              <span>По гориз.</span>
            </button>
            <button
              onClick={() => onUpdateElement(element.id, { flipY: !element.flipY })}
              className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer ${
                element.flipY ? 'bg-sky-500/20 border-sky-500/50 text-sky-300' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              <FlipVertical className="w-3.5 h-3.5" />
              <span>По вертик.</span>
            </button>
          </div>
          <div className="flex items-center gap-2 pt-1">
            <span className="text-[10px] text-slate-400 font-mono min-w-[55px]">Непрозр.:</span>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={element.opacity ?? 1}
              onChange={e => onUpdateElement(element.id, { opacity: parseFloat(e.target.value) })}
              className="flex-1 accent-sky-500 cursor-pointer"
            />
            <span className="text-[10px] font-mono text-slate-400 min-w-[30px] text-right">
              {Math.round((element.opacity ?? 1) * 100)}%
            </span>
          </div>
        </div>

        {/* Placement Relative to Hero (независимо от Z-Index) */}
        <div className="space-y-1.5 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <span>Относительно героя</span>
            </label>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              !isElementAboveHero(element) 
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}>
              {!isElementAboveHero(element) ? 'Под героем' : 'Над героем'}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1.5 pt-0.5">
            <button
              onClick={() => onUpdateElement(element.id, { renderAboveHero: false })}
              className={`py-2 px-2 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                !isElementAboveHero(element) 
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60 shadow-sm shadow-emerald-900/30' 
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <span>Под героем</span>
              <span className="text-[9px] font-normal opacity-75">(герой ходит поверх)</span>
            </button>
            <button
              onClick={() => onUpdateElement(element.id, { renderAboveHero: true })}
              className={`py-2 px-2 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                isElementAboveHero(element) 
                  ? 'bg-amber-950/80 text-amber-300 border-amber-500/60 shadow-sm shadow-amber-900/30' 
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <span>Над героем</span>
              <span className="text-[9px] font-normal opacity-75">(перекрывает героя)</span>
            </button>
          </div>
          <p className="text-[9.5px] text-slate-500 text-center">Герой независим от Z-Index. Вы можете выбрать любое положение для любого объекта.</p>
        </div>

        {/* Z-Index Priority (Порядок среди объектов) */}
        <div className="space-y-1.5 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              <span>Порядок наложения (Z-Index)</span>
            </label>
            <span className="text-[10px] text-slate-400 font-mono">Z = {element.zIndex || 0}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const nextVal = (element.zIndex || 0) - 1;
                onUpdateElement(element.id, { zIndex: nextVal });
              }}
              className="p-1.5 bg-slate-950 border border-slate-700 hover:border-slate-600 rounded-lg text-slate-300 cursor-pointer"
              title="-1 к Z-Index"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
            <input
              type="number"
              value={element.zIndex || 0}
              onChange={e => {
                const val = Number(e.target.value) || 0;
                onUpdateElement(element.id, { zIndex: val });
              }}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg py-1 px-2 text-center text-slate-100 font-mono font-bold focus:outline-none"
            />
            <button
              onClick={() => {
                const nextVal = (element.zIndex || 0) + 1;
                onUpdateElement(element.id, { zIndex: nextVal });
              }}
              className="p-1.5 bg-slate-950 border border-slate-700 hover:border-slate-600 rounded-lg text-slate-300 cursor-pointer"
              title="+1 к Z-Index"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Fire & Flame Effects */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Эффект пламени</span>
            </label>
            <button
              onClick={() => onUpdateElement(element.id, { 
                hasFireEffect: element.hasFireEffect === false ? true : (element.hasFireEffect === undefined ? !isTorchElement(element.assetId, element.name) : !element.hasFireEffect) 
              })}
              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                (element.hasFireEffect ?? isTorchElement(element.assetId, element.name))
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-950 text-slate-500 border border-slate-800'
              }`}
            >
              {(element.hasFireEffect ?? isTorchElement(element.assetId, element.name)) ? '🔥 Включен' : 'Выключен'}
            </button>
          </div>
          
          {(element.hasFireEffect ?? isTorchElement(element.assetId, element.name)) && (
            <div className="bg-amber-950/20 border border-amber-500/20 rounded-lg p-2 space-y-1.5">
              <div className="flex items-center justify-between text-[10px] text-amber-300/90">
                <span>Размер пламени</span>
                <span className="font-mono font-bold text-amber-400">{Math.round((element.fireScale || 1) * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.5"
                step="0.1"
                value={element.fireScale || 1}
                onChange={e => onUpdateElement(element.id, { fireScale: parseFloat(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          )}
        </div>

        {/* Dynamic Light Source (Освещение сцены) */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>Освещение сцены</span>
            </label>
            <button
              onClick={() => onUpdateElement(element.id, { 
                hasLight: element.hasLight === false ? true : (element.hasLight === undefined ? !isLightEmitter(element) : !element.hasLight),
                lightRadius: element.lightRadius || 220,
                lightIntensity: element.lightIntensity || 1.0,
                lightColor: element.lightColor || '#ff9d3b'
              })}
              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                (element.hasLight ?? isLightEmitter(element))
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-950 text-slate-500 border border-slate-800'
              }`}
            >
              {(element.hasLight ?? isLightEmitter(element)) ? '💡 Светит' : 'Нет света'}
            </button>
          </div>

          {(element.hasLight ?? isLightEmitter(element)) && (
            <div className="bg-slate-950/80 border border-amber-500/25 rounded-xl p-2.5 space-y-2.5 shadow-inner">
              {/* Radius */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>Радиус освещения</span>
                  </span>
                  <span className="font-mono font-bold text-amber-400">{element.lightRadius || 220}px</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="600"
                  step="10"
                  value={element.lightRadius || 220}
                  onChange={e => onUpdateElement(element.id, { lightRadius: Number(e.target.value) })}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* Intensity */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>Яркость / Интенсивность</span>
                  <span className="font-mono font-bold text-amber-400">{Math.round((element.lightIntensity ?? 1.0) * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="2.0"
                  step="0.1"
                  value={element.lightIntensity ?? 1.0}
                  onChange={e => onUpdateElement(element.id, { lightIntensity: parseFloat(e.target.value) })}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {/* Light Color Palette */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>Цвет света</span>
                  <div className="flex items-center gap-1">
                    <input
                      type="color"
                      value={element.lightColor || '#ff9d3b'}
                      onChange={e => onUpdateElement(element.id, { lightColor: e.target.value })}
                      className="w-4 h-4 rounded cursor-pointer border border-slate-700 bg-transparent"
                    />
                    <span className="font-mono text-[9px] text-slate-400">{element.lightColor || '#ff9d3b'}</span>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  {LIGHT_COLOR_PRESETS.map(p => (
                    <button
                      key={p.color}
                      onClick={() => onUpdateElement(element.id, { lightColor: p.color })}
                      className={`py-1 px-1 rounded text-[9px] font-bold border transition-all cursor-pointer truncate ${
                        (element.lightColor || '#ff9d3b') === p.color
                          ? 'border-white bg-slate-800 text-white shadow-sm'
                          : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                      }`}
                      style={{ borderLeftColor: p.color, borderLeftWidth: '3px' }}
                    >
                      {p.label.split(' ')[1]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Flicker toggle */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px]">
                <span className="text-slate-400">Мерцание огня / Пульсация</span>
                <button
                  onClick={() => onUpdateElement(element.id, { lightFlicker: !(element.lightFlicker ?? true) })}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-bold cursor-pointer ${
                    (element.lightFlicker ?? true)
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-slate-900 text-slate-500 border border-slate-800'
                  }`}
                >
                  {(element.lightFlicker ?? true) ? 'Активно' : 'Статично'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Shadow Zone Controls (Затенение: Овальное / Квадратное / Острые и закругленные углы) */}
        {(isShadowZone(element) || element.isShadowSource) && (
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span>Зона затенения (Тень)</span>
              </label>
              <span className="font-mono font-bold text-indigo-400">{Math.round((element.shadowDensity ?? element.opacity ?? 0.8) * 100)}%</span>
            </div>
            <div className="bg-slate-950/80 border border-indigo-500/30 rounded-xl p-2.5 space-y-2.5">
              {/* Shape selection: Oval vs Square */}
              <div className="space-y-1">
                <label className="text-[10px] font-semibold text-slate-400">Форма тени</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onUpdateElement(element.id, { shadowShape: 'oval' })}
                    className={`py-1 px-2 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      (element.shadowShape || 'oval') === 'oval'
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-950'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    <Circle className="w-3.5 h-3.5" />
                    <span>Овальная</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateElement(element.id, { shadowShape: 'square' })}
                    className={`py-1 px-2 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      element.shadowShape === 'square'
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-950'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Прямоугольная</span>
                  </button>
                </div>
              </div>

              {/* Corner type: Sharp (90°) vs Rounded (Закругленные) */}
              {(element.shadowShape === 'square' || element.shadowShape === undefined) && (
                <div className="space-y-1.5 pt-1.5 border-t border-slate-800/80">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-semibold text-slate-400">Тип углов тени</label>
                    <span className="text-[9px] font-mono text-indigo-400">
                      {(element.shadowCorners || 'sharp') === 'sharp' ? 'Острые 90°' : `${element.shadowCornerRadius ?? 10}px`}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onUpdateElement(element.id, { shadowCorners: 'sharp' })}
                      className={`py-1 px-2 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                        (element.shadowCorners || 'sharp') === 'sharp'
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-950'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                      title="Четкие прямые углы 90° для стыковки со стенами и блоками"
                    >
                      <Square className="w-3.5 h-3.5" />
                      <span>Острые (90°)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateElement(element.id, { shadowCorners: 'rounded', shadowCornerRadius: element.shadowCornerRadius ?? 10 })}
                      className={`py-1 px-2 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                        element.shadowCorners === 'rounded'
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm shadow-indigo-950'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                      title="Плавные скругленные углы"
                    >
                      <Circle className="w-3.5 h-3.5" />
                      <span>Закругленные</span>
                    </button>
                  </div>

                  {/* Corner Radius Slider (when rounded) */}
                  {element.shadowCorners === 'rounded' && (
                    <div className="space-y-1 pt-1 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                      <div className="flex items-center justify-between text-[10px] text-slate-300">
                        <span>Радиус скругления</span>
                        <span className="font-mono font-bold text-indigo-400">{element.shadowCornerRadius ?? 10}px</span>
                      </div>
                      <input
                        type="range"
                        min="2"
                        max="48"
                        step="2"
                        value={element.shadowCornerRadius ?? 10}
                        onChange={e => onUpdateElement(element.id, { shadowCornerRadius: parseInt(e.target.value) })}
                        className="w-full accent-indigo-400 cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Shadow Density / Opacity Slider & Presets */}
              <div className="space-y-1.5 pt-1.5 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>Прозрачность (Плотность)</span>
                  <span className="font-mono font-bold text-indigo-400">
                    {Math.round((element.shadowDensity ?? element.opacity ?? 0.8) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="1.0"
                  step="0.05"
                  value={element.shadowDensity ?? element.opacity ?? 0.8}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    onUpdateElement(element.id, { shadowDensity: val, opacity: val });
                  }}
                  className="w-full accent-indigo-400 cursor-pointer"
                />
                
                {/* Opacity Presets for easy seamless alignment */}
                <div className="grid grid-cols-4 gap-1 pt-1">
                  {[0.25, 0.5, 0.75, 0.9].map(pVal => (
                    <button
                      key={pVal}
                      type="button"
                      onClick={() => onUpdateElement(element.id, { shadowDensity: pVal, opacity: pVal })}
                      className={`py-1 text-[10px] font-mono font-bold rounded border transition-colors cursor-pointer ${
                        Math.abs((element.shadowDensity ?? element.opacity ?? 0.8) - pVal) < 0.03
                          ? 'bg-indigo-600 text-white border-indigo-400'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {Math.round(pVal * 100)}%
                    </button>
                  ))}
                </div>

                {/* Seamless Union Hint */}
                <div className="p-2 bg-indigo-950/40 rounded-lg border border-indigo-500/20 text-[10px] text-indigo-300/90 leading-tight flex items-start gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                  <span>Тени с одинаковой прозрачностью соединяются бесшовно без двойных наложений и стыков, оставаясь разными объектами.</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Auto Collision Helper */}
        <div className="pt-2 border-t border-slate-800">
          <button
            onClick={() => onAddAutoCollision(element)}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 font-bold text-[11px] cursor-pointer transition-colors shadow-sm"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Создать коллизию для блока</span>
          </button>
        </div>

        {/* Actions: Duplicate, Delete */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={() => onDuplicateElement(element.id)}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sky-300 hover:text-sky-200 font-semibold cursor-pointer transition-colors text-[11px]"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Дублировать</span>
          </button>
          <button
            onClick={() => onDeleteElement(element.id)}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 hover:text-rose-200 font-semibold cursor-pointer transition-colors text-[11px]"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Удалить</span>
          </button>
        </div>
      </div>
    </div>
  );
};
