import React from 'react';
import { CollisionBox, CollisionType } from '../../types/roomEditor';
import { useScrollClickBlocker } from '../../utils/useScrollClickBlocker';
import { Shield, Plus, Trash2, Eye, EyeOff, CheckSquare, Square, Crosshair, DoorOpen, Flame, Box, Layers, Sparkles, X } from 'lucide-react';

interface CollisionToolsPanelProps {
  collisionBoxes: CollisionBox[];
  selectedCollisionId: string | null;
  currentTool: 'select' | 'draw_collision' | 'draw_floor' | 'pan';
  collisionDrawType: CollisionType;
  showCollisions: boolean;
  onSetCurrentTool: (tool: 'select' | 'draw_collision' | 'draw_floor' | 'pan') => void;
  onSetCollisionDrawType: (type: CollisionType) => void;
  onToggleShowCollisions: () => void;
  onSelectCollision: (id: string | null) => void;
  onUpdateCollision: (id: string, updates: Partial<CollisionBox>) => void;
  onDeleteCollision: (id: string) => void;
  onClearAllCollisions: () => void;
  floorZones?: { id: string; x: number; y: number; w: number; h: number }[];
  onRemoveFloorZone?: (id: string) => void;
  onClearFloorZones?: () => void;
  onGenerateFromZones?: () => void;
  onClose?: () => void;
  panelScale?: number;
}

export const CollisionToolsPanel: React.FC<CollisionToolsPanelProps> = ({
  collisionBoxes,
  selectedCollisionId,
  currentTool,
  collisionDrawType,
  showCollisions,
  onSetCurrentTool,
  onSetCollisionDrawType,
  onToggleShowCollisions,
  onSelectCollision,
  onUpdateCollision,
  onDeleteCollision,
  onClearAllCollisions,
  floorZones = [],
  onRemoveFloorZone,
  onClearFloorZones,
  onGenerateFromZones,
  onClose,
  panelScale = 1.0
}) => {
  const collisionTypes: { id: CollisionType; label: string; desc: string; icon: React.ElementType; color: string }[] = [
    { id: 'wall', label: 'Твердая стена', desc: 'Блокирует перемещение', icon: Box, color: 'text-red-400' },
    { id: 'door', label: 'Проход / Дверь', desc: 'Вход/выход в коридор', icon: DoorOpen, color: 'text-emerald-400' },
    { id: 'pit', label: 'Бездна / Яма', desc: 'Пропасть в подземелье', icon: Crosshair, color: 'text-purple-400' },
    { id: 'hazard', label: 'Ловушка / Огонь', desc: 'Наносит урон', icon: Flame, color: 'text-amber-400' },
    { id: 'interactable', label: 'Сундук / Алтарь', desc: 'Зона взаимодействия', icon: Shield, color: 'text-yellow-400' }
  ];

  const scrollBlocker = useScrollClickBlocker();

  return (
    <div 
      {...scrollBlocker}
      className="w-full h-full bg-slate-900/95 flex flex-col select-none text-slate-200 text-xs overflow-y-auto overflow-x-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]"
      style={panelScale !== 1.0 ? { transform: `scale(${panelScale})`, transformOrigin: 'top left', width: `${100 / panelScale}%`, height: `${100 / panelScale}%` } : undefined}
    >
      {/* Header */}
      <div className="p-3 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-100">Редактор коллизий</h3>
            <p className="text-[10px] text-slate-400">Рисование непроходимых зон</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onToggleShowCollisions}
            title={showCollisions ? 'Скрыть коллизии' : 'Показать коллизии'}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              showCollisions ? 'bg-sky-500/20 border-sky-500/40 text-sky-400' : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            {showCollisions ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              title="Свернуть"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-3 space-y-4 flex-1">
        {/* Draw Mode Toggle Button */}
        <div>
          <button
            onClick={() => {
              if (currentTool === 'draw_collision') {
                onSetCurrentTool('select');
              } else {
                onSetCurrentTool('draw_collision');
              }
            }}
            className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
              currentTool === 'draw_collision'
                ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-red-950/80 ring-2 ring-red-400'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>
              {currentTool === 'draw_collision' ? 'РЕЖИМ РИСОВАНИЯ АКТИВЕН' : 'РИСОВАТЬ КВАДРАТ КОЛЛИЗИИ'}
            </span>
          </button>
          <p className="text-[10px] text-slate-400 mt-1.5 text-center">
            {currentTool === 'draw_collision'
              ? 'Зажмите и потяните мышь на холсте, чтобы создать прямоугольник коллизии'
              : 'Нажмите кнопку выше, чтобы начать рисовать коллизии'}
          </p>
        </div>

        {/* Collision Type Selection */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Тип создаваемой коллизии</label>
          <div className="space-y-1">
            {collisionTypes.map(ct => {
              const Icon = ct.icon;
              const isSelected = collisionDrawType === ct.id;
              return (
                <button
                  key={ct.id}
                  onClick={() => onSetCollisionDrawType(ct.id)}
                  className={`w-full text-left p-2 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-red-950/60 border-red-500/80 text-white'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className={`w-3.5 h-3.5 ${ct.color}`} />
                    <div>
                      <span className="text-[11px] font-bold block">{ct.label}</span>
                      <span className="text-[9px] text-slate-500">{ct.desc}</span>
                    </div>
                  </div>
                  {isSelected && <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Collision Box Properties */}
        {selectedCollisionId && (() => {
          const cb = collisionBoxes.find(c => c.id === selectedCollisionId);
          if (!cb) return null;
          return (
            <div className="p-3 bg-slate-950 rounded-xl border border-red-500/40 space-y-2.5 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-red-300">Свойства коллизии</span>
                <button
                  onClick={() => onDeleteCollision(cb.id)}
                  className="p-1 rounded bg-rose-950/80 text-rose-400 hover:bg-rose-900 border border-rose-800"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[9px] text-slate-500">X:</span>
                  <input
                    type="number"
                    value={Math.round(cb.x)}
                    onChange={e => onUpdateCollision(cb.id, { x: Number(e.target.value) || 0 })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-slate-200 font-mono text-[10px]"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-slate-500">Y:</span>
                  <input
                    type="number"
                    value={Math.round(cb.y)}
                    onChange={e => onUpdateCollision(cb.id, { y: Number(e.target.value) || 0 })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-slate-200 font-mono text-[10px]"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-slate-500">Ширина:</span>
                  <input
                    type="number"
                    value={Math.round(cb.w)}
                    onChange={e => onUpdateCollision(cb.id, { w: Math.max(8, Number(e.target.value) || 8) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-slate-200 font-mono text-[10px]"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-slate-500">Высота:</span>
                  <input
                    type="number"
                    value={Math.round(cb.h)}
                    onChange={e => onUpdateCollision(cb.id, { h: Math.max(8, Number(e.target.value) || 8) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-slate-200 font-mono text-[10px]"
                  />
                </div>
              </div>

              <div>
                <span className="text-[9px] text-slate-500">Метка:</span>
                <input
                  type="text"
                  value={cb.label || ''}
                  placeholder="Название коллизии..."
                  onChange={e => onUpdateCollision(cb.id, { label: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 text-[10px]"
                />
              </div>
            </div>
          );
        })()}

        {/* Collision List */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Все коллизии ({collisionBoxes.length})
            </label>
            {collisionBoxes.length > 0 && (
              <button
                onClick={onClearAllCollisions}
                className="text-[10px] text-rose-400 hover:underline cursor-pointer"
              >
                Очистить все
              </button>
            )}
          </div>

          <div className="max-h-48 overflow-y-auto space-y-1 custom-scrollbar">
            {collisionBoxes.map(cb => {
              const isSelected = cb.id === selectedCollisionId;
              return (
                <div
                  key={cb.id}
                  onClick={() => onSelectCollision(cb.id)}
                  className={`p-2 rounded-lg border flex items-center justify-between cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-red-950/80 border-red-500 text-red-200'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onUpdateCollision(cb.id, { enabled: !cb.enabled });
                      }}
                    >
                      {cb.enabled ? (
                        <CheckSquare className="w-3.5 h-3.5 text-red-400" />
                      ) : (
                        <Square className="w-3.5 h-3.5 text-slate-600" />
                      )}
                    </button>
                    <div>
                      <span className="text-[11px] font-medium block">
                        {cb.label || (cb.type === 'wall' ? 'Стена' : cb.type === 'door' ? 'Проход' : 'Коллизия')}
                      </span>
                      <span className="text-[9px] font-mono text-slate-500">
                        {Math.round(cb.w)}x{Math.round(cb.h)} @ ({Math.round(cb.x)}, {Math.round(cb.y)})
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onDeleteCollision(cb.id);
                    }}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}

            {collisionBoxes.length === 0 && (
              <div className="text-center py-6 text-slate-500 text-[11px]">
                Коллизии еще не добавлены
              </div>
            )}
          </div>
        </div>

        {/* Floor Zones / Room Shape (Форма комнаты) */}
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-800">
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-100">Форма комнаты</h3>
              <p className="text-[10px] text-slate-400">Чертите зоны свободного пола</p>
            </div>
          </div>

          <div className="space-y-2">
            {/* Draw Floor Tool Toggle */}
            <button
              onClick={() => {
                if (currentTool === 'draw_floor') {
                  onSetCurrentTool('select');
                } else {
                  onSetCurrentTool('draw_floor');
                }
              }}
              className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                currentTool === 'draw_floor'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-emerald-950/80 ring-2 ring-emerald-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>
                {currentTool === 'draw_floor' ? 'РИСОВАНИЕ ПОЛА АКТИВНО' : 'РИСОВАТЬ ЗОНУ ПОЛА'}
              </span>
            </button>
            <p className="text-[10px] text-slate-400 text-center leading-normal">
              {currentTool === 'draw_floor'
                ? 'Зажмите и потяните мышь на холсте, чтобы выделить зону пола. Пересекающиеся зоны объединяются!'
                : 'Нажмите кнопку, чтобы очертить периметр комнаты'}
            </p>

            {/* Generate Button */}
            {floorZones.length > 0 && onGenerateFromZones && (
              <button
                onClick={onGenerateFromZones}
                className="w-full py-2.5 px-4 rounded-xl font-bold text-xs bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-500 hover:to-indigo-500 hover:scale-[1.02] cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
                <span>ВЫЛОЖИТЬ ПЛИТКУ ПОЛА (96×96)</span>
              </button>
            )}
          </div>

          {/* List of Floor Zones */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Зоны пола ({floorZones.length})
              </label>
              {floorZones.length > 0 && onClearFloorZones && (
                <button
                  onClick={onClearFloorZones}
                  className="text-[10px] text-rose-400 hover:underline cursor-pointer"
                >
                  Очистить зоны
                </button>
              )}
            </div>

            <div className="max-h-40 overflow-y-auto space-y-1 custom-scrollbar">
              {floorZones.map((zone, idx) => (
                <div
                  key={zone.id}
                  className="p-1.5 rounded-lg border border-slate-800 bg-slate-950/60 text-slate-400 flex items-center justify-between text-[11px]"
                >
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded bg-emerald-500" />
                    <div>
                      <span className="font-semibold block text-slate-300">Зона #{idx + 1}</span>
                      <span className="text-[9px] font-mono text-slate-500">
                        {zone.w}x{zone.h} @ ({zone.x}, {zone.y})
                      </span>
                    </div>
                  </div>
                  {onRemoveFloorZone && (
                    <button
                      onClick={() => onRemoveFloorZone(zone.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}

              {floorZones.length === 0 && (
                <div className="text-center py-4 text-slate-500 text-[10px] italic">
                  Начертите зоны, чтобы сгенерировать пол свободной формы!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
