import React, { useState } from 'react';
import { RoomType, ROOM_TYPE_CONFIGS } from '../../types/roomEditor';
import { 
  Save, 
  X, 
  FolderPlus, 
  Compass, 
  GitCommit, 
  Shield, 
  Crown,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface SaveRoomModalProps {
  initialName: string;
  initialRoomType?: RoomType;
  initialIsBoss?: boolean;
  theme: 'dungeon' | 'boss' | 'crypt';
  onSave: (name: string, roomType: RoomType, theme: 'dungeon' | 'boss' | 'crypt', exportFile: boolean) => void;
  onClose: () => void;
}

export const SaveRoomModal: React.FC<SaveRoomModalProps> = ({
  initialName,
  initialRoomType,
  initialIsBoss,
  theme: initialTheme,
  onSave,
  onClose
}) => {
  const [name, setName] = useState(initialName || 'Моя_комната_1');
  
  // Determine initial type
  const [roomType, setRoomType] = useState<RoomType>(() => {
    if (initialRoomType) return initialRoomType;
    if (initialIsBoss) return 'boss';
    return 'normal';
  });

  const [theme, setTheme] = useState<'dungeon' | 'boss' | 'crypt'>(() => {
    if (initialTheme) return initialTheme;
    if (roomType === 'boss') return 'boss';
    return 'dungeon';
  });

  const [exportJson, setExportJson] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave(name.trim(), roomType, theme, exportJson);
  };

  const roomTypeOptions: {
    id: RoomType;
    title: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    accentBorder: string;
    accentBg: string;
    textColor: string;
  }[] = [
    {
      id: 'start',
      title: 'Стартовая комната',
      description: 'Зона возрождения и появления героя. Стартовый лут и безопасный вход.',
      icon: Compass,
      accentBorder: 'border-emerald-500 hover:border-emerald-400',
      accentBg: 'bg-emerald-950/40',
      textColor: 'text-emerald-300'
    },
    {
      id: 'bridge',
      title: 'Промежуточный мост',
      description: 'Мост, коридор или узкий переход между залами подземелья.',
      icon: GitCommit,
      accentBorder: 'border-amber-500 hover:border-amber-400',
      accentBg: 'bg-amber-950/40',
      textColor: 'text-amber-300'
    },
    {
      id: 'normal',
      title: 'Обычная комната',
      description: 'Стандартный боевой зал, святилище с ловушками, врагами и сундуками.',
      icon: Shield,
      accentBorder: 'border-sky-500 hover:border-sky-400',
      accentBg: 'bg-sky-950/40',
      textColor: 'text-sky-300'
    },
    {
      id: 'boss',
      title: 'Комната с боссом',
      description: 'Финальная арена с боссом уровня, троном и легендарными наградами.',
      icon: Crown,
      accentBorder: 'border-rose-500 hover:border-rose-400',
      accentBg: 'bg-rose-950/40',
      textColor: 'text-rose-300'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border-2 border-sky-500/50 rounded-2xl shadow-2xl shadow-sky-950/80 overflow-hidden text-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40">
              <FolderPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Сохранение комнаты</h3>
              <p className="text-[11px] text-slate-400">Настройка типа комнаты и сохранение в библиотеку</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto overflow-x-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]">
          {/* Room Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Название комнаты
            </label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Введите название (например, Зал_тронов)..."
              className="w-full bg-slate-950 border border-slate-700 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition-colors"
            />
          </div>

          {/* Room Type Selector (4 Types) */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Тип комнаты в подземелье</span>
              <span className="text-[10px] text-sky-400 font-normal">Определяет роль при генерации</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {roomTypeOptions.map(opt => {
                const isSelected = roomType === opt.id;
                const IconComponent = opt.icon;
                return (
                  <button
                    type="button"
                    key={opt.id}
                    onClick={() => {
                      setRoomType(opt.id);
                      if (opt.id === 'boss') setTheme('boss');
                    }}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-start gap-3 relative ${
                      isSelected
                        ? `${opt.accentBg} ${opt.accentBorder} shadow-lg shadow-black/40 border-2`
                        : 'bg-slate-950/70 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-slate-900' : 'bg-slate-900/60'} ${opt.textColor} shrink-0`}>
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                          {opt.title}
                        </span>
                        {isSelected && (
                          <CheckCircle2 className={`w-3.5 h-3.5 ${opt.textColor} shrink-0`} />
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5 leading-snug line-clamp-2">
                        {opt.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Visual Theme Style */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Визуальный стиль
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'dungeon', label: 'Подземелье' },
                { id: 'boss', label: 'Тронный / Босс' },
                { id: 'crypt', label: 'Склеп' }
              ].map(t => (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setTheme(t.id as any)}
                  className={`py-2 px-2.5 rounded-xl border text-xs font-medium cursor-pointer transition-all ${
                    theme === t.id
                      ? 'bg-sky-600 text-white border-sky-400 shadow-md shadow-sky-950'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Export JSON file Checkbox */}
          <label className="flex items-center gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
            <input
              type="checkbox"
              checked={exportJson}
              onChange={e => setExportJson(e.target.checked)}
              className="w-4 h-4 accent-sky-500 rounded"
            />
            <div>
              <span className="text-xs font-bold text-slate-200 block">Скачать файл .json на диск</span>
              <span className="text-[10px] text-slate-400">Экспорт резервной копии схемы комнаты</span>
            </div>
          </label>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer transition-colors"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-sky-950 cursor-pointer flex items-center gap-2 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>СОХРАНИТЬ</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
