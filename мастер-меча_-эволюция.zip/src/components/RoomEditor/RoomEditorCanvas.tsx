import React, { useRef, useEffect, useState, useCallback } from 'react';
import { RoomElement, CollisionBox, LayerType, CollisionType, RoomLightingSettings, isElementAboveHero } from '../../types/roomEditor';
import { EditorAssetDefinition, getAssetById } from '../../utils/wallAssets';
import { isTorchElement, getTorchConfig, drawTorchFlame, drawRoomLightingPass, isShadowZone, renderSeamlessShadows } from '../../utils/torchEffects';

type ResizeHandleType = 'tl' | 'tr' | 'br' | 'bl' | 't' | 'r' | 'b' | 'l';

interface RoomEditorCanvasProps {
  width: number;
  height: number;
  gridSize: number;
  snapToGrid: boolean;
  showGrid: boolean;
  showCollisions: boolean;
  activeLayerFilter: LayerType | 'all';
  elements: RoomElement[];
  collisionBoxes: CollisionBox[];
  selectedElementIds: string[];
  selectedCollisionId: string | null;
  currentTool: 'select' | 'draw_collision' | 'draw_floor' | 'pan';
  collisionDrawType: CollisionType;
  spawnPoint: { x: number; y: number };
  lighting?: RoomLightingSettings;
  floorZones?: { id: string; x: number; y: number; w: number; h: number }[];
  bakedUnderHeroImage?: string;
  bakedAboveHeroImage?: string;
  onAddFloorZone?: (zone: { x: number; y: number; w: number; h: number }) => void;
  onSelectElements: (ids: string[]) => void;
  onSelectCollision: (id: string | null) => void;
  onUpdateElement: (id: string, updates: Partial<RoomElement>) => void;
  onUpdateMultipleElements: (updates: { id: string; x: number; y: number }[]) => void;
  onAddMultipleElements: (newElements: RoomElement[]) => void;
  onDropAsset: (asset: EditorAssetDefinition, position: { x: number; y: number }) => void;
  onUpdateCollision: (id: string, updates: Partial<CollisionBox>) => void;
  onAddCollisionBox: (box: Omit<CollisionBox, 'id'>) => void;
  onDuplicateElement?: (id: string) => void;
  onDeleteElement?: (id: string) => void;
  onUpdateSpawnPoint: (pt: { x: number; y: number }) => void;
  zoom: number;
  onZoomChange?: (zoom: number) => void;
  panOffset: { x: number; y: number };
  onPanChange: (offset: { x: number; y: number }) => void;
}

export const RoomEditorCanvas: React.FC<RoomEditorCanvasProps> = ({
  width,
  height,
  gridSize,
  snapToGrid,
  showGrid,
  showCollisions,
  activeLayerFilter,
  elements,
  collisionBoxes,
  selectedElementIds,
  selectedCollisionId,
  currentTool,
  collisionDrawType,
  spawnPoint,
  lighting,
  floorZones,
  bakedUnderHeroImage,
  bakedAboveHeroImage,
  onAddFloorZone,
  onSelectElements,
  onSelectCollision,
  onUpdateElement,
  onUpdateMultipleElements,
  onAddMultipleElements,
  onDropAsset,
  onUpdateCollision,
  onAddCollisionBox,
  onDuplicateElement,
  onDeleteElement,
  onUpdateSpawnPoint,
  zoom,
  onZoomChange,
  panOffset,
  onPanChange
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [dragMode, setDragMode] = useState<'move' | 'ctrl_clone' | 'marquee' | 'resize' | 'rotate' | 'pan' | 'draw_col' | 'draw_floor' | 'spawn' | null>(null);
  const [activeResizeHandle, setActiveResizeHandle] = useState<ResizeHandleType | null>(null);
  const [hoverCursor, setHoverCursor] = useState<string>('cursor-default');
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragOver, setIsDragOver] = useState(false);

  // Group movement start positions map (id -> initial pos)
  const [elementsStartPositions, setElementsStartPositions] = useState<{ [id: string]: { x: number; y: number } }>({});
  
  // Single element start state for resizing / rotating / single move
  const [singleStartPos, setSingleStartPos] = useState<{ 
    x: number; 
    y: number; 
    w: number; 
    h: number; 
    scaleX: number; 
    scaleY: number; 
    rotation: number;
    cx: number;
    cy: number;
  } | null>(null);

  // Marquee selection box
  const [marqueeStart, setMarqueeStart] = useState<{ x: number; y: number } | null>(null);
  const [marqueeCurrent, setMarqueeCurrent] = useState<{ x: number; y: number } | null>(null);
  const [isShiftPressedDuringMarquee, setIsShiftPressedDuringMarquee] = useState(false);

  // Ctrl + Drag Clones preview
  const [cloningElements, setCloningElements] = useState<RoomElement[]>([]);

  // Collision box drawing
  const [drawBoxStart, setDrawBoxStart] = useState<{ x: number; y: number } | null>(null);
  const [drawBoxCurrent, setDrawBoxCurrent] = useState<{ x: number; y: number } | null>(null);

  // Mobile & Touch Gesture Refs and States
  const touchStartTimeRef = useRef<number>(0);
  const touchStartPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchStartWorldRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchMovedRef = useRef<boolean>(false);
  const longPressTimerRef = useRef<any>(null);
  const isTouchDraggingElementRef = useRef<boolean>(false);
  const isTouchPanningRef = useRef<boolean>(false);

  // Two finger pinch to zoom & pan refs
  const isPinchingRef = useRef<boolean>(false);
  const initialPinchDistRef = useRef<number>(0);
  const initialPinchZoomRef = useRef<number>(1.0);
  const initialPinchMidRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialPinchPanRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const ignoreTouchesUntilAllReleasedRef = useRef<boolean>(false);
  const isCanvasTouchRef = useRef<boolean>(false);

  // Touch Feedback messages & Pinch Zoom preview
  const [touchFeedback, setTouchFeedback] = useState<string | null>(null);
  const [pinchZoomDisplay, setPinchZoomDisplay] = useState<number | null>(null);

  // Cached image objects for smooth rendering
  const imagesRef = useRef<Map<string, HTMLImageElement>>(new Map());

  // Layer ranking for correct Z-order
  const layerWeights: Record<LayerType, number> = {
    floor_bg: 100,
    back_wall: 200,
    mid_props: 300,
    front_wall: 400,
    foreground: 500
  };

  // Preload asset images
  useEffect(() => {
    elements.forEach(el => {
      let src = el.src;
      if (el.assetId === 'shadow_square_dark' || el.assetId === 'shadow_rect_corridor' || (src && src.includes('stroke-dasharray'))) {
        const def = el.assetId ? getAssetById(el.assetId) : null;
        if (def) src = def.src;
        else if (src) src = src.replace(/stroke="[^"]*"/g, '').replace(/stroke-dasharray="[^"]*"/g, '').replace(/stroke-width="[^"]*"/g, '');
      }
      if (src && !imagesRef.current.has(src)) {
        const img = new Image();
        img.src = src;
        img.onload = () => {
          drawCanvas();
        };
        imagesRef.current.set(src, img);
      }
    });
  }, [elements]);

  // Convert client mouse coord to canvas local world room space (100% accurate 1:1)
  const screenToWorld = useCallback((screenX: number, screenY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientXInCanvas = screenX - rect.left;
    const clientYInCanvas = screenY - rect.top;
    const worldX = (clientXInCanvas - panOffset.x) / zoom;
    const worldY = (clientYInCanvas - panOffset.y) / zoom;
    return { x: worldX, y: worldY };
  }, [panOffset.x, panOffset.y, zoom]);

  // Convert world room coord to screen viewport pixel position
  const worldToScreen = useCallback((worldX: number, worldY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: rect.left + panOffset.x + worldX * zoom,
      y: rect.top + panOffset.y + worldY * zoom
    };
  }, [panOffset.x, panOffset.y, zoom]);

  const snapValue = useCallback((val: number, step: number) => {
    if (!snapToGrid) return Math.round(val * 10) / 10;
    return Math.round(val / step) * step;
  }, [snapToGrid]);

  // Resize canvas to match container's exact bounding box with devicePixelRatio
  const syncCanvasSize = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const targetW = Math.max(100, Math.floor(rect.width));
    const targetH = Math.max(100, Math.floor(rect.height));

    if (canvas.width !== Math.floor(targetW * dpr) || canvas.height !== Math.floor(targetH * dpr)) {
      canvas.width = Math.floor(targetW * dpr);
      canvas.height = Math.floor(targetH * dpr);
      canvas.style.width = `${targetW}px`;
      canvas.style.height = `${targetH}px`;
    }
  }, []);

  // Compute 8 handle positions in world coordinates for an element
  const getElementHandles = useCallback((el: RoomElement) => {
    const cx = el.x + el.w / 2;
    const cy = el.y + el.h / 2;
    const effW = el.w * (el.scaleX || 1);
    const effH = el.h * (el.scaleY || 1);
    const rad = ((el.rotation || 0) * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    const toWorld = (lx: number, ly: number) => ({
      x: cx + lx * cos - ly * sin,
      y: cy + lx * sin + ly * cos
    });

    const hw = effW / 2;
    const hh = effH / 2;

    return {
      tl: { ...toWorld(-hw, -hh), type: 'tl' as ResizeHandleType },
      t: { ...toWorld(0, -hh), type: 't' as ResizeHandleType },
      tr: { ...toWorld(hw, -hh), type: 'tr' as ResizeHandleType },
      r: { ...toWorld(hw, 0), type: 'r' as ResizeHandleType },
      br: { ...toWorld(hw, hh), type: 'br' as ResizeHandleType },
      b: { ...toWorld(0, hh), type: 'b' as ResizeHandleType },
      bl: { ...toWorld(-hw, hh), type: 'bl' as ResizeHandleType },
      l: { ...toWorld(-hw, 0), type: 'l' as ResizeHandleType },
      rot: { ...toWorld(0, -hh - 20 / zoom), type: 'rot' }
    };
  }, [zoom]);

  // Compute 8 handle positions in world coordinates for a collision box
  const getCollisionHandles = useCallback((cb: CollisionBox) => {
    return {
      tl: { x: cb.x, y: cb.y, type: 'tl' as ResizeHandleType },
      t: { x: cb.x + cb.w / 2, y: cb.y, type: 't' as ResizeHandleType },
      tr: { x: cb.x + cb.w, y: cb.y, type: 'tr' as ResizeHandleType },
      r: { x: cb.x + cb.w, y: cb.y + cb.h / 2, type: 'r' as ResizeHandleType },
      br: { x: cb.x + cb.w, y: cb.y + cb.h, type: 'br' as ResizeHandleType },
      b: { x: cb.x + cb.w / 2, y: cb.y + cb.h, type: 'b' as ResizeHandleType },
      bl: { x: cb.x, y: cb.y + cb.h, type: 'bl' as ResizeHandleType },
      l: { x: cb.x, y: cb.y + cb.h / 2, type: 'l' as ResizeHandleType }
    };
  }, []);

  // Main canvas render loop
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    syncCanvasSize();

    const dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.scale(dpr, dpr);

    // Apply pan & zoom in CSS pixel space
    ctx.translate(panOffset.x, panOffset.y);
    ctx.scale(zoom, zoom);

    // 2. High-performance, clean grid lines (Strictly inside drawn floor zones if present)
    if (showGrid && floorZones && floorZones.length > 0) {
      ctx.save();
      ctx.beginPath();
      floorZones.forEach(zone => {
        ctx.rect(zone.x, zone.y, zone.w, zone.h);
      });
      ctx.clip();

      const minX = Math.min(...floorZones.map(z => z.x));
      const minY = Math.min(...floorZones.map(z => z.y));
      const maxX = Math.max(...floorZones.map(z => z.x + z.w));
      const maxY = Math.max(...floorZones.map(z => z.y + z.h));

      // Visual step: keep grid simple, crisp and ultra-fast (prevents lag & visual noise at 4px/8px)
      // Snapping is 100% untouched and precise at gridSize (4px, 8px, 16px, etc.)
      // 32px is a multiple of 4/8/16/32 and divides 96px floor plates cleanly
      const visualStep = gridSize < 16 ? 32 : gridSize;

      ctx.strokeStyle = 'rgba(148, 163, 184, 0.12)';
      ctx.lineWidth = 1 / zoom;
      ctx.beginPath();
      for (let x = minX; x <= maxX; x += visualStep) {
        ctx.moveTo(x, minY);
        ctx.lineTo(x, maxY);
      }
      for (let y = minY; y <= maxY; y += visualStep) {
        ctx.moveTo(minX, y);
        ctx.lineTo(maxX, y);
      }
      ctx.stroke();

      ctx.restore();
    }

    // 3. Render Floor Zones (Область пола комнат - максимально простой чистый визуал без лагов и пунктиров)
    if (floorZones && floorZones.length > 0) {
      ctx.save();
      ctx.beginPath();
      floorZones.forEach(zone => {
        ctx.rect(zone.x, zone.y, zone.w, zone.h);
      });
      // Чистый полупрозрачный фон зоны пола комнат
      ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
      ctx.fill();

      // Чистый сплошной контур пола комнат (без пунктиров и тяжелых вычислений)
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5 / zoom;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
      ctx.restore();
    }

    // Drag-Drawing Preview for Floor Zone
    if (dragMode === 'draw_floor' && drawBoxStart && drawBoxCurrent) {
      const bx = Math.min(drawBoxStart.x, drawBoxCurrent.x);
      const by = Math.min(drawBoxStart.y, drawBoxCurrent.y);
      const bw = Math.abs(drawBoxCurrent.x - drawBoxStart.x);
      const bh = Math.abs(drawBoxCurrent.y - drawBoxStart.y);

      ctx.save();
      ctx.fillStyle = 'rgba(16, 185, 129, 0.35)';
      ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2 / zoom;
      ctx.strokeRect(bx, by, bw, bh);
      ctx.restore();
    }

    const timeSec = performance.now() / 1000;

    // Helper to draw an element
    const renderElement = (el: RoomElement, isPreviewClone = false) => {
      const isFilteredOut = false; // 5 Layers removed, using purely zIndex for ordering!
      const isSelected = selectedElementIds.includes(el.id);

      ctx.save();
      ctx.translate(el.x + el.w / 2, el.y + el.h / 2);
      ctx.rotate(((el.rotation || 0) * Math.PI) / 180);
      ctx.scale(
        (el.scaleX || 1) * (el.flipX ? -1 : 1),
        (el.scaleY || 1) * (el.flipY ? -1 : 1)
      );

      ctx.globalAlpha = (el.opacity ?? 1) * (isFilteredOut ? 0.35 : 1) * (isPreviewClone ? 0.85 : 1);

      const isFlameOnly = el.assetId === 'light_fire_flame' || el.assetId === 'light_torch_flame' || (el.assetId && el.assetId.includes('flame'));
      const isShadow = isShadowZone(el);
      if (!isFlameOnly && !isShadow) {
        // Contact shadow for pots (кувшины), crates, barrels at their base
        const isPot = el.assetId === 'prop_pot_1' || el.assetId === 'prop_pot_2' || (el.name && el.name.toLowerCase().includes('кувшин')) || (el.src && el.src.toLowerCase().includes('kuvshin'));
        const isCrate = el.assetId === 'prop_crate' || (el.name && el.name.toLowerCase().includes('ящик')) || (el.src && el.src.toLowerCase().includes('yashik'));
        const isBarrel = el.assetId === 'prop_barrel' || (el.name && el.name.toLowerCase().includes('бочка')) || (el.src && el.src.toLowerCase().includes('bochka'));
        const isChest = el.assetId === 'prop_chest' || (el.name && el.name.toLowerCase().includes('сундук')) || (el.src && el.src.toLowerCase().includes('sunduk'));
        if (isCrate) {
          ctx.save();
          const shadowRx = Math.round(el.w * 0.45);
          const shadowRy = Math.max(3, Math.round(el.h * 0.14));
          const shadowY = el.h / 2 - 3;
          ctx.fillStyle = 'rgba(5, 8, 15, 0.52)';
          ctx.beginPath();
          ctx.ellipse(0, shadowY, shadowRx, shadowRy, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (isBarrel) {
          ctx.save();
          const shadowRx = Math.round(el.w * 0.44);
          const shadowRy = Math.max(3, Math.round(el.h * 0.16));
          const shadowY = el.h / 2 - 3;
          ctx.fillStyle = 'rgba(5, 8, 15, 0.52)';
          ctx.beginPath();
          ctx.ellipse(0, shadowY, shadowRx, shadowRy, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (isChest) {
          ctx.save();
          const shadowRx = Math.round(el.w * 0.46);
          const shadowRy = Math.max(3, Math.round(el.h * 0.15));
          const shadowY = el.h / 2 - 3;
          ctx.fillStyle = 'rgba(5, 8, 15, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, shadowY, shadowRx, shadowRy, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }

      let assetSrc = el.src;
      if (el.assetId === 'shadow_square_dark' || el.assetId === 'shadow_rect_corridor' || (assetSrc && assetSrc.includes('stroke-dasharray'))) {
        const def = el.assetId ? getAssetById(el.assetId) : null;
        if (def) assetSrc = def.src;
        else if (assetSrc) assetSrc = assetSrc.replace(/stroke="[^"]*"/g, '').replace(/stroke-dasharray="[^"]*"/g, '').replace(/stroke-width="[^"]*"/g, '');
      }
      const img = imagesRef.current.get(assetSrc) || imagesRef.current.get(el.src);
      if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, -el.w / 2, -el.h / 2, el.w, el.h);
      } else {
        // Fallback block placeholder
        ctx.fillStyle = isPreviewClone ? '#0284c7' : '#3b82f6';
        ctx.fillRect(-el.w / 2, -el.h / 2, el.w, el.h);
        ctx.strokeStyle = '#60a5fa';
        ctx.strokeRect(-el.w / 2, -el.h / 2, el.w, el.h);
      }

      ctx.restore();

      // Render realistic animated torch fire and ambient glowing light
      const hasFire = el.hasFireEffect ?? isTorchElement(el.assetId, el.name);
      if (hasFire && el.visible !== false) {
        const config = getTorchConfig(el.assetId);
        const cx = el.x + el.w / 2;
        const cy = el.y + el.h / 2;
        const rad = ((el.rotation || 0) * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);

        const effH = el.h * (el.scaleY || 1);
        const localAnchorY = (effH / 2) * (config.anchorOffsetYRatio * 2);
        const localAnchorX = 0;

        const fx = cx + localAnchorX * cos - localAnchorY * sin;
        const fy = cy + localAnchorX * sin + localAnchorY * cos;

        const flameScale = config.scale * Math.max(0.4, (Math.abs(el.scaleX || 1) + Math.abs(el.scaleY || 1)) / 2) * (el.fireScale || 1);
        const seed = Math.abs((el.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) * 1.618) % 100);
        const flameAlpha = (el.opacity ?? 1) * (isFilteredOut ? 0.35 : 1) * (isPreviewClone ? 0.85 : 1);

        drawTorchFlame(ctx, fx, fy, flameScale, timeSec, seed, config.baseWidthScale, flameAlpha);
      }

      // Selection bounding box or clone preview box
      if (isSelected || isPreviewClone) {
        ctx.save();
        ctx.translate(el.x + el.w / 2, el.y + el.h / 2);
        ctx.rotate(((el.rotation || 0) * Math.PI) / 180);

        const effW = el.w * (el.scaleX || 1);
        const effH = el.h * (el.scaleY || 1);

        const isShadow = el.assetId?.includes('shadow') || el.name?.toLowerCase().includes('тень');
        ctx.strokeStyle = isPreviewClone ? '#38bdf8' : '#38bdf8';
        ctx.lineWidth = (isPreviewClone ? 2.5 : 2) / zoom;
        if (!isShadow) {
          ctx.setLineDash([4 / zoom, 4 / zoom]);
        } else {
          ctx.setLineDash([]);
        }
        ctx.strokeRect(-effW / 2, -effH / 2, effW, effH);
        ctx.setLineDash([]);

        if (isPreviewClone) {
          ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
          ctx.fillRect(-effW / 2, -effH / 2, effW, effH);
        }

        // Full 8 interactive handles (TL, T, TR, R, BR, B, BL, L) + Top rotation handle
        if (selectedElementIds.length === 1 && isSelected && !isPreviewClone) {
          const cornerHandleSize = Math.max(12 / zoom, 12);
          const edgeHandleSize = Math.max(10 / zoom, 10);
          ctx.lineWidth = Math.max(1.5 / zoom, 1.5);

          // Corner handles (crisp white squares with sky-blue border and dark shadow)
          const hw = effW / 2;
          const hh = effH / 2;

          const cornerPoints = [
            [-hw, -hh],
            [hw, -hh],
            [hw, hh],
            [-hw, hh]
          ];

          cornerPoints.forEach(([hx, hy]) => {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
            ctx.shadowBlur = 4;
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(hx - cornerHandleSize / 2, hy - cornerHandleSize / 2, cornerHandleSize, cornerHandleSize);
            ctx.shadowColor = 'transparent';
            ctx.strokeStyle = '#0284c7';
            ctx.strokeRect(hx - cornerHandleSize / 2, hy - cornerHandleSize / 2, cornerHandleSize, cornerHandleSize);
          });

          // Edge middle handles (cyan rectangles for side scaling)
          const edgePoints = [
            [0, -hh], // T
            [hw, 0],  // R
            [0, hh],  // B
            [-hw, 0]  // L
          ];

          edgePoints.forEach(([hx, hy]) => {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
            ctx.shadowBlur = 4;
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(hx - edgeHandleSize / 2, hy - edgeHandleSize / 2, edgeHandleSize, edgeHandleSize);
            ctx.shadowColor = 'transparent';
            ctx.strokeStyle = '#ffffff';
            ctx.strokeRect(hx - edgeHandleSize / 2, hy - edgeHandleSize / 2, edgeHandleSize, edgeHandleSize);
          });

          // Rotation stem and node on top
          const rotNodeRadius = Math.max(6.5 / zoom, 6.5);
          ctx.beginPath();
          ctx.moveTo(0, -hh);
          ctx.lineTo(0, -hh - 22 / zoom);
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = Math.max(1.8 / zoom, 1.8);
          ctx.stroke();

          ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
          ctx.shadowBlur = 4;
          ctx.beginPath();
          ctx.arc(0, -hh - 22 / zoom, rotNodeRadius, 0, Math.PI * 2);
          ctx.fillStyle = '#38bdf8';
          ctx.fill();
          ctx.shadowColor = 'transparent';
          ctx.strokeStyle = '#ffffff';
          ctx.stroke();
        }

        ctx.restore();
      }
    };

    // Helper to render Hero Spawn Marker (Strictly Layer 100)
    const renderSpawnMarker = () => {
      ctx.save();
      ctx.translate(spawnPoint.x, spawnPoint.y);

      // Hero Body Ghost Preview (Exact 35x35 in-game size to visualize hero proportions at layer 100)
      ctx.save();
      ctx.fillStyle = 'rgba(244, 63, 94, 0.4)';
      ctx.fillRect(-17.5, -17.5, 35, 35);
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 1.5 / zoom;
      ctx.strokeRect(-17.5, -17.5, 35, 35);

      // Eyes
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-6, -2, 3.5, 0, Math.PI * 2);
      ctx.arc(6, -2, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(-6, -1, 1.8, 0, Math.PI * 2);
      ctx.arc(6, -1, 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Outer target ring
      ctx.beginPath();
      ctx.arc(0, 0, 16 / zoom, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
      ctx.fill();
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2 / zoom;
      ctx.stroke();

      // Crosshair icon
      ctx.beginPath();
      ctx.moveTo(-12 / zoom, 0);
      ctx.lineTo(12 / zoom, 0);
      ctx.moveTo(0, -12 / zoom);
      ctx.lineTo(0, 12 / zoom);
      ctx.stroke();

      ctx.fillStyle = '#10b981';
      ctx.font = `bold ${10 / zoom}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('СПАВН ГЕРОЯ', 0, 26 / zoom);
      ctx.restore();
    };

    // Helper to identify upper wall elements
    const isUpperWall = (el: RoomElement) => {
      const aid = (el.assetId || '').toLowerCase();
      const name = (el.name || '').toLowerCase();
      const layer = (el.layer || '').toLowerCase();
      const src = (el.src || '').toLowerCase();
      if (layer === 'back_wall') return true;
      if (aid.includes('wall_horiz_top') || aid.includes('wall_vert_top') || aid.includes('wall_mid') || aid.includes('wall_top') || aid.includes('corner_tl') || aid.includes('corner_tr') || aid.includes('wall_top_left') || aid.includes('wall_top_right')) return true;
      if (name.includes('верхний блок') || name.includes('средний блок') || name.includes('задний левый') || name.includes('задний правый') || name.includes('стена') || name.includes('арка')) return true;
      return false;
    };

    const isFloorProp = (el: RoomElement) => {
      const aid = (el.assetId || '').toLowerCase();
      const name = (el.name || '').toLowerCase();
      const src = (el.src || '').toLowerCase();
      if (aid.startsWith('prop_chest') || aid.startsWith('prop_crate') || aid.startsWith('prop_pot') || aid.startsWith('prop_barrel')) return true;
      if (name.includes('сундук') || name.includes('ящик') || name.includes('кувшин') || name.includes('бочка')) return true;
      if (src.includes('sunduk') || src.includes('yashik') || src.includes('kuvshin') || src.includes('bochka')) return true;
      return false;
    };

    // 3. Render Elements: Upper walls render under floor props (сундуки, ящики, кувшины ALWAYS render ON TOP of upper walls)
    const sortedElements = [...elements]
      .filter(el => el.visible !== false)
      .sort((a, b) => {
        const aUpper = isUpperWall(a);
        const bUpper = isUpperWall(b);
        const aProp = isFloorProp(a);
        const bProp = isFloorProp(b);
        if (aUpper && bProp) return -1;
        if (bUpper && aProp) return 1;
        return (a.zIndex || 0) - (b.zIndex || 0);
      });

    // Helper to render an ordered list of elements with SEAMLESS UNION MERGING for shadows
    const renderElementList = (els: RoomElement[], isPreviewClone = false) => {
      let i = 0;
      while (i < els.length) {
        if (isShadowZone(els[i])) {
          // Collect contiguous run of shadow elements
          const shadowRun: RoomElement[] = [];
          while (i < els.length && isShadowZone(els[i])) {
            shadowRun.push(els[i]);
            i++;
          }
          // Render seamless unified shadows (zero seams where same opacity overlaps!)
          renderSeamlessShadows(ctx, shadowRun, 1.0, 0, 0);
          // Render selection boxes & handles for any selected shadows
          shadowRun.forEach(sEl => {
            if (selectedElementIds.includes(sEl.id) || isPreviewClone) {
              renderElement(sEl, isPreviewClone);
            }
          });
        } else {
          // Regular non-shadow element
          renderElement(els[i], isPreviewClone);
          i++;
        }
      }
    };

    // Strict Layering: Floor props (chests, crates, pots) render ON TOP of upper walls
    const upperWallElements = sortedElements.filter(el => isUpperWall(el));
    const floorPropElements = sortedElements.filter(el => isFloorProp(el));
    const otherElementsBelowHero = sortedElements.filter(el => !isUpperWall(el) && !isFloorProp(el) && !isElementAboveHero(el));
    const otherElementsAboveHero = sortedElements.filter(el => !isUpperWall(el) && !isFloorProp(el) && isElementAboveHero(el));

    // 1. Elements below hero (or baked under hero image)
    if (bakedUnderHeroImage) {
      if (!imagesRef.current.has(bakedUnderHeroImage)) {
        const img = new Image();
        img.src = bakedUnderHeroImage;
        imagesRef.current.set(bakedUnderHeroImage, img);
      }
      const img = imagesRef.current.get(bakedUnderHeroImage);
      if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, 0, 0, width, height);
      }
    }
    renderElementList(otherElementsBelowHero, false);

    // 2. Upper walls
    renderElementList(upperWallElements, false);

    // 3. Hero Spawn Marker
    renderSpawnMarker();

    // 4. Other elements above hero (or baked above hero image)
    if (bakedAboveHeroImage) {
      if (!imagesRef.current.has(bakedAboveHeroImage)) {
        const img = new Image();
        img.src = bakedAboveHeroImage;
        imagesRef.current.set(bakedAboveHeroImage, img);
      }
      const img = imagesRef.current.get(bakedAboveHeroImage);
      if (img && img.complete && img.naturalWidth > 0) {
        ctx.drawImage(img, 0, 0, width, height);
      }
    }
    renderElementList(otherElementsAboveHero, false);

    // 5. Floor props (chests, crates, pots, barrels) rendered ON TOP of upper walls!
    renderElementList(floorPropElements, false);

    // 4. Render Active Ctrl-Clone Preview Elements
    if (cloningElements.length > 0) {
      renderElementList(cloningElements, true);
    }

    // 5. Dynamic 2D Lighting & Shadow Pass (Освещение факелами strictly inside drawn floor zones)
    if (floorZones && floorZones.length > 0 && lighting?.enableLighting && (lighting?.ambientDarkness ?? 0) > 0.01) {
      const minX = Math.min(...floorZones.map(z => z.x));
      const minY = Math.min(...floorZones.map(z => z.y));
      const maxX = Math.max(...floorZones.map(z => z.x + z.w));
      const maxY = Math.max(...floorZones.map(z => z.y + z.h));
      const bW = Math.max(32, maxX - minX);
      const bH = Math.max(32, maxY - minY);

      ctx.save();
      // Clip lighting strictly inside drawn floor zones - no square backdrop EVER appears outside!
      ctx.beginPath();
      floorZones.forEach(zone => {
        ctx.rect(zone.x, zone.y, zone.w, zone.h);
      });
      ctx.clip();

      drawRoomLightingPass(ctx, bW, bH, elements, lighting, timeSec, zoom, selectedElementIds, false, minX, minY);
      ctx.restore();
    }

    // 6. Render Collision Boxes
    if (showCollisions) {
      collisionBoxes.forEach(cb => {
        if (!cb.enabled) return;
        const isSelected = cb.id === selectedCollisionId;

        let fillColor = 'rgba(239, 68, 68, 0.25)';
        let strokeColor = '#ef4444';

        if (cb.type === 'door') {
          fillColor = 'rgba(34, 197, 94, 0.25)';
          strokeColor = '#22c55e';
        } else if (cb.type === 'pit') {
          fillColor = 'rgba(168, 85, 247, 0.25)';
          strokeColor = '#a855f7';
        } else if (cb.type === 'interactable') {
          fillColor = 'rgba(234, 179, 8, 0.3)';
          strokeColor = '#eab308';
        } else if (cb.type === 'hazard') {
          fillColor = 'rgba(249, 115, 22, 0.3)';
          strokeColor = '#f97316';
        }

        ctx.save();
        ctx.fillStyle = fillColor;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = (isSelected ? 2.5 : 1.5) / zoom;

        ctx.fillRect(cb.x, cb.y, cb.w, cb.h);
        ctx.strokeRect(cb.x, cb.y, cb.w, cb.h);

        // Diagonal hatch for solid walls
        if (cb.type === 'wall') {
          ctx.beginPath();
          ctx.moveTo(cb.x, cb.y);
          ctx.lineTo(cb.x + cb.w, cb.y + cb.h);
          ctx.moveTo(cb.x + cb.w, cb.y);
          ctx.lineTo(cb.x, cb.y + cb.h);
          ctx.strokeStyle = strokeColor + '55';
          ctx.lineWidth = 1 / zoom;
          ctx.stroke();
        }

        // Label if present
        if (cb.label) {
          ctx.fillStyle = strokeColor;
          ctx.font = `${Math.max(10, 11 / zoom)}px sans-serif`;
          ctx.fillText(cb.label, cb.x + 4 / zoom, cb.y + 12 / zoom);
        }

        if (isSelected) {
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2 / zoom;
          ctx.setLineDash([4 / zoom, 4 / zoom]);
          ctx.strokeRect(cb.x, cb.y, cb.w, cb.h);
          ctx.setLineDash([]);

          const cornerHandleSize = 8 / zoom;
          const edgeHandleSize = 6 / zoom;
          ctx.lineWidth = 1.5 / zoom;

          // Corner handles (white squares with colored border)
          const cornerPoints = [
            [cb.x, cb.y],
            [cb.x + cb.w, cb.y],
            [cb.x + cb.w, cb.y + cb.h],
            [cb.x, cb.y + cb.h]
          ];

          cornerPoints.forEach(([hx, hy]) => {
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = strokeColor;
            ctx.fillRect(hx - cornerHandleSize / 2, hy - cornerHandleSize / 2, cornerHandleSize, cornerHandleSize);
            ctx.strokeRect(hx - cornerHandleSize / 2, hy - cornerHandleSize / 2, cornerHandleSize, cornerHandleSize);
          });

          // Edge middle handles (colored squares for side scaling)
          const edgePoints = [
            [cb.x + cb.w / 2, cb.y],        // T
            [cb.x + cb.w, cb.y + cb.h / 2],  // R
            [cb.x + cb.w / 2, cb.y + cb.h],  // B
            [cb.x, cb.y + cb.h / 2]         // L
          ];

          edgePoints.forEach(([hx, hy]) => {
            ctx.fillStyle = strokeColor;
            ctx.strokeStyle = '#ffffff';
            ctx.fillRect(hx - edgeHandleSize / 2, hy - edgeHandleSize / 2, edgeHandleSize, edgeHandleSize);
            ctx.strokeRect(hx - edgeHandleSize / 2, hy - edgeHandleSize / 2, edgeHandleSize, edgeHandleSize);
          });
        }

        ctx.restore();
      });
    }

    // 6. Active collision drawing box preview
    if (drawBoxStart && drawBoxCurrent) {
      const bx = Math.min(drawBoxStart.x, drawBoxCurrent.x);
      const by = Math.min(drawBoxStart.y, drawBoxCurrent.y);
      const bw = Math.abs(drawBoxCurrent.x - drawBoxStart.x);
      const bh = Math.abs(drawBoxCurrent.y - drawBoxStart.y);

      ctx.save();
      ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2 / zoom;
      ctx.setLineDash([4 / zoom, 4 / zoom]);
      ctx.fillRect(bx, by, bw, bh);
      ctx.strokeRect(bx, by, bw, bh);
      ctx.restore();
    }

    // 7. Marquee selection box preview
    if (marqueeStart && marqueeCurrent) {
      const mx = Math.min(marqueeStart.x, marqueeCurrent.x);
      const my = Math.min(marqueeStart.y, marqueeCurrent.y);
      const mw = Math.abs(marqueeCurrent.x - marqueeStart.x);
      const mh = Math.abs(marqueeCurrent.y - marqueeStart.y);

      ctx.save();
      ctx.fillStyle = 'rgba(14, 165, 233, 0.18)';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5 / zoom;
      ctx.setLineDash([5 / zoom, 5 / zoom]);
      ctx.fillRect(mx, my, mw, mh);
      ctx.strokeRect(mx, my, mw, mh);
      ctx.restore();
    }

    ctx.restore();
  }, [
    panOffset,
    zoom,
    width,
    height,
    showGrid,
    gridSize,
    elements,
    cloningElements,
    activeLayerFilter,
    selectedElementIds,
    selectedCollisionId,
    showCollisions,
    collisionBoxes,
    drawBoxStart,
    drawBoxCurrent,
    marqueeStart,
    marqueeCurrent,
    spawnPoint,
    lighting,
    syncCanvasSize
  ]);

  // Continuous animation loop for animated torch fires & ambient flicker effects
  useEffect(() => {
    let animId: number;
    let isMounted = true;

    const renderLoop = () => {
      if (!isMounted) return;
      drawCanvas();
      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);

    const handleResize = () => drawCanvas();
    window.addEventListener('resize', handleResize);

    return () => {
      isMounted = false;
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, [drawCanvas]);

  // Wheel zoom handler
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = container.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const zoomFactor = e.deltaY < 0 ? 1.12 : 0.89;
      const newZoom = Math.max(0.3, Math.min(3.0, zoom * zoomFactor));

      const worldX = (mouseX - panOffset.x) / zoom;
      const worldY = (mouseY - panOffset.y) / zoom;

      const newPanX = mouseX - worldX * newZoom;
      const newPanY = mouseY - worldY * newZoom;

      if (onZoomChange) {
        onZoomChange(newZoom);
      }
      onPanChange({ x: newPanX, y: newPanY });
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [zoom, panOffset, onPanChange, onZoomChange]);

  // Check if world coordinate is inside an element's transformed local bounds
  const isPointInElement = useCallback((worldPt: { x: number; y: number }, el: RoomElement) => {
    const cx = el.x + el.w / 2;
    const cy = el.y + el.h / 2;
    const rad = -((el.rotation || 0) * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    const dx = worldPt.x - cx;
    const dy = worldPt.y - cy;
    const localX = cos * dx - sin * dy;
    const localY = sin * dx + cos * dy;

    const halfW = (el.w * (el.scaleX || 1)) / 2;
    const halfH = (el.h * (el.scaleY || 1)) / 2;

    return Math.abs(localX) <= halfW && Math.abs(localY) <= halfH;
  }, []);

  // Update mouse hover cursor for resize handles, rotation handle, move, etc.
  const handleMouseMoveHover = (e: React.MouseEvent) => {
    if (isDragging) return;
    if (e.target !== canvasRef.current) {
      setHoverCursor('cursor-default');
      return;
    }

    if (currentTool === 'pan') {
      setHoverCursor('cursor-grab');
      return;
    }

    if (currentTool === 'draw_collision' || currentTool === 'draw_floor') {
      setHoverCursor('cursor-crosshair');
      return;
    }

    const world = screenToWorld(e.clientX, e.clientY);

    // Check handles of single selected element
    if (selectedElementIds.length === 1) {
      const selEl = elements.find(el => el.id === selectedElementIds[0]);
      if (selEl) {
        const handles = getElementHandles(selEl);
        const hitRadius = 9 / zoom;

        if (Math.hypot(world.x - handles.rot.x, world.y - handles.rot.y) <= hitRadius) {
          setHoverCursor('cursor-crosshair');
          return;
        }

        const handleEntries: [ResizeHandleType, { x: number; y: number }][] = [
          ['tl', handles.tl],
          ['tr', handles.tr],
          ['br', handles.br],
          ['bl', handles.bl],
          ['t', handles.t],
          ['r', handles.r],
          ['b', handles.b],
          ['l', handles.l]
        ];

        for (const [type, pt] of handleEntries) {
          if (Math.hypot(world.x - pt.x, world.y - pt.y) <= hitRadius) {
            if (type === 'tl' || type === 'br') setHoverCursor('cursor-nwse-resize');
            else if (type === 'tr' || type === 'bl') setHoverCursor('cursor-nesw-resize');
            else if (type === 'l' || type === 'r') setHoverCursor('cursor-ew-resize');
            else if (type === 't' || type === 'b') setHoverCursor('cursor-ns-resize');
            return;
          }
        }
      }
    }

    // Check handles of selected collision box
    if (selectedCollisionId && showCollisions) {
      const selCb = collisionBoxes.find(c => c.id === selectedCollisionId);
      if (selCb) {
        const handles = getCollisionHandles(selCb);
        const hitRadius = 9 / zoom;
        const handleEntries: [ResizeHandleType, { x: number; y: number }][] = [
          ['tl', handles.tl],
          ['tr', handles.tr],
          ['br', handles.br],
          ['bl', handles.bl],
          ['t', handles.t],
          ['r', handles.r],
          ['b', handles.b],
          ['l', handles.l]
        ];

        for (const [type, pt] of handleEntries) {
          if (Math.hypot(world.x - pt.x, world.y - pt.y) <= hitRadius) {
            if (type === 'tl' || type === 'br') setHoverCursor('cursor-nwse-resize');
            else if (type === 'tr' || type === 'bl') setHoverCursor('cursor-nesw-resize');
            else if (type === 'l' || type === 'r') setHoverCursor('cursor-ew-resize');
            else if (type === 't' || type === 'b') setHoverCursor('cursor-ns-resize');
            return;
          }
        }
      }
    }

    // Check if hovering over any collision box
    if (showCollisions) {
      for (let i = collisionBoxes.length - 1; i >= 0; i--) {
        const cb = collisionBoxes[i];
        if (cb.enabled && world.x >= cb.x && world.x <= cb.x + cb.w && world.y >= cb.y && world.y <= cb.y + cb.h) {
          setHoverCursor('cursor-move');
          return;
        }
      }
    }

    // Check if hovering over any element
    for (let i = elements.length - 1; i >= 0; i--) {
      const el = elements[i];
      if (el.visible !== false && isPointInElement(world, el)) {
        setHoverCursor('cursor-move');
        return;
      }
    }

    setHoverCursor('cursor-default');
  };

  // Mouse Down Event
  const handleMouseDown = (e: React.MouseEvent) => {
    // If click originated on floating HUD, buttons, or overlay controls, do not process as canvas click
    if (e.target !== canvasRef.current || (e.target as HTMLElement)?.closest('[data-floating-hud]')) {
      return;
    }

    const world = screenToWorld(e.clientX, e.clientY);
    const isModifierPressed = e.ctrlKey || e.metaKey;
    const isShiftPressed = e.shiftKey;

    // Pan with Middle Mouse (button === 1), Right Click (button === 2), or Pan Tool
    if (e.button === 1 || e.button === 2 || currentTool === 'pan') {
      e.preventDefault();
      e.stopPropagation();
      setDragMode('pan');
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
      return;
    }

    if (e.button !== 0) return;

    // Check if clicked near spawn point (within 22px)
    const distToSpawn = Math.hypot(world.x - spawnPoint.x, world.y - spawnPoint.y);
    if (distToSpawn < 22 / zoom) {
      setDragMode('spawn');
      setIsDragging(true);
      setDragStart({ x: world.x, y: world.y });
      return;
    }

    // If collision drawing tool is active
    if (currentTool === 'draw_collision') {
      setDragMode('draw_col');
      setIsDragging(true);
      const startX = snapValue(world.x, gridSize);
      const startY = snapValue(world.y, gridSize);
      setDrawBoxStart({ x: startX, y: startY });
      setDrawBoxCurrent({ x: startX, y: startY });
      return;
    }

    // If floor drawing tool is active
    if (currentTool === 'draw_floor') {
      setDragMode('draw_floor');
      setIsDragging(true);
      const startX = snapValue(world.x, gridSize);
      const startY = snapValue(world.y, gridSize);
      setDrawBoxStart({ x: startX, y: startY });
      setDrawBoxCurrent({ x: startX, y: startY });
      return;
    }

    // Check if clicking resize or rotation handle of single selected element
    if (selectedElementIds.length === 1) {
      const selEl = elements.find(el => el.id === selectedElementIds[0]);
      if (selEl) {
        const handles = getElementHandles(selEl);
        const hitRadius = 10 / zoom;

        // Check rotation handle
        if (Math.hypot(world.x - handles.rot.x, world.y - handles.rot.y) <= hitRadius) {
          setDragMode('rotate');
          setIsDragging(true);
          setDragStart({ x: world.x, y: world.y });
          setSingleStartPos({
            x: selEl.x,
            y: selEl.y,
            w: selEl.w,
            h: selEl.h,
            scaleX: selEl.scaleX || 1,
            scaleY: selEl.scaleY || 1,
            rotation: selEl.rotation || 0,
            cx: selEl.x + selEl.w / 2,
            cy: selEl.y + selEl.h / 2
          });
          return;
        }

        // Check 8 resize handles
        const handleEntries: [ResizeHandleType, { x: number; y: number }][] = [
          ['tl', handles.tl],
          ['tr', handles.tr],
          ['br', handles.br],
          ['bl', handles.bl],
          ['t', handles.t],
          ['r', handles.r],
          ['b', handles.b],
          ['l', handles.l]
        ];

        for (const [type, pt] of handleEntries) {
          if (Math.hypot(world.x - pt.x, world.y - pt.y) <= hitRadius) {
            setDragMode('resize');
            setActiveResizeHandle(type);
            setIsDragging(true);
            setDragStart({ x: world.x, y: world.y });
            setSingleStartPos({
              x: selEl.x,
              y: selEl.y,
              w: selEl.w,
              h: selEl.h,
              scaleX: selEl.scaleX || 1,
              scaleY: selEl.scaleY || 1,
              rotation: selEl.rotation || 0,
              cx: selEl.x + selEl.w / 2,
              cy: selEl.y + selEl.h / 2
            });
            return;
          }
        }
      }
    }

    // Check if clicking resize handle of selected collision box
    if (selectedCollisionId && showCollisions) {
      const selCb = collisionBoxes.find(c => c.id === selectedCollisionId);
      if (selCb) {
        const handles = getCollisionHandles(selCb);
        const hitRadius = 10 / zoom;
        const handleEntries: [ResizeHandleType, { x: number; y: number }][] = [
          ['tl', handles.tl],
          ['tr', handles.tr],
          ['br', handles.br],
          ['bl', handles.bl],
          ['t', handles.t],
          ['r', handles.r],
          ['b', handles.b],
          ['l', handles.l]
        ];

        for (const [type, pt] of handleEntries) {
          if (Math.hypot(world.x - pt.x, world.y - pt.y) <= hitRadius) {
            setDragMode('resize');
            setActiveResizeHandle(type);
            setIsDragging(true);
            setDragStart({ x: world.x, y: world.y });
            setSingleStartPos({
              x: selCb.x,
              y: selCb.y,
              w: selCb.w,
              h: selCb.h,
              scaleX: 1,
              scaleY: 1,
              rotation: 0,
              cx: selCb.x + selCb.w / 2,
              cy: selCb.y + selCb.h / 2
            });
            return;
          }
        }
      }
    }

    // Check hit on collision box (if collisions are shown and not clicking modifier)
    if (showCollisions && !isModifierPressed && !isShiftPressed) {
      for (let i = collisionBoxes.length - 1; i >= 0; i--) {
        const cb = collisionBoxes[i];
        if (
          world.x >= cb.x &&
          world.x <= cb.x + cb.w &&
          world.y >= cb.y &&
          world.y <= cb.y + cb.h
        ) {
          onSelectCollision(cb.id);
          onSelectElements([]);
          setDragMode('move');
          setIsDragging(true);
          setDragStart({ x: world.x, y: world.y });
          setSingleStartPos({
            x: cb.x,
            y: cb.y,
            w: cb.w,
            h: cb.h,
            scaleX: 1,
            scaleY: 1,
            rotation: 0,
            cx: cb.x + cb.w / 2,
            cy: cb.y + cb.h / 2
          });
          return;
        }
      }
    }

    // Check hit on elements using accurate rotated local coordinate space sorted by stacking priority (highest first)
    const sorted = [...elements]
      .filter(el => el.visible !== false)
      .sort((a, b) => {
        const aAbove = isElementAboveHero(a);
        const bAbove = isElementAboveHero(b);
        if (aAbove !== bAbove) return bAbove ? 1 : -1;
        return (b.zIndex || 0) - (a.zIndex || 0);
      });

    let clickedElement: RoomElement | null = null;
    for (const el of sorted) {
      if (isPointInElement(world, el)) {
        clickedElement = el;
        break;
      }
    }

    // Case 1: Clicked an element with Alt key -> Clone & Drag mode!
    if (clickedElement && e.altKey) {
      e.preventDefault();
      const targetElements = selectedElementIds.includes(clickedElement.id)
        ? elements.filter(el => selectedElementIds.includes(el.id))
        : [clickedElement];

      // Create cloned elements preview with new IDs
      const clones: RoomElement[] = targetElements.map(el => ({
        ...el,
        id: `el_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        zIndex: (el.zIndex || 0) + 1
      }));

      const startPosMap: { [id: string]: { x: number; y: number } } = {};
      clones.forEach((clone, idx) => {
        startPosMap[clone.id] = { x: targetElements[idx].x, y: targetElements[idx].y };
      });

      setCloningElements(clones);
      setElementsStartPositions(startPosMap);
      setDragMode('ctrl_clone');
      setIsDragging(true);
      setDragStart({ x: world.x, y: world.y });
      onSelectCollision(null);
      return;
    }

    // Case 2: Clicked an element with Ctrl/Cmd or Shift -> Successive multi-selection!
    if (clickedElement && (isModifierPressed || isShiftPressed)) {
      const alreadySelected = selectedElementIds.includes(clickedElement.id);
      const nextIds = alreadySelected
        ? selectedElementIds.filter(id => id !== clickedElement!.id)
        : [...selectedElementIds, clickedElement.id];

      onSelectElements(nextIds);
      onSelectCollision(null);
      return;
    }

    // Case 3: Clicked an element normally - only start dragging if already selected!
    if (clickedElement) {
      const alreadySelected = selectedElementIds.includes(clickedElement.id);
      if (!alreadySelected) {
        onSelectElements([clickedElement.id]);
        onSelectCollision(null);
        return;
      }
      onSelectCollision(null);

      // Setup multi-drag positions
      const activeIds = selectedElementIds;
      const startPosMap: { [id: string]: { x: number; y: number } } = {};
      elements
        .filter(el => activeIds.includes(el.id))
        .forEach(el => {
          startPosMap[el.id] = { x: el.x, y: el.y };
        });

      setElementsStartPositions(startPosMap);
      setDragMode('move');
      setIsDragging(true);
      setDragStart({ x: world.x, y: world.y });
      setSingleStartPos({
        x: clickedElement.x,
        y: clickedElement.y,
        w: clickedElement.w * (clickedElement.scaleX || 1),
        h: clickedElement.h * (clickedElement.scaleY || 1),
        scaleX: 1,
        scaleY: 1,
        rotation: clickedElement.rotation || 0,
        cx: clickedElement.x + clickedElement.w / 2,
        cy: clickedElement.y + clickedElement.h / 2
      });
      return;
    }

    // Case 4: Clicked on empty space -> Start Marquee Box Selection
    if (!isShiftPressed) {
      onSelectElements([]);
    }
    onSelectCollision(null);
    setDragMode('marquee');
    setIsDragging(true);
    setMarqueeStart({ x: world.x, y: world.y });
    setMarqueeCurrent({ x: world.x, y: world.y });
    setIsShiftPressedDuringMarquee(isShiftPressed);
  };

  // Global mousemove & mouseup while dragging to guarantee smooth tracking
  useEffect(() => {
    if (!isDragging) return;

    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (dragMode === 'pan') {
        const dx = e.clientX - dragStart.x;
        const dy = e.clientY - dragStart.y;
        onPanChange({
          x: panOffset.x + dx,
          y: panOffset.y + dy
        });
        setDragStart({ x: e.clientX, y: e.clientY });
        return;
      }

      const world = screenToWorld(e.clientX, e.clientY);

      if (dragMode === 'marquee') {
        setMarqueeCurrent({ x: world.x, y: world.y });
        return;
      }

      if (dragMode === 'spawn') {
        const sx = snapValue(world.x, gridSize);
        const sy = snapValue(world.y, gridSize);
        onUpdateSpawnPoint({
          x: sx,
          y: sy
        });
        return;
      }

      if (dragMode === 'draw_col') {
        const curX = snapValue(world.x, gridSize);
        const curY = snapValue(world.y, gridSize);
        setDrawBoxCurrent({ x: curX, y: curY });
        return;
      }

      if (dragMode === 'draw_floor') {
        const curX = snapValue(world.x, gridSize);
        const curY = snapValue(world.y, gridSize);
        setDrawBoxCurrent({ x: curX, y: curY });
        return;
      }

      // 1. Rotation handling
      if (dragMode === 'rotate' && selectedElementIds.length === 1 && singleStartPos) {
        const el = elements.find(item => item.id === selectedElementIds[0]);
        if (!el) return;
        const cx = singleStartPos.cx;
        const cy = singleStartPos.cy;
        const angleRad = Math.atan2(world.y - cy, world.x - cx);
        let angleDeg = Math.round((angleRad * 180) / Math.PI + 90);
        if (angleDeg < 0) angleDeg += 360;
        if (snapToGrid) {
          angleDeg = Math.round(angleDeg / 15) * 15;
        }
        onUpdateElement(el.id, { rotation: angleDeg % 360 });
        return;
      }

      // 2. Interactive Resizing in all 8 directions on canvas
      if (dragMode === 'resize' && activeResizeHandle && selectedElementIds.length === 1 && singleStartPos) {
        const el = elements.find(item => item.id === selectedElementIds[0]);
        if (!el) return;

        const { x: startX, y: startY, w: startW, h: startH } = singleStartPos;
        let newX = startX;
        let newY = startY;
        let newW = startW;
        let newH = startH;

        // X-axis adjustments
        if (activeResizeHandle.includes('r')) {
          const rawW = world.x - startX;
          newW = Math.max(8, snapToGrid ? Math.round(rawW / gridSize) * gridSize : Math.round(rawW));
          newX = startX;
        } else if (activeResizeHandle.includes('l')) {
          const rightEdge = startX + startW;
          const rawX = snapToGrid ? Math.round(world.x / gridSize) * gridSize : Math.round(world.x);
          newX = Math.min(rightEdge - 8, rawX);
          newW = rightEdge - newX;
        }

        // Y-axis adjustments
        if (activeResizeHandle.includes('b')) {
          const rawH = world.y - startY;
          newH = Math.max(8, snapToGrid ? Math.round(rawH / gridSize) * gridSize : Math.round(rawH));
          newY = startY;
        } else if (activeResizeHandle.includes('t')) {
          const bottomEdge = startY + startH;
          const rawY = snapToGrid ? Math.round(world.y / gridSize) * gridSize : Math.round(world.y);
          newY = Math.min(bottomEdge - 8, rawY);
          newH = bottomEdge - newY;
        }

        onUpdateElement(el.id, {
          x: newX,
          y: newY,
          w: newW,
          h: newH,
          scaleX: 1,
          scaleY: 1
        });
        return;
      }

      // Interactive Resizing for Selected Collision Box
      if (dragMode === 'resize' && activeResizeHandle && selectedCollisionId && singleStartPos) {
        const { x: startX, y: startY, w: startW, h: startH } = singleStartPos;
        let newX = startX;
        let newY = startY;
        let newW = startW;
        let newH = startH;

        // X-axis adjustments
        if (activeResizeHandle.includes('r')) {
          const rawW = world.x - startX;
          newW = Math.max(8, snapToGrid ? Math.round(rawW / gridSize) * gridSize : Math.round(rawW));
          newX = startX;
        } else if (activeResizeHandle.includes('l')) {
          const rightEdge = startX + startW;
          const rawX = snapToGrid ? Math.round(world.x / gridSize) * gridSize : Math.round(world.x);
          newX = Math.min(rightEdge - 8, rawX);
          newW = rightEdge - newX;
        }

        // Y-axis adjustments
        if (activeResizeHandle.includes('b')) {
          const rawH = world.y - startY;
          newH = Math.max(8, snapToGrid ? Math.round(rawH / gridSize) * gridSize : Math.round(rawH));
          newY = startY;
        } else if (activeResizeHandle.includes('t')) {
          const bottomEdge = startY + startH;
          const rawY = snapToGrid ? Math.round(world.y / gridSize) * gridSize : Math.round(world.y);
          newY = Math.min(bottomEdge - 8, rawY);
          newH = bottomEdge - newY;
        }

        onUpdateCollision(selectedCollisionId, {
          x: newX,
          y: newY,
          w: newW,
          h: newH
        });
        return;
      }

      // 3. Moving active cloned previews (Ctrl + Drag)
      if (dragMode === 'ctrl_clone' && cloningElements.length > 0) {
        const rawDx = world.x - dragStart.x;
        const rawDy = world.y - dragStart.y;
        const snapDx = snapToGrid ? Math.round(rawDx / gridSize) * gridSize : rawDx;
        const snapDy = snapToGrid ? Math.round(rawDy / gridSize) * gridSize : rawDy;

        setCloningElements(prev =>
          prev.map(clone => {
            const origin = elementsStartPositions[clone.id];
            if (!origin) return clone;
            return {
              ...clone,
              x: snapValue(origin.x + snapDx, gridSize),
              y: snapValue(origin.y + snapDy, gridSize)
            };
          })
        );
        return;
      }

      // 4. Moving selected elements (single or multiple)
      if (dragMode === 'move') {
        const rawDx = world.x - dragStart.x;
        const rawDy = world.y - dragStart.y;
        const snapDx = snapToGrid ? Math.round(rawDx / gridSize) * gridSize : rawDx;
        const snapDy = snapToGrid ? Math.round(rawDy / gridSize) * gridSize : rawDy;

        if (selectedCollisionId && singleStartPos) {
          const newX = snapValue(singleStartPos.x + snapDx, gridSize);
          const newY = snapValue(singleStartPos.y + snapDy, gridSize);
          onUpdateCollision(selectedCollisionId, { x: newX, y: newY });
          return;
        }

        if (selectedElementIds.length > 0) {
          const updates = selectedElementIds
            .map(id => {
              const startPos = elementsStartPositions[id];
              if (!startPos) return null;
              return {
                id,
                x: snapValue(startPos.x + snapDx, gridSize),
                y: snapValue(startPos.y + snapDy, gridSize)
              };
            })
            .filter((u): u is { id: string; x: number; y: number } => u !== null);

          if (updates.length > 0) {
            onUpdateMultipleElements(updates);
          }
        }
      }
    };

    const handleGlobalMouseUp = () => {
      // 1. Commit Marquee Selection
      if (dragMode === 'marquee' && marqueeStart && marqueeCurrent) {
        const minX = Math.min(marqueeStart.x, marqueeCurrent.x);
        const maxX = Math.max(marqueeStart.x, marqueeCurrent.x);
        const minY = Math.min(marqueeStart.y, marqueeCurrent.y);
        const maxY = Math.max(marqueeStart.y, marqueeCurrent.y);

        const widthDrag = maxX - minX;
        const heightDrag = maxY - minY;

        if (widthDrag > 4 || heightDrag > 4) {
          const boxedIds = elements
            .filter(el => {
              if (el.visible === false) return false;

              const elRight = el.x + el.w * (el.scaleX || 1);
              const elBottom = el.y + el.h * (el.scaleY || 1);

              return el.x < maxX && elRight > minX && el.y < maxY && elBottom > minY;
            })
            .map(el => el.id);

          if (isShiftPressedDuringMarquee) {
            const merged = Array.from(new Set([...selectedElementIds, ...boxedIds]));
            onSelectElements(merged);
          } else {
            onSelectElements(boxedIds);
          }
        }
      }

      // 2. Commit Ctrl + Drag Clone
      if (dragMode === 'ctrl_clone' && cloningElements.length > 0) {
        onAddMultipleElements(cloningElements);
        onSelectElements(cloningElements.map(e => e.id));
        setCloningElements([]);
      }

      // 3. Commit Collision Box Drawing
      if (dragMode === 'draw_col' && drawBoxStart && drawBoxCurrent) {
        const bx = Math.min(drawBoxStart.x, drawBoxCurrent.x);
        const by = Math.min(drawBoxStart.y, drawBoxCurrent.y);
        const bw = Math.abs(drawBoxCurrent.x - drawBoxStart.x);
        const bh = Math.abs(drawBoxCurrent.y - drawBoxStart.y);

        if (bw >= 8 && bh >= 8) {
          onAddCollisionBox({
            x: bx,
            y: by,
            w: bw,
            h: bh,
            type: collisionDrawType,
            enabled: true,
            label: collisionDrawType === 'door' ? 'Проход' : collisionDrawType === 'pit' ? 'Яма' : 'Стена'
          });
        }
      }

      // 4. Commit Floor Zone Drawing
      if (dragMode === 'draw_floor' && drawBoxStart && drawBoxCurrent) {
        const bx = Math.min(drawBoxStart.x, drawBoxCurrent.x);
        const by = Math.min(drawBoxStart.y, drawBoxCurrent.y);
        const bw = Math.abs(drawBoxCurrent.x - drawBoxStart.x);
        const bh = Math.abs(drawBoxCurrent.y - drawBoxStart.y);

        if (bw >= 8 && bh >= 8) {
          if (onAddFloorZone) {
            onAddFloorZone({ x: bx, y: by, w: bw, h: bh });
          }
        }
      }

      setIsDragging(false);
      setDragMode(null);
      setActiveResizeHandle(null);
      setMarqueeStart(null);
      setMarqueeCurrent(null);
      setDrawBoxStart(null);
      setDrawBoxCurrent(null);
      setSingleStartPos(null);
      setElementsStartPositions({});
    };

    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [
    isDragging,
    dragMode,
    activeResizeHandle,
    dragStart,
    singleStartPos,
    elementsStartPositions,
    cloningElements,
    drawBoxStart,
    drawBoxCurrent,
    marqueeStart,
    marqueeCurrent,
    isShiftPressedDuringMarquee,
    panOffset,
    onPanChange,
    screenToWorld,
    gridSize,
    width,
    height,
    selectedElementIds,
    selectedCollisionId,
    elements,
    onUpdateSpawnPoint,
    onUpdateElement,
    onUpdateMultipleElements,
    onAddMultipleElements,
    onSelectElements,
    onUpdateCollision,
    onAddCollisionBox,
    onAddFloorZone,
    currentTool,
    collisionDrawType,
    snapToGrid,
    snapValue,
    activeLayerFilter
  ]);

  // Drag & Drop Handlers from AssetLibrarySidebar
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    if (!isDragOver) setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    try {
      const dataStr = e.dataTransfer.getData('application/json');
      if (!dataStr) return;
      const asset: EditorAssetDefinition = JSON.parse(dataStr);
      if (!asset || !asset.id) return;

      const world = screenToWorld(e.clientX, e.clientY);
      const dropX = snapValue(world.x - (asset.defaultWidth || 64) / 2, gridSize);
      const dropY = snapValue(world.y - (asset.defaultHeight || 64) / 2, gridSize);

      onDropAsset(asset, { x: dropX, y: dropY });
    } catch (err) {
      console.error('Error handling asset drop:', err);
    }
  };

  // Mobile Touch Handlers:
  // 1. Two-finger pinch: zoom in / out and pan
  // 2. Quick tap (< 0.3s without movement): select element or collision box
  // 3. Hold 0.3s (300ms): drag / move element with grid snap

  const handleTouchStart = (e: React.TouchEvent) => {
    // If touch originated on floating HUD or other overlay controls, do not process as canvas touch
    if (e.target !== canvasRef.current || (e.target as HTMLElement)?.closest('[data-floating-hud]')) {
      isCanvasTouchRef.current = false;
      return;
    }
    isCanvasTouchRef.current = true;

    // 2 Fingers: Pinch-to-zoom & two-finger pan
    if (e.touches.length >= 2) {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
      isTouchDraggingElementRef.current = false;
      isTouchPanningRef.current = false;
      isPinchingRef.current = true;
      ignoreTouchesUntilAllReleasedRef.current = false;

      const t0 = e.touches[0];
      const t1 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
      initialPinchDistRef.current = Math.max(10, dist);
      initialPinchZoomRef.current = zoom;
      initialPinchMidRef.current = {
        x: (t0.clientX + t1.clientX) / 2,
        y: (t0.clientY + t1.clientY) / 2
      };
      initialPinchPanRef.current = { ...panOffset };
      setPinchZoomDisplay(Math.round(zoom * 100));
      return;
    }

    // If one finger was lifted during pinch and the second is still touching:
    // Ignore leftover finger to prevent scene jumping/jerking!
    if (ignoreTouchesUntilAllReleasedRef.current) {
      return;
    }

    // 1 Finger: Either Quick Tap, Long Press Drag (300ms), Handle Resize/Rotate, or Canvas Pan
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      touchStartTimeRef.current = Date.now();
      touchStartPosRef.current = { x: touch.clientX, y: touch.clientY };
      const world = screenToWorld(touch.clientX, touch.clientY);
      touchStartWorldRef.current = world;
      touchMovedRef.current = false;
      isTouchDraggingElementRef.current = false;
      isTouchPanningRef.current = false;

      // Draw tools immediately engage
      if (currentTool === 'draw_collision' || currentTool === 'draw_floor') {
        setDragMode(currentTool === 'draw_collision' ? 'draw_col' : 'draw_floor');
        setIsDragging(true);
        const startX = snapValue(world.x, gridSize);
        const startY = snapValue(world.y, gridSize);
        setDrawBoxStart({ x: startX, y: startY });
        setDrawBoxCurrent({ x: startX, y: startY });
        return;
      }

      // 1. Check elements (sorted by stacking priority descending)
      const sorted = [...elements]
        .filter(el => el.visible !== false)
        .sort((a, b) => {
          const aAbove = isElementAboveHero(a);
          const bAbove = isElementAboveHero(b);
          if (aAbove !== bAbove) return bAbove ? 1 : -1;
          return (b.zIndex || 0) - (a.zIndex || 0);
        });

      let hitEl: RoomElement | null = null;
      for (const el of sorted) {
        if (isPointInElement(world, el)) {
          hitEl = el;
          break;
        }
      }

      // Check collision box hit
      let hitCb: CollisionBox | null = null;
      if (!hitEl && showCollisions) {
        for (let i = collisionBoxes.length - 1; i >= 0; i--) {
          const cb = collisionBoxes[i];
          if (cb.enabled && world.x >= cb.x && world.x <= cb.x + cb.w && world.y >= cb.y && world.y <= cb.y + cb.h) {
            hitCb = cb;
            break;
          }
        }
      }

      // 2. Check if touching ROTATE or RESIZE handle of single selected element:
      // CRITICAL: We ONLY check corner handles (TL, TR, BR, BL) and Rotation handle!
      // And we use SCREEN distance (<= 18px) plus center distance check so that tapping
      // anywhere on the element body NEVER accidentally triggers resizing!
      if (selectedElementIds.length === 1) {
        const selEl = elements.find(el => el.id === selectedElementIds[0]);
        if (selEl) {
          const handles = getElementHandles(selEl);
          
          // Rotation handle: located above the element
          const rotScreen = worldToScreen(handles.rot.x, handles.rot.y);
          const distRot = Math.hypot(touch.clientX - rotScreen.x, touch.clientY - rotScreen.y);
          if (distRot <= 22) {
            setDragMode('rotate');
            setIsDragging(true);
            setDragStart({ x: world.x, y: world.y });
            const effW = selEl.w * (selEl.scaleX || 1);
            const effH = selEl.h * (selEl.scaleY || 1);
            setSingleStartPos({
              x: selEl.x,
              y: selEl.y,
              w: effW,
              h: effH,
              scaleX: 1,
              scaleY: 1,
              rotation: selEl.rotation || 0,
              cx: selEl.x + selEl.w / 2,
              cy: selEl.y + selEl.h / 2
            });
            setTouchFeedback(`↻ Поворот: ${selEl.rotation || 0}°`);
            return;
          }

          // 4 Corner handles ONLY (TL, TR, BR, BL) with screen distance <= 18px:
          // Must also be closer to the corner handle than to the element center,
          // so interior taps are guaranteed to move the object, not scale it!
          const centerScreen = worldToScreen(selEl.x + selEl.w / 2, selEl.y + selEl.h / 2);
          const distToCenter = Math.hypot(touch.clientX - centerScreen.x, touch.clientY - centerScreen.y);
          const cornerEntries: [ResizeHandleType, { x: number; y: number }][] = [
            ['tl', handles.tl], ['tr', handles.tr], ['br', handles.br], ['bl', handles.bl]
          ];

          for (const [type, pt] of cornerEntries) {
            const ptScreen = worldToScreen(pt.x, pt.y);
            const distHandle = Math.hypot(touch.clientX - ptScreen.x, touch.clientY - ptScreen.y);
            if (distHandle <= 18 && distHandle < distToCenter * 0.75) {
              setDragMode('resize');
              setActiveResizeHandle(type);
              setIsDragging(true);
              setDragStart({ x: world.x, y: world.y });
              const effW = selEl.w * (selEl.scaleX || 1);
              const effH = selEl.h * (selEl.scaleY || 1);
              setSingleStartPos({
                x: selEl.x,
                y: selEl.y,
                w: effW,
                h: effH,
                scaleX: 1,
                scaleY: 1,
                rotation: selEl.rotation || 0,
                cx: selEl.x + selEl.w / 2,
                cy: selEl.y + selEl.h / 2
              });
              setTouchFeedback(`⤢ Масштабирование: ${Math.round(effW)} × ${Math.round(effH)}`);
              return;
            }
          }
        }
      }

      // Check collision box corner resize handles
      if (selectedCollisionId && showCollisions) {
        const selCb = collisionBoxes.find(cb => cb.id === selectedCollisionId);
        if (selCb) {
          const handles = getCollisionHandles(selCb);
          const centerScreen = worldToScreen(selCb.x + selCb.w / 2, selCb.y + selCb.h / 2);
          const distToCenter = Math.hypot(touch.clientX - centerScreen.x, touch.clientY - centerScreen.y);
          const cornerEntries: [ResizeHandleType, { x: number; y: number }][] = [
            ['tl', handles.tl], ['tr', handles.tr], ['br', handles.br], ['bl', handles.bl]
          ];
          for (const [type, pt] of cornerEntries) {
            const ptScreen = worldToScreen(pt.x, pt.y);
            const distHandle = Math.hypot(touch.clientX - ptScreen.x, touch.clientY - ptScreen.y);
            if (distHandle <= 18 && distHandle < distToCenter * 0.75) {
              setDragMode('resize');
              setActiveResizeHandle(type);
              setIsDragging(true);
              setDragStart({ x: world.x, y: world.y });
              setSingleStartPos({
                x: selCb.x,
                y: selCb.y,
                w: selCb.w,
                h: selCb.h,
                scaleX: 1,
                scaleY: 1,
                rotation: 0,
                cx: selCb.x + selCb.w / 2,
                cy: selCb.y + selCb.h / 2
              });
              setTouchFeedback(`⤢ Изменение коллизии: ${Math.round(selCb.w)} × ${Math.round(selCb.h)}`);
              return;
            }
          }
        }
      }

      // 3. ПЕРЕМЕЩЕНИЕ ОБЪЕКТА: Активируется ТОЛЬКО если объект УЖЕ выбран!
      // Удержание 0.3 сек захватывает объект для перемещения
      if (hitEl && selectedElementIds.includes(hitEl.id)) {
        const targetElement = hitEl;
        setTouchFeedback('Удерживайте 0.3 сек для перемещения...');

        longPressTimerRef.current = setTimeout(() => {
          if (typeof navigator !== 'undefined' && navigator.vibrate) {
            try { navigator.vibrate(40); } catch (_) {}
          }
          isTouchDraggingElementRef.current = true;
          setTouchFeedback(`✋ Захвачено: ${targetElement.name || 'Объект'} (тяните палец)`);

          const activeIds = selectedElementIds;
          const startPosMap: { [id: string]: { x: number; y: number } } = {};
          elements
            .filter(el => activeIds.includes(el.id))
            .forEach(el => {
              startPosMap[el.id] = { x: el.x, y: el.y };
            });

          setElementsStartPositions(startPosMap);
          setSingleStartPos({
            x: targetElement.x,
            y: targetElement.y,
            w: targetElement.w,
            h: targetElement.h,
            scaleX: targetElement.scaleX || 1,
            scaleY: targetElement.scaleY || 1,
            rotation: targetElement.rotation || 0,
            cx: targetElement.x + targetElement.w / 2,
            cy: targetElement.y + targetElement.h / 2
          });
          setDragStart({ x: world.x, y: world.y });
          setDragMode('move');
          setIsDragging(true);
        }, 300);
        return;
      }

      // 4. ПЕРЕМЕЩЕНИЕ КОЛЛИЗИИ: Активируется ТОЛЬКО если коллизия УЖЕ выбрана!
      if (hitCb && selectedCollisionId === hitCb.id) {
        const targetCb = hitCb;
        setTouchFeedback('Удерживайте 0.3 сек для перемещения коллизии...');
        longPressTimerRef.current = setTimeout(() => {
          if (typeof navigator !== 'undefined' && navigator.vibrate) {
            try { navigator.vibrate(40); } catch (_) {}
          }
          isTouchDraggingElementRef.current = true;
          setTouchFeedback('✋ Коллизия захвачена (тяните палец)');
          setDragStart({ x: world.x, y: world.y });
          setSingleStartPos({
            x: targetCb.x,
            y: targetCb.y,
            w: targetCb.w,
            h: targetCb.h,
            scaleX: 1,
            scaleY: 1,
            rotation: 0,
            cx: targetCb.x + targetCb.w / 2,
            cy: targetCb.y + targetCb.h / 2
          });
          setDragMode('move');
          setIsDragging(true);
        }, 300);
        return;
      }

      // 5. ОБВОДКА / ВЫДЕЛЕНИЕ: Если держать 0.3 сек без выбора либо на пустом месте
      // (или на еще не выбранном объекте) -> АКТИВИРУЕТСЯ РАМКА ВЫДЕЛЕНИЯ!
      setTouchFeedback('Удерживайте 0.3 сек для рамки выделения...');
      longPressTimerRef.current = setTimeout(() => {
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          try { navigator.vibrate(35); } catch (_) {}
        }
        isTouchDraggingElementRef.current = false;
        isTouchPanningRef.current = false;
        setTouchFeedback('⬚ Рамка выделения: ведите палец по экрану');
        setDragMode('marquee');
        setIsDragging(true);
        setMarqueeStart({ x: world.x, y: world.y });
        setMarqueeCurrent({ x: world.x, y: world.y });
      }, 300);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isCanvasTouchRef.current) return;

    // 2 Fingers: Pinch zoom + Pan
    if (e.touches.length === 2 && isPinchingRef.current && containerRef.current) {
      const t0 = e.touches[0];
      const t1 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
      if (initialPinchDistRef.current > 0) {
        const ratio = dist / initialPinchDistRef.current;
        const newZoom = Math.max(0.3, Math.min(3.0, initialPinchZoomRef.current * ratio));
        setPinchZoomDisplay(Math.round(newZoom * 100));

        const rect = containerRef.current.getBoundingClientRect();
        const curMidX = (t0.clientX + t1.clientX) / 2 - rect.left;
        const curMidY = (t0.clientY + t1.clientY) / 2 - rect.top;

        const worldX = (initialPinchMidRef.current.x - rect.left - initialPinchPanRef.current.x) / initialPinchZoomRef.current;
        const worldY = (initialPinchMidRef.current.y - rect.top - initialPinchPanRef.current.y) / initialPinchZoomRef.current;

        const newPanX = curMidX - worldX * newZoom;
        const newPanY = curMidY - worldY * newZoom;

        if (onZoomChange) onZoomChange(newZoom);
        onPanChange({ x: newPanX, y: newPanY });
      }
      return;
    }

    // If currently ignoring leftover touch after a 2-finger gesture ended:
    if (ignoreTouchesUntilAllReleasedRef.current) {
      return;
    }

    // 1 Finger
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      const dx = touch.clientX - touchStartPosRef.current.x;
      const dy = touch.clientY - touchStartPosRef.current.y;
      const distMoved = Math.hypot(dx, dy);

      // If moved > 10px before 300ms long press triggered:
      if (distMoved > 10) {
        touchMovedRef.current = true;
        if (longPressTimerRef.current) {
          clearTimeout(longPressTimerRef.current);
          longPressTimerRef.current = null;
          setTouchFeedback(null);
        }

        // If not in active action mode, user is panning the canvas!
        if (
          !isTouchDraggingElementRef.current &&
          dragMode !== 'draw_col' &&
          dragMode !== 'draw_floor' &&
          dragMode !== 'resize' &&
          dragMode !== 'rotate' &&
          dragMode !== 'marquee'
        ) {
          isTouchPanningRef.current = true;
        }
      }

      // 1. Smooth 1-finger canvas panning:
      if (isTouchPanningRef.current) {
        onPanChange({
          x: panOffset.x + (touch.clientX - touchStartPosRef.current.x),
          y: panOffset.y + (touch.clientY - touchStartPosRef.current.y)
        });
        touchStartPosRef.current = { x: touch.clientX, y: touch.clientY };
        return;
      }

      // 2. Active Marquee Box Selection on touch
      if (dragMode === 'marquee' && marqueeStart) {
        const curWorld = screenToWorld(touch.clientX, touch.clientY);
        setMarqueeCurrent({ x: curWorld.x, y: curWorld.y });
        const minX = Math.min(marqueeStart.x, curWorld.x);
        const maxX = Math.max(marqueeStart.x, curWorld.x);
        const minY = Math.min(marqueeStart.y, curWorld.y);
        const maxY = Math.max(marqueeStart.y, curWorld.y);
        const count = elements.filter(el => {
          if (el.visible === false) return false;
          const effW = el.w * (el.scaleX || 1);
          const effH = el.h * (el.scaleY || 1);
          return el.x < maxX && el.x + effW > minX && el.y < maxY && el.y + effH > minY;
        }).length;
        setTouchFeedback(`⬚ В рамке: ${count} элементов`);
        return;
      }

      // 3. Interactive Resizing on Touch for selected element
      if (dragMode === 'resize' && activeResizeHandle && selectedElementIds.length === 1 && singleStartPos) {
        const el = elements.find(item => item.id === selectedElementIds[0]);
        if (el) {
          const world = screenToWorld(touch.clientX, touch.clientY);
          const { x: startX, y: startY, w: startW, h: startH } = singleStartPos;
          let newX = startX;
          let newY = startY;
          let newW = startW;
          let newH = startH;

          // X-axis adjustments
          if (activeResizeHandle.includes('r')) {
            const rawW = world.x - startX;
            newW = Math.max(8, snapToGrid ? Math.round(rawW / gridSize) * gridSize : Math.round(rawW));
            newX = startX;
          } else if (activeResizeHandle.includes('l')) {
            const rightEdge = startX + startW;
            const rawX = snapToGrid ? Math.round(world.x / gridSize) * gridSize : Math.round(world.x);
            newX = Math.min(rightEdge - 8, rawX);
            newW = rightEdge - newX;
          }

          // Y-axis adjustments
          if (activeResizeHandle.includes('b')) {
            const rawH = world.y - startY;
            newH = Math.max(8, snapToGrid ? Math.round(rawH / gridSize) * gridSize : Math.round(rawH));
            newY = startY;
          } else if (activeResizeHandle.includes('t')) {
            const bottomEdge = startY + startH;
            const rawY = snapToGrid ? Math.round(world.y / gridSize) * gridSize : Math.round(world.y);
            newY = Math.min(bottomEdge - 8, rawY);
            newH = bottomEdge - newY;
          }

          onUpdateElement(el.id, {
            x: newX,
            y: newY,
            w: newW,
            h: newH,
            scaleX: 1,
            scaleY: 1
          });
          setTouchFeedback(`Размер: ${Math.round(newW)} × ${Math.round(newH)}`);
          return;
        }
      }

      // Interactive Resizing on Touch for selected collision box
      if (dragMode === 'resize' && activeResizeHandle && selectedCollisionId && singleStartPos) {
        const world = screenToWorld(touch.clientX, touch.clientY);
        const { x: startX, y: startY, w: startW, h: startH } = singleStartPos;
        let newX = startX;
        let newY = startY;
        let newW = startW;
        let newH = startH;

        if (activeResizeHandle.includes('r')) {
          const rawW = world.x - startX;
          newW = Math.max(8, snapToGrid ? Math.round(rawW / gridSize) * gridSize : Math.round(rawW));
          newX = startX;
        } else if (activeResizeHandle.includes('l')) {
          const rightEdge = startX + startW;
          const rawX = snapToGrid ? Math.round(world.x / gridSize) * gridSize : Math.round(world.x);
          newX = Math.min(rightEdge - 8, rawX);
          newW = rightEdge - newX;
        }

        if (activeResizeHandle.includes('b')) {
          const rawH = world.y - startY;
          newH = Math.max(8, snapToGrid ? Math.round(rawH / gridSize) * gridSize : Math.round(rawH));
          newY = startY;
        } else if (activeResizeHandle.includes('t')) {
          const bottomEdge = startY + startH;
          const rawY = snapToGrid ? Math.round(world.y / gridSize) * gridSize : Math.round(world.y);
          newY = Math.min(bottomEdge - 8, rawY);
          newH = bottomEdge - newY;
        }

        onUpdateCollision(selectedCollisionId, {
          x: newX,
          y: newY,
          w: newW,
          h: newH
        });
        setTouchFeedback(`Коллизия: ${Math.round(newW)} × ${Math.round(newH)}`);
        return;
      }

      // 4. Interactive Rotation on Touch
      if (dragMode === 'rotate' && selectedElementIds.length === 1 && singleStartPos) {
        const el = elements.find(item => item.id === selectedElementIds[0]);
        if (el) {
          const world = screenToWorld(touch.clientX, touch.clientY);
          const cx = singleStartPos.cx;
          const cy = singleStartPos.cy;
          const angleRad = Math.atan2(world.y - cy, world.x - cx);
          let angleDeg = Math.round((angleRad * 180) / Math.PI + 90);
          if (angleDeg < 0) angleDeg += 360;
          if (snapToGrid) {
            angleDeg = Math.round(angleDeg / 15) * 15;
          }
          onUpdateElement(el.id, { rotation: angleDeg % 360 });
          setTouchFeedback(`Поворот: ${angleDeg}°`);
          return;
        }
      }

      // 5. Drawing collision or floor boxes on touch:
      if (dragMode === 'draw_col' || dragMode === 'draw_floor') {
        const curWorld = screenToWorld(touch.clientX, touch.clientY);
        const curX = snapValue(curWorld.x, gridSize);
        const curY = snapValue(curWorld.y, gridSize);
        setDrawBoxCurrent({ x: curX, y: curY });
        return;
      }

      // 6. Dragging element(s) with grid snapping after 0.3s hold:
      if (isTouchDraggingElementRef.current && dragMode === 'move') {
        const world = screenToWorld(touch.clientX, touch.clientY);
        const rawDx = world.x - dragStart.x;
        const rawDy = world.y - dragStart.y;
        const snapDx = snapToGrid ? Math.round(rawDx / gridSize) * gridSize : rawDx;
        const snapDy = snapToGrid ? Math.round(rawDy / gridSize) * gridSize : rawDy;

        if (selectedCollisionId && singleStartPos) {
          const newX = snapValue(singleStartPos.x + snapDx, gridSize);
          const newY = snapValue(singleStartPos.y + snapDy, gridSize);
          onUpdateCollision(selectedCollisionId, { x: newX, y: newY });
          setTouchFeedback(`Коллизия: ${newX}, ${newY}`);
          return;
        }

        if (selectedElementIds.length > 0) {
          const updates = selectedElementIds
            .map(id => {
              const startPos = elementsStartPositions[id];
              if (!startPos) return null;
              return {
                id,
                x: snapValue(startPos.x + snapDx, gridSize),
                y: snapValue(startPos.y + snapDy, gridSize)
              };
            })
            .filter((u): u is { id: string; x: number; y: number } => u !== null);

          if (updates.length > 0) {
            onUpdateMultipleElements(updates);
            if (updates.length === 1) {
              setTouchFeedback(`X: ${updates[0].x}  Y: ${updates[0].y}`);
            } else {
              setTouchFeedback(`Перемещение ${updates.length} элементов`);
            }
          }
        }
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    // Clear long press timer if still running
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }

    // If touch did not originate on the canvas (e.g. was on floating HUD or other overlay), ignore!
    if (!isCanvasTouchRef.current) {
      if (e.touches.length === 0) {
        isCanvasTouchRef.current = false;
      }
      return;
    }

    if (e.touches.length === 0) {
      isCanvasTouchRef.current = false;
    }

    // End Pinch: If pinch was active, prevent any trailing finger from causing a pan/move jerk
    if (isPinchingRef.current) {
      isPinchingRef.current = false;
      ignoreTouchesUntilAllReleasedRef.current = true;
      isTouchPanningRef.current = false;
      isTouchDraggingElementRef.current = false;
      setIsDragging(false);
      setDragMode(null);
      setTimeout(() => setPinchZoomDisplay(null), 600);
      if (e.touches.length === 0) {
        ignoreTouchesUntilAllReleasedRef.current = false;
      }
      return;
    }

    // When all fingers leave the screen, reset ignore flag
    if (e.touches.length === 0) {
      ignoreTouchesUntilAllReleasedRef.current = false;
    }

    if (ignoreTouchesUntilAllReleasedRef.current) {
      return;
    }

    // End Marquee Box Selection on Touch
    if (dragMode === 'marquee' && marqueeStart && marqueeCurrent) {
      const minX = Math.min(marqueeStart.x, marqueeCurrent.x);
      const maxX = Math.max(marqueeStart.x, marqueeCurrent.x);
      const minY = Math.min(marqueeStart.y, marqueeCurrent.y);
      const maxY = Math.max(marqueeStart.y, marqueeCurrent.y);

      if (maxX - minX > 6 || maxY - minY > 6) {
        const boxedIds = elements
          .filter(el => {
            if (el.visible === false) return false;
            const effW = el.w * (el.scaleX || 1);
            const effH = el.h * (el.scaleY || 1);
            return el.x < maxX && el.x + effW > minX && el.y < maxY && el.y + effH > minY;
          })
          .map(el => el.id);

        onSelectElements(boxedIds);
        onSelectCollision(null);
        setTouchFeedback(boxedIds.length > 0 ? `✓ Выделено: ${boxedIds.length} объектов` : 'Ничего не выделено');
      }
      setMarqueeStart(null);
      setMarqueeCurrent(null);
      setIsDragging(false);
      setDragMode(null);
      setTimeout(() => setTouchFeedback(null), 1200);
      return;
    }

    // End Resize or Rotate on Touch
    if (dragMode === 'resize' || dragMode === 'rotate') {
      setIsDragging(false);
      setDragMode(null);
      setActiveResizeHandle(null);
      setTouchFeedback('✓ Готово');
      setTimeout(() => setTouchFeedback(null), 800);
      return;
    }

    // End Touch Dragging Element
    if (isTouchDraggingElementRef.current) {
      isTouchDraggingElementRef.current = false;
      setIsDragging(false);
      setDragMode(null);
      setTouchFeedback('✓ Перемещение завершено');
      setTimeout(() => setTouchFeedback(null), 1000);
      return;
    }

    // End Touch Panning
    if (isTouchPanningRef.current) {
      isTouchPanningRef.current = false;
      return;
    }

    // End Collision / Floor Box Drawing
    if ((dragMode === 'draw_col' || dragMode === 'draw_floor') && drawBoxStart && drawBoxCurrent) {
      const bx = Math.min(drawBoxStart.x, drawBoxCurrent.x);
      const by = Math.min(drawBoxStart.y, drawBoxCurrent.y);
      const bw = Math.abs(drawBoxCurrent.x - drawBoxStart.x);
      const bh = Math.abs(drawBoxCurrent.y - drawBoxStart.y);

      if (bw >= 8 && bh >= 8) {
        if (dragMode === 'draw_col') {
          onAddCollisionBox({
            x: bx,
            y: by,
            w: bw,
            h: bh,
            type: collisionDrawType,
            enabled: true,
            label: collisionDrawType === 'door' ? 'Проход' : collisionDrawType === 'pit' ? 'Яма' : 'Стена'
          });
        } else if (dragMode === 'draw_floor' && onAddFloorZone) {
          onAddFloorZone({ x: bx, y: by, w: bw, h: bh });
        }
      }
      setIsDragging(false);
      setDragMode(null);
      setDrawBoxStart(null);
      setDrawBoxCurrent(null);
      return;
    }

    // "РЕЗКИЙ ТАП" (QUICK TAP): Tap lasted < 300ms without dragging!
    const tapDuration = Date.now() - touchStartTimeRef.current;
    if (tapDuration < 300 && !touchMovedRef.current) {
      const world = touchStartWorldRef.current;

      // Check elements (sorted by stacking priority descending)
      const sorted = [...elements]
        .filter(el => el.visible !== false)
        .sort((a, b) => {
          const aAbove = isElementAboveHero(a);
          const bAbove = isElementAboveHero(b);
          if (aAbove !== bAbove) return bAbove ? 1 : -1;
          return (b.zIndex || 0) - (a.zIndex || 0);
        });

      let hitEl: RoomElement | null = null;
      for (const el of sorted) {
        if (isPointInElement(world, el)) {
          hitEl = el;
          break;
        }
      }

      if (hitEl) {
        onSelectElements([hitEl.id]);
        onSelectCollision(null);
        setTouchFeedback(`Выбран: ${hitEl.name || 'Объект'}`);
        setTimeout(() => setTouchFeedback(null), 1000);
        return;
      }

      // Check collision boxes
      if (showCollisions) {
        let hitCb: CollisionBox | null = null;
        for (let i = collisionBoxes.length - 1; i >= 0; i--) {
          const cb = collisionBoxes[i];
          if (cb.enabled && world.x >= cb.x && world.x <= cb.x + cb.w && world.y >= cb.y && world.y <= cb.y + cb.h) {
            hitCb = cb;
            break;
          }
        }
        if (hitCb) {
          onSelectCollision(hitCb.id);
          onSelectElements([]);
          setTouchFeedback('Выбрана коллизия');
          setTimeout(() => setTouchFeedback(null), 1000);
          return;
        }
      }

      // Empty space tapped -> Deselect
      onSelectElements([]);
      onSelectCollision(null);
      setTouchFeedback(null);
    }
  };

  const handleTouchCancel = () => {
    isCanvasTouchRef.current = false;
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    isPinchingRef.current = false;
    ignoreTouchesUntilAllReleasedRef.current = false;
    isTouchDraggingElementRef.current = false;
    isTouchPanningRef.current = false;
    setIsDragging(false);
    setDragMode(null);
    setTouchFeedback(null);
    setPinchZoomDisplay(null);
  };

  return (
    <div
      ref={containerRef}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onMouseMove={handleMouseMoveHover}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchCancel}
      style={{ touchAction: 'none' }}
      className={`relative w-full h-full overflow-hidden bg-slate-950 flex items-center justify-center select-none ${
        dragMode === 'pan' || currentTool === 'pan' 
          ? 'cursor-grabbing' 
          : dragMode === 'ctrl_clone' 
          ? 'cursor-copy' 
          : hoverCursor
      } ${isDragOver ? 'ring-2 ring-sky-500 ring-inset' : ''}`}
      onMouseDown={handleMouseDown}
      onContextMenu={e => e.preventDefault()}
    >
      <canvas
        ref={canvasRef}
        className="block"
      />

      {/* Floating Info Overlay for Drag & Drop / Ctrl-Clone Guide */}
      {isDragOver && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-sky-600/90 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-2xl backdrop-blur border border-sky-400 pointer-events-none animate-pulse flex items-center gap-2">
          <span>Отпустите чтобы поставить блок на холст</span>
        </div>
      )}

      {dragMode === 'ctrl_clone' && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-emerald-600/90 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-2xl backdrop-blur border border-emerald-400 pointer-events-none animate-bounce flex items-center gap-2">
          <span>Копирование (Ctrl): Перетащите и отпустите мышь для установки</span>
        </div>
      )}

      {/* Touch Pinch Zoom Badge */}
      {pinchZoomDisplay !== null && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-sky-950/95 text-sky-300 font-bold text-xs px-4 py-2 rounded-xl shadow-2xl backdrop-blur border border-sky-500/60 pointer-events-none flex items-center gap-2 z-40 animate-pulse">
          <span>🔍 Масштаб: {pinchZoomDisplay}%</span>
        </div>
      )}

      {/* Mobile Touch Feedback Pill */}
      {touchFeedback && pinchZoomDisplay === null && (
        <div className={`absolute ${selectedElementIds.length === 1 ? 'bottom-28 sm:bottom-20' : 'bottom-4'} left-1/2 -translate-x-1/2 bg-slate-900/95 text-sky-300 font-medium text-xs px-4 py-2 rounded-xl shadow-2xl backdrop-blur border border-sky-500/50 pointer-events-none flex items-center gap-2 z-40`}>
          <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping shrink-0" />
          <span>{touchFeedback}</span>
        </div>
      )}

      {/* On-Field Quick Scale & Transform Floating HUD for Selected Element */}
      {selectedElementIds.length === 1 && !isDragging && (() => {
        const selEl = elements.find(el => el.id === selectedElementIds[0]);
        if (!selEl) return null;
        const curScale = Math.round((selEl.scaleX || 1) * 100);

        const adjustScale = (delta: number) => {
          const next = Math.max(0.1, Math.min(5, Math.round(((selEl.scaleX || 1) + delta) * 100) / 100));
          onUpdateElement(selEl.id, { scaleX: next, scaleY: next });
        };

        const setExactScale = (s: number) => {
          onUpdateElement(selEl.id, { scaleX: s, scaleY: s });
        };

        return (
          <div
            data-floating-hud="true"
            onMouseDown={e => e.stopPropagation()}
            onMouseUp={e => e.stopPropagation()}
            onTouchStart={e => e.stopPropagation()}
            onTouchMove={e => e.stopPropagation()}
            onTouchEnd={e => e.stopPropagation()}
            onClick={e => e.stopPropagation()}
            onPointerDown={e => e.stopPropagation()}
            onPointerUp={e => e.stopPropagation()}
            className="absolute bottom-16 sm:bottom-6 left-1/2 -translate-x-1/2 bg-slate-900/95 backdrop-blur-md border border-sky-500/50 rounded-2xl shadow-2xl shadow-black/90 px-3 py-1.5 flex items-center gap-2 z-40 max-w-[95vw] overflow-x-auto scrollbar-thin pointer-events-auto select-none [touch-action:pan-x]"
          >
            <div className="flex items-center gap-1.5 shrink-0 border-r border-slate-700/80 pr-2">
              <span className="text-[11px] font-bold text-sky-300 truncate max-w-[85px] sm:max-w-[130px]">
                {selEl.name || 'Объект'}
              </span>
            </div>

            {/* Scale +/- Controls */}
            <div className="flex items-center gap-1 shrink-0">
              <span className="text-[10px] text-slate-400 font-bold uppercase mr-0.5">Масштаб:</span>
              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  adjustScale(-0.1);
                }}
                className="w-8 h-8 sm:w-7 sm:h-7 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-sky-600 text-white font-bold flex items-center justify-center text-sm border border-slate-700 transition-colors cursor-pointer select-none active:scale-95"
                title="Уменьшить масштаб на 10%"
              >
                −
              </button>

              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  setExactScale(1.0);
                }}
                className="px-2 h-8 sm:h-7 rounded-lg bg-sky-950/80 text-sky-300 font-mono font-bold text-xs border border-sky-500/40 hover:bg-sky-900/60 transition-colors flex items-center cursor-pointer select-none active:scale-95"
                title="Сбросить масштаб на 100%"
              >
                {curScale}%
              </button>

              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  adjustScale(0.1);
                }}
                className="w-8 h-8 sm:w-7 sm:h-7 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-sky-600 text-white font-bold flex items-center justify-center text-sm border border-slate-700 transition-colors cursor-pointer select-none active:scale-95"
                title="Увеличить масштаб на 10%"
              >
                +
              </button>
            </div>

            {/* Quick scale presets */}
            <div className="hidden sm:flex items-center gap-1 shrink-0 border-l border-slate-700/80 pl-2">
              {[0.5, 1.0, 1.5, 2.0].map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    setExactScale(s);
                  }}
                  className={`px-1.5 h-6 rounded text-[10px] font-bold border transition-colors cursor-pointer select-none active:scale-95 ${
                    Math.abs((selEl.scaleX || 1) - s) < 0.05
                      ? 'bg-sky-500/30 text-sky-300 border-sky-400'
                      : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>

            {/* Rotate & Flip */}
            <div className="flex items-center gap-1 shrink-0 border-l border-slate-700/80 pl-2">
              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  onUpdateElement(selEl.id, { rotation: ((selEl.rotation || 0) + 90) % 360 });
                }}
                className="px-2 h-8 sm:h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors flex items-center gap-1 cursor-pointer select-none active:scale-95"
                title="Повернуть на 90°"
              >
                ↻ 90°
              </button>
              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  onUpdateElement(selEl.id, { flipX: !selEl.flipX });
                }}
                className={`w-8 h-8 sm:w-7 sm:h-7 rounded-lg text-xs font-bold border transition-colors flex items-center justify-center cursor-pointer select-none active:scale-95 ${
                  selEl.flipX ? 'bg-sky-600/40 text-sky-300 border-sky-400' : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
                title="Отразить по горизонтали"
              >
                ⇄
              </button>
            </div>

            {/* Duplicate & Delete */}
            {(onDuplicateElement || onDeleteElement) && (
              <div className="flex items-center gap-1 shrink-0 border-l border-slate-700/80 pl-2">
                {onDuplicateElement && (
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onDuplicateElement(selEl.id);
                    }}
                    className="px-2 h-8 sm:h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors cursor-pointer select-none active:scale-95"
                    title="Дублировать объект"
                  >
                    Копия
                  </button>
                )}
                {onDeleteElement && (
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onDeleteElement(selEl.id);
                    }}
                    className="w-8 h-8 sm:w-7 sm:h-7 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-bold border border-rose-800/60 transition-colors flex items-center justify-center cursor-pointer select-none active:scale-95"
                    title="Удалить объект"
                  >
                    ✕
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
};
