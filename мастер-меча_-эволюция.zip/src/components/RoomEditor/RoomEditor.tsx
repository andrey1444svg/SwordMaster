import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { CustomRoomData, RoomElement, CollisionBox, LayerType, CollisionType, RoomType, ROOM_TYPE_CONFIGS } from '../../types/roomEditor';
import { roomStorage } from '../../utils/roomStorage';
import { DEFAULT_ROOMS } from '../../rooms/defaultRooms';
import { EditorAssetDefinition, EDITOR_ASSETS } from '../../utils/wallAssets';
import { isTorchElement } from '../../utils/torchEffects';
import { useScrollClickBlocker } from '../../utils/useScrollClickBlocker';
import { RoomEditorCanvas } from './RoomEditorCanvas';
import { AssetLibrarySidebar } from './AssetLibrarySidebar';
import { ElementPropertiesPanel } from './ElementPropertiesPanel';
import { CollisionToolsPanel } from './CollisionToolsPanel';
import { PlaytestModal } from './PlaytestModal';
import { SaveRoomModal } from './SaveRoomModal';
import { RoomLibraryModal } from './RoomLibraryModal';
import { 
  ArrowLeft, 
  Save, 
  Play, 
  Folder, 
  Sliders, 
  Shield, 
  Layers, 
  ZoomIn, 
  ZoomOut, 
  Maximize, 
  RotateCcw, 
  Grid, 
  Eye, 
  EyeOff,
  Undo,
  Redo,
  Sparkles,
  HelpCircle,
  Compass,
  GitCommit,
  Crown,
  Sun,
  Moon,
  LayoutGrid,
  ChevronLeft,
  ChevronRight,
  X,
  Smartphone
} from 'lucide-react';

interface RoomEditorProps {
  onExit: () => void;
  onPlaytestDungeon?: (room: CustomRoomData) => void;
}

const createBlankRoom = (): CustomRoomData => ({
  id: `room_${Date.now()}_blank`,
  name: 'Новая комната',
  roomType: 'normal',
  width: 1200,
  height: 900,
  gridSize: 32,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  elements: [],
  collisionBoxes: [],
  floorZones: [],
  spawnPoint: { x: 400, y: 300 },
  theme: 'dungeon',
  isBossRoom: false
});

export const normalizeRoomBounds = (room: CustomRoomData): CustomRoomData => {
  if (room.floorZones && room.floorZones.length > 0) {
    const minZoneX = Math.min(...room.floorZones.map(z => z.x));
    const minZoneY = Math.min(...room.floorZones.map(z => z.y));
    const maxZoneX = Math.max(...room.floorZones.map(z => z.x + z.w));
    const maxZoneY = Math.max(...room.floorZones.map(z => z.y + z.h));
    const fzW = Math.max(320, maxZoneX - minZoneX);
    const fzH = Math.max(240, maxZoneY - minZoneY);
    if (room.width !== fzW || room.height !== fzH) {
      return { ...room, width: fzW, height: fzH };
    }
  }
  return room;
};

export const RoomEditor: React.FC<RoomEditorProps> = ({ onExit, onPlaytestDungeon }) => {
  // Load saved rooms or defaults
  const [allRooms, setAllRooms] = useState<CustomRoomData[]>(() => roomStorage.getAllRooms().map(normalizeRoomBounds));
  const [currentRoom, setCurrentRoom] = useState<CustomRoomData>(() => {
    const initialRooms = roomStorage.getAllRooms();
    const start = initialRooms.find(r => r.roomType === 'start') || initialRooms[0];
    return start ? normalizeRoomBounds(start) : normalizeRoomBounds(createBlankRoom());
  });

  // Undo / Redo history
  const [history, setHistory] = useState<CustomRoomData[]>([currentRoom]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Editor states
  const [selectedElementIds, setSelectedElementIds] = useState<string[]>([]);
  const [selectedCollisionId, setSelectedCollisionId] = useState<string | null>(null);
  const [selectedFloorZoneId, setSelectedFloorZoneId] = useState<string | null>(null);
  const [rightPanelTab, setRightPanelTab] = useState<'properties' | 'collisions'>('properties');
  const [activeLayerFilter, setActiveLayerFilter] = useState<LayerType | 'all'>('all');
  const [currentTool, setCurrentTool] = useState<'select' | 'draw_collision' | 'pan'>('select');
  const [collisionDrawType, setCollisionDrawType] = useState<CollisionType>('wall');
  const [showCollisions, setShowCollisions] = useState<boolean>(true);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [snapToGrid, setSnapToGrid] = useState<boolean>(true);
  const [gridSize, setGridSize] = useState<number>(32);
  const [isLightingMenuOpen, setIsLightingMenuOpen] = useState<boolean>(false);

  // Viewport zoom & pan
  const [zoom, setZoom] = useState<number>(1.0);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 60, y: 40 });

  // Modals
  const [isPlaytesting, setIsPlaytesting] = useState<boolean>(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState<boolean>(false);
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState<boolean>(false);

  // Mobile & Scalable Panels state
  const [isMobile, setIsMobile] = useState<boolean>(() => typeof window !== 'undefined' && window.innerWidth < 768);
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState<boolean>(() => typeof window !== 'undefined' ? window.innerWidth >= 1024 : true);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState<boolean>(() => typeof window !== 'undefined' ? window.innerWidth >= 1024 : true);
  const [leftPanelWidth, setLeftPanelWidth] = useState<number>(() => typeof window !== 'undefined' && window.innerWidth < 640 ? 250 : 280);
  const [rightPanelWidth, setRightPanelWidth] = useState<number>(() => typeof window !== 'undefined' && window.innerWidth < 640 ? 270 : 300);
  const [panelScale, setPanelScale] = useState<number>(1.0);

  const isResizingLeftRef = React.useRef(false);
  const isResizingRightRef = React.useRef(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Drag-resize left panel
  const startResizingLeft = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    isResizingLeftRef.current = true;
    const handleMove = (ev: MouseEvent | TouchEvent) => {
      if (!isResizingLeftRef.current) return;
      const clientX = 'touches' in ev ? ev.touches[0].clientX : ev.clientX;
      const clamped = Math.max(160, Math.min(window.innerWidth - 60, clientX));
      setLeftPanelWidth(clamped);
    };
    const handleUp = () => {
      isResizingLeftRef.current = false;
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleUp);
    };
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    window.addEventListener('touchmove', handleMove);
    window.addEventListener('touchend', handleUp);
  };

  // Drag-resize right panel
  const startResizingRight = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    isResizingRightRef.current = true;
    const handleMove = (ev: MouseEvent | TouchEvent) => {
      if (!isResizingRightRef.current) return;
      const clientX = 'touches' in ev ? ev.touches[0].clientX : ev.clientX;
      const clamped = Math.max(160, Math.min(window.innerWidth - 60, window.innerWidth - clientX));
      setRightPanelWidth(clamped);
    };
    const handleUp = () => {
      isResizingRightRef.current = false;
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleUp);
    };
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    window.addEventListener('touchmove', handleMove);
    window.addEventListener('touchend', handleUp);
  };

  // Push state to history
  const pushHistory = useCallback((nextRoom: CustomRoomData) => {
    setHistory(prev => {
      const nextHistory = prev.slice(0, historyIndex + 1);
      return [...nextHistory, nextRoom];
    });
    setHistoryIndex(prev => prev + 1);
    setCurrentRoom(nextRoom);
  }, [historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
      setCurrentRoom(history[historyIndex - 1]);
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
      setCurrentRoom(history[historyIndex + 1]);
    }
  }, [history, historyIndex]);

  // Selected elements lookup
  const selectedElements = useMemo(() => {
    return currentRoom.elements.filter(el => selectedElementIds.includes(el.id));
  }, [currentRoom.elements, selectedElementIds]);

  // Delete elements
  const handleDeleteElement = useCallback((id: string) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: currentRoom.elements.filter(el => el.id !== id)
    };
    pushHistory(nextRoom);
    setSelectedElementIds(prev => prev.filter(item => item !== id));
  }, [currentRoom, pushHistory]);

  const handleDeleteMultipleElements = useCallback((ids: string[]) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: currentRoom.elements.filter(el => !ids.includes(el.id))
    };
    pushHistory(nextRoom);
    setSelectedElementIds([]);
  }, [currentRoom, pushHistory]);

  // Delete collision box
  const handleDeleteCollision = useCallback((id: string) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      collisionBoxes: currentRoom.collisionBoxes.filter(cb => cb.id !== id)
    };
    pushHistory(nextRoom);
    if (selectedCollisionId === id) {
      setSelectedCollisionId(null);
    }
  }, [currentRoom, pushHistory, selectedCollisionId]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyY') {
        e.preventDefault();
        handleRedo();
      } else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyS') {
        e.preventDefault();
        setIsSaveModalOpen(true);
      } else if (e.code === 'Delete' || e.code === 'Backspace') {
        if (selectedElementIds.length > 0) {
          e.preventDefault();
          handleDeleteMultipleElements(selectedElementIds);
        } else if (selectedCollisionId) {
          e.preventDefault();
          handleDeleteCollision(selectedCollisionId);
        }
      } else if (e.code === 'Escape') {
        setSelectedElementIds([]);
        setSelectedCollisionId(null);
        setCurrentTool('select');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, selectedElementIds, selectedCollisionId, handleDeleteMultipleElements, handleDeleteCollision]);

  // Add asset from sidebar to room (by click)
  const handleAddAssetToRoom = (asset: EditorAssetDefinition) => {
    const isTorch = isTorchElement(asset.id, asset.name);
    const isShadow = !!(asset.lightingDefaults?.isShadowSource || asset.id.startsWith('shadow_') || asset.name.toLowerCase().includes('тень'));
    const newId = `el_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const baseX = currentRoom.spawnPoint?.x ?? 400;
    const baseY = currentRoom.spawnPoint?.y ?? 300;
    const newElement: RoomElement = {
      id: newId,
      assetId: asset.id,
      name: asset.name,
      src: asset.src,
      x: Math.round((baseX - asset.defaultWidth / 2) / gridSize) * gridSize,
      y: Math.round((baseY - asset.defaultHeight / 2) / gridSize) * gridSize,
      w: asset.defaultWidth,
      h: asset.defaultHeight,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      layer: asset.defaultLayer,
      zIndex: isShadow ? 10 : ((asset.defaultLayer === 'front_wall' || asset.defaultLayer === 'foreground') ? 20 : (asset.defaultLayer === 'floor_bg' ? 1 : 10)),
      renderAboveHero: isShadow ? false : (asset.defaultLayer === 'front_wall' || asset.defaultLayer === 'foreground'),
      opacity: isShadow ? (asset.lightingDefaults?.shadowDensity ?? 0.8) : 1,
      flipX: false,
      flipY: false,
      hasFireEffect: isTorch,
      hasLight: asset.lightingDefaults?.hasLight ?? (isTorch ? true : undefined),
      lightRadius: asset.lightingDefaults?.lightRadius || (isTorch ? 210 : undefined),
      lightColor: asset.lightingDefaults?.lightColor || (isTorch ? '#ff9d3b' : undefined),
      lightIntensity: asset.lightingDefaults?.lightIntensity || 1.0,
      lightFlicker: asset.lightingDefaults?.lightFlicker ?? isTorch,
      isShadowSource: isShadow,
      shadowDensity: asset.lightingDefaults?.shadowDensity ?? (isShadow ? 0.8 : undefined),
      shadowShape: asset.lightingDefaults?.shadowShape || (asset.id.includes('square') || asset.id.includes('rect') ? 'square' : 'oval'),
      shadowCorners: asset.lightingDefaults?.shadowCorners || (asset.id.includes('square') || asset.id.includes('rect') ? 'sharp' : 'rounded'),
      shadowCornerRadius: asset.lightingDefaults?.shadowCornerRadius ?? 10
    };

    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: [...currentRoom.elements, newElement]
    };

    pushHistory(nextRoom);
    setSelectedElementIds([newId]);
    setSelectedCollisionId(null);
    setRightPanelTab('properties');
  };

  // Add asset dropped onto canvas (by HTML5 Drag & Drop)
  const handleDropAsset = (asset: EditorAssetDefinition, position: { x: number; y: number }) => {
    const isTorch = isTorchElement(asset.id, asset.name);
    const isShadow = !!(asset.lightingDefaults?.isShadowSource || asset.id.startsWith('shadow_') || asset.name.toLowerCase().includes('тень'));
    const newId = `el_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newElement: RoomElement = {
      id: newId,
      assetId: asset.id,
      name: asset.name,
      src: asset.src,
      x: position.x,
      y: position.y,
      w: asset.defaultWidth,
      h: asset.defaultHeight,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      layer: asset.defaultLayer,
      zIndex: isShadow ? 10 : ((asset.defaultLayer === 'front_wall' || asset.defaultLayer === 'foreground') ? 20 : (asset.defaultLayer === 'floor_bg' ? 1 : 10)),
      renderAboveHero: isShadow ? false : (asset.defaultLayer === 'front_wall' || asset.defaultLayer === 'foreground'),
      opacity: isShadow ? (asset.lightingDefaults?.shadowDensity ?? 0.8) : 1,
      flipX: false,
      flipY: false,
      hasFireEffect: isTorch,
      hasLight: asset.lightingDefaults?.hasLight ?? (isTorch ? true : undefined),
      lightRadius: asset.lightingDefaults?.lightRadius || (isTorch ? 210 : undefined),
      lightColor: asset.lightingDefaults?.lightColor || (isTorch ? '#ff9d3b' : undefined),
      lightIntensity: asset.lightingDefaults?.lightIntensity || 1.0,
      lightFlicker: asset.lightingDefaults?.lightFlicker ?? isTorch,
      isShadowSource: isShadow,
      shadowDensity: asset.lightingDefaults?.shadowDensity ?? (isShadow ? 0.8 : undefined),
      shadowShape: asset.lightingDefaults?.shadowShape || (asset.id.includes('square') || asset.id.includes('rect') ? 'square' : 'oval'),
      shadowCorners: asset.lightingDefaults?.shadowCorners || (asset.id.includes('square') || asset.id.includes('rect') ? 'sharp' : 'rounded'),
      shadowCornerRadius: asset.lightingDefaults?.shadowCornerRadius ?? 10
    };

    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: [...currentRoom.elements, newElement]
    };

    pushHistory(nextRoom);
    setSelectedElementIds([newId]);
    setSelectedCollisionId(null);
    setRightPanelTab('properties');
  };

  // Add multiple elements (e.g. from Ctrl + Drag cloning)
  const handleAddMultipleElements = (newElements: RoomElement[]) => {
    if (newElements.length === 0) return;
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: [...currentRoom.elements, ...newElements]
    };
    pushHistory(nextRoom);
  };

  // Update single element
  const handleUpdateElement = (id: string, updates: Partial<RoomElement>) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: currentRoom.elements.map(el => (el.id === id ? { ...el, ...updates } : el))
    };
    setCurrentRoom(nextRoom);
  };

  // Update positions of multiple elements during group drag
  const handleUpdateMultiplePositionElements = (updates: { id: string; x: number; y: number }[]) => {
    const updateMap = new Map(updates.map(u => [u.id, u]));
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: currentRoom.elements.map(el => {
        const u = updateMap.get(el.id);
        if (u) {
          return { ...el, x: u.x, y: u.y };
        }
        return el;
      })
    };
    setCurrentRoom(nextRoom);
  };

  // Bulk update properties of multiple elements (layer, rotation, lock, visible)
  const handleUpdateMultipleElements = (ids: string[], updates: Partial<RoomElement>) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: currentRoom.elements.map(el => (ids.includes(el.id) ? { ...el, ...updates } : el))
    };
    pushHistory(nextRoom);
  };

  // Duplicate single element
  const handleDuplicateElement = (id: string) => {
    const el = currentRoom.elements.find(e => e.id === id);
    if (!el) return;
    const newId = `el_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const cloned: RoomElement = {
      ...el,
      id: newId,
      x: el.x + gridSize,
      y: el.y + gridSize,
      zIndex: (el.zIndex || 0) + 1
    };
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: [...currentRoom.elements, cloned]
    };
    pushHistory(nextRoom);
    setSelectedElementIds([newId]);
  };

  // Duplicate multiple elements
  const handleDuplicateMultipleElements = (ids: string[]) => {
    const toClone = currentRoom.elements.filter(e => ids.includes(e.id));
    if (toClone.length === 0) return;

    const clones: RoomElement[] = toClone.map(el => ({
      ...el,
      id: `el_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      x: el.x + gridSize,
      y: el.y + gridSize,
      zIndex: (el.zIndex || 0) + 1
    }));

    const nextRoom: CustomRoomData = {
      ...currentRoom,
      elements: [...currentRoom.elements, ...clones]
    };
    pushHistory(nextRoom);
    setSelectedElementIds(clones.map(c => c.id));
  };

  // Add auto collision for element
  const handleAddAutoCollision = (el: RoomElement) => {
    const assetDef = EDITOR_ASSETS.find(a => a.id === el.assetId);
    const colConfig = assetDef?.defaultCollision;

    const colW = colConfig ? colConfig.w * (el.scaleX || 1) : el.w * (el.scaleX || 1);
    const colH = colConfig ? colConfig.h * (el.scaleY || 1) : el.h * (el.scaleY || 1);
    const colX = el.x + (colConfig?.offsetX || 0);
    const colY = el.y + (colConfig?.offsetY || 0);

    const newBox: CollisionBox = {
      id: `col_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      x: colX,
      y: colY,
      w: colW,
      h: colH,
      type: colConfig?.type || 'wall',
      enabled: true,
      label: `Коллизия: ${el.name}`
    };

    const nextRoom: CustomRoomData = {
      ...currentRoom,
      collisionBoxes: [...currentRoom.collisionBoxes, newBox]
    };
    pushHistory(nextRoom);
    setSelectedCollisionId(newBox.id);
    setSelectedElementIds([]);
    setRightPanelTab('collisions');
    setShowCollisions(true);
  };

  // Add collision box
  const handleAddCollisionBox = (box: Omit<CollisionBox, 'id'>) => {
    const newId = `col_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newBox: CollisionBox = { ...box, id: newId };
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      collisionBoxes: [...currentRoom.collisionBoxes, newBox]
    };
    pushHistory(nextRoom);
    setSelectedCollisionId(newId);
    setSelectedElementIds([]);
    setRightPanelTab('collisions');
  };

  // Update collision box
  const handleUpdateCollision = (id: string, updates: Partial<CollisionBox>) => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      collisionBoxes: currentRoom.collisionBoxes.map(cb => (cb.id === id ? { ...cb, ...updates } : cb))
    };
    setCurrentRoom(nextRoom);
  };

  // Clear all collisions
  const handleClearAllCollisions = () => {
    const nextRoom: CustomRoomData = {
      ...currentRoom,
      collisionBoxes: []
    };
    pushHistory(nextRoom);
    setSelectedCollisionId(null);
  };

  // Helper to simplify Floor Zones without expanding into an artificial bounding square
  const simplifyFloorZones = (zones: { id: string; x: number; y: number; w: number; h: number }[]) => {
    let changed = true;
    let currentZones = [...zones];

    while (changed) {
      changed = false;
      for (let i = 0; i < currentZones.length; i++) {
        for (let j = i + 1; j < currentZones.length; j++) {
          const a = currentZones[i];
          const b = currentZones[j];

          // 1. If A is completely within B, remove redundant A
          if (a.x >= b.x && a.y >= b.y && a.x + a.w <= b.x + b.w && a.y + a.h <= b.y + b.h) {
            currentZones.splice(i, 1);
            changed = true;
            break;
          }

          // 2. If B is completely within A, remove redundant B
          if (b.x >= a.x && b.y >= a.y && b.x + b.w <= a.x + a.w && b.y + b.h <= a.y + a.h) {
            currentZones.splice(j, 1);
            changed = true;
            break;
          }

          // 3. Merge if they share exact X and width, and touch or overlap in Y (collinear vertical strip)
          if (a.x === b.x && a.w === b.w) {
            if (a.y <= b.y + b.h && b.y <= a.y + a.h) {
              const minY = Math.min(a.y, b.y);
              const maxY = Math.max(a.y + a.h, b.y + b.h);
              currentZones[i] = { ...a, y: minY, h: maxY - minY };
              currentZones.splice(j, 1);
              changed = true;
              break;
            }
          }

          // 4. Merge if they share exact Y and height, and touch or overlap in X (collinear horizontal strip)
          if (a.y === b.y && a.h === b.h) {
            if (a.x <= b.x + b.w && b.x <= a.x + a.w) {
              const minX = Math.min(a.x, b.x);
              const maxX = Math.max(a.x + a.w, b.x + b.w);
              currentZones[i] = { ...a, x: minX, w: maxX - minX };
              currentZones.splice(j, 1);
              changed = true;
              break;
            }
          }
        }
        if (changed) break;
      }
    }
    return currentZones;
  };

  const handleAddFloorZone = (newZone: { x: number; y: number; w: number; h: number }) => {
    const updatedZones = [
      ...(currentRoom.floorZones || []),
      { id: `zone_${Date.now()}_${Math.round(Math.random() * 1000)}`, ...newZone }
    ];
    const simplified = simplifyFloorZones(updatedZones);
    const minZoneX = Math.min(...simplified.map(z => z.x));
    const minZoneY = Math.min(...simplified.map(z => z.y));
    const maxZoneX = Math.max(...simplified.map(z => z.x + z.w));
    const maxZoneY = Math.max(...simplified.map(z => z.y + z.h));
    const nextRoom = {
      ...currentRoom,
      floorZones: simplified,
      width: Math.max(320, maxZoneX - minZoneX),
      height: Math.max(240, maxZoneY - minZoneY)
    };
    pushHistory(nextRoom);
  };

  const handleRemoveFloorZone = (id: string) => {
    const remaining = (currentRoom.floorZones || []).filter(z => z.id !== id);
    const minZoneX = remaining.length > 0 ? Math.min(...remaining.map(z => z.x)) : 0;
    const minZoneY = remaining.length > 0 ? Math.min(...remaining.map(z => z.y)) : 0;
    const maxZoneX = remaining.length > 0 ? Math.max(...remaining.map(z => z.x + z.w)) : currentRoom.width;
    const maxZoneY = remaining.length > 0 ? Math.max(...remaining.map(z => z.y + z.h)) : currentRoom.height;
    const nextRoom = {
      ...currentRoom,
      floorZones: remaining,
      width: remaining.length > 0 ? Math.max(320, maxZoneX - minZoneX) : currentRoom.width,
      height: remaining.length > 0 ? Math.max(240, maxZoneY - minZoneY) : currentRoom.height
    };
    pushHistory(nextRoom);
  };

  const handleClearFloorZones = () => {
    const nextRoom = {
      ...currentRoom,
      floorZones: []
    };
    pushHistory(nextRoom);
  };

  const handleGenerateFromZones = () => {
    if (!currentRoom.floorZones || currentRoom.floorZones.length === 0) return;

    // 1. Clear old generated floors & walls
    const nonFloorElements = currentRoom.elements.filter(
      el => !el.assetId.startsWith('plate_') && el.assetId !== 'floor_tiles'
    );
    const nonWallCollisions = currentRoom.collisionBoxes.filter(box => box.type !== 'wall');

    const newElements = [...nonFloorElements];
    const newCollisions = [...nonWallCollisions];

    // 2. Place whole 96x96 floor plates starting from top-left corner, going right row by row, keeping them whole without cropping
    const TILE_SIZE = 96;
    const minZoneX = Math.min(...currentRoom.floorZones.map(z => z.x));
    const minZoneY = Math.min(...currentRoom.floorZones.map(z => z.y));
    const maxZoneX = Math.max(...currentRoom.floorZones.map(z => z.x + z.w));
    const maxZoneY = Math.max(...currentRoom.floorZones.map(z => z.y + z.h));

    for (let y = minZoneY; y < maxZoneY; y += TILE_SIZE) {
      for (let x = minZoneX; x < maxZoneX; x += TILE_SIZE) {
        // Check if this 96x96 tile overlaps with any floor zone
        const hasOverlap = currentRoom.floorZones.some(zone => {
          const oL = Math.max(x, zone.x);
          const oR = Math.min(x + TILE_SIZE, zone.x + zone.w);
          const oT = Math.max(y, zone.y);
          const oB = Math.min(y + TILE_SIZE, zone.y + zone.h);
          return oR > oL && oB > oT;
        });

        if (!hasOverlap) continue;

        const seed = Math.abs(Math.sin((x / TILE_SIZE) * 12.9898 + (y / TILE_SIZE) * 78.233) * 43758.5453) % 1;
        const plateNum = 1 + Math.floor(seed * 7); // plate_1 to plate_7
        const assetId = `plate_${plateNum}`;
        
        const asset = EDITOR_ASSETS.find(a => a.id === assetId);
        const src = asset ? asset.src : '';

        // Lay tile whole (96x96) without cutting or trimming even if it exceeds the zone edge
        newElements.push({
          id: `gen_floor_${x}_${y}_${Math.random().toString(36).substring(2, 7)}`,
          assetId,
          name: asset ? asset.name : `Плита пола 96х96 (${plateNum})`,
          src,
          x,
          y,
          w: TILE_SIZE,
          h: TILE_SIZE,
          scaleX: 1,
          scaleY: 1,
          rotation: 0,
          layer: 'floor_bg' as LayerType,
          zIndex: 1, // Floor is layer 1 (well below hero at layer 100)
          opacity: 1,
          flipX: seed > 0.5,
          flipY: seed > 0.75
        });
      }
    }

    // 3. Wall collisions generation removed per user request: only floor is generated, keeping user collisions intact
    const nextRoom = {
      ...currentRoom,
      elements: newElements,
      collisionBoxes: newCollisions
    };
    pushHistory(nextRoom);
  };

  // Save Room Action
  const handleSaveRoom = (name: string, roomType: RoomType, theme: 'dungeon' | 'boss' | 'crypt', exportFile: boolean) => {
    const isBossRoom = roomType === 'boss';
    const floorZones = currentRoom.floorZones || [];
    const minZoneX = floorZones.length > 0 ? Math.min(...floorZones.map(z => z.x)) : 0;
    const minZoneY = floorZones.length > 0 ? Math.min(...floorZones.map(z => z.y)) : 0;
    const maxZoneX = floorZones.length > 0 ? Math.max(...floorZones.map(z => z.x + z.w)) : currentRoom.width;
    const maxZoneY = floorZones.length > 0 ? Math.max(...floorZones.map(z => z.y + z.h)) : currentRoom.height;
    const roomToSave: CustomRoomData = {
      ...currentRoom,
      name,
      roomType,
      isBossRoom,
      theme,
      width: floorZones.length > 0 ? Math.max(320, maxZoneX - minZoneX) : currentRoom.width,
      height: floorZones.length > 0 ? Math.max(240, maxZoneY - minZoneY) : currentRoom.height,
      updatedAt: new Date().toISOString()
    };

    const saved = roomStorage.saveRoom(roomToSave);
    if (exportFile) {
      roomStorage.exportRoomToFile(saved);
    }

    setAllRooms(roomStorage.getAllRooms());
    setCurrentRoom(saved);
    setIsSaveModalOpen(false);
  };

  // Create New Empty Room
  const handleCreateNewRoom = (roomType: RoomType = 'normal') => {
    let width = 800;
    let height = 600;
    let namePrefix = 'Обычная_комната';
    let theme: 'dungeon' | 'boss' | 'crypt' = 'dungeon';

    if (roomType === 'start') {
      namePrefix = 'Стартовая';
      width = 800;
      height = 600;
    } else if (roomType === 'bridge') {
      namePrefix = 'Мост';
      width = 800;
      height = 480;
      theme = 'crypt';
    } else if (roomType === 'boss') {
      namePrefix = 'Босс_Арена';
      width = 900;
      height = 650;
      theme = 'boss';
    }

    const newRoom: CustomRoomData = {
      id: `room_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `${namePrefix}_${allRooms.length + 1}`,
      roomType,
      width,
      height,
      gridSize: 32,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      elements: [],
      collisionBoxes: [],
      spawnPoint: { x: Math.round(width / 2), y: Math.round(height / 2) },
      theme,
      isBossRoom: roomType === 'boss'
    };
    roomStorage.saveRoom(newRoom);
    setAllRooms(roomStorage.getAllRooms());
    setCurrentRoom(newRoom);
    setHistory([newRoom]);
    setHistoryIndex(0);
    setSelectedElementIds([]);
    setSelectedCollisionId(null);
    setIsLibraryModalOpen(false);
  };

  const headerScrollBlocker = useScrollClickBlocker();

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col select-none overflow-hidden text-slate-100 font-sans">
      {/* Top Main Navigation Bar - Horizontal Scrolling on Mobile */}
      <header 
        {...headerScrollBlocker}
        className="min-h-14 h-14 bg-slate-900/95 border-b border-slate-800 px-3 flex items-center justify-between gap-3 z-20 overflow-x-auto overflow-y-hidden scrollbar-thin shrink-0 select-none [touch-action:pan-x] [-webkit-overflow-scrolling:touch] flex-nowrap"
      >
        {/* Left: Exit, Room Title & Type Selector */}
        <div className="flex items-center gap-3 shrink-0 flex-nowrap">
          <button
            onClick={onExit}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer border border-slate-700 shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>В МЕНЮ</span>
          </button>

          <div className="h-6 w-[1px] bg-slate-800 shrink-0" />

          <div className="shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-sky-400 uppercase tracking-widest shrink-0">РЕДАКТОР</span>
              <span className="text-slate-600">•</span>
              <input
                type="text"
                value={currentRoom.name}
                onChange={e => setCurrentRoom(prev => ({ ...prev, name: e.target.value }))}
                className="bg-transparent text-sm font-bold text-white focus:outline-none border-b border-transparent focus:border-sky-500 max-w-[140px] sm:max-w-[180px]"
              />
              
              {/* Room Type Switcher Badge */}
              <select
                value={currentRoom.roomType || (currentRoom.isBossRoom ? 'boss' : 'normal')}
                onChange={e => {
                  const nextType = e.target.value as RoomType;
                  const nextRoom: CustomRoomData = {
                    ...currentRoom,
                    roomType: nextType,
                    isBossRoom: nextType === 'boss',
                    theme: nextType === 'boss' ? 'boss' : (currentRoom.theme || 'dungeon')
                  };
                  pushHistory(nextRoom);
                }}
                className={`text-[11px] font-bold px-2 py-1 rounded-lg border cursor-pointer focus:outline-none transition-all shadow-sm shrink-0 ${
                  (currentRoom.roomType === 'start') 
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60 hover:border-emerald-400' 
                    : (currentRoom.roomType === 'bridge')
                    ? 'bg-amber-950/80 text-amber-300 border-amber-500/60 hover:border-amber-400'
                    : (currentRoom.roomType === 'boss' || currentRoom.isBossRoom)
                    ? 'bg-rose-950/80 text-rose-300 border-rose-500/60 hover:border-rose-400'
                    : 'bg-sky-950/80 text-sky-300 border-sky-500/60 hover:border-sky-400'
                }`}
                title="Тип комнаты: Стартовая, Промежуточный мост, Обычная или Комната с боссом"
              >
                <option value="start" className="bg-slate-900 text-emerald-300">🌟 Стартовая</option>
                <option value="bridge" className="bg-slate-900 text-amber-300">🌉 Мост</option>
                <option value="normal" className="bg-slate-900 text-sky-300">🛡️ Обычная</option>
                <option value="boss" className="bg-slate-900 text-rose-300">👑 Босс</option>
              </select>
            </div>
            <p className="text-[10px] text-slate-400">
              {currentRoom.elements.length} блоков • {currentRoom.collisionBoxes.length} коллизий • {currentRoom.width}x{currentRoom.height}px
            </p>
          </div>
        </div>

        {/* Center: Tools, Snap, History, Zoom */}
        <div className="flex items-center gap-2 shrink-0 flex-nowrap">
          {/* Undo / Redo */}
          <div className="flex items-center bg-slate-950 rounded-xl p-1 border border-slate-800 shrink-0">
            <button
              disabled={historyIndex <= 0}
              onClick={handleUndo}
              title="Отменить (Ctrl+Z)"
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                historyIndex > 0 ? 'text-slate-300 hover:bg-slate-800 hover:text-white' : 'text-slate-600 cursor-not-allowed'
              }`}
            >
              <Undo className="w-3.5 h-3.5" />
            </button>
            <button
              disabled={historyIndex >= history.length - 1}
              onClick={handleRedo}
              title="Повторить (Ctrl+Y)"
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                historyIndex < history.length - 1 ? 'text-slate-300 hover:bg-slate-800 hover:text-white' : 'text-slate-600 cursor-not-allowed'
              }`}
            >
              <Redo className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-5 w-[1px] bg-slate-800" />

          {/* Grid Snap & Display */}
          <div className="flex items-center bg-slate-950 rounded-xl p-1 border border-slate-800 gap-1">
            <button
              onClick={() => setShowGrid(!showGrid)}
              title={showGrid ? 'Скрыть сетку' : 'Показать сетку'}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                showGrid ? 'bg-sky-500/20 text-sky-400' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setSnapToGrid(!snapToGrid)}
              title={snapToGrid ? 'Привязка к сетке включена. Нажмите для свободного перемещения (1px)' : 'Свободное перемещение (1px) без привязки. Нажмите для включения сетки'}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                snapToGrid 
                  ? 'bg-sky-600/30 text-sky-300 border border-sky-500/50 shadow-sm' 
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${snapToGrid ? 'bg-sky-400 animate-pulse' : 'bg-amber-400'}`} />
              <span>{snapToGrid ? 'СЕТКА' : 'СВОБОДНО'}</span>
            </button>
            <select
              value={gridSize}
              onChange={e => setGridSize(Number(e.target.value))}
              className="bg-transparent text-slate-300 text-[11px] font-mono px-1.5 py-1 rounded focus:outline-none cursor-pointer border border-slate-800 hover:border-slate-700"
              title="Шаг сетки перемещения"
            >
              <option value="4" className="bg-slate-900">4px (Ультра)</option>
              <option value="8" className="bg-slate-900">8px (Мелкая)</option>
              <option value="16" className="bg-slate-900">16px</option>
              <option value="32" className="bg-slate-900">32px (Стандарт)</option>
              <option value="64" className="bg-slate-900">64px</option>
              <option value="128" className="bg-slate-900">128px (Крупная)</option>
            </select>
          </div>

          {/* Lighting & Darkness Control */}
          <div className="relative">
            <button
              onClick={() => setIsLightingMenuOpen(!isLightingMenuOpen)}
              title="Настройка затенения и освещения сцены"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shadow-sm ${
                (currentRoom.lighting?.enableLighting ?? false) && ((currentRoom.lighting?.ambientDarkness ?? 0) > 0.05)
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 hover:bg-amber-500/30'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>ТЬМА: {Math.round((currentRoom.lighting?.ambientDarkness ?? 0) * 100)}%</span>
            </button>
          </div>
        </div>

        {/* Right: Actions (Test, Save, Library, Panel Toggles) */}
        <div className="flex items-center gap-2 shrink-0 flex-nowrap">
          {/* Mobile & Desktop Panel Toggles */}
          <div className="flex items-center bg-slate-950 rounded-xl p-1 border border-slate-800 gap-1 shrink-0">
            <button
              onClick={() => setIsLeftPanelOpen(!isLeftPanelOpen)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isLeftPanelOpen
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
              title={isLeftPanelOpen ? 'Скрыть панель ассетов' : 'Показать панель ассетов'}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">АССЕТЫ</span>
            </button>
            <button
              onClick={() => setIsRightPanelOpen(!isRightPanelOpen)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isRightPanelOpen
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
              title={isRightPanelOpen ? 'Скрыть панель свойств' : 'Показать панель свойств'}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">СВОЙСТВА</span>
              {selectedElementIds.length > 0 && (
                <span className="px-1 py-0.2 bg-sky-400 text-slate-950 rounded-full text-[10px] font-black">
                  {selectedElementIds.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setPanelScale(s => s === 1.0 ? 0.85 : s === 0.85 ? 0.7 : s === 0.7 ? 0.55 : 1.0)}
              className="px-2 py-1 rounded-lg text-[11px] font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Масштаб интерфейса боковых панелей (100% / 85% / 70% / 55%)"
            >
              <Smartphone className="w-3.5 h-3.5 inline mr-1 text-sky-400" />
              <span>{Math.round(panelScale * 100)}%</span>
            </button>
          </div>

          <div className="h-5 w-[1px] bg-slate-800 shrink-0" />

          {/* Playtest Room */}
          <button
            onClick={() => setIsPlaytesting(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-950/80 cursor-pointer transition-all shrink-0"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>ТЕСТ</span>
          </button>

          {/* Room Library */}
          <button
            onClick={() => setIsLibraryModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold text-xs uppercase tracking-wider border border-slate-700 cursor-pointer transition-colors shrink-0"
          >
            <Folder className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ПАПКА</span>
          </button>

          {/* Save Room */}
          <button
            onClick={() => setIsSaveModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-sky-950 cursor-pointer transition-all shrink-0"
          >
            <Save className="w-3.5 h-3.5" />
            <span>СОХРАНИТЬ</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Body */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar: Asset Palette (Scalable & Resizable) */}
        {isLeftPanelOpen && (
          <div
            className={`h-full flex z-30 shrink-0 transition-all ${
              isMobile ? 'absolute inset-y-0 left-0 max-w-[85vw] shadow-2xl shadow-black/90' : 'relative'
            }`}
            style={{ width: `${leftPanelWidth}px` }}
          >
            <div className="flex-1 h-full overflow-hidden">
              <AssetLibrarySidebar 
                onAddAssetToRoom={handleAddAssetToRoom} 
                onClose={() => setIsLeftPanelOpen(false)}
                panelScale={panelScale}
              />
            </div>

            {/* Edge Resizer Handle */}
            <div
              className="w-2.5 hover:w-3 bg-slate-800/80 hover:bg-sky-500 active:bg-sky-400 cursor-col-resize transition-all flex items-center justify-center shrink-0 border-r border-slate-700/60 [touch-action:none]"
              onMouseDown={startResizingLeft}
              onTouchStart={startResizingLeft}
              title="Потяните для изменения ширины панели"
            >
              <div className="w-[2px] h-6 bg-slate-500 rounded-full" />
            </div>
          </div>
        )}

        {/* Center: Interactive Canvas */}
        <div className="flex-1 h-full relative overflow-hidden">
          {/* Floating Buttons when Panels are Closed */}
          {!isLeftPanelOpen && (
            <button
              onClick={() => setIsLeftPanelOpen(true)}
              className="absolute top-3 left-3 z-30 flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-sky-400 font-bold text-xs shadow-xl backdrop-blur cursor-pointer transition-transform hover:scale-105 active:scale-95"
              title="Открыть панель блоков и света"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Ассеты</span>
            </button>
          )}

          {!isRightPanelOpen && (
            <button
              onClick={() => setIsRightPanelOpen(true)}
              className="absolute top-3 right-3 z-30 flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-sky-400 font-bold text-xs shadow-xl backdrop-blur cursor-pointer transition-transform hover:scale-105 active:scale-95"
              title="Открыть свойства и коллизии"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{rightPanelTab === 'properties' ? 'Свойства' : 'Коллизии'}</span>
              {selectedElementIds.length > 0 && (
                <span className="px-1.5 py-0.5 bg-sky-500 text-white rounded-full text-[10px] font-black">
                  {selectedElementIds.length}
                </span>
              )}
            </button>
          )}

          <RoomEditorCanvas
            width={currentRoom.width}
            height={currentRoom.height}
            gridSize={gridSize}
            snapToGrid={snapToGrid}
            showGrid={showGrid}
            showCollisions={showCollisions}
            activeLayerFilter={activeLayerFilter}
            elements={currentRoom.elements}
            collisionBoxes={currentRoom.collisionBoxes}
            floorZones={currentRoom.floorZones}
            bakedUnderHeroImage={currentRoom.bakedUnderHeroImage}
            bakedAboveHeroImage={currentRoom.bakedAboveHeroImage}
            onAddFloorZone={handleAddFloorZone}
            selectedElementIds={selectedElementIds}
            selectedCollisionId={selectedCollisionId}
            currentTool={currentTool}
            collisionDrawType={collisionDrawType}
            spawnPoint={currentRoom.spawnPoint || { x: 400, y: 300 }}
            lighting={currentRoom.lighting}
            onSelectElements={ids => {
              setSelectedElementIds(ids);
              if (ids.length > 0) {
                setSelectedCollisionId(null);
                setRightPanelTab('properties');
              }
            }}
            onSelectCollision={id => {
              setSelectedCollisionId(id);
              if (id) {
                setSelectedElementIds([]);
                setRightPanelTab('collisions');
              }
            }}
            onUpdateElement={handleUpdateElement}
            onUpdateMultipleElements={handleUpdateMultiplePositionElements}
            onAddMultipleElements={handleAddMultipleElements}
            onDropAsset={handleDropAsset}
            onDuplicateElement={handleDuplicateElement}
            onDeleteElement={handleDeleteElement}
            onUpdateCollision={handleUpdateCollision}
            onAddCollisionBox={handleAddCollisionBox}
            onUpdateSpawnPoint={pt => setCurrentRoom(prev => ({ ...prev, spawnPoint: pt }))}
            zoom={zoom}
            onZoomChange={setZoom}
            panOffset={panOffset}
            onPanChange={setPanOffset}
          />
        </div>

        {/* Right Sidebar: Properties / Collisions (Scalable & Resizable) */}
        {isRightPanelOpen && (
          <div
            className={`h-full flex z-30 shrink-0 transition-all ${
              isMobile ? 'absolute inset-y-0 right-0 max-w-[85vw] shadow-2xl shadow-black/90' : 'relative'
            }`}
            style={{ width: `${rightPanelWidth}px` }}
          >
            {/* Edge Resizer Handle */}
            <div
              className="w-2.5 hover:w-3 bg-slate-800/80 hover:bg-sky-500 active:bg-sky-400 cursor-col-resize transition-all flex items-center justify-center shrink-0 border-l border-slate-700/60 [touch-action:none]"
              onMouseDown={startResizingRight}
              onTouchStart={startResizingRight}
              title="Потяните для изменения ширины панели"
            >
              <div className="w-[2px] h-6 bg-slate-500 rounded-full" />
            </div>

            <div className="flex-1 h-full flex flex-col bg-slate-900 overflow-hidden border-l border-slate-800">
              {/* Tab switch */}
              <div className="flex items-center p-2 bg-slate-950/80 border-b border-slate-800 gap-1 shrink-0">
                <button
                  onClick={() => setRightPanelTab('properties')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    rightPanelTab === 'properties'
                      ? 'bg-sky-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Свойства {selectedElementIds.length > 1 ? `(${selectedElementIds.length})` : ''}</span>
                </button>
                <button
                  onClick={() => setRightPanelTab('collisions')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    rightPanelTab === 'collisions'
                      ? 'bg-red-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>Коллизии ({currentRoom.collisionBoxes.length})</span>
                </button>
                <button
                  onClick={() => setIsRightPanelOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title="Свернуть панель"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Panel content */}
              <div className="flex-1 overflow-hidden">
                {rightPanelTab === 'properties' ? (
                  <ElementPropertiesPanel
                    selectedElements={selectedElements}
                    onUpdateElement={handleUpdateElement}
                    onUpdateMultipleElements={handleUpdateMultipleElements}
                    onDuplicateElement={handleDuplicateElement}
                    onDuplicateMultipleElements={handleDuplicateMultipleElements}
                    onDeleteElement={handleDeleteElement}
                    onDeleteMultipleElements={handleDeleteMultipleElements}
                    onAddAutoCollision={handleAddAutoCollision}
                    onClose={() => setIsRightPanelOpen(false)}
                    panelScale={panelScale}
                  />
                ) : (
                  <CollisionToolsPanel
                    collisionBoxes={currentRoom.collisionBoxes}
                    selectedCollisionId={selectedCollisionId}
                    currentTool={currentTool}
                    collisionDrawType={collisionDrawType}
                    showCollisions={showCollisions}
                    onSetCurrentTool={setCurrentTool}
                    onSetCollisionDrawType={setCollisionDrawType}
                    onToggleShowCollisions={() => setShowCollisions(!showCollisions)}
                    onSelectCollision={setSelectedCollisionId}
                    onUpdateCollision={handleUpdateCollision}
                    onDeleteCollision={handleDeleteCollision}
                    onClearAllCollisions={handleClearAllCollisions}
                    floorZones={currentRoom.floorZones}
                    onRemoveFloorZone={handleRemoveFloorZone}
                    onClearFloorZones={handleClearFloorZones}
                    onGenerateFromZones={handleGenerateFromZones}
                    onClose={() => setIsRightPanelOpen(false)}
                    panelScale={panelScale}
                  />
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {isPlaytesting && (
        <PlaytestModal
          room={currentRoom}
          onClose={() => setIsPlaytesting(false)}
        />
      )}

      {isSaveModalOpen && (
        <SaveRoomModal
          initialName={currentRoom.name}
          initialRoomType={currentRoom.roomType}
          initialIsBoss={currentRoom.isBossRoom || false}
          theme={currentRoom.theme || 'dungeon'}
          onSave={handleSaveRoom}
          onClose={() => setIsSaveModalOpen(false)}
        />
      )}

      {isLibraryModalOpen && (
        <RoomLibraryModal
          rooms={allRooms}
          currentRoomId={currentRoom.id}
          onSelectRoom={room => {
            const normalized = normalizeRoomBounds(room);
            setCurrentRoom(normalized);
            setHistory([normalized]);
            setHistoryIndex(0);
            setSelectedElementIds([]);
            setSelectedCollisionId(null);
            setIsLibraryModalOpen(false);
          }}
          onCreateNewRoom={handleCreateNewRoom}
          onDuplicateRoom={room => {
            const copy: CustomRoomData = {
              ...normalizeRoomBounds(room),
              id: `room_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
              name: `${room.name} (Копия)`,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            roomStorage.saveRoom(copy);
            setAllRooms(roomStorage.getAllRooms().map(normalizeRoomBounds));
          }}
          onDeleteRoom={id => {
            roomStorage.deleteRoom(id);
            const remaining = roomStorage.getAllRooms().map(normalizeRoomBounds);
            setAllRooms(remaining);
            if (currentRoom.id === id && remaining.length > 0) {
              setCurrentRoom(remaining[0]);
            }
          }}
          onPlaytestRoom={room => {
            const normalized = normalizeRoomBounds(room);
            setCurrentRoom(normalized);
            setIsLibraryModalOpen(false);
            setIsPlaytesting(true);
          }}
          onImportRoom={room => {
            setAllRooms(roomStorage.getAllRooms().map(normalizeRoomBounds));
            const normalized = normalizeRoomBounds(room);
            setCurrentRoom(normalized);
            setHistory([normalized]);
            setHistoryIndex(0);
          }}
          onClose={() => setIsLibraryModalOpen(false)}
        />
      )}

      {/* Floating Lighting & Darkness Window Modal - Guaranteed on top of everything */}
      {isLightingMenuOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm sm:items-start sm:justify-end sm:p-6 sm:pt-16">
          {/* Backdrop click to dismiss */}
          <div
            className="fixed inset-0"
            onClick={() => setIsLightingMenuOpen(false)}
          />

          <div className="relative w-full max-w-sm bg-slate-900/98 border border-amber-500/30 rounded-2xl shadow-2xl shadow-black/90 p-4 text-xs space-y-3.5 z-10 max-h-[85vh] overflow-y-auto overflow-x-auto custom-scrollbar animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
                <Sun className="w-4 h-4 text-amber-400" />
                <span>Освещение и Затенение</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const cur = currentRoom.lighting?.enableLighting ?? false;
                    const nextRoom: CustomRoomData = {
                      ...currentRoom,
                      lighting: {
                        ambientDarkness: currentRoom.lighting?.ambientDarkness ?? 0,
                        ambientColor: currentRoom.lighting?.ambientColor || '#070a14',
                        enableLighting: !cur,
                        torchFlicker: currentRoom.lighting?.torchFlicker ?? true
                      }
                    };
                    pushHistory(nextRoom);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-colors ${
                    (currentRoom.lighting?.enableLighting ?? false)
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {(currentRoom.lighting?.enableLighting ?? false) ? 'ВКЛЮЧЕНО' : 'ВЫКЛЮЧЕНО'}
                </button>
                <button
                  onClick={() => setIsLightingMenuOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Закрыть окно освещения"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Ambient Darkness Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-300">
                <span>Степень затенения (Тьма)</span>
                <span className="font-mono font-bold text-amber-400">
                  {Math.round((currentRoom.lighting?.ambientDarkness ?? 0) * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={currentRoom.lighting?.ambientDarkness ?? 0}
                onChange={e => {
                  const darkness = parseFloat(e.target.value);
                  setCurrentRoom(prev => ({
                    ...prev,
                    lighting: {
                      ambientDarkness: darkness,
                      ambientColor: prev.lighting?.ambientColor || '#070a14',
                      enableLighting: darkness > 0,
                      torchFlicker: prev.lighting?.torchFlicker ?? true
                    }
                  }));
                }}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Quick Presets */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Быстрые пресеты</span>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { label: '☀️ 0%', val: 0, title: 'Светлая комната' },
                  { label: '🕯️ 45%', val: 0.45, title: 'Полумрак' },
                  { label: '🌙 70%', val: 0.7, title: 'Подземелье' },
                  { label: '🌑 90%', val: 0.9, title: 'Глубокая тьма' }
                ].map(p => (
                  <button
                    key={p.label}
                    onClick={() => {
                      const nextRoom: CustomRoomData = {
                        ...currentRoom,
                        lighting: {
                          ambientDarkness: p.val,
                          ambientColor: currentRoom.lighting?.ambientColor || '#070a14',
                          enableLighting: true,
                          torchFlicker: currentRoom.lighting?.torchFlicker ?? true
                        }
                      };
                      pushHistory(nextRoom);
                    }}
                    className={`py-1.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      Math.abs((currentRoom.lighting?.ambientDarkness ?? 0.55) - p.val) < 0.04
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                    title={p.title}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Ambient Color Tints */}
            <div className="space-y-1 pt-1.5 border-t border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Оттенок полумрака</span>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { name: '🌙 Ночь', color: '#070a14' },
                  { name: '🌑 Тьма', color: '#020307' },
                  { name: '🩸 Склеп', color: '#140608' },
                  { name: '🌲 Мхи', color: '#05120a' }
                ].map(t => (
                  <button
                    key={t.name}
                    onClick={() => {
                      const nextRoom: CustomRoomData = {
                        ...currentRoom,
                        lighting: {
                          ambientDarkness: currentRoom.lighting?.ambientDarkness ?? 0.55,
                          ambientColor: t.color,
                          enableLighting: true,
                          torchFlicker: currentRoom.lighting?.torchFlicker ?? true
                        }
                      };
                      pushHistory(nextRoom);
                    }}
                    className={`py-1.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      (currentRoom.lighting?.ambientColor || '#070a14') === t.color
                        ? 'bg-slate-800 text-white border-amber-400/80 shadow-sm'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                    style={{ borderLeftColor: t.color, borderLeftWidth: '3px' }}
                  >
                    {t.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Dynamic Torch Flicker Toggle */}
            <div className="flex items-center justify-between pt-1.5 border-t border-slate-800 text-[11px] text-slate-300">
              <span>Мерцание огня факелов</span>
              <button
                onClick={() => {
                  const flicker = currentRoom.lighting?.torchFlicker ?? true;
                  const nextRoom: CustomRoomData = {
                    ...currentRoom,
                    lighting: {
                      ambientDarkness: currentRoom.lighting?.ambientDarkness ?? 0.55,
                      ambientColor: currentRoom.lighting?.ambientColor || '#070a14',
                      enableLighting: currentRoom.lighting?.enableLighting ?? true,
                      torchFlicker: !flicker
                    }
                  };
                  pushHistory(nextRoom);
                }}
                className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                  (currentRoom.lighting?.torchFlicker ?? true)
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {(currentRoom.lighting?.torchFlicker ?? true) ? 'АКТИВНО' : 'ВЫКЛ'}
              </button>
            </div>

            <div className="text-[10px] text-slate-400 pt-1 text-center border-t border-slate-800">
              Факелы и лампы динамически освещают комнату сквозь тьму
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
