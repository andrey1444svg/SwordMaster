import React, { useState } from 'react';
import { EDITOR_ASSETS, EditorAssetDefinition } from '../../utils/wallAssets';
import { isTorchElement } from '../../utils/torchEffects';
import { useScrollClickBlocker } from '../../utils/useScrollClickBlocker';
import { Layers, Search, Shield, Flame, Box, LayoutGrid, Sun, Moon, X } from 'lucide-react';

interface AssetLibrarySidebarProps {
  onAddAssetToRoom: (asset: EditorAssetDefinition) => void;
  onClose?: () => void;
  panelScale?: number;
}

export const AssetLibrarySidebar: React.FC<AssetLibrarySidebarProps> = ({ 
  onAddAssetToRoom,
  onClose,
  panelScale = 1.0
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'walls' | 'columns' | 'floors' | 'props' | 'lighting'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const scrollBlocker = useScrollClickBlocker();

  const categories: { id: 'all' | 'walls' | 'columns' | 'floors' | 'props' | 'lighting'; label: string; icon: React.ElementType }[] = [
    { id: 'all', label: 'Все', icon: LayoutGrid },
    { id: 'walls', label: 'Стены', icon: Box },
    { id: 'columns', label: 'Колонны', icon: Layers },
    { id: 'floors', label: 'Пол', icon: Shield },
    { id: 'props', label: 'Декор', icon: Flame },
    { id: 'lighting', label: '💡 Свет/Тени', icon: Sun }
  ];

  const filteredAssets = EDITOR_ASSETS.filter(asset => {
    const matchesCat = selectedCategory === 'all' || asset.category === selectedCategory;
    const matchesSearch = asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          asset.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleDragStart = (e: React.DragEvent, asset: EditorAssetDefinition) => {
    e.dataTransfer.setData('application/json', JSON.stringify(asset));
    e.dataTransfer.setData('text/plain', asset.id);
    e.dataTransfer.effectAllowed = 'copy';

    // Set drag preview if supported
    const ghost = e.currentTarget.querySelector('img');
    if (ghost) {
      e.dataTransfer.setDragImage(ghost, ghost.clientWidth / 2, ghost.clientHeight / 2);
    }
  };

  return (
    <div 
      {...scrollBlocker}
      className="w-full h-full bg-slate-900/95 flex flex-col select-none text-slate-200 overflow-x-auto overflow-y-auto custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]"
      style={panelScale !== 1.0 ? { transform: `scale(${panelScale})`, transformOrigin: 'top left', width: `${100 / panelScale}%`, height: `${100 / panelScale}%` } : undefined}
    >
      {/* Header */}
      <div className="p-3 border-b border-slate-800 shrink-0">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-100">Ассеты и Свет</h2>
              <p className="text-[10px] text-slate-400">Нажмите или перетащите для добавления</p>
            </div>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Свернуть панель"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск блоков, факелов, света..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
          />
        </div>
      </div>

      {/* Category Tabs - with horizontal scroll */}
      <div className="flex items-center gap-1 p-2 bg-slate-950/60 border-b border-slate-800/80 overflow-x-auto scrollbar-thin shrink-0 [touch-action:pan-x] [-webkit-overflow-scrolling:touch]">
        {categories.map(cat => {
          const Icon = cat.icon;
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md text-[11px] font-medium transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-950/60'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Asset Grid List */}
      <div className="flex-1 overflow-y-auto overflow-x-auto p-3 space-y-2 custom-scrollbar [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]">
        <div className="grid grid-cols-2 gap-2.5 min-w-[220px]">
          {filteredAssets.map(asset => {
            const isTorch = isTorchElement(asset.id, asset.name);
            const isLight = asset.category === 'lighting' || !!asset.lightingDefaults?.hasLight;
            const isShadow = asset.lightingDefaults?.isShadowSource || asset.id.startsWith('shadow_');

            return (
              <div
                key={asset.id}
                draggable={true}
                onDragStart={e => handleDragStart(e, asset)}
                onClick={() => onAddAssetToRoom(asset)}
                title="Перетащите на холст (Drag & Drop) или кликните для добавления"
                className="group relative bg-slate-950/80 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/80 rounded-xl p-2.5 flex flex-col items-center justify-between cursor-grab active:cursor-grabbing transition-all duration-200 shadow-sm hover:shadow-lg hover:shadow-sky-950/50 hover:scale-[1.02]"
              >
                {/* Asset Preview Frame */}
                <div className="w-full h-24 bg-slate-900/90 rounded-lg flex items-center justify-center p-2 mb-2 border border-slate-800/60 group-hover:border-slate-700 relative overflow-hidden pointer-events-none">
                  {asset.src ? (
                    <img
                      src={asset.src}
                      alt={asset.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] group-hover:scale-110 transition-transform duration-200"
                    />
                  ) : (
                    <div className="text-2xl opacity-40">✨</div>
                  )}
                  <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/80 text-[9px] text-slate-400 font-mono border border-slate-800">
                    {asset.defaultWidth}x{asset.defaultHeight}
                  </span>
                  
                  {isTorch && (
                    <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded bg-amber-950/90 text-[9px] text-amber-300 font-semibold border border-amber-500/40 flex items-center gap-0.5 shadow-sm shadow-amber-950/80">
                      <Flame className="w-2.5 h-2.5 text-amber-400 fill-amber-400 animate-pulse" />
                      <span>Огонь</span>
                    </span>
                  )}

                  {!isTorch && isLight && (
                    <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded bg-amber-950/90 text-[9px] text-amber-300 font-semibold border border-amber-500/40 flex items-center gap-0.5 shadow-sm">
                      <Sun className="w-2.5 h-2.5 text-amber-400" />
                      <span>Свет</span>
                    </span>
                  )}

                  {isShadow && (
                    <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded bg-slate-950/90 text-[9px] text-indigo-300 font-semibold border border-indigo-500/40 flex items-center gap-0.5 shadow-sm">
                      <Moon className="w-2.5 h-2.5 text-indigo-400" />
                      <span>Тень</span>
                    </span>
                  )}
                </div>

                {/* Title & Category */}
                <div className="w-full text-center pointer-events-none">
                  <span className="text-[11px] font-medium text-slate-200 line-clamp-1 group-hover:text-sky-300">
                    {asset.name}
                  </span>
                  <span className="text-[9px] text-slate-400 block mt-0.5 uppercase tracking-wider">
                    {asset.category === 'walls' ? 'Стена' : asset.category === 'columns' ? 'Колонна' : asset.category === 'floors' ? 'Пол' : asset.category === 'lighting' ? 'Освещение' : 'Декор'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {filteredAssets.length === 0 && (
          <div className="text-center py-12 text-slate-500 text-xs">
            Ничего не найдено по запросу «{searchQuery}»
          </div>
        )}
      </div>
    </div>
  );
};
