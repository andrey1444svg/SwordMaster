import React from 'react';
import { ItemRarity, IngredientType, EquipmentCategory } from '../types/game';

// Ingredient Image Assets
import mglashardImgSrc from '../assets/images/Осколок мглы игра.png';
import magiccrystalImgSrc from '../assets/images/Магический кристалл игра.png';
import monstercoreImgSrc from '../assets/images/Ядро монстра игра.png';
import voidsealImgSrc from '../assets/images/Печать пустоты игра.png';

// Weapon Image Assets
import spear1ImgSrc from '../assets/images/Копье 1.png';
import sword1ImgSrc from '../assets/images/Меч 1.png';
import sword2ImgSrc from '../assets/images/Меч 2.png';
import sword3ImgSrc from '../assets/images/Меч 3.png';
import sword4ImgSrc from '../assets/images/Меч 4.png';
import sword5ImgSrc from '../assets/images/Меч 5.png';
import sword6ImgSrc from '../assets/images/Меч 6.png';
import hammer1ImgSrc from '../assets/images/Молот 1.png';
import hammer2ImgSrc from '../assets/images/Молот 2.png';
import axe1ImgSrc from '../assets/images/Топор 1.png';
import axe2ImgSrc from '../assets/images/Топор 2.png';

// Helmet Image Assets
import helmet1ImgSrc from '../assets/images/Шлем 1.png';
import helmet2ImgSrc from '../assets/images/Шлем 2.png';
import helmet3ImgSrc from '../assets/images/Шлем 3.png';
import helmet4ImgSrc from '../assets/images/Шлем 4.png';
import helmet5ImgSrc from '../assets/images/Шлем 5.png';
import helmet6ImgSrc from '../assets/images/Шлем 6.png';
import helmet7ImgSrc from '../assets/images/Шлем 7.png';
import helmet8ImgSrc from '../assets/images/Шлем 8.png';
import helmet9ImgSrc from '../assets/images/Шлем 9.png';
import helmet10ImgSrc from '../assets/images/Шлем 10.png';
import helmet11ImgSrc from '../assets/images/Шлем 11.png';
import helmet12ImgSrc from '../assets/images/Шлем 12.png';
import helmet13ImgSrc from '../assets/images/Шлем 13.png';
import helmet14ImgSrc from '../assets/images/Шлем 14.png';

// Chest Image Assets
import chest1ImgSrc from '../assets/images/Нагрудник 1.png';
import chest2ImgSrc from '../assets/images/Нагрудник 2.png';
import chest3ImgSrc from '../assets/images/Нагрудник 3.png';
import chest4ImgSrc from '../assets/images/Нагрудник 4.png';
import chest5ImgSrc from '../assets/images/Нагрудник 5.png';
import chest6ImgSrc from '../assets/images/Нагрудник 6.png';
import chest7ImgSrc from '../assets/images/Нагрудник 7.png';
import chest8ImgSrc from '../assets/images/Нагрудник 8.png';
import chest9ImgSrc from '../assets/images/Нагрудник 9.png';
import chest10ImgSrc from '../assets/images/Нагрудник 10.png';
import chest11ImgSrc from '../assets/images/Нагрудник 11.png';
import chest12ImgSrc from '../assets/images/Нагрудник 12.png';
import chest13ImgSrc from '../assets/images/Нагрудник 13.png';
import chest14ImgSrc from '../assets/images/Нагрудник 14.png';

// Cloak Image Assets
import cloak1ImgSrc from '../assets/images/Плащ 1.png';
import cloak2ImgSrc from '../assets/images/Плащ 2.png';
import cloak3ImgSrc from '../assets/images/Плащ 3.png';
import cloak4ImgSrc from '../assets/images/Плащ 4.png';
import cloak5ImgSrc from '../assets/images/Плащ 5.png';
import cloak6ImgSrc from '../assets/images/Плащ 6.png';
import cloak7ImgSrc from '../assets/images/Плащ 7.png';
import cloak8ImgSrc from '../assets/images/Плащ 8.png';
import cloak9ImgSrc from '../assets/images/Плащ 9.png';
import cloak10ImgSrc from '../assets/images/Плащ 10.png';
import cloak11ImgSrc from '../assets/images/Плащ 11.png';

// Bracers Image Assets
import bracers1ImgSrc from '../assets/images/Наручи 1.png';
import bracers2ImgSrc from '../assets/images/Наручи 2.png';
import bracers3ImgSrc from '../assets/images/Наручи 3.png';
import bracers4ImgSrc from '../assets/images/Наручи 4.png';
import bracers5ImgSrc from '../assets/images/Наручи 5.png';
import bracers6ImgSrc from '../assets/images/Наручи 6.png';
import bracers7ImgSrc from '../assets/images/Наручи 7.png';
import bracers8ImgSrc from '../assets/images/Наручи 8.png';

// Gloves Image Assets
import gloves1ImgSrc from '../assets/images/Перчатка 1.png';
import gloves2ImgSrc from '../assets/images/Перчатка 2.png';
import gloves3ImgSrc from '../assets/images/Перчатка 3.png';
import gloves4ImgSrc from '../assets/images/Перчатка 4.png';
import gloves5ImgSrc from '../assets/images/Перчатка 5.png';
import gloves6ImgSrc from '../assets/images/Перчатка 6.png';
import gloves7ImgSrc from '../assets/images/Перчатка 7.png';
import gloves8ImgSrc from '../assets/images/Перчатка 8.png';
import gloves9ImgSrc from '../assets/images/Перчатка 9.png';
import gloves10ImgSrc from '../assets/images/Перчатка 10.png';

// Boots Image Assets
import boots1ImgSrc from '../assets/images/Ботинки 1.png';
import boots2ImgSrc from '../assets/images/Ботинки 2.png';
import boots3ImgSrc from '../assets/images/Ботинки 3.png';
import boots4ImgSrc from '../assets/images/Ботинки 4.png';
import boots5ImgSrc from '../assets/images/Ботинки 5.png';
import boots6ImgSrc from '../assets/images/Ботинки 6.png';
import boots7ImgSrc from '../assets/images/Ботинки 7.png';
import boots8ImgSrc from '../assets/images/Ботинки 8.png';
import boots9ImgSrc from '../assets/images/Ботинки 9.png';
import boots10ImgSrc from '../assets/images/Ботинки 10.png';

// Ring Image Assets
import ring1ImgSrc from '../assets/images/Кольцо 1.png';
import ring2ImgSrc from '../assets/images/Кольцо 2.png';
import ring3ImgSrc from '../assets/images/Кольцо 3.png';
import ring4ImgSrc from '../assets/images/Кольцо 4.png';
import ring5ImgSrc from '../assets/images/Кольцо 5.png';
import ring6ImgSrc from '../assets/images/Кольцо 6.png';
import ring7ImgSrc from '../assets/images/Кольцо 7.png';
import ring8ImgSrc from '../assets/images/Кольцо 8.png';
import ring9ImgSrc from '../assets/images/Кольцо 9.png';
import ring10ImgSrc from '../assets/images/Кольцо 10.png';
import ring11ImgSrc from '../assets/images/Кольцо 11.png';
import ring12ImgSrc from '../assets/images/Кольцо 12.png';

// Belt Image Assets
import belt1ImgSrc from '../assets/images/Пояс 1.png';
import belt2ImgSrc from '../assets/images/Пояс 2.png';
import belt3ImgSrc from '../assets/images/Пояс 3.png';
import belt4ImgSrc from '../assets/images/Пояс 4.png';
import belt5ImgSrc from '../assets/images/Пояс 5.png';
import belt6ImgSrc from '../assets/images/Пояс 6.png';
import belt7ImgSrc from '../assets/images/Пояс 7.png';
import belt8ImgSrc from '../assets/images/Пояс 8.png';
import belt9ImgSrc from '../assets/images/Пояс 9.png';
import belt10ImgSrc from '../assets/images/Пояс 10.png';

// Pants Image Assets
import pants1ImgSrc from '../assets/images/Штаны 1.png';
import pants2ImgSrc from '../assets/images/Штаны 2.png';
import pants3ImgSrc from '../assets/images/Штаны 3.png';
import pants4ImgSrc from '../assets/images/Штаны 4.png';
import pants5ImgSrc from '../assets/images/Штаны 5.png';
import pants6ImgSrc from '../assets/images/Штаны 6.png';
import pants7ImgSrc from '../assets/images/Штаны 7.png';
import pants8ImgSrc from '../assets/images/Штаны 8.png';
import pants9ImgSrc from '../assets/images/Штаны 9.png';
import pants10ImgSrc from '../assets/images/Штаны 10.png';

// Trinket Image Assets
import trinket1ImgSrc from '../assets/images/Аксессуар 1.png';
import trinket2ImgSrc from '../assets/images/Аксессуар 2.png';
import trinket3ImgSrc from '../assets/images/Аксессуар 3.png';
import trinket4ImgSrc from '../assets/images/Аксессуар 4.png';
import trinket5ImgSrc from '../assets/images/Аксессуар 5.png';
import trinket6ImgSrc from '../assets/images/Аксессуар 6.png';
import trinket7ImgSrc from '../assets/images/Аксессуар 7.png';
import trinket8ImgSrc from '../assets/images/Аксессуар 8.png';
import trinket9ImgSrc from '../assets/images/Аксессуар 9.png';
import trinket10ImgSrc from '../assets/images/Аксессуар 10.png';
import trinket11ImgSrc from '../assets/images/Аксессуар 11.png';
import trinket12ImgSrc from '../assets/images/Аксессуар 12.png';
import trinket13ImgSrc from '../assets/images/Аксессуар 13.png';
import trinket14ImgSrc from '../assets/images/Аксессуар 14.png';

// Empty Slot Silhouette Image Assets
import weaponSlotImgSrc from '../assets/images/Оружие слот.png';
import helmetSlotImgSrc from '../assets/images/Шлем слот.png';
import cloakSlotImgSrc from '../assets/images/Плащ слот.png';
import chestSlotImgSrc from '../assets/images/Нагрудник слот.png';
import bracersSlotImgSrc from '../assets/images/Наручи слот.png';
import glovesSlotImgSrc from '../assets/images/Перчатка слот.png';
import beltSlotImgSrc from '../assets/images/Пояс слот.png';
import pantsSlotImgSrc from '../assets/images/Штаны слот.png';
import bootsSlotImgSrc from '../assets/images/Ботинки слот.png';
import ringSlotImgSrc from '../assets/images/Кольцо слот.png';
import trinketSlotImgSrc from '../assets/images/Аксессуар слот.png';

export const EMPTY_SLOT_IMAGE_SOURCES: Record<string, string> = {
  weapon: weaponSlotImgSrc,
  sword: weaponSlotImgSrc,
  axe: weaponSlotImgSrc,
  hammer: weaponSlotImgSrc,
  spear: weaponSlotImgSrc,
  katana: weaponSlotImgSrc,
  rapier: weaponSlotImgSrc,
  dagger: weaponSlotImgSrc,
  greatsword: weaponSlotImgSrc,
  helmet: helmetSlotImgSrc,
  head: helmetSlotImgSrc,
  cloak: cloakSlotImgSrc,
  chest: chestSlotImgSrc,
  armor: chestSlotImgSrc,
  bracers: bracersSlotImgSrc,
  gloves: glovesSlotImgSrc,
  belt: beltSlotImgSrc,
  pants: pantsSlotImgSrc,
  boots: bootsSlotImgSrc,
  ring: ringSlotImgSrc,
  ring1: ringSlotImgSrc,
  ring2: ringSlotImgSrc,
  trinket: trinketSlotImgSrc,
  trinket1: trinketSlotImgSrc,
  trinket2: trinketSlotImgSrc,
  accessory: trinketSlotImgSrc,
  neck: trinketSlotImgSrc,
  shoulders: chestSlotImgSrc
};

const WEAPON_IMAGE_SOURCES: Record<string, string> = {
  spear1: spear1ImgSrc,
  sword1: sword1ImgSrc,
  sword2: sword2ImgSrc,
  sword3: sword3ImgSrc,
  sword4: sword4ImgSrc,
  sword5: sword5ImgSrc,
  sword6: sword6ImgSrc,
  hammer1: hammer1ImgSrc,
  hammer2: hammer2ImgSrc,
  axe1: axe1ImgSrc,
  axe2: axe2ImgSrc
};

const HELMET_IMAGE_SOURCES: Record<string, string> = {
  helmet1: helmet1ImgSrc,
  helmet2: helmet2ImgSrc,
  helmet3: helmet3ImgSrc,
  helmet4: helmet4ImgSrc,
  helmet5: helmet5ImgSrc,
  helmet6: helmet6ImgSrc,
  helmet7: helmet7ImgSrc,
  helmet8: helmet8ImgSrc,
  helmet9: helmet9ImgSrc,
  helmet10: helmet10ImgSrc,
  helmet11: helmet11ImgSrc,
  helmet12: helmet12ImgSrc,
  helmet13: helmet13ImgSrc,
  helmet14: helmet14ImgSrc
};

const CHEST_IMAGE_SOURCES: Record<string, string> = {
  chest1: chest1ImgSrc,
  chest2: chest2ImgSrc,
  chest3: chest3ImgSrc,
  chest4: chest4ImgSrc,
  chest5: chest5ImgSrc,
  chest6: chest6ImgSrc,
  chest7: chest7ImgSrc,
  chest8: chest8ImgSrc,
  chest9: chest9ImgSrc,
  chest10: chest10ImgSrc,
  chest11: chest11ImgSrc,
  chest12: chest12ImgSrc,
  chest13: chest13ImgSrc,
  chest14: chest14ImgSrc
};

const CLOAK_IMAGE_SOURCES: Record<string, string> = {
  cloak1: cloak1ImgSrc,
  cloak2: cloak2ImgSrc,
  cloak3: cloak3ImgSrc,
  cloak4: cloak4ImgSrc,
  cloak5: cloak5ImgSrc,
  cloak6: cloak6ImgSrc,
  cloak7: cloak7ImgSrc,
  cloak8: cloak8ImgSrc,
  cloak9: cloak9ImgSrc,
  cloak10: cloak10ImgSrc,
  cloak11: cloak11ImgSrc
};

const BRACERS_IMAGE_SOURCES: Record<string, string> = {
  bracers1: bracers1ImgSrc,
  bracers2: bracers2ImgSrc,
  bracers3: bracers3ImgSrc,
  bracers4: bracers4ImgSrc,
  bracers5: bracers5ImgSrc,
  bracers6: bracers6ImgSrc,
  bracers7: bracers7ImgSrc,
  bracers8: bracers8ImgSrc
};

export const GLOVES_IMAGE_SOURCES: Record<string, string> = {
  gloves1: gloves1ImgSrc,
  gloves2: gloves2ImgSrc,
  gloves3: gloves3ImgSrc,
  gloves4: gloves4ImgSrc,
  gloves5: gloves5ImgSrc,
  gloves6: gloves6ImgSrc,
  gloves7: gloves7ImgSrc,
  gloves8: gloves8ImgSrc,
  gloves9: gloves9ImgSrc,
  gloves10: gloves10ImgSrc
};

const BOOTS_IMAGE_SOURCES: Record<string, string> = {
  boots1: boots1ImgSrc,
  boots2: boots2ImgSrc,
  boots3: boots3ImgSrc,
  boots4: boots4ImgSrc,
  boots5: boots5ImgSrc,
  boots6: boots6ImgSrc,
  boots7: boots7ImgSrc,
  boots8: boots8ImgSrc,
  boots9: boots9ImgSrc,
  boots10: boots10ImgSrc
};

const RING_IMAGE_SOURCES: Record<string, string> = {
  ring1: ring1ImgSrc,
  ring2: ring2ImgSrc,
  ring3: ring3ImgSrc,
  ring4: ring4ImgSrc,
  ring5: ring5ImgSrc,
  ring6: ring6ImgSrc,
  ring7: ring7ImgSrc,
  ring8: ring8ImgSrc,
  ring9: ring9ImgSrc,
  ring10: ring10ImgSrc,
  ring11: ring11ImgSrc,
  ring12: ring12ImgSrc
};

const BELT_IMAGE_SOURCES: Record<string, string> = {
  belt1: belt1ImgSrc,
  belt2: belt2ImgSrc,
  belt3: belt3ImgSrc,
  belt4: belt4ImgSrc,
  belt5: belt5ImgSrc,
  belt6: belt6ImgSrc,
  belt7: belt7ImgSrc,
  belt8: belt8ImgSrc,
  belt9: belt9ImgSrc,
  belt10: belt10ImgSrc
};

const PANTS_IMAGE_SOURCES: Record<string, string> = {
  pants1: pants1ImgSrc,
  pants2: pants2ImgSrc,
  pants3: pants3ImgSrc,
  pants4: pants4ImgSrc,
  pants5: pants5ImgSrc,
  pants6: pants6ImgSrc,
  pants7: pants7ImgSrc,
  pants8: pants8ImgSrc,
  pants9: pants9ImgSrc,
  pants10: pants10ImgSrc
};

const TRINKET_IMAGE_SOURCES: Record<string, string> = {
  trinket1: trinket1ImgSrc,
  trinket2: trinket2ImgSrc,
  trinket3: trinket3ImgSrc,
  trinket4: trinket4ImgSrc,
  trinket5: trinket5ImgSrc,
  trinket6: trinket6ImgSrc,
  trinket7: trinket7ImgSrc,
  trinket8: trinket8ImgSrc,
  trinket9: trinket9ImgSrc,
  trinket10: trinket10ImgSrc,
  trinket11: trinket11ImgSrc,
  trinket12: trinket12ImgSrc,
  trinket13: trinket13ImgSrc,
  trinket14: trinket14ImgSrc
};

// Persistent Global Image Cache so images are loaded once and permanently retained in memory
export const GLOBAL_ICON_CACHE: Map<string, HTMLImageElement> = (typeof window !== 'undefined' && (window as any).__ICON_CACHE__) 
  ? (window as any).__ICON_CACHE__ 
  : new Map<string, HTMLImageElement>();

if (typeof window !== 'undefined') {
  (window as any).__ICON_CACHE__ = GLOBAL_ICON_CACHE;
}

let isIconsPreloadStarted = false;

export function preloadAllGameIcons() {
  if (isIconsPreloadStarted || typeof window === 'undefined') return;
  isIconsPreloadStarted = true;

  try {
    const allImages = [
      ...Object.values(WEAPON_IMAGE_SOURCES),
      ...Object.values(HELMET_IMAGE_SOURCES),
      ...Object.values(CHEST_IMAGE_SOURCES),
      ...Object.values(CLOAK_IMAGE_SOURCES),
      ...Object.values(BRACERS_IMAGE_SOURCES),
      ...Object.values(GLOVES_IMAGE_SOURCES),
      ...Object.values(BOOTS_IMAGE_SOURCES),
      ...Object.values(RING_IMAGE_SOURCES),
      ...Object.values(BELT_IMAGE_SOURCES),
      ...Object.values(PANTS_IMAGE_SOURCES),
      ...Object.values(TRINKET_IMAGE_SOURCES),
      ...Object.values(EMPTY_SLOT_IMAGE_SOURCES),
      mglashardImgSrc,
      magiccrystalImgSrc,
      monstercoreImgSrc,
      voidsealImgSrc
    ];

    for (let i = 0; i < allImages.length; i++) {
      const src = allImages[i];
      if (src && !GLOBAL_ICON_CACHE.has(src)) {
        const img = new Image();
        img.src = src;
        GLOBAL_ICON_CACHE.set(src, img);
        if (typeof img.decode === 'function') {
          img.decode().catch(() => {});
        }
      }
    }
  } catch (e) {
    console.warn("Failed to prefetch equipment icons", e);
  }
}

// Start preloading immediately on load and module execution
if (typeof window !== 'undefined') {
  preloadAllGameIcons();
  if (document.readyState !== 'complete') {
    window.addEventListener('DOMContentLoaded', preloadAllGameIcons, { once: true });
    window.addEventListener('load', preloadAllGameIcons, { once: true });
  }
}

// Deterministic index selector to guarantee variety across dropped items
function getDeterministicIndex(str: string, poolLength: number): number {
  if (poolLength <= 1) return 0;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
  }
  return hash % poolLength;
}

export function getGlovesImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && GLOVES_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('длани') || (name.includes('разрушител') && rarity === 'legendary')) return 'gloves10';
  if (name.includes('бездна') || name.includes('бездны')) return 'gloves9';
  if (name.includes('хватка') || name.includes('демон')) return 'gloves8';
  if (name.includes('пламен') || name.includes('пламени')) return 'gloves7';
  if (name.includes('силы') || name.includes('титан')) return 'gloves6';
  if (name.includes('мечник') || name.includes('стальн')) return 'gloves5';
  if (name.includes('ловк') || name.includes('рукавиц')) return 'gloves4';
  if (name.includes('охотник') || name.includes('следопыт')) return 'gloves3';
  if (name.includes('кожан')) return 'gloves2';
  if (name.includes('рабоч') || name.includes('сукон')) return 'gloves1';

  const pools: Record<string, string[]> = {
    legendary: ['gloves10'],
    epic: ['gloves7', 'gloves8', 'gloves9'],
    rare: ['gloves5', 'gloves6'],
    magic: ['gloves3', 'gloves4'],
    common: ['gloves1', 'gloves2']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'gloves', pool.length)];
}

export function getBootsImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && BOOTS_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('поступь бури') || name.includes('бури')) return 'boots10';
  if (name.includes('теневые ботфорты') || name.includes('ботфорт') || name.includes('теневые')) return 'boots9';
  if (name.includes('сапоги разрушителя') || name.includes('разрушител')) return 'boots8';
  if (name.includes('поступь ветра') || name.includes('ветра')) return 'boots7';
  if (name.includes('латные сапоги') || name.includes('латн') || name.includes('мечник')) return 'boots6';
  if (name.includes('странник') || name.includes('странника')) return 'boots5';
  if (name.includes('охотник') || name.includes('охотника')) return 'boots4';
  if (name.includes('быстроходн')) return 'boots3';
  if (name.includes('путник') || name.includes('путника')) return 'boots2';
  if (name.includes('кожан') || name.includes('башмак')) return 'boots1';

  const pools: Record<string, string[]> = {
    legendary: ['boots10'],
    epic: ['boots7', 'boots8', 'boots9'],
    rare: ['boots5', 'boots6'],
    magic: ['boots3', 'boots4'],
    common: ['boots1', 'boots2']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'boots', pool.length)];
}

export function getRingImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && RING_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('кольцо владыки') || name.includes('владык')) return 'ring12';
  if (name.includes('око бездны') || name.includes('бездны') || name.includes('вампир')) return 'ring11';
  if (name.includes('кольцо хаоса') || name.includes('хаоса') || name.includes('абсолют') || name.includes('перстень абсолюта')) return 'ring10';
  if (name.includes('перстень ветра') || name.includes('ветра')) return 'ring9';
  if (name.includes('рубин') || name.includes('рубинов') || name.includes('пламен')) return 'ring8';
  if (name.includes('кольцо ловкости') || name.includes('ловкост')) return 'ring7';
  if (name.includes('кольцо силы') || name.includes('силы')) return 'ring6';
  if (name.includes('изумруд') || name.includes('изумрудный')) return 'ring5';
  if (name.includes('нефритовый перстень') || name.includes('нефрит')) return 'ring4';
  if (name.includes('кольцо концентрации') || name.includes('концентрац')) return 'ring3';
  if (name.includes('простое кольцо') || name.includes('прост')) return 'ring2';
  if (name.includes('медное кольцо') || name.includes('медн') || name.includes('железн')) return 'ring1';

  const pools: Record<string, string[]> = {
    legendary: ['ring12'],
    epic: ['ring10', 'ring11'],
    rare: ['ring7', 'ring8', 'ring9'],
    magic: ['ring4', 'ring5', 'ring6'],
    common: ['ring1', 'ring2', 'ring3']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'ring', pool.length)];
}

export function getBeltImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && BELT_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('пояс абсолюта') || name.includes('абсолют')) return 'belt10';
  if (name.includes('драконьей мощи') || name.includes('дракон')) return 'belt9';
  if (name.includes('несокрушимости') || name.includes('несокрушим')) return 'belt8';
  if (name.includes('пояс великана') || name.includes('великан')) return 'belt7';
  if (name.includes('стойкости') || name.includes('стойкост')) return 'belt6';
  if (name.includes('пояс воина') || name.includes('воин')) return 'belt5';
  if (name.includes('кушак ловца') || name.includes('ловца')) return 'belt4';
  if (name.includes('усиленный пояс') || name.includes('усилен')) return 'belt3';
  if (name.includes('кожаный ремень') || name.includes('кожан')) return 'belt2';
  if (name.includes('веревочный пояс') || name.includes('веревоч')) return 'belt1';

  const pools: Record<string, string[]> = {
    legendary: ['belt10'],
    epic: ['belt8', 'belt9'],
    rare: ['belt5', 'belt6', 'belt7'],
    magic: ['belt3', 'belt4'],
    common: ['belt1', 'belt2']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'belt', pool.length)];
}

export function getPantsImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && PANTS_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('поножи вечности') || name.includes('вечност')) return 'pants10';
  if (name.includes('поножи дракона') || name.includes('дракон')) return 'pants9';
  if (name.includes('поножи инферно') || name.includes('инферно')) return 'pants8';
  if (name.includes('поножи стража') || name.includes('стража') || name.includes('страж')) return 'pants7';
  if (name.includes('штаны шиноби') || name.includes('шиноби')) return 'pants6';
  if (name.includes('латные поножи') || name.includes('латн') || name.includes('воин')) return 'pants5';
  if (name.includes('штаны следопыта') || name.includes('следопыт')) return 'pants4';
  if (name.includes('укрепленные поножи') || name.includes('укреплен')) return 'pants3';
  if (name.includes('кожаные поножи') || name.includes('кожан')) return 'pants2';
  if (name.includes('суконные штаны') || name.includes('сукон')) return 'pants1';

  const pools: Record<string, string[]> = {
    legendary: ['pants10'],
    epic: ['pants8', 'pants9'],
    rare: ['pants5', 'pants6', 'pants7'],
    magic: ['pants3', 'pants4'],
    common: ['pants1', 'pants2']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'pants', pool.length)];
}

export function getTrinketImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && TRINKET_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const id = (item.id || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('цепн') || name.includes('молни') || name.includes('грозов') || id.includes('chain_lightning')) return 'trinket3';
  if (name.includes('слеза богов') || name.includes('богов')) return 'trinket14';
  if (name.includes('пламен') || name.includes('сердце феникса') || name.includes('феникс')) return 'trinket13';
  if (name.includes('печать дракона') || name.includes('дракон')) return 'trinket12';
  if (name.includes('осколок вечности') || name.includes('вечност')) return 'trinket11';
  if (name.includes('реликвия древних') || name.includes('древних')) return 'trinket10';
  if (name.includes('огонь') || name.includes('огня') || name.includes('талисман огня')) return 'trinket9';
  if (name.includes('символ ветра') || name.includes('ветра')) return 'trinket8';
  if (name.includes('печать воина') || name.includes('воина') || name.includes('воин')) return 'trinket7';
  if (name.includes('рунный талисман') || name.includes('рунн')) return 'trinket6';
  if (name.includes('янтар') || name.includes('янтарный')) return 'trinket5';
  if (name.includes('лесной оберег') || name.includes('лесн')) return 'trinket4';
  if (name.includes('заряженный талисман') || name.includes('заряжен')) return 'trinket3';
  if (name.includes('медный талисман') || name.includes('медн') || name.includes('путника')) return 'trinket2';
  if (name.includes('деревянный оберег') || name.includes('деревян')) return 'trinket1';

  const pools: Record<string, string[]> = {
    legendary: ['trinket14'],
    epic: ['trinket11', 'trinket12', 'trinket13'],
    rare: ['trinket7', 'trinket8', 'trinket9', 'trinket10'],
    magic: ['trinket4', 'trinket5', 'trinket6'],
    common: ['trinket1', 'trinket2', 'trinket3']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'trinket', pool.length)];
}

export function getHelmetImageKey(helmet: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (helmet.imageKey && HELMET_IMAGE_SOURCES[helmet.imageKey]) return helmet.imageKey;
  const name = (helmet.name || '').toLowerCase();
  const rarity = (helmet.rarity || 'common').toLowerCase();

  if (name.includes('корона бессмертных') || (name.includes('бессмертн') && rarity === 'legendary')) return 'helmet14';
  if (name.includes('корона пламени') || name.includes('пламен')) return 'helmet13';
  if (name.includes('лик бездны') || name.includes('безды') || name.includes('бездна')) return 'helmet12';
  if (name.includes('драконь') || name.includes('дракон')) return 'helmet11';
  if (name.includes('венец титана') || name.includes('титан')) return 'helmet10';
  if (name.includes('самурая') || name.includes('самурай')) return 'helmet9';
  if (name.includes('стража') || name.includes('визор')) return 'helmet8';
  if (name.includes('подшлемник') || name.includes('закален')) return 'helmet7';
  if (name.includes('капюшон') || name.includes('лесн')) return 'helmet6';
  if (name.includes('следопыт')) return 'helmet5';
  if (name.includes('новичка') || name.includes('бацинет')) return 'helmet4';
  if (name.includes('ополчен')) return 'helmet3';
  if (name.includes('капеллин') || name.includes('кожан')) return 'helmet2';
  if (name.includes('железный шлем') || name.includes('железн')) return 'helmet1';

  const pools: Record<string, string[]> = {
    legendary: ['helmet14'],
    epic: ['helmet11', 'helmet12', 'helmet13'],
    rare: ['helmet8', 'helmet9', 'helmet10'],
    magic: ['helmet5', 'helmet6', 'helmet7'],
    common: ['helmet1', 'helmet2', 'helmet3', 'helmet4']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(helmet.id || helmet.name || 'helmet', pool.length)];
}

export function getChestImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && CHEST_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('эгида богов') || (name.includes('богов') && rarity === 'legendary')) return 'chest14';
  if (name.includes('пустоты') || name.includes('пустот')) return 'chest13';
  if (name.includes('бессмертного') || name.includes('бессмертн')) return 'chest12';
  if (name.includes('доспех драконьей') || name.includes('чешуи') || name.includes('дракон')) return 'chest11';
  if (name.includes('кираса мечника') || name.includes('мечник')) return 'chest10';
  if (name.includes('латы титана') || name.includes('титан')) return 'chest9';
  if (name.includes('нагрудник стража') || name.includes('страж')) return 'chest8';
  if (name.includes('кираса следопыта') || name.includes('следопыт')) return 'chest7';
  if (name.includes('закаленная кольчуга') || (name.includes('кольчуга') && rarity === 'magic')) return 'chest6';
  if (name.includes('чешуйчатый доспех') || name.includes('чешуй')) return 'chest5';
  if (name.includes('нагрудник ополченца') || name.includes('ополчен')) return 'chest4';
  if (name.includes('стеганый доспех') || name.includes('стеган')) return 'chest3';
  if (name.includes('железная кольчуга') || name.includes('железн')) return 'chest2';
  if (name.includes('кожаный панцирь') || name.includes('кожан')) return 'chest1';

  const pools: Record<string, string[]> = {
    legendary: ['chest14'],
    epic: ['chest11', 'chest12', 'chest13'],
    rare: ['chest8', 'chest9', 'chest10'],
    magic: ['chest5', 'chest6', 'chest7'],
    common: ['chest1', 'chest2', 'chest3', 'chest4']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'chest', pool.length)];
}

export function getCloakImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && CLOAK_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('покров бессмертия') || (name.includes('бессмерт') && rarity === 'legendary')) return 'cloak11';
  if (name.includes('плащ дракона') || name.includes('дракон')) return 'cloak10';
  if (name.includes('мантия владыки') || name.includes('владык')) return 'cloak9';
  if (name.includes('саван пустоты') || name.includes('саван') || name.includes('пустот')) return 'cloak8';
  if (name.includes('накидка сквозняка') || name.includes('сквозняк')) return 'cloak7';
  if (name.includes('мантия бури') || name.includes('бури')) return 'cloak6';
  if (name.includes('плащ тени') || name.includes('тени')) return 'cloak5';
  if (name.includes('лесная мантия') || name.includes('лесн')) return 'cloak4';
  if (name.includes('плащ следопыта') || name.includes('следопыт')) return 'cloak3';
  if (name.includes('накидка путника') || name.includes('путник')) return 'cloak3';
  if (name.includes('холщовый плащ') || name.includes('холщ')) return 'cloak2';
  if (name.includes('походная мантия') || name.includes('походн')) return 'cloak1';

  const pools: Record<string, string[]> = {
    legendary: ['cloak11'],
    epic: ['cloak9', 'cloak10'],
    rare: ['cloak6', 'cloak7', 'cloak8'],
    magic: ['cloak4', 'cloak5'],
    common: ['cloak1', 'cloak2', 'cloak3']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'cloak', pool.length)];
}

export function getBracersImageKey(item: { rarity?: ItemRarity; name?: string; id?: string; imageKey?: string }) {
  if (item.imageKey && BRACERS_IMAGE_SOURCES[item.imageKey]) return item.imageKey;
  const name = (item.name || '').toLowerCase();
  const rarity = (item.rarity || 'common').toLowerCase();

  if (name.includes('оковы титана') || (name.includes('титан') && rarity === 'legendary')) return 'bracers8';
  if (name.includes('наручи дракона') || name.includes('дракон')) return 'bracers7';
  if (name.includes('повелителя бурь') || name.includes('бурь')) return 'bracers6';
  if (name.includes('наручи стража') || name.includes('страж')) return 'bracers5';
  if (name.includes('наручи воина') || name.includes('воин')) return 'bracers4';
  if (name.includes('браслеты охотника') || name.includes('охотник')) return 'bracers3';
  if (name.includes('нарукавники') || name.includes('укреплен')) return 'bracers2';
  if (name.includes('железные запястья') || name.includes('железн')) return 'bracers2';
  if (name.includes('кожаные наручи') || name.includes('кожан')) return 'bracers1';

  const pools: Record<string, string[]> = {
    legendary: ['bracers8'],
    epic: ['bracers7', 'bracers8'],
    rare: ['bracers5', 'bracers6'],
    magic: ['bracers3', 'bracers4'],
    common: ['bracers1', 'bracers2']
  };
  const pool = pools[rarity] || pools.common;
  return pool[getDeterministicIndex(item.id || item.name || 'bracers', pool.length)];
}

export function getWeaponImageKey(weapon: { id?: string; type?: string; rarity?: ItemRarity; name?: string; imageKey?: string }) {
  if (weapon.imageKey && WEAPON_IMAGE_SOURCES[weapon.imageKey]) return weapon.imageKey;
  const type = (weapon.type || 'sword').toLowerCase();
  const rarity = (weapon.rarity || 'common').toLowerCase();
  const id = (weapon.id || '').toLowerCase();
  const name = (weapon.name || '').toLowerCase();

  if (type === 'spear' || id.includes('spear') || name.includes('копье') || name.includes('пика') || name.includes('гунгнир')) {
    return 'spear1';
  }
  if (type === 'axe' || id.includes('axe') || name.includes('топор') || name.includes('секир') || name.includes('секач')) {
    if (rarity === 'epic' || rarity === 'legendary') return 'axe2';
    return 'axe1';
  }
  if (type === 'hammer' || id.includes('hammer') || name.includes('молот') || name.includes('mace') || name.includes('сокрушител')) {
    if (rarity === 'epic' || rarity === 'legendary') return 'hammer2';
    return 'hammer1';
  }

  // Swords, katanas, rapiers, greatswords, daggers
  if (id.includes('starter_sword') || id.includes('starter')) return 'sword1';
  if (id.includes('wind_katana')) return 'sword2';
  if (id.includes('frost_rapier')) return 'sword3';
  if (id.includes('chaos_greatsword')) return 'sword4';

  if (type === 'katana' || name.includes('катана')) {
    if (rarity === 'epic' || rarity === 'legendary') return 'sword6';
    return 'sword2';
  }
  if (type === 'greatsword' || name.includes('двуручник') || name.includes('великий')) {
    if (rarity === 'epic' || rarity === 'legendary') return 'sword4';
    return 'sword6';
  }
  if (type === 'rapier' || name.includes('рапира') || name.includes('шпага')) {
    if (rarity === 'epic' || rarity === 'legendary') return 'sword5';
    return 'sword3';
  }
  if (type === 'dagger' || name.includes('кинжал') || name.includes('нож') || name.includes('стилет')) {
    return 'sword5';
  }

  // Swords by rarity pool with deterministic diversity
  const swordPools: Record<string, string[]> = {
    legendary: ['sword6', 'sword5'],
    epic: ['sword5', 'sword6', 'sword4'],
    rare: ['sword3', 'sword4'],
    magic: ['sword2', 'sword3'],
    common: ['sword1', 'sword2']
  };
  const pool = swordPools[rarity] || swordPools.common;
  return pool[getDeterministicIndex(weapon.id || weapon.name || 'sword', pool.length)];
}

interface GameIconProps {
  name: string;
  className?: string;
  rarity?: ItemRarity;
  size?: number;
}

export const ResourceIcon: React.FC<{ type: IngredientType; className?: string; size?: number }> = React.memo(({ 
  type, 
  className = 'w-6 h-6',
  size = 24
}) => {
  let src = mglashardImgSrc;
  let dropShadowGlow = 'drop-shadow(0 0 4px rgba(241, 245, 249, 0.95)) drop-shadow(0 0 10px rgba(148, 163, 184, 0.85)) drop-shadow(0 0 18px rgba(100, 116, 139, 0.5))';
  let auraColor = 'rgba(203, 213, 225, 0.35)';
  
  if (type === 'iron_ore') {
    // Осколок мглы игра.png - Ethereal silver-slate moonlight glow
    src = mglashardImgSrc;
    dropShadowGlow = 'drop-shadow(0 0 4px rgba(241, 245, 249, 0.95)) drop-shadow(0 0 10px rgba(148, 163, 184, 0.85)) drop-shadow(0 0 18px rgba(100, 116, 139, 0.5))';
    auraColor = 'rgba(203, 213, 225, 0.35)';
  } else if (type === 'magic_crystal') {
    // Магический кристалл игра.png - Radiant emerald mana glow
    src = magiccrystalImgSrc;
    dropShadowGlow = 'drop-shadow(0 0 4px rgba(134, 239, 172, 0.95)) drop-shadow(0 0 10px rgba(34, 197, 94, 0.9)) drop-shadow(0 0 18px rgba(22, 163, 74, 0.6))';
    auraColor = 'rgba(34, 197, 94, 0.4)';
  } else if (type === 'monster_core') {
    // Ядро монстра игра.png - Luminous electric cyan soul glow
    src = monstercoreImgSrc;
    dropShadowGlow = 'drop-shadow(0 0 4px rgba(125, 211, 252, 0.95)) drop-shadow(0 0 10px rgba(14, 165, 233, 0.9)) drop-shadow(0 0 18px rgba(2, 132, 199, 0.6))';
    auraColor = 'rgba(6, 182, 212, 0.4)';
  } else if (type === 'ancient_rune' || type === 'fire_essence') {
    // Печать пустоты игра.png - Celestial purple void arcane glow
    src = voidsealImgSrc;
    dropShadowGlow = 'drop-shadow(0 0 4px rgba(216, 180, 254, 0.95)) drop-shadow(0 0 10px rgba(168, 85, 247, 0.9)) drop-shadow(0 0 18px rgba(147, 51, 234, 0.6))';
    auraColor = 'rgba(168, 85, 247, 0.4)';
  }

  return (
    <div 
      className={`relative flex items-center justify-center group shrink-0 ${className}`} 
      style={size ? { width: size, height: size } : undefined}
    >
      {/* Radiant Glowing Background Aura */}
      <div 
        className="absolute inset-[-20%] rounded-full pointer-events-none opacity-80 group-hover:opacity-100 transition-opacity blur-[2px]" 
        style={{ background: `radial-gradient(circle, ${auraColor} 0%, rgba(0,0,0,0) 72%)` }} 
      />
      {src ? (
        <img 
          src={src} 
          alt={type} 
          loading="eager"
          decoding="sync"
          draggable={false}
          className="relative z-10 w-full h-full object-contain pointer-events-none group-hover:scale-115 transition-transform duration-200"
          style={{ filter: dropShadowGlow }}
          referrerPolicy="no-referrer"
        />
      ) : null}
    </div>
  );
});

// Slot Silhouette Icons (Clean, crisp slot placeholder images matching user assets)
export const SlotSilhouetteIcon: React.FC<{ slotKey: string; className?: string; size?: number }> = ({
  slotKey,
  className = 'w-5 h-5 sm:w-5.5 sm:h-5.5',
  size
}) => {
  const src = EMPTY_SLOT_IMAGE_SOURCES[slotKey];
  if (src && src.trim() !== '') {
    return (
      <img
        src={src}
        alt={`${slotKey} slot`}
        loading="eager"
        decoding="sync"
        draggable={false}
        className={`object-contain pointer-events-none opacity-70 group-hover:opacity-100 transition-opacity duration-150 filter drop-shadow-[0_2px_5px_rgba(0,0,0,0.8)] ${className}`}
        style={size ? { width: size, height: size } : undefined}
      />
    );
  }

  return (
    <svg viewBox="0 0 24 24" className={className} width={size} height={size} fill="currentColor">
      <circle cx="12" cy="12" r="8" />
    </svg>
  );
};

// Item Graphic Renderer with Rarity Accents & Specific Reference Icons (Matching Photos 1-15)
export const GameItemIcon: React.FC<{ 
  item: { category: EquipmentCategory | 'resource'; icon: string; rarity: ItemRarity; resourceType?: IngredientType; weaponData?: { type?: string }; name?: string; isResource?: boolean }; 
  className?: string; 
  size?: number 
}> = React.memo(({
  item,
  className = 'w-6 h-6',
  size = 24
}) => {
  const anyItem = item as any;
  if (item.category === 'resource' || anyItem.isResource || item.resourceType) {
    let resType = item.resourceType;
    if (!resType) {
      const name = (item.name || '').toLowerCase();
      const icon = (item.icon || '').toLowerCase();
      if (name.includes('осколок') || name.includes('мглы') || icon.includes('iron_ore')) resType = 'iron_ore';
      else if (name.includes('кристалл') || icon.includes('magic_crystal')) resType = 'magic_crystal';
      else if (name.includes('ядро') || name.includes('монстр') || icon.includes('monster_core')) resType = 'monster_core';
      else if (name.includes('печать') || name.includes('пустот') || icon.includes('ancient_rune')) resType = 'ancient_rune';
      else if (name.includes('плам') || name.includes('огнен') || icon.includes('fire_essence')) resType = 'fire_essence';
      else resType = 'iron_ore';
    }
    return <ResourceIcon type={resType} className={className} size={size} />;
  }

  let src: string | undefined = undefined;

  const itemId = anyItem.id;
  const itemImageKey = anyItem.imageKey;

  if (item.category === 'weapon') {
    const weaponData = item.weaponData || { type: 'sword', rarity: item.rarity, name: item.name };
    const imgKey = getWeaponImageKey({ ...weaponData, id: itemId, rarity: item.rarity, name: item.name, imageKey: itemImageKey });
    src = WEAPON_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'helmet') {
    const imgKey = getHelmetImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = HELMET_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'chest') {
    const imgKey = getChestImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = CHEST_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'cloak') {
    const imgKey = getCloakImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = CLOAK_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'bracers') {
    const imgKey = getBracersImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = BRACERS_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'gloves') {
    const imgKey = getGlovesImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = GLOVES_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'boots') {
    const imgKey = getBootsImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = BOOTS_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'ring') {
    const imgKey = getRingImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = RING_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'belt') {
    const imgKey = getBeltImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = BELT_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'pants') {
    const imgKey = getPantsImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = PANTS_IMAGE_SOURCES[imgKey];
  } else if (item.category === 'trinket') {
    const imgKey = getTrinketImageKey({ rarity: item.rarity, name: item.name, id: itemId, imageKey: itemImageKey });
    src = TRINKET_IMAGE_SOURCES[imgKey];
  }

  if (src && src.trim() !== '') {
    const isLegendary = item.rarity === 'legendary';
    const isEpic = item.rarity === 'epic';
    const isMagic = item.rarity === 'magic';
    const glowCol = isLegendary ? 'rgba(251,191,36,0.3)' : isEpic ? 'rgba(192,132,252,0.3)' : isMagic ? 'rgba(74,222,128,0.2)' : 'rgba(56,189,248,0.2)';
    const borderCol = isLegendary ? 'border-amber-500/40' : isEpic ? 'border-purple-500/40' : isMagic ? 'border-emerald-500/40' : 'border-sky-500/40';
    return (
      <div className={`relative flex items-center justify-center rounded bg-slate-950/40 p-0.5 border ${borderCol} shadow-inner group overflow-hidden ${className}`} style={{ width: size, height: size }}>
        <img 
          src={src} 
          alt={item.name || ''} 
          loading="eager"
          decoding="sync"
          draggable={false}
          className="w-full h-full object-contain filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] group-hover:scale-110 transition-transform duration-200 pointer-events-none"
        />
        <div className="absolute inset-0 pointer-events-none group-hover:opacity-20 transition-opacity opacity-10" style={{ background: `radial-gradient(circle, ${glowCol} 0%, transparent 70%)` }} />
      </div>
    );
  }

  const name = (item.name || '').toLowerCase();
  const icon = (item.icon || '').toLowerCase();

  // Resource fallbacks
  if (icon.includes('crystal') || name.includes('кристалл') || name.includes('алмаз')) {
    return <ResourceIcon type="magic_crystal" className={className} size={size} />;
  }
  if (icon.includes('cube') || name.includes('куб') || name.includes('руда')) {
    return <ResourceIcon type="iron_ore" className={className} size={size} />;
  }
  if (icon.includes('eye') || name.includes('глаз') || name.includes('ядро')) {
    return <ResourceIcon type="monster_core" className={className} size={size} />;
  }
  if (icon.includes('potion') || name.includes('зелье') || name.includes('эликсир')) {
    return (
      <svg viewBox="0 0 32 32" className={className} width={size} height={size} fill="none">
        <defs>
          <linearGradient id="potionLiquid" x1="0" y1="0" x2="0" y2="32">
            <stop offset="0%" stopColor="#f472b6" />
            <stop offset="60%" stopColor="#c084fc" />
            <stop offset="100%" stopColor="#7e22ce" />
          </linearGradient>
        </defs>
        <rect x="13" y="3" width="6" height="3" rx="1" fill="#a16207" />
        <rect x="14" y="6" width="4" height="4" fill="#cbd5e1" fillOpacity="0.5" stroke="#94a3b8" strokeWidth="1" />
        <path d="M14 10 L8 18 C5 22 7 28 12 28 L20 28 C25 28 27 22 24 18 L18 10 Z" fill="#cbd5e1" fillOpacity="0.3" stroke="#e2e8f0" strokeWidth="1.5" />
        <path d="M11 15 L9 19 C7 22 8 26 12 26 L20 26 C24 26 25 22 23 19 L21 15 Z" fill="url(#potionLiquid)" />
        <circle cx="14" cy="20" r="1.5" fill="#ffffff" fillOpacity="0.8" />
        <circle cx="18" cy="22" r="1" fill="#ffffff" fillOpacity="0.6" />
      </svg>
    );
  }

  // Color palette by rarity tier (Matching Photos 1-15)
  // Common/Magic/Rare: Neon Blue/Cyan
  // Epic: Deep Magenta/Purple with sparks
  // Legendary: Gold body & haft + Cyan Diamond Gem (#00f0ff) inlaid in center!
  const isLegendary = item.rarity === 'legendary';
  const isEpic = item.rarity === 'epic';

  const primaryColor = isLegendary ? '#f59e0b' : isEpic ? '#c084fc' : '#38bdf8';
  const strokeColor = isLegendary ? '#fde047' : isEpic ? '#f472b6' : '#7dd3fc';
  const fillColor = isLegendary ? '#d97706' : isEpic ? '#9333ea' : '#0284c7';
  const highlightColor = isLegendary ? '#fef08a' : isEpic ? '#f5d0fe' : '#e0f2fe';
  const shadowColor = isLegendary ? '#78350f' : isEpic ? '#581c87' : '#075985';
  const gemFill = isLegendary ? '#00f0ff' : isEpic ? '#f472b6' : '#00f0ff';

  // Determine Equipment Type
  const cat = item.category;
  const wType = (item.weaponData?.type || '').toLowerCase();

  let equipType = 'sword';
  if (cat === 'weapon') {
    if (wType === 'axe' || icon.includes('axe') || name.includes('топор')) equipType = 'axe';
    else if (wType === 'hammer' || icon.includes('hammer') || name.includes('молот')) equipType = 'hammer';
    else if (wType === 'spear' || icon.includes('spear') || name.includes('копье') || name.includes('пика')) equipType = 'spear';
    else equipType = 'sword';
  } else if (cat === 'helmet' || name.includes('шлем') || name.includes('шапка')) equipType = 'helmet';
  else if (cat === 'chest' || name.includes('нагрудник')) equipType = 'chest';
  else if (cat === 'cloak' || name.includes('плащ')) equipType = 'cloak';
  else if (cat === 'bracers' || name.includes('наручи')) equipType = 'bracers';
  else if (cat === 'gloves' || name.includes('перчатк')) equipType = 'gloves';
  else if (cat === 'belt' || name.includes('пояс')) equipType = 'belt';
  else if (cat === 'pants' || name.includes('штаны') || name.includes('поножи')) equipType = 'pants';
  else if (cat === 'boots' || name.includes('ботинки') || name.includes('сапоги')) equipType = 'boots';
  else if (cat === 'ring' || name.includes('кольцо')) equipType = 'ring';
  else if (cat === 'trinket' || name.includes('аксессуар') || name.includes('амулет')) equipType = 'accessory';
  else equipType = 'sword';

  // Render SVG matching Photos 1-15
  return (
    <svg viewBox="0 0 32 32" className={className} width={size} height={size} fill="none">
      <defs>
        <linearGradient id={`grad_body_${equipType}_${item.rarity}`} x1="0" y1="0" x2="32" y2="32">
          <stop offset="0%" stopColor={highlightColor} />
          <stop offset="45%" stopColor={primaryColor} />
          <stop offset="85%" stopColor={fillColor} />
          <stop offset="100%" stopColor={shadowColor} />
        </linearGradient>
        <filter id={`glow_${item.rarity}`} x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation={isEpic || isLegendary ? "1.2" : "0.8"} result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <g filter={`url(#glow_${item.rarity})`}>
        {/* 1. SWORD (Photo 1) */}
        {equipType === 'sword' && (
          <g>
            <polygon points="16,3 20,7 18,21 14,21" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <line x1="16" y1="3" x2="16" y2="21" stroke={highlightColor} strokeWidth="1" />
            <path d="M 8,21 C 12,19 20,19 24,21 L 22,24 C 18,23 14,23 10,24 Z" fill={fillColor} stroke={strokeColor} strokeWidth="1" />
            <rect x="14.5" y="24" width="3" height="5" fill={shadowColor} rx="0.5" />
            <polygon points="16,29 18.5,31 16,33 13.5,31" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,20 18,22 16,24 14,22" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 2. AXE (Photo 2) */}
        {equipType === 'axe' && (
          <g>
            <path d="M 14,31 L 18,29 L 18,6 L 14,8 Z" fill={shadowColor} stroke={strokeColor} strokeWidth="1" />
            <path d="M 14,8 C 5,6 3,17 12,22 C 13,18 14,14 14,8 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <path d="M 18,8 C 27,6 29,17 20,22 C 19,18 18,14 18,8 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <polygon points="16,2 18.5,8 13.5,8" fill={highlightColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,11 19,14 16,17 13,14" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 3. HAMMER (Photo 3) */}
        {equipType === 'hammer' && (
          <g>
            <path d="M 14,31 L 18,29 L 18,14 L 14,16 Z" fill={shadowColor} stroke={strokeColor} strokeWidth="1" />
            <polygon points="5,8 27,8 29,16 3,16" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <polygon points="5,8 27,8 24,4 8,4" fill={highlightColor} opacity="0.6" stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,1 18.5,4 13.5,4" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
            <polygon points="16,9 19,12 16,15 13,12" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 4. SPEAR (Photo 4) */}
        {equipType === 'spear' && (
          <g>
            <line x1="16" y1="33" x2="16" y2="15" stroke={shadowColor} strokeWidth="2.5" strokeLinecap="round" />
            <path d="M 16,2 C 21,8 22,14 19,17 L 16,15 L 13,17 C 10,14 11,8 16,2 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <path d="M 11,17 L 7,20 L 12,21 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 21,17 L 25,20 L 20,21 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,7 18,10 16,13 14,10" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}


        {/* 6. HELMET (Photo 6) */}
        {equipType === 'helmet' && (
          <g>
            {(isEpic || isLegendary) && (
              <>
                <path d="M 7,15 C 2,10 4,2 10,8 Z" fill={highlightColor} stroke={strokeColor} strokeWidth="0.8" />
                <path d="M 25,15 C 30,10 28,2 22,8 Z" fill={highlightColor} stroke={strokeColor} strokeWidth="0.8" />
              </>
            )}
            <path d="M 8,20 C 6,7 26,7 24,20 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <path d="M 8,20 L 10,30 L 14,27 L 12,20 Z" fill={fillColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 24,20 L 22,30 L 18,27 L 20,20 Z" fill={fillColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 10,17 L 22,17 L 20,20 L 12,20 Z" fill="#02081a" stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,9 18.5,12 16,15 13.5,12" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 7. CHEST (Photo 7) */}
        {equipType === 'chest' && (
          <g>
            <path d="M 5,9 C 2,12 4,18 9,15 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 27,9 C 30,12 28,18 23,15 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 9,7 L 16,9 L 23,7 L 26,13 L 23,29 L 9,29 L 6,13 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <path d="M 9,7 L 16,14 L 23,7" stroke={highlightColor} strokeWidth="1" fill="none" />
            <polygon points="16,13 19,17 16,21 13,17" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 8. CLOAK (Photo 8) */}
        {equipType === 'cloak' && (
          <g>
            <path d="M 8,11 C 4,15 3,31 7,32 C 11,29 21,29 25,32 C 29,31 28,15 24,11 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <path d="M 11,4 C 11,1 21,1 21,4 C 25,9 21,11 16,11 C 11,11 7,9 11,4 Z" fill={shadowColor} stroke={strokeColor} strokeWidth="1" />
            <path d="M 13,5 C 13,3 19,3 19,5 C 22,8 19,10 16,10 C 13,10 10,8 13,5 Z" fill="#02081a" />
            <polygon points="16,9 18.5,11.5 16,14 13.5,11.5" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 9. BRACERS (Photo 9) */}
        {equipType === 'bracers' && (
          <g>
            <path d="M 9,7 L 23,7 L 25,28 L 7,28 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <line x1="8.5" y1="13" x2="23.5" y2="13" stroke={highlightColor} strokeWidth="1.5" />
            <line x1="8" y1="21" x2="24" y2="21" stroke={highlightColor} strokeWidth="1.5" />
            <polygon points="16,14 19,17 16,20 13,17" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 10. GLOVES (Photo 10) */}
        {equipType === 'gloves' && (
          <g>
            <path d="M 7,19 L 25,19 L 23,29 L 9,29 Z" fill={fillColor} stroke={strokeColor} strokeWidth="1" />
            <path d="M 9,19 C 9,11 10,3 12,3 C 13,3 13,9 14,9 C 15,9 15,2 17,2 C 18,2 18,9 19,9 C 20,9 21,5 22,6 C 23,7 23,15 22,19 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <polygon points="16,13 18.5,15.5 16,18 13.5,15.5" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 11. BELT (Photo 11) */}
        {equipType === 'belt' && (
          <g>
            <path d="M 3,13 C 11,10 21,10 29,13 C 29,20 21,23 3,20 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <rect x="11" y="11" width="10" height="11" rx="2" fill={fillColor} stroke={strokeColor} strokeWidth="1" />
            <polygon points="16,13 19,16.5 16,20 13,16.5" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 12. PANTS (Photo 12) */}
        {equipType === 'pants' && (
          <g>
            <path d="M 7,7 L 25,7 L 23,31 L 18,31 L 16,17 L 14,17 L 9,31 L 5,31 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1.2" />
            <circle cx="8.5" cy="21" r="2.5" fill={fillColor} stroke={strokeColor} strokeWidth="0.8" />
            <circle cx="23.5" cy="21" r="2.5" fill={fillColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,6 18.5,8.5 16,11 13.5,8.5" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 13. BOOTS (Photo 13) */}
        {equipType === 'boots' && (
          <g>
            <path d="M 5,7 L 13,7 L 11,23 L 14,25 L 14,30 L 3,30 L 3,23 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <path d="M 20,7 L 27,7 L 29,23 L 29,30 L 18,30 L 18,25 L 21,23 Z" fill={`url(#grad_body_${equipType}_${item.rarity})`} stroke={strokeColor} strokeWidth="1" />
            <polygon points="8,11 10,13 8,15 6,13" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
            <polygon points="24,11 26,13 24,15 22,13" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 14. RING (Photo 14) */}
        {equipType === 'ring' && (
          <g>
            <ellipse cx="16" cy="20" rx="10" ry="8" fill="none" stroke={`url(#grad_body_${equipType}_${item.rarity})`} strokeWidth="3.5" />
            <ellipse cx="16" cy="20" rx="10" ry="8" fill="none" stroke={highlightColor} strokeWidth="1" />
            <polygon points="11,9 21,9 18,13 14,13" fill={shadowColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,2 21,8 16,13 11,8" fill={gemFill} stroke="#ffffff" strokeWidth="0.8" />
          </g>
        )}

        {/* 15. ACCESSORY (Photo 15) */}
        {equipType === 'accessory' && (
          <g>
            <path d="M 6,3 C 10,13 22,13 26,3" fill="none" stroke={strokeColor} strokeWidth="1.5" strokeDasharray="3 2" />
            <path d="M 10,14 C 6,11 6,21 13,19 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <path d="M 22,14 C 26,11 26,21 19,19 Z" fill={primaryColor} stroke={strokeColor} strokeWidth="0.8" />
            <polygon points="16,12 21,18 16,28 11,18" fill={gemFill} stroke="#ffffff" strokeWidth="1" />
            <circle cx="16" cy="18" r="1.5" fill="#ffffff" />
          </g>
        )}

        {/* Legendary Sparkle Accents */}
        {isLegendary && (
          <g fill="#ffffff">
            <circle cx="5" cy="5" r="1" />
            <circle cx="27" cy="6" r="1.2" />
            <circle cx="28" cy="26" r="1" />
            <circle cx="4" cy="27" r="1" />
          </g>
        )}
      </g>
    </svg>
  );
});

