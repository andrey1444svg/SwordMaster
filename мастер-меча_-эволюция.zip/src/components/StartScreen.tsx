import React, { useEffect, useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Smartphone, 
  Maximize2, 
  Minimize2,
  Wrench, 
  Flame, 
  X, 
  ShieldAlert, 
  Sparkles,
  Crosshair,
  Layers,
  LayoutGrid
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { enterFullscreenAndLockLandscape, toggleFullscreen } from '../utils/orientation';
import SakuraMenuBackground from './SakuraMenuBackground';

export interface BossOption {
  id: string;
  name: string;
  title: string;
  hp: number;
  icon: React.ElementType;
  color: string;
  borderColor: string;
  badgeColor: string;
  description: string;
  difficulty: string;
}

export const BOSSES_LIST: BossOption[] = [
  {
    id: 'fatty',
    name: 'ТОЛСТЯК',
    title: 'Древний Монокульт',
    hp: 2000,
    icon: Flame,
    color: 'from-rose-600 via-red-600 to-amber-600',
    borderColor: 'border-rose-500/70',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    description: 'Главный босс игры: огненные выстрелы из глаза, наведение шипованной булавой с застреванием в земле и радиальным взрывом.',
    difficulty: 'ГЛАВНЫЙ БОСС'
  },
  {
    id: 'demon_lord',
    name: 'ВЛАДЫКА БЕЗДНЫ',
    title: 'Повелитель Тьмы',
    hp: 3500,
    icon: ShieldAlert,
    color: 'from-purple-600 via-indigo-600 to-rose-600',
    borderColor: 'border-purple-500/70',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    description: 'Элитная форма босса арены Бездны с повышенным запасом здоровья и усиленной атакой.',
    difficulty: 'ЭЛИТНЫЙ БОСС'
  },
  {
    id: 'skeleton_king',
    name: 'КОРОЛЬ СКЕЛЕТОВ',
    title: 'Владыка Некрополя',
    hp: 1500,
    icon: Crosshair,
    color: 'from-sky-600 via-teal-600 to-emerald-600',
    borderColor: 'border-teal-500/70',
    badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
    description: 'Скоростной босс древнего захоронения с силой быстрого давления на арене.',
    difficulty: 'ДРЕВНИЙ БОСС'
  }
];

interface StartScreenProps {
  onStartGame: () => void;
  onStartGameWithBoss?: (bossId: string, level: number) => void;
  onExitGame?: () => void;
  onOpenTesterArmory?: () => void;
  onOpenRoomEditor?: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStartGame,
  onStartGameWithBoss,
  onExitGame,
  onOpenTesterArmory,
  onOpenRoomEditor
}) => {
  const [isPortrait, setIsPortrait] = useState(
    typeof window !== 'undefined' ? window.innerHeight > window.innerWidth : false
  );
  // Controls fullscreen prompt state after device rotation to landscape
  const [needsFullscreenConfirm, setNeedsFullscreenConfirm] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [isTesterModalOpen, setIsTesterModalOpen] = useState(false);
  const [selectedBossId, setSelectedBossId] = useState<string>('fatty');
  const [selectedBossLevel, setSelectedBossLevel] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => {
    return typeof document !== 'undefined' ? Boolean(document.fullscreenElement || (document as any).webkitFullscreenElement) : false;
  });

  useEffect(() => {
    const checkFs = () => {
      setIsFullscreen(Boolean(document.fullscreenElement || (document as any).webkitFullscreenElement));
    };
    document.addEventListener('fullscreenchange', checkFs);
    document.addEventListener('webkitfullscreenchange', checkFs);
    return () => {
      document.removeEventListener('fullscreenchange', checkFs);
      document.removeEventListener('webkitfullscreenchange', checkFs);
    };
  }, []);

  const handleToggleFullscreen = async () => {
    const res = await toggleFullscreen();
    setIsFullscreen(res);
  };

  useEffect(() => {
    const handleResize = () => {
      const portrait = window.innerHeight > window.innerWidth;
      setIsPortrait(prev => {
        // If we transitioned from portrait to landscape, show fullscreen activation prompt
        if (prev && !portrait) {
          setNeedsFullscreenConfirm(true);
        }
        return portrait;
      });
    };
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  const handleFullscreenPromptConfirm = async () => {
    try {
      await enterFullscreenAndLockLandscape();
    } catch {
      // Ignore fullscreen restrictions in iframe
    }
    setNeedsFullscreenConfirm(false);
  };

  const handleStart = async () => {
    if (isExiting) return;
    setIsExiting(true);
    try {
      await enterFullscreenAndLockLandscape();
    } catch {
      // Ignore fullscreen restrictions in iframe
    }
    setTimeout(() => {
      onStartGame();
    }, 1000);
  };

  const handleStartBossTeleport = async (bossId: string) => {
    if (isExiting) return;
    setIsTesterModalOpen(false);
    setIsExiting(true);
    try {
      await enterFullscreenAndLockLandscape();
    } catch {
      // Ignore fullscreen restrictions in iframe
    }
    setTimeout(() => {
      if (onStartGameWithBoss) {
        onStartGameWithBoss(bossId, selectedBossLevel);
      } else {
        onStartGame();
      }
    }, 900);
  };

  const handleResetOrExit = () => {
    if (isExiting) return;
    if (onExitGame) {
      onExitGame();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black overflow-hidden select-none">
      {/* 1. Panoramic Dynamic Scene Background with Floating Petals */}
      <SakuraMenuBackground />

      {/* Fade to black overlay on exit */}
      {isExiting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.0, ease: 'easeInOut' }}
          className="absolute inset-0 z-50 bg-black pointer-events-none"
        />
      )}

      {/* 2. Portrait Orientation Guard for Mobile Devices */}
      {isPortrait ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-white text-center p-8 bg-slate-950/95 rounded-3xl border border-rose-500/40 z-20 space-y-6 max-w-sm mx-auto shadow-2xl shadow-rose-950/60"
        >
          <motion.div 
            animate={{ rotate: 90 }}
            transition={{ repeat: Infinity, duration: 2, repeatType: "reverse", ease: "easeInOut" }}
            className="flex justify-center"
          >
            <Smartphone className="w-20 h-20 text-rose-500" />
          </motion.div>
          <div className="space-y-2">
            <p className="text-xl font-bold text-rose-100">Пожалуйста, поверните устройство</p>
            <p className="text-xs text-slate-300">Для игры требуется альбомная ориентация экрана</p>
          </div>
        </motion.div>
      ) : needsFullscreenConfirm ? (
        /* 2B. Fullscreen Request Modal after Rotation */
        <motion.div 
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-white text-center p-7 bg-slate-950/95 rounded-3xl border-2 border-rose-500/60 z-30 space-y-5 max-w-sm mx-auto shadow-[0_0_50px_rgba(244,63,94,0.4)]"
        >
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-400/50 flex items-center justify-center text-rose-300 shadow-lg shadow-rose-950/50">
              <Maximize2 className="w-8 h-8" />
            </div>
          </div>
          <div className="space-y-1.5">
            <h3 
              style={{ fontFamily: "'Russo One', 'Cinzel Decorative', sans-serif" }}
              className="text-lg font-black text-rose-100 uppercase tracking-wider"
            >
              Альбомный режим
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Нажмите кнопку ниже, чтобы развернуть игру на весь экран и войти в главное меню.
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleFullscreenPromptConfirm}
            style={{
              clipPath: 'polygon(12px 0%, calc(100% - 12px) 0%, 100% 50%, calc(100% - 12px) 100%, 12px 100%, 0% 50%)'
            }}
            className="w-full py-3.5 px-6 bg-gradient-to-r from-rose-600 via-red-500 to-rose-600 hover:from-rose-500 hover:to-rose-500 text-white font-black text-sm tracking-[0.18em] shadow-xl shadow-red-950/80 border-y border-rose-300/80 cursor-pointer flex items-center justify-center gap-2 transition-all"
          >
            <Maximize2 className="w-4 h-4" />
            <span>РАЗВЕРНУТЬ НА ВЕСЬ ЭКРАН</span>
          </motion.button>
        </motion.div>
      ) : (
        /* 3. Authentic Japanese Calligraphy Title & Action Interface */
        <motion.div 
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative z-10 flex flex-col items-center justify-center w-full max-w-2xl px-4 text-center select-none"
        >
          {/* Main Title Area with Sumi-e Brush Splash Backdrop */}
          <div className="relative flex flex-col items-center justify-center my-3 py-4 w-full">
            {/* Authentic Sumi-e Black Ink Brush Stroke & Splash Behind Text */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-95">
              <svg 
                viewBox="0 0 700 180" 
                className="w-full max-w-[620px] h-[140px] filter drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]"
                preserveAspectRatio="none"
              >
                {/* Horizontal textured main ink splash */}
                <path 
                  d="M20,95 Q70,75 140,88 T280,80 T420,92 T560,78 Q640,85 680,95 Q640,110 560,105 T420,115 T280,102 T140,112 Q60,118 20,95 Z" 
                  fill="#0c0714" 
                />
                {/* Torn dry-brush top and bottom bristles */}
                <path 
                  d="M45,82 C110,62 210,65 350,60 C480,55 580,68 655,80 C600,68 490,62 350,66 C210,70 110,72 45,82 Z" 
                  fill="#15091c" 
                />
                <path 
                  d="M60,108 C130,126 230,122 360,128 C490,132 580,120 640,110 C570,122 470,124 350,120 C230,116 130,118 60,108 Z" 
                  fill="#15091c" 
                />
                {/* Ink spatters and mist */}
                <circle cx="95" cy="62" r="3.5" fill="#0d0713" />
                <circle cx="115" cy="52" r="2.2" fill="#0d0713" />
                <circle cx="160" cy="45" r="1.8" fill="#0d0713" />
                <circle cx="585" cy="55" r="3.2" fill="#0d0713" />
                <circle cx="615" cy="64" r="2.5" fill="#0d0713" />
                <circle cx="540" cy="132" r="2.5" fill="#0d0713" />
                <circle cx="480" cy="138" r="3" fill="#0d0713" />
                <circle cx="210" cy="134" r="2.8" fill="#0d0713" />
              </svg>
            </div>

            {/* Stylized Japanese-Asian Brush Calligraphy Title */}
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.25, duration: 0.7 }}
              className="relative flex items-center justify-center px-4 py-2"
            >
              {/* High-Contrast Luminous Master of the Sword Title */}
              <h1 
                style={{ 
                  color: '#ffffff',
                  fontStyle: 'normal',
                  textDecorationLine: 'none',
                  fontFamily: "'Ruslan Display', 'Shojumaru', 'Dela Gothic One', 'Russo One', serif",
                  letterSpacing: '0.14em',
                  textShadow: '0 0 35px rgba(255, 100, 130, 0.95), 0 0 15px rgba(255, 255, 255, 0.9), 0 4px 12px rgba(0, 0, 0, 0.98)'
                }}
                className="text-4xl sm:text-5xl md:text-6xl font-black uppercase select-none tracking-wider filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]"
              >
                МАСТЕР МЕЧА
              </h1>
            </motion.div>

            {/* Horizontal Line with Centered Stylized Cherry Blossom (Sakura) */}
            <div className="relative flex items-center justify-center w-72 md:w-96 my-1.5">
              <div className="flex-1 h-[2px] bg-gradient-to-r from-transparent via-rose-500 to-rose-300" />
              <div className="mx-3 flex items-center justify-center">
                {/* 5-Petal Sakura Blossom Vector Crest */}
                <svg viewBox="0 0 24 24" className="w-7 h-7 filter drop-shadow-[0_0_10px_rgba(244,63,94,0.9)]">
                  {/* Petals */}
                  <g fill="#f43f5e">
                    <circle cx="12" cy="7" r="3.6" />
                    <circle cx="16.5" cy="10.5" r="3.6" />
                    <circle cx="15" cy="16" r="3.6" />
                    <circle cx="9" cy="16" r="3.6" />
                    <circle cx="7.5" cy="10.5" r="3.6" />
                  </g>
                  <g fill="#ffe4e6">
                    <circle cx="12" cy="7.5" r="2.2" />
                    <circle cx="15.8" cy="10.8" r="2.2" />
                    <circle cx="14.4" cy="15.2" r="2.2" />
                    <circle cx="9.6" cy="15.2" r="2.2" />
                    <circle cx="8.2" cy="10.8" r="2.2" />
                  </g>
                  {/* Golden Center Pistil */}
                  <circle cx="12" cy="12" r="2.4" fill="#fde047" />
                </svg>
              </div>
              <div className="flex-1 h-[2px] bg-gradient-to-l from-transparent via-rose-500 to-rose-300" />
            </div>
          </div>

          {/* Action Menu Buttons */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.6 }}
            className="flex flex-col items-center justify-center gap-3.5 w-full max-w-xs mt-2"
          >
            {/* Primary Button: НОВАЯ ИГРА (Ruby Faceted Wooden Plaque) */}
            <motion.button
              disabled={isExiting}
              whileHover={isExiting ? {} : { scale: 1.04 }}
              whileTap={isExiting ? {} : { scale: 0.96 }}
              onClick={handleStart}
              style={{
                clipPath: 'polygon(14px 0%, calc(100% - 14px) 0%, 100% 50%, calc(100% - 14px) 100%, 14px 100%, 0% 50%)'
              }}
              className={`relative w-full py-4 px-8 bg-gradient-to-r from-rose-700 via-red-600 to-rose-700 hover:from-rose-600 hover:via-red-500 hover:to-rose-600 text-white font-black text-base md:text-lg shadow-xl shadow-red-950/80 border-y-2 border-rose-400/80 flex items-center justify-center gap-3 tracking-[0.2em] transition-all group overflow-hidden ${
                isExiting ? 'opacity-80 cursor-not-allowed pointer-events-none' : 'cursor-pointer'
              }`}
            >
              {/* Shimmer sweep effect */}
              <div className="absolute inset-0 w-1/2 h-full bg-white/15 -skew-x-12 transform -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000" />

              <Play className="w-5 h-5 fill-white text-white filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]" />
              <span 
                style={{ fontFamily: "'Russo One', 'Cinzel Decorative', sans-serif" }}
                className="drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
              >
                НОВАЯ ИГРА
              </span>
            </motion.button>

            {/* Secondary Button: РЕДАКТОР КОМНАТ (Sapphire Faceted Plaque) */}
            {onOpenRoomEditor && (
              <motion.button
                disabled={isExiting}
                whileHover={isExiting ? {} : { scale: 1.03 }}
                whileTap={isExiting ? {} : { scale: 0.97 }}
                onClick={onOpenRoomEditor}
                style={{
                  clipPath: 'polygon(10px 0%, calc(100% - 10px) 0%, 100% 50%, calc(100% - 10px) 100%, 10px 100%, 0% 50%)'
                }}
                className={`w-full py-3 px-6 bg-gradient-to-r from-sky-950 via-blue-900 to-sky-950 hover:from-sky-800 hover:via-blue-700 hover:to-sky-800 text-sky-200 hover:text-white font-bold text-xs md:text-sm border-y border-sky-400/80 shadow-lg shadow-sky-950/70 flex items-center justify-center gap-2.5 tracking-[0.15em] transition-all cursor-pointer group`}
              >
                <LayoutGrid className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
                <span style={{ fontFamily: "'Russo One', 'Cinzel Decorative', sans-serif" }}>
                  РЕДАКТОР КОМНАТ
                </span>
              </motion.button>
            )}

            {/* Tertiary Button: СБРОСИТЬ В МЕНЮ (Dark Charcoal Slate Plaque) */}
            {onExitGame && (
              <motion.button
                disabled={isExiting}
                whileHover={isExiting ? {} : { scale: 1.03 }}
                whileTap={isExiting ? {} : { scale: 0.97 }}
                onClick={handleResetOrExit}
                style={{
                  clipPath: 'polygon(10px 0%, calc(100% - 10px) 0%, 100% 50%, calc(100% - 10px) 100%, 10px 100%, 0% 50%)'
                }}
                className={`w-full py-2.5 px-6 bg-slate-950/85 hover:bg-slate-900 text-slate-300 hover:text-white font-bold text-xs md:text-sm border-y border-slate-700/80 hover:border-rose-500/50 shadow-lg shadow-black/70 flex items-center justify-center gap-2 tracking-[0.15em] transition-all ${
                  isExiting ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer'
                }`}
              >
                <RotateCcw className="w-4 h-4 text-slate-300" />
                <span style={{ fontFamily: "'Russo One', 'Cinzel Decorative', sans-serif" }}>
                  СБРОСИТЬ В МЕНЮ
                </span>
              </motion.button>
            )}
          </motion.div>
        </motion.div>
      )}

      {/* 4. Top-Right Buttons: Room Editor, Tester Mode & Fullscreen */}
      {!isPortrait && !needsFullscreenConfirm && (
        <div className="absolute top-4 right-4 z-40 flex items-center gap-2">
          {/* Fullscreen Mode Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleToggleFullscreen}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/95 border border-rose-500/60 text-rose-300 font-bold text-xs uppercase tracking-wider shadow-lg shadow-rose-950/50 hover:bg-slate-900 hover:border-rose-400 hover:text-rose-200 transition-all cursor-pointer group"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform duration-300" />
            ) : (
              <Maximize2 className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform duration-300" />
            )}
            <span style={{ fontFamily: "'Russo One', sans-serif" }} className="text-[11px] sm:text-xs">
              {isFullscreen ? 'В ОКНЕ' : 'ВО ВЕСЬ ЭКРАН'}
            </span>
          </motion.button>

          {onOpenRoomEditor && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenRoomEditor}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/95 border border-sky-500/60 text-sky-300 font-bold text-xs uppercase tracking-wider shadow-lg shadow-sky-950/50 hover:bg-slate-900 hover:border-sky-400 hover:text-sky-200 transition-all cursor-pointer group"
            >
              <LayoutGrid className="w-4 h-4 text-sky-400 group-hover:rotate-12 transition-transform duration-300" />
              <span style={{ fontFamily: "'Russo One', sans-serif" }} className="text-[11px] sm:text-xs">
                РЕДАКТОР УРОВНЕЙ
              </span>
            </motion.button>
          )}

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              if (onOpenTesterArmory) {
                onOpenTesterArmory();
              } else {
                setIsTesterModalOpen(true);
              }
            }}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950/95 border border-amber-500/60 text-amber-300 font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-950/50 hover:bg-slate-900 hover:border-amber-400 hover:text-amber-200 transition-all cursor-pointer group"
          >
            <Wrench className="w-4 h-4 text-amber-400 group-hover:rotate-45 transition-transform duration-300" />
            <span style={{ fontFamily: "'Russo One', sans-serif" }} className="text-[11px] sm:text-xs">
              ТЕСТИРОВЩИК
            </span>
          </motion.button>
        </div>
      )}

      {/* 5. Tester Boss Selector Modal Overlay */}
      <AnimatePresence>
        {isTesterModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90"
          >
            <motion.div
              initial={{ scale: 0.9, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 15 }}
              className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-950/95 rounded-2xl border-2 border-amber-500/60 shadow-[0_0_50px_rgba(245,158,11,0.3)] overflow-hidden text-slate-100"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-900/80">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 
                      style={{ fontFamily: "'Russo One', sans-serif" }}
                      className="text-base sm:text-lg font-black text-amber-300 uppercase tracking-wide flex items-center gap-2"
                    >
                      <span>РЕЖИМ ТЕСТИРОВЩИКА</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono">
                        DEV TOOLS
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Мгновенная телепортация на арену главного босса Толстяка
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsTesterModalOpen(false)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body with Boss Cards Grid */}
              <div className="p-4 sm:p-5 overflow-y-auto space-y-4 custom-scrollbar flex-1">
                {/* Level Tier Selector Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-slate-300">Уровень сложности босса:</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map(lvl => (
                      <button
                        key={lvl}
                        onClick={() => setSelectedBossLevel(lvl)}
                        className={`px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                          selectedBossLevel === lvl
                            ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                        }`}
                      >
                        Ур. {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tester Loadout Info Badge */}
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                  <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>В режиме тестировщика персонажу выдаётся случайное магическое оружие 2-го уровня и ресурсы для тестов кузницы.</span>
                </div>

                {/* Boss Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {BOSSES_LIST.map((boss) => {
                    const BossIcon = boss.icon;
                    const isSelected = selectedBossId === boss.id;
                    return (
                      <motion.div
                        key={boss.id}
                        whileHover={{ y: -3 }}
                        onClick={() => setSelectedBossId(boss.id)}
                        className={`relative flex flex-col justify-between p-4 rounded-xl border-2 transition-all cursor-pointer ${
                          isSelected
                            ? `${boss.borderColor} bg-slate-900/90 shadow-lg shadow-slate-950/80 ring-2 ring-amber-500/50`
                            : 'border-slate-800 hover:border-slate-700 bg-slate-900/40 hover:bg-slate-900/70'
                        }`}
                      >
                        <div>
                          {/* Boss Card Header */}
                          <div className="flex items-center justify-between mb-2.5">
                            <div className={`p-2.5 rounded-xl bg-gradient-to-br ${boss.color} text-white shadow-md`}>
                              <BossIcon className="w-5 h-5" />
                            </div>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${boss.badgeColor}`}>
                              {boss.difficulty}
                            </span>
                          </div>

                          {/* Boss Name & Title */}
                          <h4 
                            style={{ fontFamily: "'Russo One', sans-serif" }}
                            className="text-sm font-black text-white tracking-wide uppercase"
                          >
                            {boss.name}
                          </h4>
                          <p className="text-[11px] font-semibold text-amber-400/90 mb-2">
                            {boss.title}
                          </p>

                          {/* Description */}
                          <p className="text-[11px] text-slate-300 leading-relaxed mb-3 line-clamp-2">
                            {boss.description}
                          </p>
                        </div>

                        {/* Action Teleport Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedBossId(boss.id);
                            handleStartBossTeleport(boss.id);
                          }}
                          className={`w-full py-2 px-3 rounded-lg font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-gradient-to-r ${boss.color} hover:brightness-110 text-white shadow-md shadow-black/50`}
                        >
                          <Crosshair className="w-3.5 h-3.5" />
                          <span>ТЕЛЕПОРТ К БОССУ</span>
                        </button>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Готово к мгновенному старту арены
                </span>
                <button
                  onClick={() => setIsTesterModalOpen(false)}
                  className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition-colors cursor-pointer"
                >
                  Закрыть
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

