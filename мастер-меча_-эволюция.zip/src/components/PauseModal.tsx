import React from 'react';
import { soundManager } from '../utils/audio';
import { 
  Play, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Home, 
  ShieldAlert, 
  Briefcase,
  Wrench,
  LayoutGrid
} from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenInventory: () => void;
  onQuitToMenu: () => void;
  onOpenTesterArmory?: () => void;
  onOpenRoomEditor?: () => void;
  showShadows: boolean;
  setShowShadows: (show: boolean) => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onOpenInventory,
  onQuitToMenu,
  onOpenTesterArmory,
  onOpenRoomEditor,
  showShadows,
  setShowShadows
}) => {
  const [isMuted, setIsMuted] = React.useState<boolean>(soundManager.getMuted());

  const handleToggleSound = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl p-6 text-center text-white space-y-5">
        <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-300">
          ПАУЗА
        </h2>

        <div className="space-y-2.5">
          <button
            onClick={onResume}
            className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white font-extrabold rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" /> Продолжить
          </button>

          <button
            onClick={onOpenInventory}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Briefcase className="w-4 h-4 text-sky-400" /> Инвентарь & Навыки
          </button>

          {onOpenTesterArmory && (
            <button
              onClick={onOpenTesterArmory}
              className="w-full py-3 bg-amber-950/50 hover:bg-amber-900/70 border border-amber-500/50 text-amber-300 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-amber-950/30"
            >
              <Wrench className="w-4 h-4 text-amber-400" /> Арсенал Тестировщика
            </button>
          )}

          {onOpenRoomEditor && (
            <button
              onClick={onOpenRoomEditor}
              className="w-full py-3 bg-sky-950/50 hover:bg-sky-900/70 border border-sky-500/50 text-sky-300 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-sky-950/30"
            >
              <LayoutGrid className="w-4 h-4 text-sky-400" /> Редактор Комнат / Уровней
            </button>
          )}

          <button
            onClick={handleToggleSound}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            Звук: {isMuted ? 'Выключен' : 'Включен'}
          </button>

          <button
            onClick={() => setShowShadows(!showShadows)}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {showShadows ? 'Тени: Вкл' : 'Тени: Выкл'}
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" /> Начать заново
          </button>

          <button
            onClick={onQuitToMenu}
            className="w-full py-3 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" /> Главное Меню
          </button>
        </div>
      </div>
    </div>
  );
};
