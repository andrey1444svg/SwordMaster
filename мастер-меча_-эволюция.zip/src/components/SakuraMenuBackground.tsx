import React, { useEffect, useRef } from 'react';
import menuBackgroundImgSrc from '../assets/images/Background.png';

interface Petal {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  rotation: number;
  rotationSpeed: number;
  flip: number;
  flipSpeed: number;
  opacity: number;
  color: string;
}

const PETAL_COLORS = [
  'rgba(255, 183, 197, 0.85)',
  'rgba(255, 192, 203, 0.8)',
  'rgba(244, 114, 182, 0.75)',
  'rgba(251, 113, 133, 0.7)',
  'rgba(254, 226, 226, 0.9)',
];

const SakuraMenuBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Atmospheric Floating Sakura Petals Canvas Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleCanvasResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleCanvasResize);
    document.addEventListener('fullscreenchange', handleCanvasResize);
    document.addEventListener('webkitfullscreenchange', handleCanvasResize);

    const petalCount = 42;
    const petals: Petal[] = Array.from({ length: petalCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: 9 + Math.random() * 11,
      speedX: 0.6 + Math.random() * 1.4,
      speedY: 0.8 + Math.random() * 1.5,
      rotation: Math.random() * Math.PI * 2,
      rotationSpeed: (Math.random() - 0.5) * 0.03,
      flip: Math.random() * Math.PI * 2,
      flipSpeed: 0.02 + Math.random() * 0.04,
      opacity: 0.45 + Math.random() * 0.45,
      color: PETAL_COLORS[Math.floor(Math.random() * PETAL_COLORS.length)]
    }));

    let windTime = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      windTime += 0.015;
      const windForce = Math.sin(windTime) * 0.8;

      for (let i = 0; i < petals.length; i++) {
        const p = petals[i];
        p.x += p.speedX + windForce;
        p.y += p.speedY;
        p.rotation += p.rotationSpeed;
        p.flip += p.flipSpeed;

        // Wrap around viewport boundaries
        if (p.y > height + 25) {
          p.y = -25;
          p.x = Math.random() * width;
        }
        if (p.x > width + 25) {
          p.x = -25;
        } else if (p.x < -25) {
          p.x = width + 25;
        }

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        // 3D flutter effect using cosine scaling
        const scaleX = Math.cos(p.flip);
        ctx.scale(scaleX, 1);
        ctx.globalAlpha = p.opacity;

        // Sakura petal curve
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(0, -p.size);
        ctx.bezierCurveTo(
          p.size * 0.6, -p.size * 0.6,
          p.size * 0.7, p.size * 0.3,
          0, p.size
        );
        ctx.bezierCurveTo(
          -p.size * 0.7, p.size * 0.3,
          -p.size * 0.6, -p.size * 0.6,
          0, -p.size
        );
        ctx.fill();

        // Delicate spine highlight
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, -p.size * 0.7);
        ctx.lineTo(0, p.size * 0.6);
        ctx.stroke();

        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleCanvasResize);
      document.removeEventListener('fullscreenchange', handleCanvasResize);
      document.removeEventListener('webkitfullscreenchange', handleCanvasResize);
    };
  }, []);

  return (
    <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden bg-slate-950 select-none">
      {/* 1. Permanent clean high-resolution background artwork - completely stable in fullscreen */}
      <img
        src={menuBackgroundImgSrc}
        alt="Menu Background"
        className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
        decoding="async"
        loading="eager"
      />

      {/* 2. Floating Sakura Petals Canvas Animation */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* 3. Vignette and gradient overlays for menu contrast */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-slate-950/50 pointer-events-none z-10" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0)_30%,rgba(2,1,6,0.7)_100%)] pointer-events-none z-10" />
    </div>
  );
};

export default SakuraMenuBackground;
