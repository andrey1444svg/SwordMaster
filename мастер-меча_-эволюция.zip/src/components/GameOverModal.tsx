import React from 'react';
import { CharacterStats, Weapon, ResourceInventory, DifficultyConfig } from '../types/game';
import { 
  RotateCcw, 
  Crown, 
  Skull, 
  Swords, 
  Briefcase, 
  Boxes, 
  Home 
} from 'lucide-react';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewRecord: boolean;
  stats: CharacterStats;
  difficulty: DifficultyConfig;
  resources: ResourceInventory;
  weaponsCount: number;
  onRestart: () => void;
  onQuitToMenu: () => void;
  isVictory?: boolean;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  onRestart,
  onQuitToMenu,
  isVictory = false
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 animate-fade-in">
      <div className={`relative w-full max-w-[320px] bg-slate-900 border-2 ${isVictory ? 'border-amber-500/70 shadow-[0_0_40px_rgba(245,158,11,0.25)]' : 'border-slate-800 shadow-2xl'} rounded-2xl p-6 text-center text-white space-y-5`}>
        
        {/* Title */}
        <div className="space-y-2">
          {isVictory ? (
            <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mx-auto shadow-md">
              <Crown className="w-8 h-8 animate-bounce text-amber-400" />
            </div>
          ) : (
            <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-center mx-auto shadow-md">
              <Skull className="w-6 h-6 animate-pulse" />
            </div>
          )}
          
          <h2 className={`text-2xl font-black tracking-wider ${isVictory ? 'text-amber-400' : 'text-rose-500'}`}>
            {isVictory ? 'ИГРА ПРОЙДЕНА!' : 'ГЕРОЙ ПАЛ'}
          </h2>
          <p className="text-xs text-slate-400">
            {isVictory 
              ? 'Вы зачистили все 20 уровней цитадели и победили Тьму!' 
              : 'Ваше путешествие оборвалось в глубинах лабиринта.'}
          </p>
        </div>

        {/* Victory/Defeat Details */}
        {isVictory && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs space-y-1">
            <p className="text-amber-300 font-bold">🎉 Великий Триумф!</p>
            <p className="text-slate-300">Легендарный герой очистил Цитадель Времени и навсегда вписал свое имя в летопись!</p>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2.5">
          <button
            onClick={onRestart}
            className={`w-full py-3 ${isVictory ? 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500' : 'bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500'} text-white font-black rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2`}
          >
            <RotateCcw className="w-3.5 h-3.5" /> {isVictory ? 'Играть снова' : 'Заново'}
          </button>

          <button
            onClick={onQuitToMenu}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <Home className="w-3.5 h-3.5" /> Главное Меню
          </button>
        </div>

      </div>
    </div>
  );
};
