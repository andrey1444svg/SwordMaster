import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Intercept benign browser extension messaging failures (e.g. ad blockers / translators)
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    const msg = event?.message || '';
    if (
      msg.includes('Could not establish connection') ||
      msg.includes('Receiving end does not exist') ||
      msg.includes('allowed')
    ) {
      event.stopImmediatePropagation?.();
      event.preventDefault?.();
      return true;
    }
  }, true);

  window.addEventListener('unhandledrejection', (event) => {
    const reasonStr = String(event?.reason?.message || event?.reason || '');
    if (
      reasonStr.includes('Could not establish connection') ||
      reasonStr.includes('Receiving end does not exist') ||
      reasonStr.includes('allowed')
    ) {
      event.stopImmediatePropagation?.();
      event.preventDefault?.();
    }
  }, true);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
