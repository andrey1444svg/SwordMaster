export type DifficultyLevel = 'easy' | 'normal' | 'hard' | 'nightmare';

export interface DifficultyConfig {
  id: DifficultyLevel;
  name: string;
  description: string;
  hpMultiplier: number;
  damageMultiplier: number;
  xpMultiplier: number;
  dropRateMultiplier: number;
  scoreMultiplier: number;
  color: string;
  badge: string;
}

export type IngredientType = 
  | 'iron_ore' 
  | 'magic_crystal' 
  | 'monster_core' 
  | 'ancient_rune' 
  | 'fire_essence';

export interface Ingredient {
  id: IngredientType;
  name: string;
  description: string;
  icon: string;
  rarity: ItemRarity;
  color: string;
}

export type ResourceInventory = Record<IngredientType, number>;

export type EquipmentSlotType = 
  | 'weapon'
  | 'helmet'
  | 'cloak'
  | 'chest'
  | 'bracers'
  | 'gloves'
  | 'belt'
  | 'pants'
  | 'boots'
  | 'ring1'
  | 'ring2'
  | 'trinket1'
  | 'trinket2';

export type EquipmentCategory = 
  | 'weapon'
  | 'helmet'
  | 'cloak'
  | 'chest'
  | 'bracers'
  | 'gloves'
  | 'belt'
  | 'pants'
  | 'boots'
  | 'ring'
  | 'trinket';

export type ItemRarity = 'common' | 'magic' | 'rare' | 'epic';

export interface InventoryItemStats {
  damageMin?: number;
  damageMax?: number;
  armor?: number;
  hp?: number;
  critChance?: number;     // e.g. 0.05 for +5%
  critMultiplier?: number; // e.g. 0.10 for +10%
  speed?: number;
  mana?: number;
  strength?: number;
  agility?: number;
  endurance?: number;
  intelligence?: number;
  vampirism?: number;      // e.g. 1 for 1%
  chainLightningChance?: number; // e.g. 0.10 for 10% chance
  chainLightningDamageRatio?: number; // e.g. 0.50 for 50% damage ratio
  attackRecoverySpeed?: number; // Attack recovery speed percentage bonus e.g. 25 for +25%
  doubleStrikeChance?: number; // e.g. 0.05 for 5% chance
  bleedChance?: number;       // e.g. 0.05 for 5%
  bleedDamageRatio?: number;  // e.g. 0.30 for 30%
  stunChance?: number;
  bonusDamageMultiplier?: number;
  ruthlessnessRatio?: number; // e.g. 0.002 for +0.2% axe damage per 1% missing target HP
}

export interface InventoryItem {
  id: string;
  name: string;
  category: EquipmentCategory | 'resource';
  rarity: ItemRarity;
  icon: string;
  description: string;
  level: number;
  stats: InventoryItemStats;
  salvageYield?: {
    iron_ore?: number;
    magic_crystal?: number;
    monster_core?: number;
    ancient_rune?: number;
    fire_essence?: number;
  };
  weaponData?: Weapon;
  quantity?: number;
  resourceType?: IngredientType;
  isResource?: boolean;
  imageKey?: string;
  chainLightningChance?: number;
  chainLightningDamageRatio?: number;
  attackRecoverySpeed?: number;
  vampirism?: number;
  ruthlessnessRatio?: number;
}

export type EquipmentState = Record<EquipmentSlotType, InventoryItem | null>;

export type WeaponRarity = 'common' | 'rare' | 'epic';

export type WeaponType = 
  | 'sword'
  | 'katana' 
  | 'axe'
  | 'hammer' 
  | 'spear'
  | 'rapier' 
  | 'greatsword' 
  | 'dagger'
  | 'fist';

export type WeaponElement = 'none' | 'fire' | 'ice' | 'wind' | 'chaos';

export interface Weapon {
  id: string;
  name: string;
  type: WeaponType;
  rarity: WeaponRarity;
  minDamage: number;
  maxDamage: number;
  length: number;       // blade length px (e.g. 70 - 110)
  weight: number;       // physics weight factor (0.5 light to 1.8 heavy)
  critChance: number;   // 0.05 = 5%
  critMultiplier: number; // 1.5x, 2.0x, etc.
  element: WeaponElement;
  upgradeLevel: number; // 0 to 10
  maxUpgradeLevel: number;
  description: string;
  color: string;
  glowColor: string;
  iconName: string;
  stunChance?: number; // e.g. 0.01 for 1%
  stunDurationMin?: number; // seconds
  stunDurationMax?: number; // seconds
  bonusDamageMultiplier?: number; // e.g. 0.10 for 10%
  doubleStrikeChance?: number; // e.g. 0.05 for 5% chance
  bleedChance?: number;
  bleedDamageRatio?: number;
  ruthlessnessRatio?: number; // Axe special ability: damage bonus ratio per 1% missing target HP
}

export interface CharacterStats {
  level: number;
  xp: number;
  maxXp: number;
  statPoints: number;
  
  // Primary Attributes
  strength: number;     // 1 сила = +0.50 ед. урона
  agility: number;      // 1 ловкость = +0.15% крит шанс, +0.17% крит урон
  endurance: number;    // 1 выносливость = +3 ед. макс. ХП
  intelligence: number; // 1 интеллект = +3.0 ед. макс. маны

  // Dynamic Pools
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;

  moveSpeed: number;        // base 7
  jumpPower: number;        // base -18
  armor?: number;           // Total armor from equipped gear
  bonusDamage?: number;     // Extra damage from rings/accessories/gear
  minDamage?: number;       // Calculated total minimum attack damage
  maxDamage?: number;       // Calculated total maximum attack damage
  vampirism?: number;       // Total vampirism percentage from gear
  effectiveAgi?: number;    // Total agility including gear bonuses
  attackRecoverySpeed?: number; // Total attack recovery speed percentage from gear
}

export type SkillId = 'none';

export interface Skill {
  id: string;
  name: string;
  description: string;
  icon: string;
  key: string;
  level: number;
  maxLevel: number;
  cooldown: number;
  currentCooldown: number;
  isActive: boolean;
  activeDuration: number;
  activeTimer: number;
}

export interface UpgradeRecipe {
  costIngredients: Partial<Record<IngredientType, number>>;
  damageGain: number;     // +min/max damage gain
  lengthGain: number;     // +length gain
  critGain: number;       // +crit gain
  critMultiplierGain: number; // +crit multiplier gain
}

export interface ActiveBleed {
  id: string;
  durationTimer: number;
  tickTimer: number;
  baseTickDamage: number;
}

export interface LootDrop {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'weapon' | 'ingredient' | 'hp' | 'xp' | 'equipment';
  ingredientType?: IngredientType;
  weaponData?: Weapon;
  itemData?: InventoryItem;
  rarity?: ItemRarity;
  amount?: number;
  alive: boolean;
  yOffset?: number;
  pickupDelay?: number;
}

export interface Chest {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  opened: boolean;
  type: 'wooden' | 'gold';
  isFirstLevelStartWeapon?: boolean;
  isBossChest?: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  gravity?: number;
  shape?: 'circle' | 'spark' | 'ring';
  targetX?: number;
  targetY?: number;
  alpha?: number;
}

export interface DamageText {
  id: string;
  text: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  isCrit?: boolean;
  color?: string;
}

export interface ActiveEffect {
  type: 'burn' | 'freeze' | 'slow' | 'bleed';
  duration: number;
  damagePerSec?: number;
}
