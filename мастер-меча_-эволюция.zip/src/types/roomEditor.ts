export type LayerType = 'floor_bg' | 'back_wall' | 'mid_props' | 'front_wall' | 'foreground';

export interface RoomLightingSettings {
  ambientDarkness: number; // 0.0 (fully lit / light) to 1.0 (pitch black / deep shadow), default 0.55
  ambientColor?: string; // hex color for shadow/darkness tint: '#070a14' (dungeon night blue), '#020307' (pitch dark), '#140608' (crypt blood red)
  enableLighting?: boolean; // toggle lighting in editor/preview
  torchFlicker?: boolean; // dynamic fire flicker
}

export interface RoomElement {
  id: string;
  assetId: string;
  name: string;
  src: string;
  x: number;
  y: number;
  w: number;
  h: number;
  scaleX: number;
  scaleY: number;
  rotation: number; // degrees: 0, 90, 180, 270, or free float
  layer: LayerType;
  zIndex: number;
  renderAboveHero?: boolean; // false = под героем (герой поверх), true = над героем (передний план, герой сзади), независимо от zIndex
  opacity: number;
  flipX: boolean;
  flipY: boolean;
  locked?: boolean;
  visible?: boolean;
  hasFireEffect?: boolean;
  fireScale?: number;
  // Lighting & Shadow properties
  hasLight?: boolean;
  lightRadius?: number; // Radius in pixels (e.g. 50 - 600px)
  lightIntensity?: number; // 0.1 to 2.0 (default 1.0)
  lightColor?: string; // Hex color (e.g. '#ff9d3b')
  lightFlicker?: boolean;
  isShadowSource?: boolean;
  shadowDensity?: number; // 0.1 to 1.0
  shadowShape?: 'oval' | 'square';
  shadowCorners?: 'sharp' | 'rounded'; // 'sharp' = острые углы (90°), 'rounded' = закругленные углы
  shadowCornerRadius?: number; // радиус закругления в px (по умолчанию 10)
}

/**
 * Determines whether an element is rendered above the hero or below the hero.
 * Independent of zIndex: uses explicit renderAboveHero property if defined,
 * with legacy fallback to (zIndex > 100) for old rooms.
 */
export const isElementAboveHero = (el?: { renderAboveHero?: boolean; zIndex?: number } | null): boolean => {
  if (!el) return false;
  if (typeof el.renderAboveHero === 'boolean') {
    return el.renderAboveHero;
  }
  return (el.zIndex ?? 0) > 100;
};

export type CollisionType = 'wall' | 'door' | 'pit' | 'hazard' | 'interactable';

export interface CollisionBox {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation?: number;
  type: CollisionType;
  enabled: boolean;
  label?: string;
}

export type RoomType = 'start' | 'bridge' | 'normal' | 'boss';

export interface RoomTypeConfig {
  id: RoomType;
  title: string;
  shortLabel: string;
  description: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
}

export const ROOM_TYPE_CONFIGS: Record<RoomType, RoomTypeConfig> = {
  start: {
    id: 'start',
    title: 'Стартовая комната',
    shortLabel: 'СТАРТ',
    description: 'Начальная точка появления героя, арсенал и безопасная зона',
    badgeBg: 'bg-emerald-500/20',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-500/40'
  },
  bridge: {
    id: 'bridge',
    title: 'Промежуточный мост',
    description: 'Коридор, мост или переход между основными боевыми залами',
    shortLabel: 'МОСТ',
    badgeBg: 'bg-amber-500/20',
    badgeText: 'text-amber-300',
    badgeBorder: 'border-amber-500/40'
  },
  normal: {
    id: 'normal',
    title: 'Обычная комната',
    shortLabel: 'ОБЫЧНАЯ',
    description: 'Стандартный зал подземелья: сражения с врагами, лут и ловушки',
    badgeBg: 'bg-sky-500/20',
    badgeText: 'text-sky-300',
    badgeBorder: 'border-sky-500/40'
  },
  boss: {
    id: 'boss',
    title: 'Комната с боссом',
    shortLabel: 'БОСС',
    description: 'Финальная боевая арена с боссом уровня и золотыми сундуками',
    badgeBg: 'bg-rose-500/20',
    badgeText: 'text-rose-300',
    badgeBorder: 'border-rose-500/40'
  }
};

export interface CustomRoomData {
  id: string;
  name: string;
  roomType?: RoomType;
  width: number;
  height: number;
  gridSize: number;
  createdAt: string;
  updatedAt: string;
  elements: RoomElement[];
  collisionBoxes: CollisionBox[];
  spawnPoint: { x: number; y: number };
  doors?: {
    direction: 'north' | 'south' | 'west' | 'east';
    x: number;
    y: number;
    width: number;
  }[];
  isBossRoom?: boolean;
  theme?: 'dungeon' | 'boss' | 'crypt';
  tags?: string[];
  lighting?: RoomLightingSettings;
  floorZones?: { id: string; x: number; y: number; w: number; h: number }[];
  bakedUnderHeroImage?: string;
  bakedAboveHeroImage?: string;
}
