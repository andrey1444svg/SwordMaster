import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  DifficultyLevel, 
  CharacterStats, 
  Weapon, 
  Skill, 
  ResourceInventory, 
  LootDrop, 
  IngredientType,
  EquipmentState,
  InventoryItem,
  EquipmentSlotType,
  ItemRarity
} from './types/game';
import { 
  DIFFICULTY_CONFIGS, 
  STARTER_WEAPONS, 
  UNARMED_FIST_WEAPON,
  INITIAL_STATS, 
  INITIAL_SKILLS, 
  INGREDIENTS,
  INITIAL_EQUIPMENT,
  INITIAL_INVENTORY,
  getUpgradeRecipe,
  weaponToInventoryItem,
  ensureWeaponData
} from './utils/gameDefaults';
import { 
  createResourceItem, 
  addItemToInventory, 
  countResourceInInventory, 
  deductResourcesFromInventory, 
  getItemUpgradeCost, 
  upgradeItemStats,
  generateEquipmentDrop
} from './utils/lootGenerator';
import { soundManager } from './utils/audio';
import { enterFullscreenAndLockLandscape } from './utils/orientation';
import { HUD } from './components/HUD';
import { StartScreen } from './components/StartScreen';
import { InventoryModal } from './components/InventoryModal';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { TesterArmoryModal } from './components/TesterArmoryModal';
import { GameCanvas } from './components/GameCanvas';
import { RoomEditor } from './components/RoomEditor/RoomEditor';
import { RotateCw, Maximize2 } from 'lucide-react';

export default function App() {
  const [gamePhase, setGamePhase] = useState<'menu' | 'playing' | 'paused' | 'gameover' | 'editor'>('menu');
  const [isVictory, setIsVictory] = useState<boolean>(false);
  const [targetBoss, setTargetBoss] = useState<{ id: string; level: number } | null>(null);
  const [startingLevel, setStartingLevel] = useState<number>(1);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(0);
  const [gameSessionId, setGameSessionId] = useState<number>(1);
  const [isPortrait, setIsPortrait] = useState<boolean>(false);
  const [showShadows, setShowShadows] = useState<boolean>(true);

  const [stats, setStats] = useState<CharacterStats>(INITIAL_STATS);
  const [equipment, setEquipment] = useState<EquipmentState>(INITIAL_EQUIPMENT);
  const [inventory, setInventory] = useState<(InventoryItem | null)[]>(INITIAL_INVENTORY);
  const [weapons, setWeapons] = useState<Weapon[]>([UNARMED_FIST_WEAPON]);
  const [equippedWeapon, setEquippedWeapon] = useState<Weapon>(UNARMED_FIST_WEAPON);
  const [resources, setResources] = useState<ResourceInventory>({
    iron_ore: 0,
    magic_crystal: 0,
    monster_core: 0,
    ancient_rune: 0,
    fire_essence: 0
  });

  const [skills, setSkills] = useState<Skill[]>(INITIAL_SKILLS);
  const [isInventoryOpen, setIsInventoryOpen] = useState<boolean>(false);
  const [isTesterArmoryOpen, setIsTesterArmoryOpen] = useState<boolean>(false);

  const handleAddResources = useCallback((res: Partial<ResourceInventory>) => {
    setResources(prev => ({
      iron_ore: Math.min(999, prev.iron_ore + (res.iron_ore || 0)),
      magic_crystal: Math.min(999, prev.magic_crystal + (res.magic_crystal || 0)),
      monster_core: Math.min(999, prev.monster_core + (res.monster_core || 0)),
      ancient_rune: Math.min(999, prev.ancient_rune + (res.ancient_rune || 0)),
      fire_essence: Math.min(999, prev.fire_essence + (res.fire_essence || 0))
    }));
  }, []);

  const handleAddItemDirect = useCallback((item: InventoryItem) => {
    setInventory(prev => addItemToInventory(prev, item).newInventory);
  }, []);

  const difficultyConfig = DIFFICULTY_CONFIGS['normal'];

  // Check orientation on resize and mount
  useEffect(() => {
    const handleOrientation = () => {
      const portrait = window.innerHeight > window.innerWidth;
      setIsPortrait(portrait);
    };
    handleOrientation();
    window.addEventListener('resize', handleOrientation);
    window.addEventListener('orientationchange', handleOrientation);
    return () => {
      window.removeEventListener('resize', handleOrientation);
      window.removeEventListener('orientationchange', handleOrientation);
    };
  }, []);

  // Background Music (BGM) sync based on gamePhase
  useEffect(() => {
    if (gamePhase === 'menu') {
      soundManager.playMenuMusic();
    } else if (gamePhase === 'playing') {
      soundManager.playDungeonMusic();
    }
  }, [gamePhase]);

  // Mobs slain score update
  const handleScoreAdd = useCallback((mobsKilled: number) => {
    setScore(mobsKilled);
    setHighScore(prev => Math.max(prev, mobsKilled));
  }, []);

  // Check if inventory has any free slots (30 slots total)
  const isInventoryFull = useMemo(() => {
    return !inventory.some(slot => slot === null);
  }, [inventory]);

  // Cooldown & Skill Duration Ticker
  useEffect(() => {
    if (gamePhase !== 'playing' || isInventoryOpen) return;

    const interval = setInterval(() => {
      setSkills(prevSkills => {
        let changed = false;
        const next = prevSkills.map(skill => {
          let currentCooldown = skill.currentCooldown;
          let isActive = skill.isActive;
          let activeTimer = skill.activeTimer;

          // Tick down cooldown
          if (currentCooldown > 0) {
            currentCooldown = Math.max(0, currentCooldown - 0.1);
          }

          // Tick down active state duration
          if (isActive) {
            activeTimer -= 0.1;
            if (activeTimer <= 0) {
              isActive = false;
              activeTimer = 0;
            }
          }

          if (
            currentCooldown === skill.currentCooldown &&
            isActive === skill.isActive &&
            activeTimer === skill.activeTimer
          ) {
            return skill;
          }

          changed = true;
          return {
            ...skill,
            currentCooldown,
            isActive,
            activeTimer
          };
        });
        return changed ? next : prevSkills;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [gamePhase, isInventoryOpen]);

  // Skill trigger
  const handleSkillUse = useCallback((skillId: string) => {
    setSkills(prevSkills =>
      prevSkills.map(skill => {
        if (skill.id === skillId && skill.level > 0 && skill.currentCooldown === 0) {
          const effectiveCooldown = skill.cooldown * (1 - stats.cooldownReduction);
          soundManager.playSkill(skill.id as any);

          return {
            ...skill,
            isActive: true,
            activeTimer: skill.activeDuration,
            currentCooldown: effectiveCooldown
          };
        }
        return skill;
      })
    );
  }, [stats.cooldownReduction]);

  // Stat upgrade
  const handleUpgradeStat = (statKey: keyof CharacterStats) => {
    setStats(prev => {
      if (prev.statPoints <= 0) return prev;

      if (statKey === 'strength') {
        return {
          ...prev,
          statPoints: prev.statPoints - 1,
          strength: prev.strength + 1
        };
      } else if (statKey === 'agility') {
        return {
          ...prev,
          statPoints: prev.statPoints - 1,
          agility: prev.agility + 1
        };
      } else if (statKey === 'endurance') {
        return {
          ...prev,
          statPoints: prev.statPoints - 1,
          endurance: prev.endurance + 1
        };
      } else if (statKey === 'intelligence') {
        return {
          ...prev,
          statPoints: prev.statPoints - 1,
          intelligence: prev.intelligence + 1
        };
      }
      return prev;
    });
  };

  // Skill upgrade
  const handleUpgradeSkill = (skillId: string) => {
    if (stats.skillPoints <= 0) return;

    const skillToUpgrade = skills.find(s => s.id === skillId);
    if (!skillToUpgrade || skillToUpgrade.level >= skillToUpgrade.maxLevel) return;

    setStats(s => ({ ...s, skillPoints: Math.max(0, s.skillPoints - 1) }));
    setSkills(prev =>
      prev.map(skill =>
        skill.id === skillId
          ? { ...skill, level: skill.level + 1 }
          : skill
      )
    );
  };

  // Equip / Unequip / Move / Salvage Items
  const handleEquipItem = (item: InventoryItem, targetSlot?: EquipmentSlotType) => {
    let slot: EquipmentSlotType = targetSlot || 'weapon';
    if (!targetSlot) {
      switch (item.category) {
        case 'weapon': slot = 'weapon'; break;
        case 'helmet': slot = 'helmet'; break;
        case 'cloak': slot = 'cloak'; break;
        case 'chest': slot = 'chest'; break;
        case 'bracers': slot = 'bracers'; break;
        case 'gloves': slot = 'gloves'; break;
        case 'belt': slot = 'belt'; break;
        case 'pants': slot = 'pants'; break;
        case 'boots': slot = 'boots'; break;
        case 'ring':
          slot = !equipment.ring1 ? 'ring1' : !equipment.ring2 ? 'ring2' : 'ring1';
          break;
        case 'trinket':
          slot = !equipment.trinket1 ? 'trinket1' : !equipment.trinket2 ? 'trinket2' : 'trinket1';
          break;
      }
    }

    const prevEquipped = equipment[slot];

    // Find if the item is currently equipped in another slot (e.g., ring1 -> ring2)
    const otherEquippedSlot = (Object.keys(equipment) as EquipmentSlotType[]).find(
      s => s !== slot && equipment[s]?.id === item.id
    );

    setEquipment(prev => {
      const nextEq = { ...prev, [slot]: item };
      if (otherEquippedSlot) {
        nextEq[otherEquippedSlot] = prevEquipped || null;
      }
      return nextEq;
    });

    setInventory(prev => {
      const invIndex = prev.findIndex(inv => inv?.id === item.id);
      if (invIndex !== -1) {
        const next = [...prev];
        next[invIndex] = otherEquippedSlot ? null : prevEquipped;
        return next;
      }
      return prev;
    });

    if (slot === 'weapon') {
      const wData = item.weaponData || ensureWeaponData(item);
      setEquippedWeapon(wData);
    }

    soundManager.playEquip();
  };

  const handleUnequipItem = (slot: EquipmentSlotType) => {
    const item = equipment[slot];
    if (!item) return;

    // First check if inventory has free space
    setInventory(prev => {
      const emptyIndex = prev.findIndex(slotItem => !slotItem);
      if (emptyIndex === -1) {
        soundManager.playError();
        return prev;
      }

      // Unequip from equipment slot atomically
      setEquipment(eqPrev => ({
        ...eqPrev,
        [slot]: null
      }));

      const next = [...prev];
      next[emptyIndex] = item;
      soundManager.playEquip();
      return next;
    });
  };

  const handleMoveItem = (fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    setInventory(prev => {
      const next = [...prev];
      const fromItem = next[fromIndex];
      const toItem = next[toIndex];
      
      // If dropping one resource onto another identical resource, merge their stacks
      if (
        fromItem && toItem &&
        fromItem.isResource && toItem.isResource &&
        fromItem.resourceType === toItem.resourceType
      ) {
        next[toIndex] = {
          ...toItem,
          quantity: (toItem.quantity || 1) + (fromItem.quantity || 1)
        };
        next[fromIndex] = null;
        return next;
      }

      next[fromIndex] = toItem;
      next[toIndex] = fromItem;
      return next;
    });
  };

  const handleSalvageItem = (
    item: InventoryItem, 
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }
  ) => {
    if (source.type === 'equipment') {
      setEquipment(prev => ({
        ...prev,
        [source.slot]: null
      }));
    }

    setInventory(prev => {
      let currentInv = [...prev];
      if (source.type === 'inventory') {
        currentInv[source.index] = null;
      }

      // Add salvaged materials directly into inventory stacks
      const y = item.salvageYield;
      if (y) {
        const yieldEntries: [IngredientType, number][] = [
          ['iron_ore', y.iron_ore || 0],
          ['magic_crystal', y.magic_crystal || 0],
          ['monster_core', y.monster_core || 0],
          ['ancient_rune', y.ancient_rune || 0],
          ['fire_essence', y.fire_essence || 0]
        ];

        for (const [type, amt] of yieldEntries) {
          if (amt > 0) {
            const resItem = createResourceItem(type, amt);
            const res = addItemToInventory(currentInv, resItem);
            if (res.success) {
              currentInv = res.newInventory;
            }
          }
        }
      }
      return currentInv;
    });

    soundManager.playForge();
  };

  const handleSalvageMultiple = (rarity: ItemRarity) => {
    setInventory(prev => {
      let currentInv = [...prev];
      
      for (let i = 0; i < currentInv.length; i++) {
        const item = currentInv[i];
        if (item && item.rarity === rarity && item.category !== 'resource') {
          // Salvage item
          const y = item.salvageYield;
          if (y) {
            const yieldEntries: [IngredientType, number][] = [
              ['iron_ore', y.iron_ore || 0],
              ['magic_crystal', y.magic_crystal || 0],
              ['monster_core', y.monster_core || 0],
              ['ancient_rune', y.ancient_rune || 0],
              ['fire_essence', y.fire_essence || 0]
            ];

            for (const [type, amt] of yieldEntries) {
              if (amt > 0) {
                const resItem = createResourceItem(type, amt);
                const res = addItemToInventory(currentInv, resItem);
                if (res.success) {
                  currentInv = res.newInventory;
                }
              }
            }
          }
          currentInv[i] = null;
        }
      }
      return currentInv;
    });
    soundManager.playForge();
  };

  const handleUpgradeItem = (
    item: InventoryItem,
    source: { type: 'inventory'; index: number } | { type: 'equipment'; slot: EquipmentSlotType }
  ) => {
    const costs = getItemUpgradeCost(item);
    // Check if player has enough resources in inventory
    for (const [resKey, needed] of Object.entries(costs)) {
      if (!needed) continue;
      const have = countResourceInInventory(inventory, resKey as IngredientType);
      if (have < needed) return;
    }

    const newInv = deductResourcesFromInventory(inventory, costs);
    const upgradedItem = upgradeItemStats(item);

    if (source.type === 'inventory') {
      newInv[source.index] = upgradedItem;
      setInventory(newInv);
    } else {
      setInventory(newInv);
      setEquipment(prev => ({
        ...prev,
        [source.slot]: upgradedItem
      }));
      if (source.slot === 'weapon' && upgradedItem.weaponData) {
        setEquippedWeapon(upgradedItem.weaponData);
      }
    }

    soundManager.playForge();
  };

  // Synchronize equipment stats bonus to stats (HP, Mana, Armor, Damage, Crit, Speed, Attributes)
  useEffect(() => {
    const equippedItems = Object.values(equipment).filter(Boolean) as InventoryItem[];
    const nonWeaponEquippedItems = equippedItems.filter(it => it.category !== 'weapon');
    const armorTotal = equippedItems.reduce((sum, it) => sum + (it.stats.armor || 0), 0);
    const equipMinDmgTotal = equippedItems.reduce((sum, it) => sum + (it.stats.damageMin || 0), 0);
    const equipMaxDmgTotal = equippedItems.reduce((sum, it) => sum + (it.stats.damageMax || 0), 0);
    const bonusHpTotal = equippedItems.reduce((sum, it) => sum + (it.stats.hp || 0), 0);
    const bonusManaTotal = equippedItems.reduce((sum, it) => sum + (it.stats.mana || 0), 0);
    const bonusCritTotal = nonWeaponEquippedItems.reduce((sum, it) => sum + (it.stats.critChance || 0), 0);
    const bonusSpeedTotal = equippedItems.reduce((sum, it) => sum + (it.stats.speed || 0), 0);
    const bonusVampTotal = equippedItems.reduce((sum, it) => sum + (it.stats.vampirism || 0), 0);

    const bonusStrTotal = equippedItems.reduce((sum, it) => sum + (it.stats.strength || 0), 0);
    const bonusAgiTotal = equippedItems.reduce((sum, it) => sum + (it.stats.agility || 0), 0);
    const bonusEndTotal = equippedItems.reduce((sum, it) => sum + (it.stats.endurance || 0), 0);
    const bonusIntTotal = equippedItems.reduce((sum, it) => sum + (it.stats.intelligence || 0), 0);

    setStats(prev => {
      const effectiveStr = prev.strength + bonusStrTotal;
      const effectiveAgi = prev.agility + bonusAgiTotal;
      const effectiveEnd = prev.endurance + bonusEndTotal;
      const effectiveInt = prev.intelligence + bonusIntTotal;

      const baseMaxHp = 15 + effectiveEnd * 3;
      const targetMaxHp = baseMaxHp + bonusHpTotal;
      const hpDiff = targetMaxHp - prev.maxHp;
      const newHp = hpDiff > 0 ? prev.hp + hpDiff : Math.min(targetMaxHp, prev.hp);

      const baseMaxMana = effectiveInt * 3;
      const targetMaxMana = baseMaxMana + bonusManaTotal;
      const manaDiff = targetMaxMana - prev.maxMana;
      const newMana = manaDiff > 0 ? prev.mana + manaDiff : Math.min(targetMaxMana, prev.mana);

      const strBonus = effectiveStr * 0.50;
      const finalMinDamage = Math.round((3 + equipMinDmgTotal + strBonus) * 10) / 10;
      const finalMaxDamage = Math.round((3 + equipMaxDmgTotal + strBonus) * 10) / 10;

      return {
        ...prev,
        armor: armorTotal,
        minDamage: finalMinDamage,
        maxDamage: finalMaxDamage,
        maxHp: targetMaxHp,
        hp: Math.max(1, newHp),
        maxMana: targetMaxMana,
        mana: Math.max(0, newMana),
        critChanceBonus: Math.round(((effectiveAgi * 0.0015) + bonusCritTotal) * 10000) / 10000,
        vampirism: Math.round(bonusVampTotal * 100) / 100,
        moveSpeed: 7 + (bonusSpeedTotal > 0 ? bonusSpeedTotal * 0.2 : 0),
        effectiveAgi: effectiveAgi
      };
    });
  }, [equipment, stats.strength, stats.agility, stats.endurance, stats.intelligence]);

  // Synchronize equipped weapon state whenever weapon slot changes
  useEffect(() => {
    if (equipment.weapon) {
      const wData = equipment.weapon.weaponData || ensureWeaponData(equipment.weapon);
      setEquippedWeapon(wData);
    } else {
      setEquippedWeapon(UNARMED_FIST_WEAPON);
    }
  }, [equipment.weapon]);

  // Handle Loot Drop Picked Up
  const handleAddLoot = useCallback((loot: LootDrop) => {
    let itemToAdd: InventoryItem | null = null;
    if (loot.type === 'ingredient' && loot.ingredientType) {
      itemToAdd = createResourceItem(loot.ingredientType, loot.amount || 1);
    } else if (loot.type === 'equipment' && loot.itemData) {
      itemToAdd = loot.itemData;
    } else if (loot.type === 'weapon' && loot.weaponData) {
      itemToAdd = weaponToInventoryItem(loot.weaponData);
    }

    if (!itemToAdd) return;

    // Auto-equip if the item is an equipment piece and the target slot is currently empty
    if (itemToAdd.category !== 'resource') {
      let targetEmptySlot: EquipmentSlotType | null = null;
      const cat = itemToAdd.category;

      if (cat === 'ring') {
        if (!equipment.ring1) targetEmptySlot = 'ring1';
        else if (!equipment.ring2) targetEmptySlot = 'ring2';
      } else if (cat === 'trinket') {
        if (!equipment.trinket1) targetEmptySlot = 'trinket1';
        else if (!equipment.trinket2) targetEmptySlot = 'trinket2';
      } else {
        const slotKey = cat as EquipmentSlotType;
        if (!equipment[slotKey]) {
          targetEmptySlot = slotKey;
        }
      }

      if (targetEmptySlot) {
        const itemToEquip = { ...itemToAdd };
        if (targetEmptySlot === 'weapon' && !itemToEquip.weaponData) {
          itemToEquip.weaponData = ensureWeaponData(itemToEquip);
        }

        setEquipment(prev => ({
          ...prev,
          [targetEmptySlot!]: itemToEquip
        }));

        if (targetEmptySlot === 'weapon') {
          const wData = itemToEquip.weaponData || ensureWeaponData(itemToEquip);
          setEquippedWeapon(wData);
          setWeapons(prev => {
            const exists = prev.some(w => w.id === wData.id);
            return exists ? prev : [wData, ...prev.filter(w => w.id !== 'fist_starter')];
          });
        }
        soundManager.playEquip();
        return;
      }
    }

    setInventory(prevInv => {
      const res = addItemToInventory(prevInv, itemToAdd!);
      if (res.success) {
        return res.newInventory;
      }
      return prevInv;
    });
  }, [equipment]);

  // Start fresh new game handler
  const handleStartGame = async () => {
    setTargetBoss(null);
    setIsVictory(false);
    try {
      await enterFullscreenAndLockLandscape();
    } catch {
      // Graceful fallback
    }
    setScore(0);
    setStats({ ...INITIAL_STATS });
    setWeapons([UNARMED_FIST_WEAPON]);
    setEquippedWeapon(UNARMED_FIST_WEAPON);
    setEquipment({ ...INITIAL_EQUIPMENT });
    setInventory([...INITIAL_INVENTORY]);
    setResources({
      iron_ore: 0,
      magic_crystal: 0,
      monster_core: 0,
      ancient_rune: 0,
      fire_essence: 0
    });
    setSkills(INITIAL_SKILLS.map(s => ({ ...s, currentCooldown: 0, isActive: false, activeTimer: 0 })));
    setStartingLevel(1);
    setGameSessionId(prev => prev + 1);
    setGamePhase('playing');
  };

  const handleStartGameAtLevel = async (levelNumber: number) => {
    setTargetBoss(null);
    setIsVictory(false);
    setStartingLevel(levelNumber);
    try {
      await enterFullscreenAndLockLandscape();
    } catch {}
    setScore(0);
    setGameSessionId(prev => prev + 1);
    setGamePhase('playing');
    setIsInventoryOpen(false);
    setIsTesterArmoryOpen(false);
  };

  const handleStartGameWithBoss = async (bossId: string, level: number = 1) => {
    setTargetBoss({ id: bossId, level });
    setStartingLevel(level);
    setIsVictory(false);
    try {
      await enterFullscreenAndLockLandscape();
    } catch {
      // Graceful fallback
    }
    setScore(0);

    // If player has no equipped weapon yet, give a default tester weapon
    if (!equipment.weapon) {
      let testerWeaponItem = generateEquipmentDrop('magic', 2, 'weapon');
      while (testerWeaponItem.level < 2) {
        testerWeaponItem = upgradeItemStats(testerWeaponItem);
      }
      const wData = testerWeaponItem.weaponData || ensureWeaponData(testerWeaponItem);
      testerWeaponItem.weaponData = wData;

      setWeapons([wData]);
      setEquippedWeapon(wData);
      setEquipment({
        ...INITIAL_EQUIPMENT,
        weapon: testerWeaponItem
      });
    }

    setSkills(INITIAL_SKILLS.map(s => ({ ...s, currentCooldown: 0, isActive: false, activeTimer: 0 })));
    setGameSessionId(prev => prev + 1);
    setGamePhase('playing');
    setIsInventoryOpen(false);
    setIsTesterArmoryOpen(false);
  };

  // Pause / Resume
  const handlePause = useCallback(() => {
    setGamePhase('paused');
  }, []);

  const handleResume = useCallback(() => {
    setGamePhase('playing');
  }, []);

  // Quit to Menu
  const handleQuitToMenu = useCallback(() => {
    setIsInventoryOpen(false);
    setGamePhase('menu');
  }, []);

  const handleOpenInventory = useCallback(() => {
    setIsInventoryOpen(true);
  }, []);

  const handleGameOver = useCallback((victory: boolean = false) => {
    setIsVictory(victory);
    setGamePhase('gameover');
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black font-sans select-none">
      
      {/* Active Game Canvas (Only mounted during active gameplay/pause/gameover, not in menu or editor) */}
      {gamePhase !== 'menu' && gamePhase !== 'editor' && (
        <GameCanvas
          key={gameSessionId}
          targetBoss={targetBoss}
          startLevel={startingLevel}
          stats={stats}
          equippedWeapon={equippedWeapon}
          equipment={equipment}
          difficulty={difficultyConfig}
          skills={skills}
          showShadows={showShadows}
          isPaused={gamePhase !== 'playing' || isInventoryOpen || isTesterArmoryOpen}
          onUpdateStats={setStats}
          onAddScore={handleScoreAdd}
          onAddLoot={handleAddLoot}
          onGameOver={(vic) => handleGameOver(vic)}
          onSkillUsed={handleSkillUse}
          onOpenInventory={handleOpenInventory}
          isInventoryFull={isInventoryFull}
        />
      )}

      {/* In-Game HUD Header & Skill Bar */}
      {gamePhase === 'playing' && (
        <HUD
          stats={stats}
          equippedWeapon={equippedWeapon}
          difficulty={difficultyConfig}
          score={score}
          highScore={highScore}
          skills={skills}
          onSkillUse={handleSkillUse}
          onOpenInventory={handleOpenInventory}
          onPause={handlePause}
          onOpenTesterArmory={() => setIsTesterArmoryOpen(true)}
        />
      )}

      {/* Start Menu Overlay */}
      {gamePhase === 'menu' && (
        <StartScreen
          onStartGame={handleStartGame}
          onStartGameWithBoss={handleStartGameWithBoss}
          onExitGame={handleQuitToMenu}
          onOpenTesterArmory={() => setIsTesterArmoryOpen(true)}
          onOpenRoomEditor={() => setGamePhase('editor')}
        />
      )}

      {/* Room and Level Editor Mode */}
      {gamePhase === 'editor' && (
        <RoomEditor
          onExit={() => setGamePhase('menu')}
        />
      )}

      {/* Pause Modal Overlay */}
      {gamePhase === 'paused' && (
        <PauseModal
          onResume={handleResume}
          onRestart={handleStartGame}
          onOpenInventory={() => handleOpenInventory()}
          onQuitToMenu={handleQuitToMenu}
          onOpenTesterArmory={() => setIsTesterArmoryOpen(true)}
          onOpenRoomEditor={() => setGamePhase('editor')}
          showShadows={showShadows}
          setShowShadows={setShowShadows}
        />
      )}

      {/* Game Over Modal Overlay */}
      {gamePhase === 'gameover' && (
        <GameOverModal
          score={score}
          highScore={highScore}
          isNewRecord={score >= highScore && score > 0}
          stats={stats}
          difficulty={difficultyConfig}
          resources={resources}
          weaponsCount={weapons.length}
          onRestart={handleStartGame}
          onQuitToMenu={handleQuitToMenu}
          isVictory={isVictory}
        />
      )}

      {/* Unified Character, Equipment & 30-Slot Inventory Dashboard */}
      <InventoryModal
        isOpen={isInventoryOpen}
        stats={stats}
        resources={resources}
        equipment={equipment}
        inventory={inventory}
        onClose={() => setIsInventoryOpen(false)}
        onUpgradeStat={handleUpgradeStat}
        onEquipItem={handleEquipItem}
        onUnequipItem={handleUnequipItem}
        onMoveItem={handleMoveItem}
        onSalvageItem={handleSalvageItem}
        onSalvageMultiple={handleSalvageMultiple}
        onUpgradeItem={handleUpgradeItem}
        onOpenTesterArmory={() => setIsTesterArmoryOpen(true)}
      />

      {/* Tester Armory & Item Spawner Modal */}
      <TesterArmoryModal
        isOpen={isTesterArmoryOpen}
        onClose={() => setIsTesterArmoryOpen(false)}
        equipment={equipment}
        onEquipItem={handleEquipItem}
        onAddItem={handleAddItemDirect}
        onAddResources={handleAddResources}
        onStartGameAtLevel={handleStartGameAtLevel}
        onStartGameWithBoss={(bossId, level) => {
          setIsTesterArmoryOpen(false);
          handleStartGameWithBoss(bossId, level);
        }}
        onStartGame={() => {
          setIsTesterArmoryOpen(false);
          if (gamePhase === 'menu') {
            handleStartGame();
          }
        }}
      />

      {/* Portrait Mode Advisory Banner for Mobile */}
      {isPortrait && gamePhase === 'playing' && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-40 bg-slate-950/95 border border-sky-500/50 text-white text-xs px-3 py-1.5 rounded-full shadow-2xl flex items-center gap-2 animate-fade-in pointer-events-auto">
          <RotateCw className="w-3.5 h-3.5 text-sky-400 animate-spin" />
          <span className="text-[11px] font-medium text-slate-200">Поверните экран горизонтально</span>
          <button
            onClick={() => enterFullscreenAndLockLandscape()}
            className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-2 py-0.5 rounded-full text-[10px] uppercase cursor-pointer"
          >
            Во весь экран
          </button>
        </div>
      )}

    </div>
  );
}
