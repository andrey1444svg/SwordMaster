// Utility to enter fullscreen and lock landscape orientation for optimal gameplay

export async function enterFullscreenAndLockLandscape(): Promise<void> {
  // 1. Request Fullscreen (safe against iframe restrictions)
  try {
    const docEl = document.documentElement as any;
    if (docEl.requestFullscreen) {
      await docEl.requestFullscreen().catch(() => {});
    } else if (docEl.webkitRequestFullscreen) {
      await docEl.webkitRequestFullscreen().catch(() => {});
    }
    // Small delay to allow browser to transition to fullscreen if permitted
    await new Promise(resolve => setTimeout(resolve, 150));
  } catch {
    // Silently ignore if fullscreen is disallowed or user cancels
  }

  // 2. Request Landscape Screen Orientation Lock if supported and allowed
  try {
    let isInsideRestrictedFrame = false;
    try {
      isInsideRestrictedFrame = typeof window !== 'undefined' && window.self !== window.top;
    } catch {
      isInsideRestrictedFrame = true;
    }
    const screenOrientation = (screen as any)?.orientation || (screen as any)?.mozOrientation || (screen as any)?.msOrientation;

    if (!isInsideRestrictedFrame && screenOrientation && typeof screenOrientation.lock === 'function') {
      try {
        await screenOrientation.lock('landscape').catch(async () => {
          try {
            await screenOrientation.lock('landscape-primary').catch(() => {});
          } catch {}
        });
      } catch {}
    }
  } catch {
    // Silently ignore orientation lock restrictions
  }
}

export async function toggleFullscreen(): Promise<boolean> {
  try {
    const doc = document as any;
    const isFullscreen = Boolean(
      doc.fullscreenElement || 
      doc.webkitFullscreenElement || 
      doc.mozFullScreenElement || 
      doc.msFullscreenElement
    );

    if (isFullscreen) {
      if (doc.exitFullscreen) {
        await doc.exitFullscreen().catch(() => {});
      } else if (doc.webkitExitFullscreen) {
        await doc.webkitExitFullscreen().catch(() => {});
      } else if (doc.mozCancelFullScreen) {
        await doc.mozCancelFullScreen().catch(() => {});
      } else if (doc.msExitFullscreen) {
        await doc.msExitFullscreen().catch(() => {});
      }
      return false;
    } else {
      await enterFullscreenAndLockLandscape();
      return true;
    }
  } catch {
    return false;
  }
}

