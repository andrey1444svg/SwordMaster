import { 
  InventoryItem, 
  ItemRarity, 
  EquipmentCategory, 
  IngredientType, 
  Weapon, 
  WeaponType, 
  WeaponElement 
} from '../types/game';

// Helper to enforce mandatory armor and mutually exclusive Agility/Crit Chance/Crit Multiplier
export function enforceStatRules(item: InventoryItem): InventoryItem {
  if (!item || !item.stats) return item;

  // 1. Mandatory Armor on Helm, Chest, Gloves, Pants, Boots
  const armorCategories: EquipmentCategory[] = ['helmet', 'chest', 'gloves', 'pants', 'boots'];
  if ((armorCategories as string[]).includes(item.category)) {
    if (item.stats.armor === undefined || item.stats.armor <= 0) {
      const baseArmor = item.rarity === 'epic' ? 12 : item.rarity === 'rare' ? 7 : item.rarity === 'magic' ? 4 : 2;
      item.stats.armor = baseArmor;
    }
  }

  // 2. Agility, Crit Chance, Crit Multiplier MUTUALLY EXCLUSIVE RULE across ALL items
  // Must give EITHER agility OR critChance OR critMultiplier and NEVER 2 or 3 together!
  const hasAgility = item.stats.agility !== undefined && item.stats.agility > 0;
  const hasCritChance = (item.stats.critChance !== undefined && item.stats.critChance > 0) ||
                        (item.weaponData?.critChance !== undefined && (item.weaponData?.critChance || 0) > 0);
  const hasCritMultiplier = (item.stats.critMultiplier !== undefined && item.stats.critMultiplier > 0) ||
                            (item.weaponData?.critMultiplier !== undefined && (item.weaponData?.critMultiplier || 1.0) > 1.0);

  if (hasAgility) {
    delete item.stats.critChance;
    delete item.stats.critMultiplier;
    if (item.weaponData) {
      item.weaponData.critChance = 0;
      delete (item.weaponData as any).critMultiplier;
    }
  } else if (hasCritChance) {
    delete item.stats.agility;
    delete item.stats.critMultiplier;
    if (item.weaponData) {
      delete (item.weaponData as any).critMultiplier;
    }
  } else if (hasCritMultiplier) {
    delete item.stats.agility;
    delete item.stats.critChance;
    if (item.weaponData) {
      item.weaponData.critChance = 0;
    }
  }

  // 3. STRICT INTEGER ENFORCEMENT ON ALL STATS (No floating point inaccuracies like 10.000000004):
  // Damage, Strength, Agility, Endurance, Intelligence, Armor, HP, Mana, Speed, Recovery Speed
  // All numerical stats must be pure, clean integers, except vampirism (rounded to hundredths, e.g. 0.28%)
  // and percentage chances (critChance, etc.)
  for (const key of Object.keys(item.stats) as (keyof typeof item.stats)[]) {
    const val = item.stats[key];
    if (typeof val === 'number') {
      if (key === 'vampirism') {
        item.stats[key] = Math.round(val * 100) / 100;
      } else if (key === 'critChance' || key === 'chainLightningChance' || key === 'chainLightningDamageRatio') {
        item.stats[key] = Math.round(val * 1000) / 1000;
      } else {
        item.stats[key] = Math.round(val);
      }
    }
  }

  if (item.weaponData) {
    item.weaponData.minDamage = Math.round(item.weaponData.minDamage);
    item.weaponData.maxDamage = Math.round(item.weaponData.maxDamage);
    if (item.weaponData.critChance !== undefined) {
      item.weaponData.critChance = Math.round(item.weaponData.critChance * 1000) / 1000;
    }
    if (item.weaponData.stunChance !== undefined) {
      item.weaponData.stunChance = Math.round(item.weaponData.stunChance * 1000) / 1000;
    }
    if (item.weaponData.bonusDamageMultiplier !== undefined) {
      item.weaponData.bonusDamageMultiplier = Math.round(item.weaponData.bonusDamageMultiplier * 100) / 100;
    }
    if (item.weaponData.doubleStrikeChance !== undefined) {
      item.weaponData.doubleStrikeChance = Math.round(item.weaponData.doubleStrikeChance * 100) / 100;
    }
    if (item.weaponData.bleedChance !== undefined) {
      item.weaponData.bleedChance = Math.round(item.weaponData.bleedChance * 100) / 100;
    }
    if (item.weaponData.bleedDamageRatio !== undefined) {
      item.weaponData.bleedDamageRatio = Math.round(item.weaponData.bleedDamageRatio * 100) / 100;
    }
    if (item.weaponData.ruthlessnessRatio !== undefined) {
      item.weaponData.ruthlessnessRatio = Math.round(item.weaponData.ruthlessnessRatio * 100000) / 100000;
    }
  }

  if (item.vampirism !== undefined) {
    item.vampirism = Math.round(item.vampirism * 100) / 100;
  }
  if (item.attackRecoverySpeed !== undefined) {
    item.attackRecoverySpeed = Math.round(item.attackRecoverySpeed);
  }

  return item;
}

// Resource Item creation helper
export function createResourceItem(type: IngredientType, quantity: number = 1): InventoryItem {
  const meta: Record<IngredientType, { name: string; icon: string; rarity: ItemRarity; desc: string }> = {
    iron_ore: {
      name: 'Осколок мглы',
      icon: 'iron_ore',
      rarity: 'common',
      desc: 'Обычный ингредиент 1-го тира. Осколок сконденсированной тьмы, используемый для базового усиления снаряжения.'
    },
    magic_crystal: {
      name: 'Магический кристалл',
      icon: 'magic_crystal',
      rarity: 'magic',
      desc: 'Магический ингредиент 2-го тира (зеленый). Кристалл сгущенной маны для зачарования снаряжения.'
    },
    monster_core: {
      name: 'Ядро монстра',
      icon: 'monster_core',
      rarity: 'rare',
      desc: 'Редкий ингредиент 3-го тира (синий). Пульсирующий источник жизненной силы чудовищ для ковки мощных доспехов.'
    },
    ancient_rune: {
      name: 'Печать пустоты',
      icon: 'ancient_rune',
      rarity: 'epic',
      desc: 'Эпический ингредиент 4-го тира (фиолетовый). Могущественная печать из глубин Бездны для легендарных кузнечных работ.'
    },
    fire_essence: {
      name: 'Огненная эссенция',
      icon: 'fire_essence',
      rarity: 'epic',
      desc: 'Эпический ингредиент наивысшего порядка. Концентрированное пламя древних богов.'
    }
  };

  const itemMeta = meta[type];

  return {
    id: `res_${type}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name: itemMeta.name,
    category: 'resource',
    rarity: itemMeta.rarity,
    icon: itemMeta.icon,
    description: itemMeta.desc,
    level: 1,
    stats: {},
    quantity,
    resourceType: type,
    isResource: true,
    salvageYield: {}
  };
}

// Check how many of a specific resource the player has in the 30-slot inventory
export function countResourceInInventory(inventory: (InventoryItem | null)[], type: IngredientType): number {
  return inventory.reduce((total, item) => {
    if (item && item.isResource && item.resourceType === type) {
      return total + (item.quantity || 1);
    }
    return total;
  }, 0);
}

// Deduct required resources from inventory stacks
export function deductResourcesFromInventory(
  inventory: (InventoryItem | null)[], 
  costs: Partial<Record<IngredientType, number>>
): (InventoryItem | null)[] {
  const newInv = [...inventory];

  for (const [resKey, amountNeeded] of Object.entries(costs)) {
    if (!amountNeeded) continue;
    let remainingToDeduct = amountNeeded;
    const type = resKey as IngredientType;

    for (let i = 0; i < newInv.length; i++) {
      const it = newInv[i];
      if (it && it.isResource && it.resourceType === type) {
        const curQty = it.quantity || 1;
        if (curQty > remainingToDeduct) {
          newInv[i] = { ...it, quantity: curQty - remainingToDeduct };
          remainingToDeduct = 0;
          break;
        } else {
          remainingToDeduct -= curQty;
          newInv[i] = null; // Stack exhausted
          if (remainingToDeduct <= 0) break;
        }
      }
    }
  }

  return newInv;
}

// Helper to add an item or stack resources into the 30-slot inventory
export function addItemToInventory(
  inventory: (InventoryItem | null)[], 
  item: InventoryItem
): { success: boolean; newInventory: (InventoryItem | null)[]; slotIndex: number } {
  const newInv = [...inventory];
  while (newInv.length < 30) {
    newInv.push(null);
  }

  // If it is a stackable resource, look for an existing stack first
  if (item.isResource && item.resourceType) {
    const existingIndex = newInv.findIndex(
      slot => Boolean(slot && slot.isResource && slot.resourceType === item.resourceType)
    );
    if (existingIndex !== -1) {
      const existing = newInv[existingIndex]!;
      newInv[existingIndex] = {
        ...existing,
        quantity: (existing.quantity || 1) + (item.quantity || 1)
      };
      return { success: true, newInventory: newInv, slotIndex: existingIndex };
    }
  }

  // Otherwise find the first empty slot (equipment/gear never stacks, each placed in its own slot)
  const emptyIndex = newInv.findIndex(slot => !slot);
  if (emptyIndex !== -1) {
    newInv[emptyIndex] = item;
    return { success: true, newInventory: newInv, slotIndex: emptyIndex };
  }

  // Inventory is full
  return { success: false, newInventory: inventory, slotIndex: -1 };
}

// Calculate upgrade cost for an equipment item
export function getItemUpgradeCost(item: InventoryItem): Partial<Record<IngredientType, number>> {
  if (item.isResource || item.level >= 10) return {};

  const nextLevel = item.level + 1;
  const costs: Partial<Record<IngredientType, number>> = {};

  if (item.rarity === 'common') {
    // Обычный предмет: только тир 1 ресурс (2, 4, 6, 8...) за улучшение
    costs.iron_ore = nextLevel * 2;
  } else if (item.rarity === 'magic') {
    // Зеленый предмет: тир 1 (6, 12, 18, 24...) и тир 2 ресурсы (2, 4, 6, 8...)
    costs.iron_ore = nextLevel * 6;
    costs.magic_crystal = nextLevel * 2;
  } else if (item.rarity === 'rare') {
    // Синие предметы: тир 1 ресурс (10, 20, 30, 40...), тир 2 ресурс (3, 6, 9, 12...), тир 3 ресурс (2, 4, 6, 8, 10...)
    costs.iron_ore = nextLevel * 10;
    costs.magic_crystal = nextLevel * 3;
    costs.monster_core = nextLevel * 2;
  } else if (item.rarity === 'epic' || item.rarity === 'legendary') {
    // Эпический предмет: тир 1 ресурс (20, 40, 60, 80...), тир 2 ресурс (8, 16, 24, 32...), тир 3 ресурс (4, 8, 12, 16...), тир 4 ресурс (1, 2, 3, 4...)
    costs.iron_ore = nextLevel * 20;
    costs.magic_crystal = nextLevel * 8;
    costs.monster_core = nextLevel * 4;
    costs.ancient_rune = nextLevel; // Древний свиток
  }

  return costs;
}

// Upgrade an item's stats and level (+1 Level)
// Rules:
// - Weapons: Epic +4 dmg, Rare +3 dmg (50% more than Magic), Magic +2 dmg, Common +1 dmg
// - Attributes: Epic +3, Rare +2, Magic +1, Common 0
// - All values strictly integers at all upgrade levels!
export function upgradeItemStats(item: InventoryItem): InventoryItem {
  const nextLevel = Math.min(10, item.level + 1);
  const nextStats = { ...item.stats };

  const isWeapon = item.category === 'weapon';
  const dmgInc = isWeapon
    ? (item.rarity === 'epic' ? 4 : item.rarity === 'rare' ? 3 : item.rarity === 'magic' ? 2 : 1)
    : 0;

  const inc = item.rarity === 'epic' ? 4 : item.rarity === 'rare' ? 3 : item.rarity === 'magic' ? 2 : 1;

  if (nextStats.armor !== undefined) {
    nextStats.armor = Math.round(nextStats.armor + inc);
  }
  if (nextStats.hp !== undefined) {
    nextStats.hp = Math.round(nextStats.hp + inc);
  }
  if (nextStats.critChance !== undefined) {
    const critBonus = item.rarity === 'epic' ? 0.01 : (item.rarity === 'rare' ? (nextLevel % 2 === 0 ? 0.01 : 0) : (nextLevel % 3 === 0 ? 0.01 : 0));
    nextStats.critChance = Math.min(0.5, Math.round((nextStats.critChance + critBonus) * 100) / 100);
  }
  if (nextStats.speed !== undefined) {
    const speedBonus = item.rarity === 'epic' ? (nextLevel % 2 === 0 ? 1 : 0) : (item.rarity === 'rare' ? (nextLevel % 3 === 0 ? 1 : 0) : (nextLevel % 5 === 0 ? 1 : 0));
    nextStats.speed = Math.round(nextStats.speed + speedBonus);
  }
  if (nextStats.mana !== undefined) {
    nextStats.mana = Math.round(nextStats.mana + inc * 2);
  }

  // Primary attributes upgrades (Common items do NOT have primary attributes):
  // Magic: +1 per level
  // Rare: +2 per level (50-100% better than Magic)
  // Epic: +3 per level (100-200% better than Magic)
  if (item.rarity !== 'common') {
    const attrInc = item.rarity === 'epic' ? 3 : (item.rarity === 'rare' ? 2 : 1);

    if (nextStats.strength !== undefined) {
      nextStats.strength = Math.round(nextStats.strength + attrInc);
    }
    if (nextStats.agility !== undefined) {
      nextStats.agility = Math.round(nextStats.agility + attrInc);
    }
    if (nextStats.endurance !== undefined) {
      nextStats.endurance = Math.round(nextStats.endurance + attrInc);
    }
    if (nextStats.intelligence !== undefined) {
      nextStats.intelligence = Math.round(nextStats.intelligence + attrInc);
    }
  }

  const isVampireItem = item.name === 'Клыки Вампира' || item.name === 'Кольцо Вампира' || item.name === 'Колье Вампира' || nextStats.vampirism !== undefined || item.stats.vampirism !== undefined || item.vampirism !== undefined;
  if (isVampireItem) {
    const curVamp = nextStats.vampirism ?? item.stats.vampirism ?? item.vampirism ?? 0.39;
    const vampInc = nextLevel % 2 === 0 ? 0.20 : 0;
    nextStats.vampirism = Math.round((curVamp + vampInc) * 100) / 100;
  }

  let updatedWeapon = item.weaponData ? { ...item.weaponData } : undefined;
  if (updatedWeapon) {
    const rarity = item.rarity || 'common';
    const stunInc = 0.007; // -30% (was 0.01) -> +0.7%/lvl
    const hammerBonusInc = 0.02; // +2%/lvl
    const dsInc = 0.01; // +1%/lvl
    const bleedChanceInc = 0.01; // +1%/lvl
    const bleedDmgInc = 0.03; // +3%/lvl
    const ruthlessnessInc = 0.00021125; // +30% -> +0.021125%/lvl

    const baseMinDmg = Math.round(updatedWeapon.minDamage ?? nextStats.damageMin ?? 4);
    const baseMaxDmg = Math.round(updatedWeapon.maxDamage ?? nextStats.damageMax ?? 8);
    const newMinDmg = Math.round(baseMinDmg + dmgInc);
    const newMaxDmg = Math.round(baseMaxDmg + dmgInc);

    nextStats.damageMin = newMinDmg;
    nextStats.damageMax = newMaxDmg;

    const curStunChance = updatedWeapon.stunChance ?? (rarity === 'epic' ? 0.14 : rarity === 'rare' ? 0.105 : 0.07);
    const curHammerBonus = updatedWeapon.bonusDamageMultiplier ?? (rarity === 'epic' ? 1.00 : rarity === 'rare' ? 0.80 : 0.65);
    const curDsChance = updatedWeapon.doubleStrikeChance ?? (rarity === 'epic' ? 0.20 : rarity === 'rare' ? 0.15 : 0.10);
    const curBleedChance = updatedWeapon.bleedChance ?? (rarity === 'epic' ? 0.20 : rarity === 'rare' ? 0.15 : 0.10);
    const curBleedRatio = updatedWeapon.bleedDamageRatio ?? (rarity === 'epic' ? 0.60 : rarity === 'rare' ? 0.45 : 0.30);
    const curRuthlessness = updatedWeapon.ruthlessnessRatio ?? (rarity === 'epic' ? 0.0054925 : rarity === 'rare' ? 0.0038025 : 0.00232375);

    updatedWeapon = {
      ...updatedWeapon,
      upgradeLevel: nextLevel,
      minDamage: newMinDmg,
      maxDamage: newMaxDmg,
      critChance: nextStats.critChance !== undefined ? Math.round(nextStats.critChance * 100) / 100 : updatedWeapon.critChance,
      stunChance: updatedWeapon.type === 'hammer' ? Math.min(0.6, Math.round((curStunChance + stunInc) * 1000) / 1000) : undefined,
      bonusDamageMultiplier: updatedWeapon.type === 'hammer' ? Math.round((curHammerBonus + hammerBonusInc) * 100) / 100 : updatedWeapon.bonusDamageMultiplier,
      stunDurationMin: updatedWeapon.type === 'hammer' ? 2 : undefined,
      stunDurationMax: updatedWeapon.type === 'hammer' ? 2 : undefined,
      doubleStrikeChance: (updatedWeapon.type === 'sword' || updatedWeapon.type === 'rapier' || updatedWeapon.type === 'katana' || updatedWeapon.type === 'greatsword' || updatedWeapon.type === 'dagger')
        ? Math.min(0.6, Math.round((curDsChance + dsInc) * 100) / 100)
        : undefined,
      bleedChance: updatedWeapon.type === 'spear' ? Math.min(0.7, Math.round((curBleedChance + bleedChanceInc) * 100) / 100) : undefined,
      bleedDamageRatio: updatedWeapon.type === 'spear' ? Math.round((curBleedRatio + bleedDmgInc) * 100) / 100 : undefined,
      ruthlessnessRatio: updatedWeapon.type === 'axe' ? Math.round((curRuthlessness + ruthlessnessInc) * 100000) / 100000 : undefined
    };

    if (updatedWeapon.stunChance !== undefined) nextStats.stunChance = updatedWeapon.stunChance;
    if (updatedWeapon.bonusDamageMultiplier !== undefined) nextStats.bonusDamageMultiplier = updatedWeapon.bonusDamageMultiplier;
    if (updatedWeapon.doubleStrikeChance !== undefined) nextStats.doubleStrikeChance = updatedWeapon.doubleStrikeChance;
    if (updatedWeapon.bleedChance !== undefined) nextStats.bleedChance = updatedWeapon.bleedChance;
    if (updatedWeapon.bleedDamageRatio !== undefined) nextStats.bleedDamageRatio = updatedWeapon.bleedDamageRatio;
    if (updatedWeapon.ruthlessnessRatio !== undefined) nextStats.ruthlessnessRatio = updatedWeapon.ruthlessnessRatio;
  } else {
    // Non-weapon damage stats
    if (nextStats.damageMin !== undefined && nextStats.damageMax !== undefined) {
      nextStats.damageMin = Math.round(nextStats.damageMin + dmgInc);
      nextStats.damageMax = Math.round(nextStats.damageMax + dmgInc);
    } else if (nextStats.damageMin !== undefined) {
      nextStats.damageMin = Math.round(nextStats.damageMin + dmgInc);
    }
  }

  let finalDescription = item.description;
  if (isVampireItem) {
    const vStr = Number((nextStats.vampirism || 0.39).toFixed(2));
    finalDescription = `• Уникальный эффект: Вампиризм +${vStr}% (восстанавливает здоровье при ударе, +0.20% каждые 2 ур.)`;
    if (updatedWeapon) {
      updatedWeapon = {
        ...updatedWeapon,
        description: finalDescription
      };
    }
  } else if (updatedWeapon && updatedWeapon.type === 'hammer') {
    const sChance = Math.round((updatedWeapon.stunChance || 0) * 100);
    const sBonus = Math.round((updatedWeapon.bonusDamageMultiplier || 0) * 100);
    
    finalDescription = `• Уникальный эффект: Оглушение ${sChance}% шанс (+0.7%/ур.) на 2 сек. и +${sBonus}% (+2%/ур.) доп. урона.`;
    updatedWeapon.description = finalDescription;
  } else if (updatedWeapon && (updatedWeapon.type === 'sword' || updatedWeapon.type === 'rapier' || updatedWeapon.type === 'katana' || updatedWeapon.type === 'greatsword' || updatedWeapon.type === 'dagger')) {
    const dsChance = Math.round((updatedWeapon.doubleStrikeChance || 0) * 100);
    
    finalDescription = `• Уникальный эффект: Двойной удар ${dsChance}% шанс (+1%/ур.) мгновенно нанести 2-й удар (КД 1 сек).`;
    updatedWeapon.description = finalDescription;
  } else if (updatedWeapon && updatedWeapon.type === 'spear') {
    const bChance = Math.round((updatedWeapon.bleedChance || 0) * 100);
    const bDmg = Math.round((updatedWeapon.bleedDamageRatio || 0) * 100);

    finalDescription = `• Уникальный эффект: Рваная рана ${bChance}% шанс (+1%/ур.) наносит ${bDmg}% (+3%/ур.) урона за 2.5 сек.`;
    updatedWeapon.description = finalDescription;
  } else if (updatedWeapon && updatedWeapon.type === 'axe') {
    const rVal = Math.round((updatedWeapon.ruthlessnessRatio || 0) * 10000) / 100;

    finalDescription = `• Уникальный эффект: Безжалостность +${rVal}% (+0.01%/ур.) урона за каждый 1% недостающего здоровья цели.`;
    updatedWeapon.description = finalDescription;
  }

  const isChainLightningItem = item.id.includes('chain_lightning') || item.name.includes('Цепн') || item.name.includes('Грозов') || item.chainLightningChance !== undefined || nextStats.chainLightningChance !== undefined;
  if (isChainLightningItem) {
    const chancePerLvl = 0.01; // +1%/lvl
    const dmgPerLvl = 0.02; // +2%/lvl

    const baseChance = item.rarity === 'epic' ? 0.30 : item.rarity === 'rare' ? 0.20 : 0.12;
    const curChance = nextStats.chainLightningChance ?? item.chainLightningChance ?? baseChance;
    const nextChance = Math.min(0.8, Math.round((curChance + chancePerLvl) * 100) / 100);
    nextStats.chainLightningChance = nextChance;

    const baseDmgRatio = item.rarity === 'epic' ? 0.55 : item.rarity === 'rare' ? 0.40 : 0.25;
    const curDmgRatio = nextStats.chainLightningDamageRatio ?? item.chainLightningDamageRatio ?? baseDmgRatio;
    const nextDmgRatio = Math.round((curDmgRatio + dmgPerLvl) * 100) / 100;
    nextStats.chainLightningDamageRatio = nextDmgRatio;

    const cChance = Math.round((nextStats.critChance || 0) * 100);
    finalDescription = `• Уникальный эффект: Крит. шанс +${cChance}%. Удар с шансом ${Math.round(nextChance * 100)}% (+1%/ур.) вызывает Цепную молнию на ${Math.round(nextDmgRatio * 100)}% урона (+2%/ур.).`;
  }

  // Gloves Attack Recovery Speed Upgrade (+1-2-3-5% based on rarity)
  let updatedAttackRecoverySpeed = item.attackRecoverySpeed;
  if (item.category === 'gloves' || nextStats.attackRecoverySpeed !== undefined || item.stats.attackRecoverySpeed !== undefined) {
    const rarity = item.rarity || 'common';
    const speedInc = rarity === 'common' ? 1 : rarity === 'magic' ? 2 : rarity === 'rare' ? 3 : 5;
    const curSpeed = Math.round(nextStats.attackRecoverySpeed ?? item.stats.attackRecoverySpeed ?? item.attackRecoverySpeed ?? 5);
    nextStats.attackRecoverySpeed = curSpeed + speedInc;
    updatedAttackRecoverySpeed = nextStats.attackRecoverySpeed;
  }

  return enforceStatRules({
    ...item,
    level: nextLevel,
    description: finalDescription,
    stats: nextStats,
    vampirism: nextStats.vampirism,
    chainLightningChance: nextStats.chainLightningChance,
    chainLightningDamageRatio: nextStats.chainLightningDamageRatio,
    attackRecoverySpeed: updatedAttackRecoverySpeed,
    weaponData: updatedWeapon
  });
}

// Names and descriptors for procedural equipment generation
export const WEAPON_NAMES_BY_TYPE: Record<WeaponType, Record<ItemRarity, string[]>> = {
  sword: {
    common: ['Стальной Меч', 'Рыцарский Меч', 'Пехотный Меч'],
    magic: ['Клинок Ветра', 'Закаленный Меч', 'Меч Следопыта'],
    rare: ['Лазурный Меч', 'Рунный Клинок', 'Сапфировый Меч'],
    epic: ['Пламенный Меч Дракона', 'Меч Бездны', 'Сияющий Клинок Солнца', 'Клинок Солнца', 'Меч Архангела']
  },
  katana: {
    common: ['Ученическая Катана', 'Стальная Катана'],
    magic: ['Катана Ветра', 'Клинок Сакуры'],
    rare: ['Катана Бури', 'Теневая Катана', 'Лазурная Катана'],
    epic: ['Катана Ярости Дракона', 'Клинок Кровавой Луны', 'Катана Мурамаса', 'Клинок Вечности']
  },
  axe: {
    common: ['Железный Топор', 'Топор Ополченца', 'Деревенский Секач'],
    magic: ['Боевой Топор', 'Закаленный Секач', 'Топор Ловца'],
    rare: ['Секира Палача', 'Топор Северных Ветров', 'Рунный Топор'],
    epic: ['Огненная Секира Дракона', 'Топор Сокрушителя Черепов', 'Секира Разрушителя Миров', 'Топор Вечного Пламени']
  },
  hammer: {
    common: ['Железный Молот', 'Кузнечный Молот'],
    magic: ['Тяжелый Молот', 'Боевой Молот Воина'],
    rare: ['Молот Крушителя', 'Молот Грома', 'Рунный Молот'],
    epic: ['Титановый Сокрушитель', 'Молот Вулкана', 'Молот Бездны', 'Молот Прародителей', 'Крушитель Богов']
  },
  greatsword: {
    common: ['Тяжелый Двуручник', 'Двуручный Меч'],
    magic: ['Двуручный Меч Ветра', 'Палаш Великана'],
    rare: ['Великий Меч Стража', 'Двуручник Титана'],
    epic: ['Великий Меч Хаоса', 'Пожиратель Душ', 'Комета Пустоты', 'Великий Клинок Бездны', 'Владыка Хаоса']
  },
  spear: {
    common: ['Копье Ополченца', 'Деревянное Копье'],
    magic: ['Острое Копье Ветра', 'Стальное Копье'],
    rare: ['Копье Грифона', 'Руническая Пика'],
    epic: ['Копье Небес', 'Копье Огня', 'Гунгнир', 'Копье Судьбы']
  },
  rapier: {
    common: ['Стальная Рапира', 'Ученическая Шпага'],
    magic: ['Игольчатая Рапира', 'Шпага Следопыта'],
    rare: ['Ледяная Рапира', 'Рапира Шторма', 'Шпага Ветра'],
    epic: ['Хрустальная Рапира Мороза', 'Пронзатель Сердец', 'Рапира Абсолютного Нуля', 'Шпага Звездного Света']
  },
  dagger: {
    common: ['Охотничий Нож', 'Железный Кинжал'],
    magic: ['Изумрудный Стилет', 'Кинжал Следопыта'],
    rare: ['Кинжал Тени', 'Стилет Убийцы'],
    epic: ['Клыки Вампира', 'Кинжал Бездны', 'Кинжал Ночной Тени', 'Стилет Вечности']
  },
  fist: {
    common: ['Голые Кулаки', 'Кулаки Новичка'],
    magic: ['Кулаки Ветра', 'Стальные Кулаки'],
    rare: ['Кулаки Титана', 'Рунные Кулаки'],
    epic: ['Кулаки Дракона', 'Кулаки Бездны', 'Кулаки Первородного Гнева', 'Божественные Кулаки']
  }
};

export const ITEM_NAMES: Record<
  Exclude<EquipmentCategory, 'weapon'>,
  Record<ItemRarity, string[]>
> = {
  helmet: {
    common: ['Железный Шлем', 'Кожаный Капеллин', 'Шлем Ополченца', 'Бацинет Новичка'],
    magic: ['Шлем Следопыта', 'Лесной Капюшон', 'Закаленный Подшлемник'],
    rare: ['Визор Стража', 'Шлем Самурая', 'Венец Титана'],
    epic: ['Шлем Драконьего Владыки', 'Лик Бездны', 'Корона Пламени', 'Корона Бессмертных']
  },
  cloak: {
    common: ['Походная Мантия', 'Холщовый Плащ', 'Накидка Путника'],
    magic: ['Лесная Мантия', 'Плащ Тени', 'Плащ Следопыта'],
    rare: ['Мантия Бури', 'Накидка Сквозняка', 'Саван Пустоты'],
    epic: ['Мантия Владыки', 'Плащ Дракона', 'Покров Бессмертия']
  },
  chest: {
    common: ['Кожаный Панцирь', 'Железная Кольчуга', 'Стеганый Доспех', 'Нагрудник Ополченца'],
    magic: ['Чешуйчатый Доспех', 'Закаленная Кольчуга', 'Кираса Следопыта'],
    rare: ['Нагрудник Стража', 'Латы Титана', 'Кираса Мечника'],
    epic: ['Доспех Драконьей Чешуи', 'Кираса Бессмертного', 'Панцирь Пустоты', 'Эгида Богов']
  },
  bracers: {
    common: ['Кожаные Наручи', 'Железные Запястья'],
    magic: ['Браслеты Охотника', 'Наручи Воина'],
    rare: ['Наручи Стража', 'Браслеты Повелителя Бурь'],
    epic: ['Наручи Дракона', 'Оковы Титана']
  },
  gloves: {
    common: ['Рабочие Рукавицы', 'Кожаные Перчатки'],
    magic: ['Перчатки Охотника', 'Ловкие Рукавицы'],
    rare: ['Перчатки Мечника', 'Рукавицы Силы'],
    epic: ['Перчатки Пламени', 'Хватка Демона', 'Перчатки Бездны', 'Длани Разрушителя']
  },
  belt: {
    common: ['Веревочный Пояс', 'Кожаный Ремень'],
    magic: ['Усиленный Пояс', 'Кушак Ловца'],
    rare: ['Пояс Воина', 'Ремень Стойкости', 'Пояс Великана'],
    epic: ['Пояс Несокрушимости', 'Пояс Драконьей Мощи', 'Пояс Абсолюта']
  },
  pants: {
    common: ['Суконные Штаны', 'Кожаные Поножи'],
    magic: ['Укрепленные Поножи', 'Штаны Следопыта'],
    rare: ['Латные Поножи Воина', 'Штаны Шиноби', 'Поножи Стража'],
    epic: ['Поножи Инферно', 'Поножи Дракона', 'Поножи Вечности']
  },
  boots: {
    common: ['Кожаные Башмаки', 'Сапоги Путника'],
    magic: ['Быстроходные Ботинки', 'Сапоги Охотника'],
    rare: ['Сапоги Странника', 'Латные Сапоги Мечника'],
    epic: ['Поступь Ветра', 'Сапоги Разрушителя', 'Теневые Ботфорты', 'Поступь Бури']
  },
  ring: {
    common: ['Медное Кольцо', 'Простое Кольцо', 'Железное Кольцо'],
    magic: ['Нефритовый Перстень', 'Изумрудное Кольцо', 'Кольцо Концентрации'],
    rare: ['Кольцо Силы', 'Кольцо Ловкости', 'Перстень Ветра'],
    epic: ['Перстень Абсолюта', 'Кольцо Хаоса', 'Око Бездны', 'Кольцо Вампира', 'Кольцо Владыки']
  },
  trinket: {
    common: ['Деревянный Оберег', 'Медный Талисман', 'Амулет Путника'],
    magic: ['Лесной Оберег', 'Янтарный Кулон', 'Заряженный Талисман', 'Амулет Цепной Молнии'],
    rare: ['Печать Воина', 'Символ Ветра', 'Талисман Огня', 'Рунный Талисман', 'Амулет Цепной Молнии'],
    epic: ['Осколок Вечности', 'Печать Дракона', 'Сердце Феникса', 'Реликвия Древних', 'Амулет Цепной Молнии', 'Слеза Богов']
  }
};

const CATEGORY_ICONS: Record<EquipmentCategory, string> = {
  weapon: 'Sword',
  helmet: 'HardHat',
  cloak: 'Wind',
  chest: 'Shirt',
  bracers: 'Watch',
  gloves: 'Hand',
  belt: 'Minimize2',
  pants: 'Footprints',
  boots: 'Sparkle',
  ring: 'CircleDot',
  trinket: 'Sparkles'
};

// Procedural generation of dropped equipment items
// Green (magic): 2 random stats (1-2 each), upgrade +1 each
// Blue (rare): 2 random stats (3-4 each), upgrade +2 each
// Epic (epic): 3 random stats (4-6 each), upgrade +3 each
export function generateEquipmentDrop(
  rarity: ItemRarity, 
  dungeonLevel: number = 1,
  forcedCategory?: EquipmentCategory
): InventoryItem {
  const categories: EquipmentCategory[] = [
    'weapon',
    'helmet',
    'cloak',
    'chest',
    'bracers',
    'gloves',
    'belt',
    'pants',
    'boots',
    'ring',
    'trinket'
  ];

  const category = forcedCategory || categories[Math.floor(Math.random() * categories.length)];
  const rarityMult = rarity === 'epic' ? 2.5 : rarity === 'rare' ? 1.8 : rarity === 'magic' ? 1.4 : 1.0;

  let name = '';
  let icon = CATEGORY_ICONS[category];
  let weaponData: Weapon | undefined = undefined;

  const stats: InventoryItem['stats'] = {};

  // Determine number of stats and roll range based on rarity:
  // Green: 2 stats (2-3)
  // Blue: 2 stats (3-5)
  // Epic: 3 stats (5-8)
  // Common: 1 stat (1-2)
  const statCount = rarity === 'epic' ? 3 : rarity === 'rare' ? 2 : rarity === 'magic' ? 2 : 1;
  const rollMin = rarity === 'epic' ? 5 : rarity === 'rare' ? 3 : rarity === 'magic' ? 2 : 1;
  const rollMax = rarity === 'epic' ? 8 : rarity === 'rare' ? 5 : rarity === 'magic' ? 3 : 2;

  const getRoll = () => rollMin + Math.floor(Math.random() * (rollMax - rollMin + 1));

  if (category === 'weapon') {
    const weaponTypes: WeaponType[] = ['sword', 'katana', 'axe', 'hammer', 'greatsword', 'spear', 'rapier', 'dagger'];
    const wType = weaponTypes[Math.floor(Math.random() * weaponTypes.length)];
    let pool = WEAPON_NAMES_BY_TYPE[wType][rarity] || WEAPON_NAMES_BY_TYPE[wType]['common'];
    if (wType === 'dagger' && (rarity === 'rare' || rarity === 'epic') && Math.random() < 0.6) {
      name = 'Клыки Вампира';
    } else {
      name = pool[Math.floor(Math.random() * pool.length)];
      if (wType === 'dagger' && (rarity === 'rare' || rarity === 'epic') && Math.random() < 0.4) name = 'Клыки Вампира';
    }

    const wDmgRoll = getRoll();
    stats.damageMin = 2 + wDmgRoll;
    stats.damageMax = 5 + wDmgRoll;

    const secondaryPool: ('critChance' | 'hp' | 'speed' | 'armor' | 'mana')[] = ['critChance', 'hp', 'speed', 'armor', 'mana'];
    const shuffledSec = [...secondaryPool].sort(() => Math.random() - 0.5);
    const extraStatCount = statCount - 1; // 1 stat is already weapon damage

    for (let i = 0; i < extraStatCount; i++) {
      const sType = shuffledSec[i];
      const roll = getRoll();
      if (sType === 'critChance') {
        stats.critChance = Math.max(0.005, Math.round(((roll * 0.5) / 100) * 1000) / 1000);
      } else if (sType === 'hp') {
        stats.hp = Math.max(1, roll);
      } else if (sType === 'speed') {
        stats.speed = Math.max(1, Math.round(roll));
      } else if (sType === 'armor') {
        stats.armor = Math.max(1, roll);
      } else if (sType === 'mana') {
        stats.mana = Math.max(1, roll * 2);
      }
    }

    const elements: WeaponElement[] = ['none', 'wind', 'fire', 'ice'];
    const wElem = rarity === 'epic' ? elements[Math.floor(Math.random() * elements.length)] : 'none';

    icon = wType === 'axe' ? 'Axe' : wType === 'hammer' ? 'Hammer' : 'Sword';
    const wLen = wType === 'greatsword' ? 100 : wType === 'dagger' ? 65 : wType === 'spear' ? 105 : wType === 'axe' ? 82 : wType === 'hammer' ? 88 : 80;
    const wWeight = wType === 'greatsword' ? 1.5 : wType === 'hammer' ? 1.6 : wType === 'axe' ? 1.3 : wType === 'spear' ? 1.1 : wType === 'dagger' ? 0.6 : 0.9;

    weaponData = {
      id: `wep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name,
      type: wType,
      rarity: rarity === 'magic' ? 'rare' : rarity as any,
      minDamage: stats.damageMin,
      maxDamage: stats.damageMax,
      length: wLen,
      weight: wWeight,
      critChance: stats.critChance || 0,
      critMultiplier: rarity === 'epic' ? 1.6 : rarity === 'rare' ? 1.4 : 1.25,
      element: wElem,
      upgradeLevel: 0,
      maxUpgradeLevel: 10,
      stunChance: wType === 'hammer' ? (
        rarity === 'magic' ? 0.07 :
        rarity === 'rare' ? 0.105 :
        rarity === 'epic' ? 0.14 :
        0.04
      ) : undefined,
      stunDurationMin: wType === 'hammer' ? 2 : undefined,
      stunDurationMax: wType === 'hammer' ? 2 : undefined,
      bonusDamageMultiplier: wType === 'hammer' ? (
        rarity === 'magic' ? 0.65 : 
        rarity === 'rare' ? 0.80 : 
        rarity === 'epic' ? 1.00 : 
        0.50
      ) : undefined,
      doubleStrikeChance: (wType === 'sword' || wType === 'rapier' || wType === 'katana' || wType === 'greatsword' || wType === 'dagger') ? (
        rarity === 'magic' ? (0.07 + Math.random() * 0.02) :
        rarity === 'rare' ? (0.10 + Math.random() * 0.02) :
        rarity === 'epic' ? (0.15 + Math.random() * 0.03) :
        0.06
      ) : undefined,
      bleedChance: wType === 'spear' ? (
        rarity === 'magic' ? (0.06 + Math.random() * 0.02) :
        rarity === 'rare' ? (0.09 + Math.random() * 0.03) :
        rarity === 'epic' ? (0.16 + Math.random() * 0.04) :
        0.05
      ) : undefined,
      bleedDamageRatio: wType === 'spear' ? (
        rarity === 'magic' ? 1.20 :
        rarity === 'rare' ? 1.50 :
        rarity === 'epic' ? 1.85 :
        1.00
      ) : undefined,
      ruthlessnessRatio: wType === 'axe' ? (
        rarity === 'epic' ? Math.round(((0.0110 + Math.random() * 0.0040) * 0.4225) * 100000) / 100000 :
        rarity === 'rare' ? Math.round(((0.0070 + Math.random() * 0.0040) * 0.4225) * 100000) / 100000 :
        rarity === 'magic' ? Math.round(((0.0040 + Math.random() * 0.0030) * 0.4225) * 100000) / 100000 :
        0.0012675
      ) : undefined,
      description: '', // set below
      color: rarity === 'epic' ? '#c084fc' : rarity === 'rare' ? '#38bdf8' : rarity === 'magic' ? '#4ade80' : '#cbd5e1',
      glowColor: rarity === 'epic' ? '#a855f7' : rarity === 'rare' ? '#0284c7' : rarity === 'magic' ? '#22c55e' : '#94a3b8',
      iconName: icon
    };

    const dsChanceVal = weaponData.doubleStrikeChance ? Math.round(weaponData.doubleStrikeChance * 1000) / 10 : 0;
    const dsIncVal = rarity === 'magic' ? '0.75' : rarity === 'rare' ? '1' : rarity === 'epic' ? '2' : '0.5';
    const sIncVal = rarity === 'magic' ? '1.35' : rarity === 'rare' ? '1.8' : rarity === 'epic' ? '3.15' : '0.9';
    const sChanceVal = weaponData.stunChance ? Math.round(weaponData.stunChance * 1000) / 10 : 0;
    
    if (wType === 'hammer') {
      const sBonusVal = Math.round((weaponData.bonusDamageMultiplier || 0) * 100);
      weaponData.description = `• Уникальный эффект: Оглушение ${sChanceVal}% шанс (+${sIncVal}%/ур.) на 2 сек. и +${sBonusVal}% доп. урона.`;
    } else if (wType === 'spear') {
      const bChanceVal = Math.round((weaponData.bleedChance || 0) * 1000) / 10;
      const bDmgVal = Math.round((weaponData.bleedDamageRatio || 0) * 100);
      const bChanceInc = rarity === 'magic' ? '0.75' : rarity === 'rare' ? '1' : rarity === 'epic' ? '1.75' : '0.5';
      const bDmgInc = rarity === 'magic' ? '3.5' : rarity === 'rare' ? '5.5' : rarity === 'epic' ? '7.5' : '2';
      weaponData.description = `• Уникальный эффект: Рваная рана ${bChanceVal}% шанс (+${bChanceInc}%/ур.) наносит ${bDmgVal}% (+${bDmgInc}%/ур.) урона за 2.5 сек.`;
    } else if (wType === 'axe') {
      const rVal = Math.round((weaponData.ruthlessnessRatio || 0) * 10000) / 100;
      const rIncStr = rarity === 'magic' ? '0.02' : rarity === 'rare' ? '0.04' : rarity === 'epic' ? '0.05' : '0.01';
      weaponData.description = `• Уникальный эффект: Безжалостность +${rVal}% (+${rIncStr}%/ур.) урона за каждый 1% недостающего здоровья цели.`;
    } else if (weaponData.doubleStrikeChance !== undefined) {
      weaponData.description = `• Уникальный эффект: Двойной удар ${dsChanceVal}% шанс (+${dsIncVal}%/ур.) мгновенно восстановить атаку.`;
    }
  } else {
    const nameList = (ITEM_NAMES as any)[category][rarity] || (ITEM_NAMES as any)[category]['common'];
    if (category === 'ring' && (rarity === 'rare' || rarity === 'epic') && Math.random() < 0.6) {
      name = 'Кольцо Вампира';
    } else if (category === 'trinket' && (rarity === 'magic' || rarity === 'rare' || rarity === 'epic') && Math.random() < 0.45) {
      name = 'Амулет Цепной Молнии';
    } else {
      name = nameList[Math.floor(Math.random() * nameList.length)];
      if (category === 'ring' && (rarity === 'rare' || rarity === 'epic') && Math.random() < 0.4) name = 'Кольцо Вампира';
      if (category === 'trinket' && (rarity === 'magic' || rarity === 'rare' || rarity === 'epic') && Math.random() < 0.3) name = 'Амулет Цепной Молнии';
    }

    // Stat candidates pool for armor/accessories
    let poolCandidates: ('armor' | 'hp' | 'damage' | 'critChance' | 'speed' | 'mana')[] = ['armor', 'hp', 'damage', 'critChance', 'speed', 'mana'];
    if (category === 'chest' || category === 'helmet' || category === 'pants') {
      poolCandidates = ['armor', 'hp', 'armor', 'hp', 'speed', 'mana'];
    } else if (category === 'ring' || category === 'trinket') {
      poolCandidates = ['damage', 'critChance', 'damage', 'hp', 'mana', 'armor'];
    } else if (category === 'boots' || category === 'cloak') {
      poolCandidates = ['speed', 'armor', 'speed', 'hp', 'critChance', 'mana'];
    }

    const chosenStats: ('armor' | 'hp' | 'damage' | 'critChance' | 'speed' | 'mana')[] = [];
    const shuffled = [...poolCandidates].sort(() => Math.random() - 0.5);
    for (const s of shuffled) {
      if (!chosenStats.includes(s)) {
        chosenStats.push(s);
        if (chosenStats.length >= statCount) break;
      }
    }

    for (const sType of chosenStats) {
      const roll = getRoll();
      if (sType === 'armor') {
        stats.armor = Math.max(1, roll);
      } else if (sType === 'hp') {
        stats.hp = Math.max(1, roll);
      } else if (sType === 'damage') {
        stats.damageMin = Math.max(1, roll);
        stats.damageMax = Math.max(stats.damageMin + 1, roll + (rarity === 'epic' ? 3 : rarity === 'rare' ? 2 : 1));
      } else if (sType === 'critChance') {
        stats.critChance = Math.max(0.005, Math.round(((roll * 0.5) / 100) * 1000) / 1000);
      } else if (sType === 'speed') {
        stats.speed = Math.max(1, Math.round(roll));
      } else if (sType === 'mana') {
        stats.mana = Math.max(1, roll * 2);
      }
    }
  }

  // Roll additional primary attributes (strength, agility, endurance, intelligence):
  // Common items have NO primary attributes per user requirement!
  // Green (magic): 2 random attributes (1-2 each)
  // Blue (rare): 2 random attributes (3-4 each)
  // Purple (epic): 3 random attributes (4-6 each)
  if (rarity !== 'common') {
    const primaryPool: ('strength' | 'agility' | 'endurance' | 'intelligence')[] = [
      'strength',
      'agility',
      'endurance',
      'intelligence'
    ];
    const shuffledPrimary = [...primaryPool].sort(() => Math.random() - 0.5);

    const primaryCount = rarity === 'epic' ? 3 : 2;
    const primaryMin = rarity === 'epic' ? 4 : rarity === 'rare' ? 3 : 2;
    const primaryMax = rarity === 'epic' ? 6 : rarity === 'rare' ? 5 : 3;

    for (let i = 0; i < primaryCount; i++) {
      const attrKey = shuffledPrimary[i];
      const rollVal = primaryMin + Math.floor(Math.random() * (primaryMax - primaryMin + 1));
      stats[attrKey] = rollVal;
    }
  }

  // Salvage Yield
  const salvageYield = {
    iron_ore: Math.max(3, Math.round(5 * rarityMult)),
    magic_crystal: rarity !== 'common' ? Math.max(1, Math.round(2 * rarityMult)) : undefined,
    monster_core: rarity === 'epic' ? 1 : undefined,
    ancient_rune: undefined
  };

  const isVampireItem = name === 'Клыки Вампира' || name === 'Кольцо Вампира' || name === 'Колье Вампира';
  if (isVampireItem) {
    stats.vampirism = 0.39;
  }

  const isChainLightningItem = name === 'Амулет Цепной Молнии' || name.includes('Цепн');
  let itemChainChance: number | undefined = undefined;
  let itemChainDmg: number | undefined = undefined;

  // Gloves Attack Recovery Speed:
  // common: 3-7%, magic: 5-9%, rare: 9-15%, epic: 15-25%
  let itemAttackRecoverySpeed: number | undefined = undefined;
  if (category === 'gloves') {
    let speedMin = 3;
    let speedMax = 7;
    if (rarity === 'magic') {
      speedMin = 5;
      speedMax = 9;
    } else if (rarity === 'rare') {
      speedMin = 9;
      speedMax = 15;
    } else if (rarity === 'epic') {
      speedMin = 12;
      speedMax = 20;
    }
    const rolledSpeed = speedMin + Math.floor(Math.random() * (speedMax - speedMin + 1));
    stats.attackRecoverySpeed = rolledSpeed;
    itemAttackRecoverySpeed = rolledSpeed;
  }

  if (isChainLightningItem) {
    // 3 Versions:
    // Green (magic): 15% chance (+3%/lvl), 30% damage (+5%/lvl)
    // Blue (rare): 25% chance (+5%/lvl), 45% damage (+10%/lvl)
    // Purple (epic): 40% chance (+15%/lvl), 55% damage (+15%/lvl)
    const chancePerLvl = rarity === 'magic' ? 0.03 : rarity === 'epic' ? 0.15 : 0.05;
    const dmgPerLvl = rarity === 'magic' ? 0.05 : rarity === 'epic' ? 0.15 : 0.10;
    const baseChance = rarity === 'magic' ? 0.15 : rarity === 'epic' ? 0.40 : 0.25;
    const baseDmgRatio = rarity === 'magic' ? 0.30 : rarity === 'epic' ? 0.55 : 0.45;

    itemChainChance = baseChance;
    itemChainDmg = baseDmgRatio;
    stats.chainLightningChance = baseChance;
    stats.chainLightningDamageRatio = baseDmgRatio;
  }

  let finalDescription = `Качественная экипировка (${rarity === 'epic' ? 'Эпическая' : rarity === 'rare' ? 'Редкая' : rarity === 'magic' ? 'Магическая' : 'Обычная'}). Масштабируется с уровнем подземелья.`;
  if (isVampireItem) {
    const vStr = Number((stats.vampirism || 0.39).toFixed(2));
    finalDescription = `• Уникальный эффект: Вампиризм +${vStr}% (восстанавливает здоровье при ударе, +0.10%/ур.)`;
  } else if (weaponData && (weaponData.type === 'sword' || weaponData.type === 'rapier' || weaponData.type === 'katana' || weaponData.type === 'greatsword' || weaponData.type === 'dagger')) {
    finalDescription = weaponData.description;
  } else if (weaponData && weaponData.type === 'spear') {
    finalDescription = weaponData.description;
  } else if (weaponData && weaponData.type === 'hammer') {
    finalDescription = weaponData.description;
  } else if (weaponData && weaponData.type === 'axe') {
    finalDescription = weaponData.description;
  } else if (isChainLightningItem) {
    const chancePerLvl = rarity === 'magic' ? 0.03 : rarity === 'epic' ? 0.15 : 0.05;
    const dmgPerLvl = rarity === 'magic' ? 0.05 : rarity === 'epic' ? 0.15 : 0.10;
    const baseChance = rarity === 'magic' ? 0.15 : rarity === 'epic' ? 0.40 : 0.25;
    const baseDmgRatio = rarity === 'magic' ? 0.30 : rarity === 'epic' ? 0.55 : 0.45;
    finalDescription = `• Уникальный эффект: Удар с шансом ${Math.round(baseChance * 100)}% (+${Math.round(chancePerLvl * 100)}%/ур.) вызывает Цепную молнию (до 4 целей).`;
  }

  let finalWeaponData = weaponData;
  if (finalWeaponData && name === 'Клыки Вампира') {
    finalWeaponData = {
      ...finalWeaponData,
      description: `${name} • Навык: Вампиризм +${stats.vampirism}% (Восстанавливает здоровье при нанесении урона, +0.35% при улучшении) • Редкость: EPIC`
    };
  }

  let baseItem: InventoryItem = {
    id: `item_${category}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name,
    category,
    rarity,
    icon,
    description: finalDescription,
    level: 1,
    chainLightningChance: itemChainChance,
    chainLightningDamageRatio: itemChainDmg,
    attackRecoverySpeed: itemAttackRecoverySpeed,
    stats,
    salvageYield,
    weaponData: finalWeaponData,
    imageKey: isChainLightningItem ? 'trinket7' : undefined
  };

  // Compute target item level based on dungeon level:
  // 1 ур. подземелья: все предметы 1 уровня
  // 2 ур. подземелья: обычные и зеленые 2 ур., синие и эпик 1 ур.
  // 3 ур. подземелья: обычные и зеленые 3 ур., синие и эпик 2 ур.
  // 4 ур. подземелья: обычные и зеленые 4 ур., синие 3 и эпик 3 ур.
  // Общая формула для ур. L >= 1:
  // - common, magic: L
  // - rare, epic, legendary: Math.max(1, L - 1)
  const dLvl = Math.max(1, dungeonLevel);
  let targetItemLevel = 1;
  if (rarity === 'common' || rarity === 'magic') {
    targetItemLevel = Math.min(10, dLvl);
  } else {
    targetItemLevel = Math.min(10, Math.max(1, dLvl - 1));
  }

  for (let lvl = 1; lvl < targetItemLevel; lvl++) {
    baseItem = upgradeItemStats(baseItem);
  }

  // Add chance for pre-upgraded (enchanted) items:
  // Chance is now balanced inversely with rarity:
  // Common: 40% base + 1%/lvl, Magic: 25% + 1%/lvl, Rare: 15% + 0.5%/lvl, Epic: 5% + 0.2%/lvl
  const rarityChances: Record<string, number> = {
    common: Math.min(0.7, 0.40 + (dungeonLevel - 1) * 0.01),
    magic: Math.min(0.5, 0.25 + (dungeonLevel - 1) * 0.01),
    rare: Math.min(0.3, 0.15 + (dungeonLevel - 1) * 0.005),
    epic: Math.min(0.15, 0.05 + (dungeonLevel - 1) * 0.002),
  };

  if (Math.random() < (rarityChances[rarity] || 0)) {
    // Level = dungeonLevel / 2, minimum 1, capped at 10
    const enchantLevel = Math.max(1, Math.min(10, Math.floor(dungeonLevel / 2)));
    for (let l = 0; l < enchantLevel; l++) {
      if (baseItem.level < 10) baseItem = upgradeItemStats(baseItem);
    }
  }

  return enforceStatRules(baseItem);
}

// Generate random common weapon of level 1 for the starter chamber chest
export function generateRandomStarterWeapon(): InventoryItem {
  return generateEquipmentDrop('common', 1, 'weapon');
}

// Chain Lightning Trinket (Green / Blue / Epic)
// Green (magic): 15% chance (+3%/lvl), 30% dmg (+5%/lvl)
// Blue (rare): 25% chance (+5%/lvl), 45% dmg (+10%/lvl)
// Purple (epic): 40% chance (+15%/lvl), 55% dmg (+15%/lvl)
export function createChainLightningTrinket(rarity: ItemRarity = 'rare', dungeonLevel: number = 1): InventoryItem {
  const actualRarity: ItemRarity = (rarity === 'magic' || rarity === 'epic') ? rarity : 'rare';

  const baseChance = actualRarity === 'epic' ? 0.30 : actualRarity === 'rare' ? 0.20 : 0.12;
  const chancePerLvl = 0.015;
  const baseDmg = actualRarity === 'epic' ? 0.55 : actualRarity === 'rare' ? 0.40 : 0.25;
  const dmgPerLvl = 0.025;
  const critChance = actualRarity === 'epic' ? 0.03 : actualRarity === 'rare' ? 0.02 : 0.01;

  const desc = `• Уникальный эффект: Крит. шанс +${(critChance * 100).toFixed(1).replace(/\.0$/, '')}%. Удар с шансом ${Math.round(baseChance * 100)}% (+1.5%/ур.) вызывает Цепную молнию на ${Math.round(baseDmg * 100)}% урона (+2.5%/ур.).`;

  let item: InventoryItem = {
    id: `trinket_chain_lightning_${actualRarity}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name: 'Амулет Цепной Молнии',
    category: 'trinket',
    rarity: actualRarity,
    icon: 'Sparkles',
    description: desc,
    level: 1,
    chainLightningChance: baseChance,
    chainLightningDamageRatio: baseDmg,
    stats: {
      chainLightningChance: baseChance,
      chainLightningDamageRatio: baseDmg,
      critChance: critChance
    },
    salvageYield: {
      iron_ore: actualRarity === 'epic' ? 12 : actualRarity === 'rare' ? 8 : 4,
      magic_crystal: actualRarity === 'epic' ? 6 : actualRarity === 'rare' ? 3 : 1,
      monster_core: actualRarity === 'epic' ? 1 : undefined
    },
    imageKey: 'trinket7'
  };

  const dLvl = Math.max(1, dungeonLevel);
  let targetItemLevel = 1;
  if (actualRarity === 'magic') {
    targetItemLevel = Math.min(10, dLvl);
  } else {
    targetItemLevel = Math.min(10, Math.max(1, dLvl - 1));
  }

  for (let lvl = 1; lvl < targetItemLevel; lvl++) {
    item = upgradeItemStats(item);
  }

  return enforceStatRules(item);
}

export interface CreateTesterItemOptions {
  category: EquipmentCategory | 'resource';
  weaponType?: WeaponType;
  name?: string;
  rarity?: ItemRarity;
  level?: number; // 0 to 10
  resourceType?: IngredientType;
  quantity?: number;
}

export function createTesterEquipmentItem(options: CreateTesterItemOptions): InventoryItem {
  const {
    category,
    weaponType = 'sword',
    name: customName,
    rarity = 'epic',
    level = 0,
    resourceType = 'iron_ore',
    quantity = 1
  } = options;

  if (category === 'resource') {
    return createResourceItem(resourceType, quantity);
  }

  // Base generation using standard logic
  let item = generateEquipmentDrop(rarity, 1, category);

  // If specific name requested
  if (customName) {
    item.name = customName;
    if (customName === 'Кольцо Вампира' || customName === 'Клыки Вампира') {
      item.stats.vampirism = Math.round(((item.stats.vampirism || 0) + 0.39) * 100) / 100;
      item.vampirism = item.stats.vampirism;
      const vStr = Number(item.stats.vampirism.toFixed(2));
      item.description = `• Уникальный эффект: Вампиризм +${vStr}% (восстанавливает здоровье при ударе)`;
    } else if (customName === 'Амулет Цепной Молнии') {
      const isEpic = rarity === 'epic';
      const isRare = rarity === 'rare';
      const baseChance = isEpic ? 0.40 : isRare ? 0.25 : 0.15;
      const baseDmg = isEpic ? 0.55 : isRare ? 0.45 : 0.30;
      item.chainLightningChance = baseChance;
      item.chainLightningDamageRatio = baseDmg;
      item.stats.chainLightningChance = baseChance;
      item.stats.chainLightningDamageRatio = baseDmg;
      item.description = `• Уникальный эффект: Удар с шансом ${Math.round(baseChance * 100)}% вызывает Цепную молнию (до 4 целей).`;
    }
  }

  if (category === 'weapon') {
    // If specific weaponType requested, reconfigure weaponData
    const wType = weaponType;
    const wNames = WEAPON_NAMES_BY_TYPE[wType][rarity] || WEAPON_NAMES_BY_TYPE[wType]['common'];
    const wName = customName || wNames[0];
    item.name = wName;
    item.icon = wType === 'axe' ? 'Axe' : wType === 'hammer' ? 'Hammer' : 'Sword';

    const wLen = wType === 'greatsword' ? 100 : wType === 'dagger' ? 65 : wType === 'spear' ? 105 : wType === 'axe' ? 82 : wType === 'hammer' ? 88 : 80;
    const wWeight = wType === 'greatsword' ? 1.5 : wType === 'hammer' ? 1.6 : wType === 'axe' ? 1.3 : wType === 'spear' ? 1.1 : wType === 'dagger' ? 0.6 : 0.9;

    const wData: Weapon = {
      id: `wep_tester_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: wName,
      type: wType,
      rarity: rarity === 'magic' ? 'rare' : rarity as any,
      minDamage: item.stats.damageMin || 8,
      maxDamage: item.stats.damageMax || 14,
      length: wLen,
      weight: wWeight,
      critChance: item.stats.critChance || 0,
      critMultiplier: rarity === 'epic' ? 1.6 : rarity === 'rare' ? 1.4 : 1.25,
      element: 'none',
      upgradeLevel: 0,
      maxUpgradeLevel: 10,
      stunChance: wType === 'hammer' ? (rarity === 'epic' ? 0.126 : rarity === 'rare' ? 0.0756 : 0.0504) : undefined,
      stunDurationMin: wType === 'hammer' ? 2 : undefined,
      stunDurationMax: wType === 'hammer' ? 2 : undefined,
      bonusDamageMultiplier: wType === 'hammer' ? (rarity === 'epic' ? 1.00 : 0.80) : undefined,
      bleedChance: wType === 'spear' ? (rarity === 'epic' ? 0.18 : 0.08) : undefined,
      bleedDamageRatio: wType === 'spear' ? (rarity === 'epic' ? 1.85 : 1.50) : undefined,
      ruthlessnessRatio: wType === 'axe' ? (rarity === 'epic' ? 0.0054925 : 0.0038025) : undefined,
      doubleStrikeChance: (wType === 'sword' || wType === 'rapier' || wType === 'katana' || wType === 'greatsword' || wType === 'dagger')
        ? (rarity === 'epic' ? 0.15 : 0.10)
        : undefined,
      description: '',
      color: rarity === 'epic' ? '#c084fc' : rarity === 'rare' ? '#38bdf8' : rarity === 'magic' ? '#4ade80' : '#cbd5e1',
      glowColor: rarity === 'epic' ? '#a855f7' : rarity === 'rare' ? '#0284c7' : rarity === 'magic' ? '#22c55e' : '#94a3b8',
      iconName: item.icon
    };

    if (wType === 'hammer') {
      wData.description = `• Уникальный эффект: Оглушение ${Math.round((wData.stunChance || 0) * 100)}% шанс на 2 сек. и +${Math.round((wData.bonusDamageMultiplier || 0) * 100)}% доп. урона.`;
    } else if (wType === 'spear') {
      wData.description = `• Уникальный эффект: Рваная рана ${Math.round((wData.bleedChance || 0) * 100)}% шанс наносит ${Math.round((wData.bleedDamageRatio || 0) * 100)}% урона за 2.5 сек.`;
    } else if (wType === 'axe') {
      wData.description = `• Уникальный эффект: Безжалостность +${Math.round((wData.ruthlessnessRatio || 0) * 10000) / 100}% урона за каждый 1% недостающего здоровья цели.`;
    } else if (wData.doubleStrikeChance !== undefined) {
      wData.description = `• Уникальный эффект: Двойной удар ${Math.round(wData.doubleStrikeChance * 100)}% шанс мгновенно восстановить атаку.`;
    }

    item.weaponData = wData;
    item.description = wData.description;
  }

  // Apply upgrade levels (0 to 10)
  item.level = 0;
  for (let l = 0; l < level; l++) {
    item = upgradeItemStats(item);
  }

  return enforceStatRules(item);
}

