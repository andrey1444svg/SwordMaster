// Map of all wall, floor, column, and dungeon environment assets
import colWallBack from '../assets/images/Стены/Блок колонны стенной задней.png';
import floorTilesBg from '../assets/images/Стены/Блок плит пола заднего фона.png';
import wallTorchBlock from '../assets/images/Стены/Блок под настенный факел.png';
import wallBgBlock from '../assets/images/Стены/Блок стены заднего фона.png';
import wallVertTop from '../assets/images/Стены/Верхний блок вертикальной стены.png';
import wallHorizTop from '../assets/images/Стены/Верхний блок горизонтальной стены.png';
import colTop from '../assets/images/Стены/Верхний блок колонны.png';
import cornerBackLeft2 from '../assets/images/Стены/Задний левый угловой блок стены 2.png';
import cornerBackLeft from '../assets/images/Стены/Задний левый угловой блок стены.png';
import cornerBackRight2 from '../assets/images/Стены/Задний правый угловой блок стены 2.png';
import cornerBackRight from '../assets/images/Стены/Задний правый угловой блок стены.png';
import cornerBackAngle from '../assets/images/Стены/Задний угловой блок стены.png';
import stairsPassage from '../assets/images/Стены/Проход с лестницей.png';
import colMid2 from '../assets/images/Стены/Средний блок колонны 2.png';
import colMid1 from '../assets/images/Стены/Средний блок колонны.png';
import wallMid2 from '../assets/images/Стены/Средний блок стены 2.png';
import wallMid1 from '../assets/images/Стены/Средний блок стены.png';

// Additional props & floor plates
import altarImg from '../assets/images/Altar.png';
import chestImg from '../assets/images/Sunduk.png';
import pot1Img from '../assets/images/Kuvshin.png';
import pot2Img from '../assets/images/Kuvshin 2.png';
import barrelImg from '../assets/images/Bochka.png';
import crateImg from '../assets/images/Yashik.png';
import flagImg from '../assets/images/Flag 1.png';
import torch1Img from '../assets/images/Fakel 1.png';
import torch2Img from '../assets/images/Fakel 2.png';
import torch3Img from '../assets/images/Fakel 3.png';

// New dungeon columns & corners & bridge
import bridgeHoriz from '../assets/images/Стены/Мост горизонтальный.png';
import cornerTopLeft from '../assets/images/Стены/Целый угол левый верхний.png';
import cornerTopRight from '../assets/images/Стены/Целый угол правый верхний.png';
import col1 from '../assets/images/Стены/Колонна 1.png';
import col2 from '../assets/images/Стены/Колонна 2.png';
import col3 from '../assets/images/Стены/Колонна 3.png';
import col4 from '../assets/images/Стены/Колонна 4.png';
import col5 from '../assets/images/Стены/Колонна 5.png';
import col6 from '../assets/images/Стены/Колонна 6.png';

// Floor plates
import plate1 from '../assets/images/plate 1.png';
import plate2 from '../assets/images/plate 2.png';
import plate3 from '../assets/images/plate 3.png';
import plate4 from '../assets/images/plate 4.png';
import plate5 from '../assets/images/plate 5.png';
import plate6 from '../assets/images/plate 6.png';
import plate7 from '../assets/images/plate 7.png';
import plate8 from '../assets/images/plate 8.png';
import plate9 from '../assets/images/plate 9.png';
import plate10 from '../assets/images/plate 10.png';
import plate11 from '../assets/images/plate 11.png';

export interface EditorAssetDefinition {
  id: string;
  name: string;
  category: 'walls' | 'columns' | 'floors' | 'props' | 'lighting';
  src: string;
  defaultWidth: number;
  defaultHeight: number;
  defaultLayer: 'floor_bg' | 'back_wall' | 'mid_props' | 'front_wall' | 'foreground';
  defaultCollision?: {
    w: number;
    h: number;
    offsetX?: number;
    offsetY?: number;
    type: 'wall' | 'door' | 'pit' | 'hazard' | 'interactable';
  };
  lightingDefaults?: {
    hasLight?: boolean;
    lightRadius?: number;
    lightIntensity?: number;
    lightColor?: string;
    lightFlicker?: boolean;
    isShadowSource?: boolean;
    shadowDensity?: number;
    shadowShape?: 'oval' | 'square';
    shadowCorners?: 'sharp' | 'rounded';
    shadowCornerRadius?: number;
  };
}

export const EDITOR_ASSETS: EditorAssetDefinition[] = [
  // --- СТЕНЫ ---
  {
    id: 'wall_horiz_top',
    name: 'Верхний блок гориз. стены',
    category: 'walls',
    src: wallHorizTop,
    defaultWidth: 64,
    defaultHeight: 48,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 48, type: 'wall' }
  },
  {
    id: 'wall_vert_top',
    name: 'Верхний блок верт. стены',
    category: 'walls',
    src: wallVertTop,
    defaultWidth: 48,
    defaultHeight: 64,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 48, h: 64, type: 'wall' }
  },
  {
    id: 'wall_bg_block',
    name: 'Блок стены заднего фона',
    category: 'walls',
    src: wallBgBlock,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 64, type: 'wall' }
  },
  {
    id: 'wall_mid_1',
    name: 'Средний блок стены 1',
    category: 'walls',
    src: wallMid1,
    defaultWidth: 64,
    defaultHeight: 48,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 48, type: 'wall' }
  },
  {
    id: 'wall_mid_2',
    name: 'Средний блок стены 2',
    category: 'walls',
    src: wallMid2,
    defaultWidth: 64,
    defaultHeight: 48,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 48, type: 'wall' }
  },
  {
    id: 'bridge_horizontal',
    name: 'Мост горизонтальный (Пролет)',
    category: 'walls',
    src: bridgeHoriz,
    defaultWidth: 128,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'corner_top_left',
    name: 'Целый угол левый верхний',
    category: 'walls',
    src: cornerTopLeft,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 64, type: 'wall' }
  },
  {
    id: 'corner_top_right',
    name: 'Целый угол правый верхний',
    category: 'walls',
    src: cornerTopRight,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 64, type: 'wall' }
  },
  {
    id: 'stairs_passage',
    name: 'Проход с лестницей',
    category: 'walls',
    src: stairsPassage,
    defaultWidth: 96,
    defaultHeight: 96,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 96, h: 32, offsetY: 0, type: 'door' }
  },
  {
    id: 'wall_torch_block',
    name: 'Блок под настенный факел',
    category: 'walls',
    src: wallTorchBlock,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 64, h: 64, type: 'wall' }
  },

  // --- КОЛОННЫ И УГЛЫ ---
  {
    id: 'column_pillar_1',
    name: 'Колонна замковая 1',
    category: 'columns',
    src: col1,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_pillar_2',
    name: 'Колонна замковая 2',
    category: 'columns',
    src: col2,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_pillar_3',
    name: 'Колонна замковая 3',
    category: 'columns',
    src: col3,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_pillar_4',
    name: 'Колонна замковая 4',
    category: 'columns',
    src: col4,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_pillar_5',
    name: 'Колонна замковая 5',
    category: 'columns',
    src: col5,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_pillar_6',
    name: 'Колонна замковая 6',
    category: 'columns',
    src: col6,
    defaultWidth: 48,
    defaultHeight: 80,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 40, h: 40, offsetY: 40, type: 'wall' }
  },
  {
    id: 'column_top',
    name: 'Верхний блок колонны',
    category: 'columns',
    src: colTop,
    defaultWidth: 54,
    defaultHeight: 60,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 48, h: 48, offsetY: 12, type: 'wall' }
  },
  {
    id: 'column_mid_1',
    name: 'Средний блок колонны 1',
    category: 'columns',
    src: colMid1,
    defaultWidth: 48,
    defaultHeight: 48,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 48, h: 48, type: 'wall' }
  },
  {
    id: 'column_mid_2',
    name: 'Средний блок колонны 2',
    category: 'columns',
    src: colMid2,
    defaultWidth: 48,
    defaultHeight: 48,
    defaultLayer: 'front_wall',
    defaultCollision: { w: 48, h: 48, type: 'wall' }
  },
  {
    id: 'column_wall_back',
    name: 'Блок колонны задней',
    category: 'columns',
    src: colWallBack,
    defaultWidth: 48,
    defaultHeight: 48,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 48, h: 48, type: 'wall' }
  },
  {
    id: 'corner_back_left',
    name: 'Задний левый угол 1',
    category: 'columns',
    src: cornerBackLeft,
    defaultWidth: 56,
    defaultHeight: 56,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 56, h: 56, type: 'wall' }
  },
  {
    id: 'corner_back_left_2',
    name: 'Задний левый угол 2',
    category: 'columns',
    src: cornerBackLeft2,
    defaultWidth: 56,
    defaultHeight: 56,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 56, h: 56, type: 'wall' }
  },
  {
    id: 'corner_back_right',
    name: 'Задний правый угол 1',
    category: 'columns',
    src: cornerBackRight,
    defaultWidth: 56,
    defaultHeight: 56,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 56, h: 56, type: 'wall' }
  },
  {
    id: 'corner_back_right_2',
    name: 'Задний правый угол 2',
    category: 'columns',
    src: cornerBackRight2,
    defaultWidth: 56,
    defaultHeight: 56,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 56, h: 56, type: 'wall' }
  },
  {
    id: 'corner_back_angle',
    name: 'Задний угловой блок',
    category: 'columns',
    src: cornerBackAngle,
    defaultWidth: 56,
    defaultHeight: 56,
    defaultLayer: 'back_wall',
    defaultCollision: { w: 56, h: 56, type: 'wall' }
  },

  // --- ПЛИТЫ И ПОЛ ---
  {
    id: 'floor_tiles_bg',
    name: 'Блок плит пола (Фон)',
    category: 'floors',
    src: floorTilesBg,
    defaultWidth: 128,
    defaultHeight: 128,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_1',
    name: 'Плита пола базовая',
    category: 'floors',
    src: plate1,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_2',
    name: 'Плита пола темная',
    category: 'floors',
    src: plate2,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_3',
    name: 'Плита пола треснувшая',
    category: 'floors',
    src: plate3,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_4',
    name: 'Плита пола узорная',
    category: 'floors',
    src: plate4,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_5',
    name: 'Плита пола каменная',
    category: 'floors',
    src: plate5,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_6',
    name: 'Плита пола мощеная',
    category: 'floors',
    src: plate6,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_7',
    name: 'Плита пола замковая',
    category: 'floors',
    src: plate7,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_8',
    name: 'Плита пола гранитная',
    category: 'floors',
    src: plate8,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_9',
    name: 'Плита пола руническая',
    category: 'floors',
    src: plate9,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_10',
    name: 'Плита пола древняя',
    category: 'floors',
    src: plate10,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },
  {
    id: 'plate_11',
    name: 'Плита пола малая',
    category: 'floors',
    src: plate11,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'floor_bg'
  },

  // --- ДЕКОР И ИНТЕРАКТИВ ---
  {
    id: 'prop_torch_1',
    name: 'Факел 1 (Настенный)',
    category: 'props',
    src: torch1Img,
    defaultWidth: 32,
    defaultHeight: 48,
    defaultLayer: 'mid_props'
  },
  {
    id: 'prop_torch_2',
    name: 'Факел 2 (Стойка)',
    category: 'props',
    src: torch2Img,
    defaultWidth: 32,
    defaultHeight: 52,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 24, h: 24, offsetY: 24, type: 'wall' }
  },
  {
    id: 'prop_torch_3',
    name: 'Факел 3 (Жаровня)',
    category: 'props',
    src: torch3Img,
    defaultWidth: 36,
    defaultHeight: 48,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 28, h: 24, offsetY: 20, type: 'wall' }
  },
  {
    id: 'prop_barrel',
    name: 'Деревянная бочка',
    category: 'props',
    src: barrelImg,
    defaultWidth: 42,
    defaultHeight: 48,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 38, h: 38, offsetY: 8, type: 'wall' }
  },
  {
    id: 'prop_pot_1',
    name: 'Кувшин 1 (Круглый)',
    category: 'props',
    src: pot1Img,
    defaultWidth: 36,
    defaultHeight: 36,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 28, h: 26, offsetY: 2, type: 'wall' }
  },
  {
    id: 'prop_pot_2',
    name: 'Кувшин 2 (Высокий)',
    category: 'props',
    src: pot2Img,
    defaultWidth: 34,
    defaultHeight: 44,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 28, h: 28, offsetY: 2, type: 'wall' }
  },
  {
    id: 'prop_crate',
    name: 'Деревянный ящик',
    category: 'props',
    src: crateImg,
    defaultWidth: 44,
    defaultHeight: 44,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 40, h: 40, offsetY: 2, type: 'wall' }
  },
  {
    id: 'prop_chest',
    name: 'Сундук с сокровищами',
    category: 'props',
    src: chestImg,
    defaultWidth: 48,
    defaultHeight: 48,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 40, h: 36, offsetY: 6, type: 'interactable' }
  },
  {
    id: 'prop_altar',
    name: 'Древний алтарь',
    category: 'props',
    src: altarImg,
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'mid_props',
    defaultCollision: { w: 56, h: 48, offsetY: 8, type: 'interactable' }
  },
  {
    id: 'prop_flag',
    name: 'Знамя подземелья',
    category: 'props',
    src: flagImg,
    defaultWidth: 40,
    defaultHeight: 64,
    defaultLayer: 'back_wall'
  },

  // --- ОСВЕЩЕНИЕ И ТЕНИ (LIGHTING & SHADOWS) ---
  {
    id: 'light_fire_flame',
    name: 'Огонек факела',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><linearGradient id="flameGrad" x1="0%" y1="100%" x2="0%" y2="0%"><stop offset="0%" stop-color="%23ea580c"/><stop offset="50%" stop-color="%23facc15"/><stop offset="100%" stop-color="%23fef08a"/></linearGradient><filter id="flameGlow" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3" result="blur"/><feComposite in="SourceGraphic" in2="blur" operator="over"/></filter></defs><path d="M 32 6 C 32 6 38 18 38 26 C 38 32 44 34 44 42 C 44 52 36 58 26 58 C 16 58 12 50 12 42 C 12 32 20 28 20 20 C 20 20 26 28 28 24 C 30 20 32 6 32 6 Z" fill="url(%23flameGrad)" filter="url(%23flameGlow)"/><path d="M 31 22 C 31 22 35 30 35 35 C 35 39 38 40 38 45 C 38 51 33 55 27 55 C 21 55 18 50 18 45 C 18 38 24 35 24 30 C 24 30 28 35 29 32 C 30 29 31 22 31 22 Z" fill="%23fff7ed"/></svg>',
    defaultWidth: 32,
    defaultHeight: 32,
    defaultLayer: 'foreground',
    lightingDefaults: {
      hasLight: true,
      lightRadius: 210,
      lightIntensity: 1.0,
      lightColor: '#ff9d3b',
      lightFlicker: true
    }
  },
  {
    id: 'light_omni_default',
    name: 'Свет',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"></svg>',
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'mid_props',
    lightingDefaults: {
      hasLight: true,
      lightRadius: 220,
      lightIntensity: 1.0,
      lightColor: '#ff9d3b',
      lightFlicker: false
    }
  },
  {
    id: 'shadow_dark_zone',
    name: 'Зона затенения (Темный угол)',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><radialGradient id="g6" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="%23020617" stop-opacity="0.95"/><stop offset="50%" stop-color="%230f172a" stop-opacity="0.75"/><stop offset="100%" stop-color="%231e293b" stop-opacity="0"/></radialGradient></defs><circle cx="32" cy="32" r="30" fill="url(%23g6)"/></svg>',
    defaultWidth: 64,
    defaultHeight: 64,
    defaultLayer: 'front_wall',
    lightingDefaults: {
      isShadowSource: true,
      shadowDensity: 0.8
    }
  },
  {
    id: 'shadow_vignette',
    name: 'Мрачная тень (Овальное пятно)',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="96" height="64" viewBox="0 0 96 64"><defs><radialGradient id="g7" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="%23000000" stop-opacity="0.9"/><stop offset="60%" stop-color="%23020617" stop-opacity="0.6"/><stop offset="100%" stop-color="%23020617" stop-opacity="0"/></radialGradient></defs><ellipse cx="48" cy="32" rx="44" ry="28" fill="url(%23g7)"/></svg>',
    defaultWidth: 96,
    defaultHeight: 64,
    defaultLayer: 'front_wall',
    lightingDefaults: {
      isShadowSource: true,
      shadowDensity: 0.85,
      shadowShape: 'oval'
    }
  },
  {
    id: 'shadow_square_dark',
    name: 'Квадратная тень (Темный блок)',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><defs><linearGradient id="sq1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="%23020617" stop-opacity="0.95"/><stop offset="100%" stop-color="%23000000" stop-opacity="0.9"/></linearGradient></defs><rect width="96" height="96" rx="4" fill="url(%23sq1)"/></svg>',
    defaultWidth: 96,
    defaultHeight: 96,
    defaultLayer: 'mid_props',
    lightingDefaults: {
      isShadowSource: true,
      shadowDensity: 0.85,
      shadowShape: 'square',
      shadowCorners: 'sharp',
      shadowCornerRadius: 10
    }
  },
  {
    id: 'shadow_rect_corridor',
    name: 'Прямоугольная тень (Коридор)',
    category: 'lighting',
    src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="96" height="48" viewBox="0 0 96 48"><defs><linearGradient id="sq2" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="%23000000" stop-opacity="0.92"/><stop offset="100%" stop-color="%23020617" stop-opacity="0.88"/></linearGradient></defs><rect width="96" height="48" fill="url(%23sq2)"/></svg>',
    defaultWidth: 96,
    defaultHeight: 48,
    defaultLayer: 'mid_props',
    lightingDefaults: {
      isShadowSource: true,
      shadowDensity: 0.8,
      shadowShape: 'square',
      shadowCorners: 'sharp',
      shadowCornerRadius: 10
    }
  }
];

export const getAssetById = (id: string): EditorAssetDefinition | undefined => {
  return EDITOR_ASSETS.find(a => a.id === id);
};
