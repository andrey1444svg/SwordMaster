// High-Fidelity Realistic Audio Engine: Physical Acoustics, Mechanical Spikes & Ethereal Magic

import spearHitAudio from '../assets/Удар копьем.mp3';
import swordHitAudio from '../assets/Удар мечом.mp3';
import hammerHitAudio from '../assets/Удар молотом.mp3';
import axeHitAudio from '../assets/Удар топором.mp3';
import lightningHitAudio from '../assets/Молния разряд 1.mp3';
import maceHitAudio from '../assets/Удар гирей.mp3';
import fattyFallAudio from '../assets/Толстяк упал.mp3';
import playerSpawnAudio from '../assets/Появление игрока.mp3';

import menuMusicSrc from '../assets/Музыка Меню.mp3';
import dungeonMusic1Src from '../assets/Музыка Подземелья.mp3';
import dungeonMusic2Src from '../assets/Музыка Подземелья 2.mp3';

interface SoundBufferBank {
  hits: AudioBuffer[];
  crits: AudioBuffer[];
  fistHits: AudioBuffer[];
  fistCrits: AudioBuffer[];
  clashes: AudioBuffer[];
  swings: AudioBuffer[];
  loots: AudioBuffer[];
  equips: AudioBuffer[];
  forges: AudioBuffer[];
  errors: AudioBuffer[];
  lasers: AudioBuffer[];
  chargingLasers: AudioBuffer[];
  droneCharges: AudioBuffer[];
  droneBlasts: AudioBuffer[];
  iceShots: AudioBuffer[];
  levelUps: AudioBuffer[];
  spikePrepares: AudioBuffer[];
  spikeErupts: AudioBuffer[];
  spikeRetracts: AudioBuffer[];
  teleports: AudioBuffer[];
  shieldBlocks: AudioBuffer[];
  wallBumps: AudioBuffer[];
  bossAwakens: AudioBuffer[];
  particles: AudioBuffer[];
  materializes: AudioBuffer[];
  skills: {
    whirlwind: AudioBuffer[];
    flame_wave: AudioBuffer[];
    aegis_shield: AudioBuffer[];
    shadow_dash: AudioBuffer[];
  };
}

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;

  // Throttling timers
  private lastHitTime: number = 0;
  private lastClashTime: number = 0;
  private lastChargingLaserTime: number = 0;
  private lastLaserTime: number = 0;
  private lastDroneChargeTime: number = 0;
  private lastDroneBlastTime: number = 0;
  private lastIceShotTime: number = 0;
  private lastLootTime: number = 0;
  private lastSwingTime: number = 0;
  private lastSpikeTime: number = 0;
  private lastTeleportTime: number = 0;
  private lastWallBumpTime: number = 0;
  private lastParticleTime: number = 0;

  private banks: SoundBufferBank | null = null;
  private isGenerating: boolean = false;
  private customWeaponBuffers: Record<string, AudioBuffer[]> = {
    sword: [],
    axe: [],
    hammer: [],
    spear: [],
    lightning: []
  };
  private customWeaponAudios: Record<string, HTMLAudioElement[]> = {
    sword: [],
    axe: [],
    hammer: [],
    spear: [],
    lightning: []
  };

  // Background Music (BGM) state
  private bgmType: 'menu' | 'dungeon' | null = null;
  private bgmAudio: HTMLAudioElement = new Audio();
  private playPromise: Promise<void> | null = null;
  private dungeonTracks: string[] = [dungeonMusic1Src, dungeonMusic2Src];
  private lastDungeonTrackIdx: number = -1;

  private currentTrackSrc: string | null = null;
  private dungeonLevel: number = 1;

  constructor() {
    this.loadCustomWeaponSounds();
    if (typeof window !== 'undefined') {
      let unlocked = false;
      const unlockAudio = () => {
        if (unlocked) return;
        unlocked = true;
        this.init();
        this.resumeBgm();
        // Remove listeners to ensure this only runs once
        window.removeEventListener('click', unlockAudio);
        window.removeEventListener('keydown', unlockAudio);
        window.removeEventListener('touchstart', unlockAudio);
      };
      
      // Add listeners
      window.addEventListener('click', unlockAudio, { passive: true });
      window.addEventListener('keydown', unlockAudio, { passive: true });
      window.addEventListener('touchstart', unlockAudio, { passive: true });
      
      // Attempt immediate unlock just in case the app is already interacted with
      setTimeout(() => {
        if (!unlocked) {
            // Even if ctx is not running, try to resume BGM as a "retry"
            this.resumeBgm();
        }
      }, 1000);

      // Pre-configure bgmAudio
      this.bgmAudio.loop = true;
      this.bgmAudio.defaultPlaybackRate = 1.0;
      this.bgmAudio.playbackRate = 1.0;
      if ('preservesPitch' in this.bgmAudio) {
        (this.bgmAudio as any).preservesPitch = true;
      }
    }
  }

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();

        // Warm analog-style master limiter to prevent clipping and keep dynamics punchy
        this.compressor = this.ctx.createDynamicsCompressor();
        this.compressor.threshold.setValueAtTime(-14, this.ctx.currentTime);
        this.compressor.knee.setValueAtTime(10, this.ctx.currentTime);
        this.compressor.ratio.setValueAtTime(4, this.ctx.currentTime);
        this.compressor.attack.setValueAtTime(0.005, this.ctx.currentTime);
        this.compressor.release.setValueAtTime(0.15, this.ctx.currentTime);

        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.55, this.ctx.currentTime);

        this.compressor.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);

        this.generateAllBuffers();
        this.loadCustomWeaponSounds();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  // --- BACKGROUND MUSIC (BGM) METHODS ---

  public async playMenuMusic() {
    this.bgmType = 'menu';
    if (this.isMuted) return;

    if (this.currentTrackSrc === menuMusicSrc && !this.bgmAudio.paused) return;

    const played = await this.safePlay(menuMusicSrc, 0.50);
    
    // If it didn't play (likely browser block), retry in 1s if still in menu
    if (!played) {
      setTimeout(() => {
        if (this.bgmType === 'menu' && this.bgmAudio.paused) {
          this.playMenuMusic();
        }
      }, 1000);
    }
  }

  public async playDungeonMusic(level?: number) {
    this.bgmType = 'dungeon';
    if (level !== undefined) this.dungeonLevel = level;
    if (this.isMuted) return;

    const lvl = this.dungeonLevel || 1;
    const nextIdx = Math.abs(lvl - 1) % this.dungeonTracks.length;
    const trackSrc = this.dungeonTracks[nextIdx];

    if (this.currentTrackSrc === trackSrc && !this.bgmAudio.paused) return;

    await this.safePlay(trackSrc, 0.45);
  }

  private async safePlay(src: string, volume: number): Promise<boolean> {
    // If a play is already in progress, wait for it
    if (this.playPromise) {
      try { await this.playPromise; } catch {}
    }

    // If it's the same source and already playing, just update volume
    if (this.currentTrackSrc === src && !this.bgmAudio.paused) {
      this.bgmAudio.volume = volume;
      return true;
    }

    this.bgmAudio.pause();
    this.bgmAudio.src = src;
    this.bgmAudio.volume = volume;
    this.bgmAudio.playbackRate = 1.0;
    this.bgmAudio.defaultPlaybackRate = 1.0;
    this.currentTrackSrc = src;

    try {
      this.playPromise = this.bgmAudio.play();
      await this.playPromise;
      return true;
    } catch (e) {
      // "play() request was interrupted by a call to pause()" or "Autoplay policy"
      return false;
    } finally {
      this.playPromise = null;
    }
  }

  public async stopBgm() {
    this.bgmType = null;
    if (this.playPromise) {
      try { await this.playPromise; } catch {}
    }
    this.bgmAudio.pause();
    this.currentTrackSrc = null;
  }

  public resumeBgm() {
    if (this.isMuted) return;
    if (this.bgmType === 'menu') {
      this.playMenuMusic();
    } else if (this.bgmType === 'dungeon') {
      this.playDungeonMusic(this.dungeonLevel);
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.55, this.ctx.currentTime);
    }
    if (this.isMuted) {
      if (this.bgmAudio) {
        this.bgmAudio.pause();
      }
    } else {
      this.resumeBgm();
    }
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public getContext(): AudioContext | null {
    this.init();
    return this.ctx;
  }

  private createBuffer(duration: number, channels: number = 2): AudioBuffer {
    const sampleRate = this.ctx?.sampleRate || 44100;
    const frameCount = Math.max(1, Math.floor(sampleRate * duration));
    if (this.ctx) {
      return this.ctx.createBuffer(channels, frameCount, sampleRate);
    }
    return {
      duration,
      length: frameCount,
      numberOfChannels: channels,
      sampleRate,
      getChannelData: () => new Float32Array(frameCount),
      copyFromChannel: () => {},
      copyToChannel: () => {}
    } as unknown as AudioBuffer;
  }

  private generateAllBuffers() {
    if (!this.ctx || this.banks || this.isGenerating) return;
    this.isGenerating = true;

    try {
      this.banks = {
        hits: [
          this.buildRealSwordSlashBuffer(0.24, 1.0, 101),
          this.buildRealSwordSlashBuffer(0.26, 1.08, 102),
          this.buildRealSwordSlashBuffer(0.22, 0.94, 103)
        ],
        crits: [
          this.buildRealSwordCritBuffer(0.38, 1.0, 201),
          this.buildRealSwordCritBuffer(0.40, 0.95, 202)
        ],
        fistHits: [
          this.buildFistPunchBuffer(0.18, 1.0, false),
          this.buildFistPunchBuffer(0.20, 1.08, false),
          this.buildFistPunchBuffer(0.17, 0.94, false)
        ],
        fistCrits: [
          this.buildFistPunchBuffer(0.26, 0.92, true),
          this.buildFistPunchBuffer(0.28, 0.88, true)
        ],
        clashes: [
          this.buildRealSteelParryBuffer(0.32, 1.0, 301),
          this.buildRealSteelParryBuffer(0.30, 1.06, 302),
          this.buildRealSteelParryBuffer(0.35, 0.92, 303)
        ],
        swings: [
          this.buildSwordWhooshBuffer(0.25, 1.0),
          this.buildSwordWhooshBuffer(0.27, 1.12),
          this.buildSwordWhooshBuffer(0.23, 0.90)
        ],
        spikePrepares: [
          this.buildSpikePrepareGrindBuffer(0.48, 1.0),
          this.buildSpikePrepareGrindBuffer(0.52, 0.95)
        ],
        spikeErupts: [
          this.buildSpikeEruptThrustBuffer(0.36, 1.0),
          this.buildSpikeEruptThrustBuffer(0.38, 1.05)
        ],
        spikeRetracts: [
          this.buildSpikeRetractBuffer(0.40, 1.0),
          this.buildSpikeRetractBuffer(0.42, 0.94)
        ],
        teleports: [
          this.buildSoftMagicTeleportBuffer(0.55, 1.0),
          this.buildSoftMagicTeleportBuffer(0.58, 1.12),
          this.buildSoftMagicTeleportBuffer(0.52, 0.92)
        ],
        shieldBlocks: [
          this.buildShieldBlockBuffer(0.28, 1.0),
          this.buildShieldBlockBuffer(0.30, 0.95)
        ],
        wallBumps: [
          this.buildWallBumpBuffer(0.18, 1.0),
          this.buildWallBumpBuffer(0.20, 1.08)
        ],
        bossAwakens: [
          this.buildBossAwakenBuffer(1.4)
        ],
        particles: [
          this.buildParticleGatherBuffer(0.35, 1.0),
          this.buildParticleGatherBuffer(0.38, 1.15),
          this.buildParticleGatherBuffer(0.32, 0.88)
        ],
        materializes: [
          this.buildMaterializeImpactBuffer(0.65, 1.0),
          this.buildMaterializeImpactBuffer(0.70, 0.95)
        ],
        loots: [
          this.buildWarmCoinLootBuffer(0.22, 1.0),
          this.buildWarmCoinLootBuffer(0.24, 1.15),
          this.buildWarmCoinLootBuffer(0.20, 0.88)
        ],
        equips: [
          this.buildLeatherGearEquipBuffer(0.22, 1.0),
          this.buildLeatherGearEquipBuffer(0.24, 0.94)
        ],
        forges: [
          this.buildBlacksmithAnvilBuffer(0.55, 1.0),
          this.buildBlacksmithAnvilBuffer(0.58, 1.05)
        ],
        errors: [
          this.buildDullErrorThudBuffer(0.22)
        ],
        lasers: [
          this.buildPlasmaLaserBuffer(0.28, 1.0),
          this.buildPlasmaLaserBuffer(0.30, 1.06)
        ],
        chargingLasers: [
          this.buildCoilChargeBuffer(1.1)
        ],
        droneCharges: [
          this.buildDroneTurbineChargeBuffer(1.0)
        ],
        droneBlasts: [
          this.buildDroneBassBlastBuffer(0.45)
        ],
        iceShots: [
          this.buildSubZeroFrostBuffer(0.45, 1.0),
          this.buildSubZeroFrostBuffer(0.48, 1.08)
        ],
        levelUps: [
          this.buildLevelUpHarmonicsBuffer(1.5)
        ],
        skills: {
          whirlwind: [this.buildWhirlwindCycloneBuffer(0.60)],
          flame_wave: [this.buildFlameWaveRoarBuffer(0.65)],
          aegis_shield: [this.buildAegisWarmSanctuaryBuffer(0.80)],
          shadow_dash: [this.buildShadowMistDashBuffer(0.35)]
        }
      };
    } catch (e) {
      console.warn('Audio synthesis initialized with fallback.', e);
    } finally {
      this.isGenerating = false;
    }
  }

  // =========================================================================
  // 1.B. FIST PUNCH / BLUNT THUD IMPACT (Удар кулаком - плотный глухой телесный удар)
  // =========================================================================
  private buildFistPunchBuffer(dur: number, pitchMult: number, isCrit: boolean): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Fast punch attack envelope with punchy meatiness
      const env = Math.exp(-progress * (isCrit ? 18 : 26));

      // Low-end chest/body compression thud (sweeping from ~180Hz down to 45Hz)
      const startFreq = (isCrit ? 220 : 180) * pitchMult;
      const thud = Math.sin(2 * Math.PI * (startFreq * Math.exp(-progress * 24) + 40) * t) * 0.85;

      // Mid-frequency flesh smack / body impact transient
      const smack = Math.sin(2 * Math.PI * (340 * pitchMult * Math.exp(-progress * 30)) * t) * Math.exp(-progress * 35) * 0.45;

      // Quick burst of damped bone/body friction noise
      const noise = (Math.random() * 2 - 1) * Math.exp(-progress * 42) * (isCrit ? 0.35 : 0.22);

      const raw = (thud + smack + noise) * env * (isCrit ? 1.4 : 1.1);
      const sample = Math.tanh(raw);

      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 1. REALISTIC SWORD SLASH & FLESH IMPACT (Меч рубит плоть - без звука посуды!)
  // =========================================================================
  private buildRealSwordSlashBuffer(dur: number, pitchMult: number, seed: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let noiseState = seed * 12.345;
    let lp1 = 0, lp2 = 0; // 2-pole lowpass filter for dark visceral gore

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // 1. Aerodynamic blade edge entry (short sharp woosh 0-15ms)
      const bladeAirEnv = Math.exp(-progress * 42) * Math.sin(Math.min(1, progress * 12) * Math.PI);
      const bladeAir = Math.sin(2 * Math.PI * (450 * pitchMult) * Math.exp(-progress * 25) * t) * bladeAirEnv * 0.45;

      // 2. Heavy flesh impact body thud (deep low punch 60-120Hz, not high ringing!)
      const thudEnv = Math.exp(-progress * 20);
      const thudFreq = (110 * pitchMult) * Math.exp(-progress * 15) + 38;
      const thud = Math.sin(2 * Math.PI * thudFreq * t) * thudEnv * 0.75;

      // 3. Wet lacerating slice texture (shaped bandlimited pink/brown noise, no high ceramic rings)
      noiseState = (noiseState * 9301 + 49297) % 233280;
      const whiteNoise = (noiseState / 233280) * 2 - 1;
      // Filter out high frequencies above 2.5kHz completely to eliminate any dish/glass tone
      lp1 += 0.18 * (whiteNoise - lp1);
      lp2 += 0.18 * (lp1 - lp2);
      const goreEnv = Math.exp(-progress * 16) * Math.sin(Math.min(1, progress * 6) * Math.PI);
      const goreSlice = lp2 * goreEnv * 0.85;

      // 4. Blade friction through target body
      const friction = Math.sin(2 * Math.PI * (280 * pitchMult) * t) * Math.exp(-progress * 28) * 0.35;

      const raw = bladeAir + thud + goreSlice + friction;
      // Soft saturation for deep meaty punch
      const sample = Math.tanh(raw * 1.35);

      L[i] = sample * (1.0 - progress * 0.05);
      R[i] = sample * (0.95 + progress * 0.05);
    }
    return buf;
  }

  // =========================================================================
  // 2. CRITICAL STRIKE / DEEP CLEAVE (Мощный отчетливый разрубающий крит)
  // =========================================================================
  private buildRealSwordCritBuffer(dur: number, pitchMult: number, seed: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let noiseState = seed * 87.654;
    let lp1 = 0, lp2 = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // 1. Heavy sub-bass concussion thud (instant chest impact dropping from 160Hz to 38Hz)
      const subEnv = Math.exp(-progress * 10);
      const subFreq = (160 * pitchMult) * Math.exp(-progress * 12) + 38;
      const subThud = Math.sin(2 * Math.PI * subFreq * t) * subEnv * 1.1;

      // 2. Heavy visceral flesh/armor crunch (damped punchy noise)
      noiseState = (noiseState * 9301 + 49297) % 233280;
      const rawNoise = (noiseState / 233280) * 2 - 1;
      lp1 += 0.28 * (rawNoise - lp1);
      lp2 += 0.28 * (lp1 - lp2);
      const crunchEnv = Math.exp(-progress * 16) * Math.sin(Math.min(1, progress * 10) * Math.PI);
      const crunch = lp2 * crunchEnv * 1.3;

      // 3. Distinctive razor blade shear / high steel ring (1760 Hz high harmonic bell zing)
      const steelZingEnv = Math.exp(-progress * 24);
      const steelZing = Math.sin(2 * Math.PI * (1760 * pitchMult) * t) * steelZingEnv * 0.45;
      const steelHarmonic = Math.sin(2 * Math.PI * (3520 * pitchMult) * t) * Math.exp(-progress * 38) * 0.25;

      // 4. Broadsword blade body resonance (deep steel vibration around 420Hz)
      const bladeVibeEnv = Math.exp(-progress * 18);
      const bladeVibe = Math.sin(2 * Math.PI * (420 * pitchMult) * t) * bladeVibeEnv * 0.5;

      const raw = subThud + crunch + steelZing + steelHarmonic + bladeVibe;
      const sample = Math.tanh(raw * 1.6);

      L[i] = sample * 0.98;
      R[i] = sample * 1.0;
    }
    return buf;
  }

  // =========================================================================
  // 3. REAL HEAVY STEEL BLADE PARRY / CLASH (Удар стали о сталь - глухой тяжелый)
  // =========================================================================
  private buildRealSteelParryBuffer(dur: number, pitchMult: number, seed: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let noiseState = seed * 3.1415;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // 1. Initial solid metallic impact click (damped, NOT high frequency ceramic bell)
      const clickEnv = Math.exp(-progress * 75);
      const impactClick = Math.sin(2 * Math.PI * (520 * pitchMult) * Math.exp(-progress * 30) * t) * clickEnv * 0.65;

      // 2. Heavy steel blade mass body (420Hz fundamental with fast natural damping)
      const steelEnv = Math.exp(-progress * 25);
      const steelBody = Math.sin(2 * Math.PI * (420 * pitchMult) * t) * steelEnv * 0.55;

      // 3. Second blade harmonic (840Hz octave, subtle)
      const overtone = Math.sin(2 * Math.PI * (840 * pitchMult) * t) * Math.exp(-progress * 35) * 0.25;

      // 4. Short scrape friction between crossed blades
      noiseState = (noiseState * 9301 + 49297) % 233280;
      const scrape = ((noiseState / 233280) * 2 - 1) * Math.exp(-progress * 40) * 0.3;

      const raw = impactClick + steelBody + overtone + scrape;
      const sample = Math.tanh(raw * 1.25);

      L[i] = sample * 0.95;
      R[i] = sample * 1.05;
    }
    return buf;
  }

  // =========================================================================
  // 4. SWORD SWING WHOOSH (Аэродинамический свист клинка)
  // =========================================================================
  private buildSwordWhooshBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let bpState1 = 0, bpState2 = 0;

    for (let i = 0; i < len; i++) {
      const progress = i / len;
      const t = i / sr;

      // Bell curve envelope
      const env = Math.sin(progress * Math.PI);
      const shapedEnv = Math.pow(env, 2.0);

      // Center frequency sweeps: 180Hz -> 580Hz -> 200Hz
      const centerFreq = (180 + 400 * env) * pitchMult;
      const alpha = Math.sin(2 * Math.PI * centerFreq / sr) / 4.0;

      const noise = Math.random() * 2 - 1;
      bpState1 += alpha * (noise - bpState1);
      bpState2 += alpha * (bpState1 - bpState2);

      // Low air displacement body
      const airBody = Math.sin(2 * Math.PI * (95 + 140 * env) * t) * 0.3;

      const sample = Math.tanh((bpState2 * 1.8 + airBody) * shapedEnv * 0.8);

      L[i] = sample * (1.1 - progress * 0.3);
      R[i] = sample * (0.8 + progress * 0.3);
    }
    return buf;
  }

  // =========================================================================
  // 5. SPIKE PREPARE / SCRAPE IN FLOOR SLITS (Шеркание механизма по щелям в камне)
  // =========================================================================
  private buildSpikePrepareGrindBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let stoneNoise1 = 0.5, stoneNoise2 = 0.5;
    let b1 = 0, b2 = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Swelling grinding envelope
      const env = Math.sin(progress * Math.PI) * (0.5 + 0.5 * progress);

      // Low stone rumble vibration (45-80 Hz)
      const rumble = Math.sin(2 * Math.PI * (55 * pitchMult + Math.sin(25 * t) * 15) * t) * 0.35;

      // Rough granular stone-on-metal friction in floor slot (bandpass noise around 300-800 Hz)
      stoneNoise1 = (stoneNoise1 * 9301 + 49297) % 233280;
      stoneNoise2 = (stoneNoise2 * 9301 + 49297) % 233280;
      const rawStone = ((stoneNoise1 + stoneNoise2) / 233280) - 1.0;

      b1 += 0.15 * (rawStone - b1);
      b2 += 0.15 * (b1 - b2);
      const stoneScrape = (b1 - b2) * 2.8;

      // Mechanical gear ratchet click ticks
      const tick = (Math.sin(2 * Math.PI * 32 * t) > 0.92) ? (Math.random() * 2 - 1) * 0.4 : 0;

      const sample = Math.tanh((rumble + stoneScrape + tick) * env * 1.15);

      L[i] = sample * (0.9 + 0.1 * Math.sin(15 * t));
      R[i] = sample * (0.9 - 0.1 * Math.sin(15 * t));
    }
    return buf;
  }

  // =========================================================================
  // 6. SPIKE ERUPT / HEAVY METALLIC THRUST (Резкий выстрел тяжелых шипов из щелей)
  // =========================================================================
  private buildSpikeEruptThrustBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let scrapeLP = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // 1. Violent mechanical spring discharge (instant snap & heavy sub punch 80Hz)
      const snapEnv = Math.exp(-progress * 35);
      const mechSnap = Math.sin(2 * Math.PI * (160 * pitchMult) * Math.exp(-progress * 22) * t) * snapEnv * 0.8;

      // 2. High-speed metal sliding friction across stone slot edges (chhhhhk-thud)
      const slideEnv = Math.exp(-progress * 22) * Math.sin(Math.min(1, progress * 10) * Math.PI);
      const rawNoise = Math.random() * 2 - 1;
      scrapeLP += 0.25 * (rawNoise - scrapeLP);
      const ironScrape = scrapeLP * slideEnv * 0.95;

      // 3. Heavy iron locking clack at full spike extension (at t ~ 40ms)
      const lockProg = Math.max(0, (i - len * 0.15) / (len * 0.85));
      const lockEnv = i >= len * 0.15 ? Math.exp(-lockProg * 28) : 0;
      const lockThud = Math.sin(2 * Math.PI * (240 * pitchMult) * lockProg * dur) * lockEnv * 0.7;

      const raw = mechSnap + ironScrape + lockThud;
      const sample = Math.tanh(raw * 1.3);

      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 7. SPIKE RETRACT / RETRACTING INTO SLITS (Шипы прячутся обратно в щели)
  // =========================================================================
  private buildSpikeRetractBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let lp = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Smooth sliding scrape descending
      const env = Math.sin(progress * Math.PI) * (1 - progress * 0.3);

      const rawNoise = Math.random() * 2 - 1;
      lp += 0.14 * (rawNoise - lp);
      const friction = lp * env * 0.75;

      // Low mechanical tension release hum
      const springHum = Math.sin(2 * Math.PI * (85 * pitchMult) * t) * env * 0.35;

      // Soft bottom stone latch click
      const latchProg = Math.max(0, (i - len * 0.75) / (len * 0.25));
      const latch = (i >= len * 0.75) ? Math.sin(2 * Math.PI * 190 * (t - 0.75 * dur)) * Math.exp(-latchProg * 25) * 0.4 : 0;

      const sample = Math.tanh((friction + springHum + latch) * 1.1);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 8. SOFT ETHEREAL MAGIC TELEPORT / PHASE (Мягкий шелест магии и телепортации)
  // =========================================================================
  private buildSoftMagicTeleportBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    // Warm pentatonic magic chord frequencies (F3, C4, Eb4, G4, Bb4) — soft & ethereal
    const freqs = [174.61 * pitchMult, 261.63 * pitchMult, 311.13 * pitchMult, 392.00 * pitchMult, 466.16 * pitchMult];

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Smooth asymmetric bell envelope (soft attack, dreamy smooth fadeout)
      const attack = Math.min(1.0, progress * 4.5);
      const decay = Math.pow(1 - progress, 1.8);
      const env = attack * decay;

      // Soft magical sine pad with gentle pitch glide (subtle upward/downward phase)
      let magicPad = 0;
      for (let fIdx = 0; fIdx < freqs.length; fIdx++) {
        const baseF = freqs[fIdx];
        const glide = baseF * (1.0 + 0.04 * Math.sin(progress * Math.PI));
        const ph = 2 * Math.PI * glide * t + (fIdx * 0.7);
        // Pure smooth sine wave with subtle tremolo
        magicPad += Math.sin(ph) * (0.22 / freqs.length) * (1 + 0.15 * Math.sin(12 * t));
      }

      // Airy celestial breath (lowpass filtered pink mist, zero harsh clicks)
      const airNoise = (Math.random() * 2 - 1) * 0.12 * Math.sin(progress * Math.PI);

      const sample = Math.tanh((magicPad + airNoise) * env * 1.8);

      // Stereo wide ethereal panning
      L[i] = sample * (0.6 + 0.4 * Math.sin(2 * Math.PI * 1.5 * t));
      R[i] = sample * (0.6 + 0.4 * Math.cos(2 * Math.PI * 1.5 * t));
    }
    return buf;
  }

  // =========================================================================
  // 9. SHIELD BLOCK / BARRIER ABSORB (Тяжелый глухой блок щитом)
  // =========================================================================
  private buildShieldBlockBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 24);
      // Heavy wood/iron boss thud (130Hz downward sweep)
      const thud = Math.sin(2 * Math.PI * (160 * pitchMult * Math.exp(-progress * 18) + 40) * t) * env * 0.8;
      // Damped barrier resonance
      const res = Math.sin(2 * Math.PI * (280 * pitchMult) * t) * Math.exp(-progress * 30) * 0.35;

      const sample = Math.tanh((thud + res) * 1.2);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 10. WALL BUMP / FOOT SCUFF (Мягкое касание стены)
  // =========================================================================
  private buildWallBumpBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 35);
      const thud = Math.sin(2 * Math.PI * (85 * pitchMult) * t) * env * 0.35;
      const scrape = (Math.random() * 2 - 1) * Math.exp(-progress * 45) * 0.15;

      const sample = Math.tanh(thud + scrape);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 11. BOSS AWAKEN (Пробуждение босса - глубокий тектонический гул)
  // =========================================================================
  private buildBossAwakenBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.sin(progress * Math.PI) * Math.exp(-progress * 2.5);
      const sub = Math.sin(2 * Math.PI * (48 + Math.sin(8 * t) * 12) * t) * 0.7;
      const rumble = (Math.random() * 2 - 1) * 0.25 * env;

      const sample = Math.tanh((sub + rumble) * env * 1.3);
      L[i] = sample * (0.8 + 0.2 * Math.sin(6 * t));
      R[i] = sample * (0.8 - 0.2 * Math.sin(6 * t));
    }
    return buf;
  }

  // =========================================================================
  // 11B. PARTICLES GATHERING (Звук собирающихся частиц - нежный шелест и эфирное втягивание)
  // =========================================================================
  private buildParticleGatherBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Swelling crescendo envelope as particles converge towards silhouette
      const env = Math.pow(progress, 1.8) * Math.sin(progress * Math.PI);

      // Rising ethereal vortex tone (300Hz soaring to 750Hz)
      const sweepFreq = (320 * pitchMult) + (450 * progress * progress);
      const vortex = Math.sin(2 * Math.PI * sweepFreq * t) * 0.35;

      // Soft crystalline sparkle harmonics (1200Hz - 2400Hz soft chimes)
      const chime1 = Math.sin(2 * Math.PI * (1280 * pitchMult) * t + Math.sin(20 * t)) * 0.15;
      const chime2 = Math.sin(2 * Math.PI * (1920 * pitchMult) * t) * 0.10;

      // Gentle inward air rush (pink whisper)
      const whisper = (Math.random() * 2 - 1) * 0.12 * Math.pow(progress, 1.4);

      const sample = Math.tanh((vortex + chime1 + chime2 + whisper) * env * 1.5);
      // Subtle swirling stereo rotation
      L[i] = sample * (0.5 + 0.5 * Math.sin(2 * Math.PI * 3 * t));
      R[i] = sample * (0.5 + 0.5 * Math.cos(2 * Math.PI * 3 * t));
    }
    return buf;
  }

  // =========================================================================
  // 11C. MATERIALIZE APPEARANCE (Сам момент появления игрока - сочный взрывной импульс)
  // =========================================================================
  private buildMaterializeImpactBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    let noiseLP = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // 1. Solid punchy sub thump dropping from 140Hz to 42Hz
      const subEnv = Math.exp(-progress * 8.5);
      const subFreq = (140 * pitchMult) * Math.exp(-progress * 14) + 42;
      const sub = Math.sin(2 * Math.PI * subFreq * t) * subEnv * 0.85;

      // 2. Ethereal shockwave blast (soft filtered magic burst)
      const rawWhite = Math.random() * 2 - 1;
      noiseLP += 0.22 * (rawWhite - noiseLP);
      const blastEnv = Math.exp(-progress * 14) * Math.sin(Math.min(1, progress * 8) * Math.PI);
      const blast = noiseLP * blastEnv * 0.65;

      // 3. Radiant celestial bloom harmonic (pure magic chord ringing out: F4, C5, A5)
      const bloomEnv = Math.exp(-progress * 5.5);
      const bloom1 = Math.sin(2 * Math.PI * (349.23 * pitchMult) * t) * 0.22;
      const bloom2 = Math.sin(2 * Math.PI * (523.25 * pitchMult) * t) * 0.18;
      const bloom3 = Math.sin(2 * Math.PI * (880.00 * pitchMult) * t) * 0.12;
      const bloom = (bloom1 + bloom2 + bloom3) * bloomEnv;

      const sample = Math.tanh((sub + blast + bloom) * 1.5);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 12. COIN / GEM LOOT (Мягкий звон золотых монет в кошельке)
  // =========================================================================
  private buildWarmCoinLootBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    // Warm golden coin clink (e.g. 1046Hz C6 -> 1318Hz E6, fast decay)
    const f1 = 1046.5 * pitchMult;
    const f2 = 1318.5 * pitchMult;
    const split = Math.floor(len * 0.25);

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const coin1 = Math.sin(2 * Math.PI * f1 * t) * Math.exp(-progress * 28) * 0.35;
      let coin2 = 0;
      if (i >= split) {
        const t2 = (i - split) / sr;
        const p2 = (i - split) / (len - split);
        coin2 = Math.sin(2 * Math.PI * f2 * t2) * Math.exp(-p2 * 22) * 0.45;
      }

      const sample = Math.tanh((coin1 + coin2) * 0.9);
      L[i] = sample * 0.95;
      R[i] = sample * 1.05;
    }
    return buf;
  }

  // =========================================================================
  // 13. BLACKSMITH ANVIL (Тяжелый молот кузнеца по горячему железу)
  // =========================================================================
  private buildBlacksmithAnvilBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      // Heavy solid hammer blow
      const hammerEnv = Math.exp(-progress * 38);
      const hammer = Math.sin(2 * Math.PI * (140 * pitchMult * Math.exp(-progress * 18) + 40) * t) * hammerEnv * 0.8;

      // Hot iron ring (damped, 880Hz & 1320Hz)
      const ironEnv = Math.exp(-progress * 18);
      const iron = (Math.sin(2 * Math.PI * 880 * pitchMult * t) * 0.3 + Math.sin(2 * Math.PI * 1320 * pitchMult * t) * 0.15) * ironEnv;

      // Hot spark sizzle
      const sizzle = (Math.random() * 2 - 1) * Math.exp(-progress * 26) * 0.2;

      const sample = Math.tanh((hammer + iron + sizzle) * 1.2);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 14. LEATHER GEAR & ARMOR EQUIP (Надевание экипировки)
  // =========================================================================
  private buildLeatherGearEquipBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const snapEnv = Math.exp(-progress * 42);
      const buckleSnap = Math.sin(2 * Math.PI * (620 * pitchMult) * t) * snapEnv * 0.4;
      const leatherThud = Math.sin(2 * Math.PI * (160 * pitchMult) * t) * Math.exp(-progress * 22) * 0.45;

      const sample = Math.tanh(buckleSnap + leatherThud);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 15. ERROR / BLOCKED (Глухой деревянный щелчок)
  // =========================================================================
  private buildDullErrorThudBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env1 = Math.exp(-progress * 28);
      const thud1 = Math.sin(2 * Math.PI * 110 * t) * env1 * 0.4;

      const t2 = Math.max(0, t - 0.08);
      const prog2 = Math.max(0, (i - len * 0.35) / (len * 0.65));
      const env2 = i >= len * 0.35 ? Math.exp(-prog2 * 28) : 0;
      const thud2 = Math.sin(2 * Math.PI * 90 * t2) * env2 * 0.35;

      const sample = Math.tanh(thud1 + thud2);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // =========================================================================
  // 16. PLASMA LASER, DRONES & ICE
  // =========================================================================
  private buildPlasmaLaserBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 15);
      const beam = Math.sin(2 * Math.PI * (850 * Math.exp(-progress * 14) + 90) * pitchMult * t) * env * 0.6;
      const hiss = (Math.random() * 2 - 1) * Math.exp(-progress * 22) * 0.25;

      const sample = Math.tanh((beam + hiss) * 1.2);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildCoilChargeBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.pow(progress, 1.7);
      const freq = 90 + Math.pow(progress, 2.2) * 650;
      const coil = Math.sin(2 * Math.PI * freq * t) * 0.35;

      const sample = Math.tanh(coil * env * 0.5);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildDroneTurbineChargeBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.pow(progress, 1.5);
      const freq = 120 + Math.pow(progress, 2.0) * 520;
      const turbine = Math.sin(2 * Math.PI * freq * t) * 0.35;

      const sample = Math.tanh(turbine * env * 0.4);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildDroneBassBlastBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 10);
      const blast = Math.sin(2 * Math.PI * (260 * Math.exp(-progress * 12) + 48) * t) * env * 0.75;
      const sizzle = (Math.random() * 2 - 1) * Math.exp(-progress * 16) * 0.3;

      const sample = Math.tanh((blast + sizzle) * 1.3);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildSubZeroFrostBuffer(dur: number, pitchMult: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const shardEnv = Math.exp(-progress * 14);
      const s1 = Math.sin(2 * Math.PI * (1400 * pitchMult) * t) * 0.25;
      const s2 = Math.sin(2 * Math.PI * (2100 * pitchMult) * t) * 0.15;
      const shards = (s1 + s2) * shardEnv;

      const windEnv = Math.sin(progress * Math.PI) * Math.exp(-progress * 6);
      const wind = (Math.random() * 2 - 1) * windEnv * 0.35;

      const sample = Math.tanh((shards + wind) * 1.1);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildLevelUpHarmonicsBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    // Warm triumphant orchestral chord (C4, G4, C5, E5, G5)
    const chord = [
      { freq: 261.63, delay: 0.00, dur: 1.4, vol: 0.24 },
      { freq: 392.00, delay: 0.08, dur: 1.3, vol: 0.22 },
      { freq: 523.25, delay: 0.16, dur: 1.2, vol: 0.26 },
      { freq: 659.25, delay: 0.24, dur: 1.1, vol: 0.25 },
      { freq: 783.99, delay: 0.32, dur: 1.0, vol: 0.28 }
    ];

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      let total = 0;

      for (const n of chord) {
        if (t >= n.delay) {
          const dtNote = t - n.delay;
          const prog = dtNote / n.dur;
          if (prog < 1.0) {
            const attack = Math.min(1.0, dtNote / 0.04);
            const decay = Math.exp(-prog * 3.2);
            const env = attack * decay * n.vol;
            const w = 2 * Math.PI * n.freq;
            total += (Math.sin(w * dtNote) * 0.7 + Math.sin(w * 2 * dtNote) * 0.3) * env;
          }
        }
      }

      const sample = Math.tanh(total * 0.95);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildWhirlwindCycloneBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.sin(progress * Math.PI);
      const rotor = Math.sin(2 * Math.PI * (140 + progress * 180) * t) * 0.35;
      const wind = (Math.random() * 2 - 1) * 0.45;

      const sample = Math.tanh((rotor + wind) * env * 1.1);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildFlameWaveRoarBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 6.5);
      const subBlast = Math.sin(2 * Math.PI * (180 * Math.exp(-progress * 12) + 40) * t) * env * 0.65;
      const roar = (Math.random() * 2 - 1) * Math.exp(-progress * 5.5) * 0.55;

      const sample = Math.tanh((subBlast + roar) * 1.25);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildAegisWarmSanctuaryBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.exp(-progress * 4.5);
      const chord = (
        Math.sin(2 * Math.PI * 330 * t) * 0.3 +
        Math.sin(2 * Math.PI * 440 * t) * 0.3 +
        Math.sin(2 * Math.PI * 554.37 * t) * 0.25
      ) * env;

      const sample = Math.tanh(chord * 1.1);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  private buildShadowMistDashBuffer(dur: number): AudioBuffer {
    const buf = this.createBuffer(dur, 2);
    const L = buf.getChannelData(0);
    const R = buf.getChannelData(1);
    const sr = buf.sampleRate;
    const len = buf.length;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const progress = i / len;

      const env = Math.sin(progress * Math.PI);
      const whoosh = Math.sin(2 * Math.PI * (340 * Math.exp(-progress * 8) + 70) * t) * env * 0.45;
      const mist = (Math.random() * 2 - 1) * env * 0.3;

      const sample = Math.tanh((whoosh + mist) * 1.1);
      L[i] = sample;
      R[i] = sample;
    }
    return buf;
  }

  // --- PLAYBACK ENGINE ---

  private playBuffer(
    buffers: AudioBuffer[] | undefined,
    volume: number = 1.0,
    pitchVariance: number = 0.04,
    playbackRate: number = 1.0
  ) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx || !this.compressor || !buffers || buffers.length === 0) return;

    try {
      const buf = buffers[Math.floor(Math.random() * buffers.length)];
      if (!buf) return;

      const source = this.ctx.createBufferSource();
      source.buffer = buf;

      let rate = playbackRate;
      if (pitchVariance > 0) {
        const randPitch = 1.0 + (Math.random() * 2 - 1) * pitchVariance;
        rate *= randPitch;
      }
      source.playbackRate.setValueAtTime(rate, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(volume, this.ctx.currentTime);

      source.connect(gain);
      gain.connect(this.compressor);

      source.start();
    } catch {
      // Ignore aborts
    }
  }

  // =========================================================================
  // PUBLIC SOUND API
  // =========================================================================

  public playSwing(intensity: number = 1.0, _weight: number = 1.0) {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastSwingTime < 75) return;
    this.lastSwingTime = nowPerf;

    const vol = Math.min(0.45, 0.24 * intensity);
    this.playBuffer(this.banks?.swings, vol, 0.06);
  }

  private loadCustomWeaponSounds() {
    const soundUrls: Record<string, string> = {
      sword: swordHitAudio,
      axe: axeHitAudio,
      hammer: hammerHitAudio,
      spear: spearHitAudio,
      lightning: lightningHitAudio,
      maceHit: maceHitAudio,
      fattyFall: fattyFallAudio,
      playerSpawn: playerSpawnAudio
    };

    if (typeof Audio !== 'undefined') {
      Object.entries(soundUrls).forEach(([key, url]) => {
        const pool: HTMLAudioElement[] = [];
        for (let i = 0; i < 4; i++) {
          const a = new Audio(url);
          a.preload = 'auto';
          pool.push(a);
        }
        this.customWeaponAudios[key] = pool;
      });
    }

    if (this.ctx) {
      Object.entries(soundUrls).forEach(([key, url]) => {
        fetch(url)
          .then(res => res.arrayBuffer())
          .then(ab => this.ctx?.decodeAudioData(ab))
          .then(decoded => {
            if (decoded) {
              this.customWeaponBuffers[key] = [decoded];
            }
          })
          .catch(() => {});
      });
    }
  }

  public playHit(isCrit: boolean = false, weaponType?: string) {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastHitTime < 30) return;
    this.lastHitTime = nowPerf;

    const normType = (weaponType || 'fist').toLowerCase();

    // Check for unarmed fist punch
    if (normType === 'fist' || normType === 'unarmed' || normType === 'none' || normType === '') {
      if (isCrit) {
        this.playBuffer(this.banks?.fistCrits || this.banks?.crits, 0.92, 0.04);
      } else {
        this.playBuffer(this.banks?.fistHits || this.banks?.hits, 0.80, 0.05);
      }
      return;
    }

    let category: 'sword' | 'axe' | 'hammer' | 'spear' = 'sword';
    if (normType === 'axe') {
      category = 'axe';
    } else if (normType === 'hammer') {
      category = 'hammer';
    } else if (normType === 'spear') {
      category = 'spear';
    } else {
      category = 'sword';
    }

    const bufs = this.customWeaponBuffers[category];
    if (bufs && bufs.length > 0) {
      const vol = (isCrit ? 0.95 : 0.80) * 0.42; // Lowered by 40% + another 30% for weapon hits (0.6 * 0.7 = 0.42)
      const rate = 1.0;
      this.playBuffer(bufs, vol, 0.04, rate);
      return;
    }

    const pool = this.customWeaponAudios[category];
    if (pool && pool.length > 0) {
      const audio = pool.find(a => a.paused || a.ended) || pool[0];
      if (audio) {
        audio.currentTime = 0;
        audio.volume = (isCrit ? 0.95 : 0.80) * 0.42; // Lowered by 40% + another 30% for weapon hits (0.6 * 0.7 = 0.42)
        audio.playbackRate = 1.0;
        audio.play().catch(() => {});
        return;
      }
    }

    if (isCrit) {
      this.playBuffer(this.banks?.crits, 0.85 * 0.42, 0.04);
    } else {
      this.playBuffer(this.banks?.hits, 0.70 * 0.42, 0.05);
    }
  }

  public playClash() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastClashTime < 45) return;
    this.lastClashTime = nowPerf;

    this.playBuffer(this.banks?.clashes, 0.65, 0.05);
  }

  public playSpikePrepare() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastSpikeTime < 100) return;
    this.lastSpikeTime = nowPerf;

    this.playBuffer(this.banks?.spikePrepares, 0.22, 0.04);
  }

  public playSpikeErupt() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastSpikeTime < 80) return;
    this.lastSpikeTime = nowPerf;

    this.playBuffer(this.banks?.spikeErupts, 0.25, 0.04);
  }

  public playSpikeRetract() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.spikeRetracts, 0.18, 0.04);
  }

  public playTeleport() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastTeleportTime < 80) return;
    this.lastTeleportTime = nowPerf;

    this.playBuffer(this.banks?.teleports, 0.65, 0.04);
  }

  public playShieldBlock() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.shieldBlocks, 0.70, 0.04);
  }

  public playWallBump() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastWallBumpTime < 120) return;
    this.lastWallBumpTime = nowPerf;

    this.playBuffer(this.banks?.wallBumps, 0.35, 0.06);
  }

  public playBossAwaken() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.bossAwakens, 0.85, 0.0);
  }

  public playChargingLaser() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastChargingLaserTime < 120) return;
    this.lastChargingLaserTime = nowPerf;

    this.playBuffer(this.banks?.chargingLasers, 0.40, 0.02);
  }

  public playLaser() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastLaserTime < 60) return;
    this.lastLaserTime = nowPerf;

    this.playBuffer(this.banks?.lasers, 0.55, 0.04);
  }

  public playDroneCharge() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastDroneChargeTime < 120) return;
    this.lastDroneChargeTime = nowPerf;

    this.playBuffer(this.banks?.droneCharges, 0.40, 0.03);
  }

  public playDroneBlast() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastDroneBlastTime < 80) return;
    this.lastDroneBlastTime = nowPerf;

    this.playBuffer(this.banks?.droneBlasts, 0.60, 0.04);
  }

  public playIceShot() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastIceShotTime < 60) return;
    this.lastIceShotTime = nowPerf;

    this.playBuffer(this.banks?.iceShots, 0.55, 0.05);
  }

  public playSkill(skillType: 'whirlwind' | 'flame_wave' | 'aegis_shield' | 'shadow_dash') {
    if (this.isMuted) return;
    const buffers = this.banks?.skills[skillType];
    this.playBuffer(buffers, 0.70, 0.03);
  }

  public playLoot() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastLootTime < 45) return;
    this.lastLootTime = nowPerf;

    this.playBuffer(this.banks?.loots, 0.50, 0.06);
  }

  public playEquip() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.equips, 0.55, 0.04);
  }

  public playLevelUp() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.levelUps, 0.42, 0.0);
  }

  public playForge() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.forges, 0.75, 0.04);
  }

  public playError() {
    if (this.isMuted) return;
    this.playBuffer(this.banks?.errors, 0.50, 0.03);
  }

  public playParticleGather() {
    if (this.isMuted) return;
    const nowPerf = performance.now();
    if (nowPerf - this.lastParticleTime < 240) return;
    this.lastParticleTime = nowPerf;

    this.playBuffer(this.banks?.particles, 0.22, 0.08);
  }

  public playMaterializeImpact() {
    if (this.isMuted) return;
    const bufs = this.customWeaponBuffers.playerSpawn;
    if (bufs && bufs.length > 0) {
      this.playBuffer(bufs, 0.90, 0.02);
      return;
    }
    const pool = this.customWeaponAudios.playerSpawn;
    if (pool && pool.length > 0) {
      const audio = pool.find(a => a.paused || a.ended) || pool[0];
      if (audio) {
        audio.currentTime = 0;
        audio.volume = 0.90;
        audio.play().catch(() => {});
        return;
      }
    }
    this.playBuffer(this.banks?.materializes, 0.42, 0.03);
  }

  public playLightningZap() {
    if (this.isMuted) return;

    const bufs = this.customWeaponBuffers.lightning;
    if (bufs && bufs.length > 0) {
      this.playBuffer(bufs, 0.85, 0.03);
      return;
    }

    const pool = this.customWeaponAudios.lightning;
    if (pool && pool.length > 0) {
      const audio = pool.find(a => a.paused || a.ended) || pool[0];
      if (audio) {
        audio.currentTime = 0;
        audio.volume = 0.85;
        audio.play().catch(() => {});
        return;
      }
    }

    try {
      const ctx = (this as any).getCtx ? (this as any).getCtx() : ((window as any).AudioContext ? new ((window as any).AudioContext || (window as any).webkitAudioContext)() : null);
      if (!ctx) {
        this.playLaser();
        return;
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2600, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.16);

      osc.frequency.setValueAtTime(820 + Math.random() * 240, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.16);

      gain.gain.setValueAtTime(0.32, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.16);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.17);
    } catch {
      this.playLaser();
    }
  }

  public playMaceHit() {
    if (this.isMuted) return;
    const bufs = this.customWeaponBuffers.maceHit;
    if (bufs && bufs.length > 0) {
      this.playBuffer(bufs, 0.90 * 0.42, 0.04);
      return;
    }
    const pool = this.customWeaponAudios.maceHit;
    if (pool && pool.length > 0) {
      const audio = pool.find(a => a.paused || a.ended) || pool[0];
      if (audio) {
        audio.currentTime = 0;
        audio.volume = 0.90 * 0.42;
        audio.play().catch(() => {});
        return;
      }
    }
    this.playHit(true, 'hammer');
  }

  public playFattyFall() {
    if (this.isMuted) return;
    const bufs = this.customWeaponBuffers.fattyFall;
    if (bufs && bufs.length > 0) {
      this.playBuffer(bufs, 0.95, 0.02);
      return;
    }
    const pool = this.customWeaponAudios.fattyFall;
    if (pool && pool.length > 0) {
      const audio = pool.find(a => a.paused || a.ended) || pool[0];
      if (audio) {
        audio.currentTime = 0;
        audio.volume = 0.95;
        audio.play().catch(() => {});
        return;
      }
    }
    this.playClash();
  }
}

export const soundManager = new SoundManager();
