import { CustomRoomData, isElementAboveHero, RoomElement } from '../types/roomEditor';
import { DEFAULT_ROOMS } from '../rooms/defaultRooms';
import { getAssetById } from './wallAssets';

const STORAGE_KEY = 'swordsman_custom_dungeon_rooms';
const ACTIVE_ROOMS_KEY = 'swordsman_active_custom_rooms_enabled';

export const roomStorage = {
  // Get all rooms (bundled presets + user saved rooms)
  getAllRooms(): CustomRoomData[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        // Initialize with default rooms
        this.saveAllRooms(DEFAULT_ROOMS);
        return DEFAULT_ROOMS;
      }
      let parsed: CustomRoomData[] = JSON.parse(stored);
      
      // Filter out old pre-created room presets that are no longer in DEFAULT_ROOMS
      const activeDefaultIds = new Set(DEFAULT_ROOMS.map(r => r.id));
      parsed = parsed.filter(r => !r.id.startsWith('room_preset_') || activeDefaultIds.has(r.id));

      // Sync active default rooms only if default is newer or stored room lacks updatedAt
      DEFAULT_ROOMS.forEach(def => {
        const idx = parsed.findIndex(r => r.id === def.id);
        if (idx !== -1) {
          const storedTime = new Date(parsed[idx].updatedAt || 0).getTime();
          const defTime = new Date(def.updatedAt || 0).getTime();
          if (defTime > storedTime) {
            parsed[idx] = def;
          }
        } else {
          parsed.unshift(def);
        }
      });

      // Clean up and resolve robust asset URLs for production builds
      parsed.forEach(r => {
        r.elements?.forEach(el => {
          if (el.assetId) {
            const assetDef = getAssetById(el.assetId);
            if (assetDef) {
              el.src = assetDef.src;
            }
          }
          if (el.assetId === 'shadow_square_dark' || el.assetId === 'shadow_rect_corridor' || (el.src && el.src.includes('stroke-dasharray'))) {
            el.src = el.src.replace(/stroke="[^"]*"/g, '').replace(/stroke-dasharray="[^"]*"/g, '').replace(/stroke-width="[^"]*"/g, '');
          }
        });
      });

      this.saveAllRooms(parsed);
      return parsed;
    } catch (e) {
      console.error('Failed to load custom rooms from storage:', e);
      return DEFAULT_ROOMS;
    }
  },

  // Save full room array
  saveAllRooms(rooms: CustomRoomData[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(rooms));
    } catch (e) {
      console.error('Failed to save rooms to storage:', e);
    }
  },

  // Save or update single room
  saveRoom(room: CustomRoomData): CustomRoomData {
    const all = this.getAllRooms();
    const existingIndex = all.findIndex(r => r.id === room.id);
    const now = new Date().toISOString();
    const roomToSave: CustomRoomData = {
      ...room,
      updatedAt: now
    };

    let updated: CustomRoomData[];
    if (existingIndex !== -1) {
      updated = [...all];
      updated[existingIndex] = roomToSave;
    } else {
      updated = [roomToSave, ...all];
    }
    this.saveAllRooms(updated);
    return roomToSave;
  },

  // Delete room by ID
  deleteRoom(id: string): void {
    const all = this.getAllRooms().filter(r => r.id !== id);
    this.saveAllRooms(all);
  },

  // Export room to JSON file (Baking elements into 2 images: under hero & above hero, plus floor zones, collision boxes, and doors/spawn)
  async exportRoomToFile(room: CustomRoomData): Promise<void> {
    const width = room.width || 800;
    const height = room.height || 600;

    const canvasUnder = document.createElement('canvas');
    canvasUnder.width = width;
    canvasUnder.height = height;
    const ctxUnder = canvasUnder.getContext('2d');

    const canvasAbove = document.createElement('canvas');
    canvasAbove.width = width;
    canvasAbove.height = height;
    const ctxAbove = canvasAbove.getContext('2d');

    const elements = room.elements || [];
    const underElements = elements.filter(el => !isElementAboveHero(el)).sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
    const aboveElements = elements.filter(el => isElementAboveHero(el)).sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));

    const loadImage = (src: string): Promise<HTMLImageElement | null> => {
      return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        let cleanSrc = src;
        try { cleanSrc = decodeURIComponent(src); } catch (e) {}
        img.src = cleanSrc;
      });
    };

    const drawGroup = async (ctx: CanvasRenderingContext2D | null, group: RoomElement[]) => {
      if (!ctx) return;
      for (const el of group) {
        if (el.visible === false) continue;
        let assetSrc = el.src;
        if (el.assetId === 'shadow_square_dark' || el.assetId === 'shadow_rect_corridor' || (assetSrc && assetSrc.includes('stroke-dasharray'))) {
          assetSrc = assetSrc.replace(/stroke="[^"]*"/g, '').replace(/stroke-dasharray="[^"]*"/g, '').replace(/stroke-width="[^"]*"/g, '');
        }
        const img = await loadImage(assetSrc || el.src);
        ctx.save();
        const cx = el.x + el.w / 2;
        const cy = el.y + el.h / 2;
        ctx.translate(cx, cy);
        if (el.rotation) ctx.rotate((el.rotation * Math.PI) / 180);
        if (el.scaleX !== undefined || el.scaleY !== undefined || el.flipX || el.flipY) {
          ctx.scale((el.flipX ? -1 : 1) * (el.scaleX ?? 1), (el.flipY ? -1 : 1) * (el.scaleY ?? 1));
        }
        if (el.opacity !== undefined) {
          ctx.globalAlpha = el.opacity;
        }

        if (el.isShadowSource || (el.assetId && el.assetId.startsWith('shadow_'))) {
          ctx.fillStyle = '#000000';
          const sw = Math.abs(el.w);
          const sh = Math.abs(el.h);
          const shape = el.shadowShape || 'square';
          const cornerStyle = el.shadowCorners || 'sharp';
          ctx.beginPath();
          if (shape === 'oval') {
            ctx.ellipse(0, 0, Math.max(1, sw / 2), Math.max(1, sh / 2), 0, 0, Math.PI * 2);
          } else if (cornerStyle === 'sharp') {
            ctx.rect(-sw / 2, -sh / 2, sw, sh);
          } else {
            const r = Math.min(el.shadowCornerRadius ?? 10, sw / 2, sh / 2);
            if (typeof (ctx as any).roundRect === 'function') {
              (ctx as any).roundRect(-sw / 2, -sh / 2, sw, sh, r);
            } else {
              ctx.rect(-sw / 2, -sh / 2, sw, sh);
            }
          }
          ctx.fill();
        } else if (img && img.complete && img.naturalWidth > 0) {
          ctx.drawImage(img, -el.w / 2, -el.h / 2, el.w, el.h);
        } else {
          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(-el.w / 2, -el.h / 2, el.w, el.h);
        }
        ctx.restore();
      }
    };

    await drawGroup(ctxUnder, underElements);
    await drawGroup(ctxAbove, aboveElements);

    const bakedUnderHeroImage = canvasUnder.toDataURL('image/png');
    const bakedAboveHeroImage = canvasAbove.toDataURL('image/png');

    const bakedRoom: CustomRoomData = {
      ...room,
      bakedUnderHeroImage,
      bakedAboveHeroImage,
      floorZones: room.floorZones || [],
      collisionBoxes: room.collisionBoxes || [],
      doors: room.doors || [],
      spawnPoint: room.spawnPoint || { x: width / 2, y: height / 2 },
      elements: [] // Baked into 2 images instead of 300-400 individual assets!
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(bakedRoom, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    const safeName = bakedRoom.name.replace(/[^a-zA-Z0-9а-яА-ЯёЁ_-]/g, '_');
    downloadAnchor.setAttribute('download', `комната_${safeName || 'unnamed'}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  },

  // Import room from JSON string
  importRoomFromJson(jsonString: string): CustomRoomData | null {
    try {
      const data = JSON.parse(jsonString) as CustomRoomData;
      if (!data.name || (!Array.isArray(data.elements) && !data.bakedUnderHeroImage && !data.bakedAboveHeroImage)) {
        throw new Error('Некорректная структура файла комнаты');
      }
      const newRoom: CustomRoomData = {
        ...data,
        elements: Array.isArray(data.elements) ? data.elements.map(el => {
          if (el.assetId) {
            const def = getAssetById(el.assetId);
            if (def) return { ...el, src: def.src };
          }
          return el;
        }) : [],
        id: 'room_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        updatedAt: new Date().toISOString()
      };
      this.saveRoom(newRoom);
      return newRoom;
    } catch (e) {
      console.error('Error importing room:', e);
      return null;
    }
  },

  // Is custom rooms generation in dungeon enabled
  isCustomRoomsGenerationEnabled(): boolean {
    const val = localStorage.getItem(ACTIVE_ROOMS_KEY);
    return val === null ? true : val === 'true';
  },

  setCustomRoomsGenerationEnabled(enabled: boolean): void {
    localStorage.setItem(ACTIVE_ROOMS_KEY, enabled ? 'true' : 'false');
  }
};
