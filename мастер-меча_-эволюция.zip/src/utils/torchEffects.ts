// Utility and rendering engine for realistic animated torch fire effects and dynamic scene lighting in the Level Editor and Game
import { RoomElement, RoomLightingSettings } from '../types/roomEditor';

export interface TorchConfig {
  anchorOffsetYRatio: number; // Ratio from center: negative is higher up
  scale: number;
  baseWidthScale: number;
  glowRadiusRatio: number;
}

export const TORCH_CONFIGS: Record<string, TorchConfig> = {
  light_fire_flame: {
    anchorOffsetYRatio: 0.15,
    scale: 0.85,
    baseWidthScale: 1.0,
    glowRadiusRatio: 2.5
  },
  prop_torch_1: {
    anchorOffsetYRatio: -0.32, // Upper tip of wall torch bracket
    scale: 0.85,
    baseWidthScale: 0.9,
    glowRadiusRatio: 2.2
  },
  prop_torch_2: {
    anchorOffsetYRatio: -0.36, // Top of torch post
    scale: 0.95,
    baseWidthScale: 1.0,
    glowRadiusRatio: 2.5
  },
  prop_torch_3: {
    anchorOffsetYRatio: -0.25, // Upper basin of brazier bowl
    scale: 1.2,
    baseWidthScale: 1.45,
    glowRadiusRatio: 2.8
  },
  wall_torch_block: {
    anchorOffsetYRatio: -0.15, // Sconce on wall block
    scale: 0.85,
    baseWidthScale: 0.9,
    glowRadiusRatio: 2.2
  },
  light_torch_point: {
    anchorOffsetYRatio: 0,
    scale: 1.0,
    baseWidthScale: 1.0,
    glowRadiusRatio: 3.0
  },
  light_omni_warm: {
    anchorOffsetYRatio: 0,
    scale: 1.0,
    baseWidthScale: 1.0,
    glowRadiusRatio: 3.2
  }
};

/**
 * Checks whether an element or asset definition is an explicit flame or fire asset.
 */
export const isTorchElement = (assetId?: string, name?: string): boolean => {
  if (!assetId && !name) return false;
  const aid = (assetId || '').toLowerCase();
  const n = (name || '').toLowerCase();
  return (
    aid === 'light_fire_flame' ||
    aid === 'light_torch_flame' ||
    aid === 'prop_flame' ||
    n.includes('огонек') ||
    n.includes('пламя')
  );
};

/**
 * Checks whether an element is an active light emitter (flame, light spot, lamp, crystal)
 */
export const isLightEmitter = (el: RoomElement): boolean => {
  if (el.hasLight === true) return true;
  if (el.hasLight === false) return false;
  const aid = (el.assetId || '').toLowerCase();
  const n = (el.name || '').toLowerCase();
  return (
    isTorchElement(el.assetId, el.name) ||
    aid.startsWith('light_') ||
    aid.includes('lamp') ||
    n.includes('свет') ||
    n.includes('лампа') ||
    n.includes('луч') ||
    n.includes('огонек') ||
    n.includes('пламя')
  );
};

/**
 * Checks whether an element is a dedicated shadow or darkness patch
 */
export const isShadowZone = (el: RoomElement): boolean => {
  if (el.isShadowSource === true) return true;
  const aid = (el.assetId || '').toLowerCase();
  const n = (el.name || '').toLowerCase();
  return aid.startsWith('shadow_') || n.includes('тень') || n.includes('затенение') || n.includes('мрак');
};

export const getTorchConfig = (assetId?: string): TorchConfig => {
  if (assetId && TORCH_CONFIGS[assetId]) {
    return TORCH_CONFIGS[assetId];
  }
  return {
    anchorOffsetYRatio: -0.3,
    scale: 0.9,
    baseWidthScale: 1.0,
    glowRadiusRatio: 2.3
  };
};

/**
 * Converts Hex color string to { r, g, b } components
 */
export const hexToRgb = (hex: string): { r: number; g: number; b: number } => {
  let cleaned = hex.replace('#', '').trim();
  if (cleaned.length === 3) {
    cleaned = cleaned.split('').map(c => c + c).join('');
  }
  const num = parseInt(cleaned, 16);
  if (isNaN(num)) {
    return { r: 255, g: 157, b: 59 }; // Warm torch gold default
  }
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
};

/**
 * Computes world-space light origin and animated parameters
 */
export const getElementLightInfo = (el: RoomElement, timeSec: number) => {
  const isTorch = isTorchElement(el.assetId, el.name);
  const cx = el.x + el.w / 2;
  const cy = el.y + el.h / 2;
  const rad = ((el.rotation || 0) * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);

  let lx = cx;
  let ly = cy;

  if (isTorch) {
    const config = getTorchConfig(el.assetId);
    const effH = el.h * (el.scaleY || 1);
    const localAnchorY = (effH / 2) * (config.anchorOffsetYRatio * 2);
    const localAnchorX = 0;
    lx = cx + localAnchorX * cos - localAnchorY * sin;
    ly = cy + localAnchorX * sin + localAnchorY * cos;
  }

  const baseRadius = el.lightRadius || (isTorch ? 210 : 180);
  const intensity = el.lightIntensity ?? 1.0;
  const color = el.lightColor || (isTorch ? '#ff9d3b' : '#fbbf24');
  const allowFlicker = el.lightFlicker ?? true;

  const seed = Math.abs((el.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) * 1.618) % 100);
  const flicker = allowFlicker ? (Math.sin(timeSec * 7.5 + seed) * 0.05 + Math.cos(timeSec * 13 + seed * 2) * 0.035) : 0;
  const currentRadius = Math.max(30, baseRadius * (1 + flicker));

  return {
    x: lx,
    y: ly,
    radius: currentRadius,
    intensity,
    color,
    rgb: hexToRgb(color),
    seed
  };
};

/**
 * Draws ultra-realistic animated flame, glow, core, and rising embers onto a 2D canvas context.
 */
export const drawTorchFlame = (
  ctx: CanvasRenderingContext2D,
  fx: number,
  fy: number,
  scale: number,
  timeSec: number,
  seed: number = 0,
  baseScaleW: number = 1.0,
  glowAlpha: number = 1.0
) => {
  const t = timeSec * 1.8;
  const sway1 = Math.sin(t * 8.5 + seed) * 2.2 * scale;
  const sway2 = Math.cos(t * 14.2 + seed * 1.6) * 1.4 * scale;
  const hPulse = Math.sin(t * 11 + seed * 3.1) * 0.12 + Math.cos(t * 6.5 + seed) * 0.06;

  const mainH = 24 * scale * (1 + hPulse);
  const baseW = 6.2 * scale * baseScaleW;
  const midW = 8.5 * scale * baseScaleW;
  const tipX = fx + sway1 + sway2 * 0.35;
  const tipY = fy - mainH;

  // 1. Soft Warm Radial Ambient Glow Halo
  const glowR = 48 * scale * (1 + Math.sin(t * 7 + seed) * 0.08);
  const glow = ctx.createRadialGradient(fx, fy - mainH * 0.4, 0, fx, fy - mainH * 0.4, glowR);
  glow.addColorStop(0, `rgba(251, 191, 36, ${0.42 * glowAlpha})`);
  glow.addColorStop(0.35, `rgba(245, 158, 11, ${0.22 * glowAlpha})`);
  glow.addColorStop(0.7, `rgba(234, 88, 12, ${0.08 * glowAlpha})`);
  glow.addColorStop(1, 'rgba(234, 88, 12, 0)');

  ctx.save();
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(fx, fy - mainH * 0.4, glowR, 0, Math.PI * 2);
  ctx.fill();

  // 2. Outer Fire Plume (Rich fiery orange-red with organic fluid sway)
  ctx.fillStyle = '#ea580c';
  ctx.beginPath();
  ctx.moveTo(fx - baseW, fy);
  ctx.bezierCurveTo(
    fx - midW * 1.35 + Math.sin(t * 10 + seed) * 1.5 * scale,
    fy - mainH * 0.38,
    fx - midW * 0.8 + sway1 * 0.7,
    fy - mainH * 0.76,
    tipX,
    tipY
  );
  ctx.bezierCurveTo(
    fx + midW * 0.8 + sway1 * 0.7,
    fy - mainH * 0.76,
    fx + midW * 1.35 + Math.cos(t * 12 + seed) * 1.5 * scale,
    fy - mainH * 0.38,
    fx + baseW,
    fy
  );
  ctx.closePath();
  ctx.fill();

  // 3. Mid Flame Layer (Vibrant amber yellow to radiant gold)
  const midH = mainH * 0.72;
  const midBaseW = baseW * 0.65;
  const midTipX = fx + sway1 * 0.55;
  const midTipY = fy - midH;

  ctx.fillStyle = '#facc15';
  ctx.beginPath();
  ctx.moveTo(fx - midBaseW, fy);
  ctx.bezierCurveTo(
    fx - midW * 0.75 + Math.sin(t * 13 + seed) * 0.9 * scale,
    fy - midH * 0.38,
    fx - midW * 0.35 + sway1 * 0.45,
    fy - midH * 0.74,
    midTipX,
    midTipY
  );
  ctx.bezierCurveTo(
    fx + midW * 0.35 + sway1 * 0.45,
    fy - midH * 0.74,
    fx + midW * 0.75 + Math.cos(t * 15 + seed) * 0.9 * scale,
    fy - midH * 0.38,
    fx + midBaseW,
    fy
  );
  ctx.closePath();
  ctx.fill();

  // 4. Intense Hot Combustion Core (Luminous white-gold teardrop)
  const coreH = mainH * 0.42;
  const coreBaseW = baseW * 0.42;
  const coreTipX = fx + sway1 * 0.25;
  const coreTipY = fy - coreH;

  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.moveTo(fx - coreBaseW, fy);
  ctx.quadraticCurveTo(fx - coreBaseW * 1.3, fy - coreH * 0.48, coreTipX, coreTipY);
  ctx.quadraticCurveTo(fx + coreBaseW * 1.3, fy - coreH * 0.48, coreTipX + coreBaseW * 0.5, fy);
  ctx.closePath();
  ctx.fill();

  // 5. Rising Spark Embers (Turbulent sparks rising upward with fade-out)
  const emberCount = Math.max(1, Math.round(2 * scale));
  for (let i = 0; i < emberCount; i++) {
    const emberLife = ((t * (14 + i * 5) + seed * 3.7 + i * 11) % 24) / 24;
    const emberY = fy - mainH * 0.2 - emberLife * (mainH * 1.4);
    const emberX = fx + Math.sin(t * (10 + i * 4) + i * 2.5) * (4 * scale + emberLife * 8 * scale) + sway1 * 0.3;
    const emberAlpha = Math.max(0, (1 - emberLife) * 0.95);
    const emberSize = Math.max(0.7, (1 - emberLife * 0.5) * (1.6 * scale));

    ctx.fillStyle = i % 2 === 0 ? `rgba(254, 240, 138, ${emberAlpha})` : `rgba(251, 146, 60, ${emberAlpha})`;
    ctx.beginPath();
    ctx.arc(emberX, emberY, emberSize * 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
};

/**
 * Helper to draw a rounded or sharp rectangle path
 */
export const drawRoundRectPath = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) => {
  const radius = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
  if (radius <= 0) {
    ctx.rect(x, y, w, h);
    return;
  }
  if (typeof (ctx as any).roundRect === 'function') {
    (ctx as any).roundRect(x, y, w, h, radius);
  } else {
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.arcTo(x + w, y, x + w, y + radius, radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.arcTo(x + w, y + h, x + w - radius, y + h, radius);
    ctx.lineTo(x + radius, y + h);
    ctx.arcTo(x, y + h, x, y + h - radius, radius);
    ctx.lineTo(x, y + radius);
    ctx.arcTo(x, y, x + radius, y, radius);
    ctx.closePath();
  }
};

/**
 * Helper to compute Axis-Aligned Bounding Box for an element in world space
 */
interface ShadowAABB {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

const getShadowElementAABB = (el: RoomElement): ShadowAABB => {
  const sw = Math.abs(el.w * (el.scaleX || 1));
  const sh = Math.abs(el.h * (el.scaleY || 1));
  const rad = ((el.rotation || 0) * Math.PI) / 180;
  const cos = Math.abs(Math.cos(rad));
  const sin = Math.abs(Math.sin(rad));
  const boundW = sw * cos + sh * sin;
  const boundH = sw * sin + sh * cos;
  const cx = el.x + el.w / 2;
  const cy = el.y + el.h / 2;
  return {
    minX: cx - boundW / 2,
    minY: cy - boundH / 2,
    maxX: cx + boundW / 2,
    maxY: cy + boundH / 2
  };
};

const doAABBIntersect = (a: ShadowAABB, b: ShadowAABB, margin = 2): boolean => {
  return !(
    a.maxX + margin < b.minX ||
    a.minX - margin > b.maxX ||
    a.maxY + margin < b.minY ||
    a.minY - margin > b.maxY
  );
};

/**
 * Reusable offscreen canvas for rendering seamless unified shadow masks
 */
let offscreenShadowCanvas: HTMLCanvasElement | null = null;
let offscreenShadowCtx: CanvasRenderingContext2D | null = null;

const getOffscreenShadowContext = (w: number, h: number) => {
  if (!offscreenShadowCanvas) {
    offscreenShadowCanvas = document.createElement('canvas');
  }
  const safeW = Math.max(32, Math.ceil(w));
  const safeH = Math.max(32, Math.ceil(h));
  if (offscreenShadowCanvas.width !== safeW || offscreenShadowCanvas.height !== safeH) {
    offscreenShadowCanvas.width = safeW;
    offscreenShadowCanvas.height = safeH;
    offscreenShadowCtx = offscreenShadowCanvas.getContext('2d');
  }
  return { canvas: offscreenShadowCanvas, ctx: offscreenShadowCtx };
};

/**
 * Renders shadow elements with SEAMLESS UNION MERGING:
 * Elements with identical opacity/density merge seamlessly without overlapping seams.
 * Supports sharp 90° corners (sharp) and rounded corners (rounded).
 */
export const renderSeamlessShadows = (
  targetCtx: CanvasRenderingContext2D,
  shadowElements: RoomElement[],
  globalAlphaMultiplier: number = 1.0,
  originX: number = 0,
  originY: number = 0
) => {
  const activeShadows = shadowElements.filter(el => el.visible !== false && isShadowZone(el));
  if (activeShadows.length === 0) return;

  // Group shadows by effective density percentage (1..100)
  const groups = new Map<number, RoomElement[]>();
  for (const el of activeShadows) {
    const rawDensity = el.shadowDensity ?? el.opacity ?? 0.8;
    const key = Math.max(1, Math.min(100, Math.round(rawDensity * 100)));
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key)!.push(el);
  }

  // Render each density group seamlessly
  groups.forEach((groupEls, densityPercent) => {
    const groupAlpha = (densityPercent / 100) * globalAlphaMultiplier;
    if (groupAlpha <= 0.005) return;

    // Cluster overlapping / touching shadows into connected groups
    const aabbs = groupEls.map(el => getShadowElementAABB(el));
    const visited = new Array(groupEls.length).fill(false);
    const clusters: RoomElement[][] = [];

    for (let i = 0; i < groupEls.length; i++) {
      if (visited[i]) continue;
      visited[i] = true;
      const currentCluster: RoomElement[] = [groupEls[i]];
      const queue: number[] = [i];

      while (queue.length > 0) {
        const currIdx = queue.pop()!;
        for (let j = 0; j < groupEls.length; j++) {
          if (!visited[j] && doAABBIntersect(aabbs[currIdx], aabbs[j])) {
            visited[j] = true;
            currentCluster.push(groupEls[j]);
            queue.push(j);
          }
        }
      }
      clusters.push(currentCluster);
    }

    // Render each cluster seamlessly: overlapping items in same cluster merge into a single solid mask
    for (const cluster of clusters) {
      let minX = Infinity;
      let minY = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;

      for (const el of cluster) {
        const aabb = getShadowElementAABB(el);
        minX = Math.min(minX, aabb.minX);
        minY = Math.min(minY, aabb.minY);
        maxX = Math.max(maxX, aabb.maxX);
        maxY = Math.max(maxY, aabb.maxY);
      }

      const pad = 6;
      minX -= pad;
      minY -= pad;
      maxX += pad;
      maxY += pad;

      const bw = Math.ceil(Math.max(16, maxX - minX));
      const bh = Math.ceil(Math.max(16, maxY - minY));

      const { canvas: shadowCanvas, ctx: sCtx } = getOffscreenShadowContext(bw, bh);
      if (!sCtx) continue;

      // 1. Clear offscreen cluster mask to full transparency
      sCtx.clearRect(0, 0, bw, bh);

      // 2. Draw all shapes in this cluster as SOLID 100% BLACK
      // Where shapes overlap, 100% black + 100% black = 100% black (ZERO SEAMS!)
      sCtx.save();
      sCtx.fillStyle = '#000000';

      for (const el of cluster) {
        const sw = Math.abs(el.w * (el.scaleX || 1));
        const sh = Math.abs(el.h * (el.scaleY || 1));
        const cx = (el.x + el.w / 2) - minX;
        const cy = (el.y + el.h / 2) - minY;

        sCtx.save();
        sCtx.translate(cx, cy);
        if (el.rotation) {
          sCtx.rotate(((el.rotation || 0) * Math.PI) / 180);
        }
        if (el.flipX || el.flipY) {
          sCtx.scale(el.flipX ? -1 : 1, el.flipY ? -1 : 1);
        }

        const shape = el.shadowShape || (el.assetId?.includes('square') || el.assetId?.includes('rect') ? 'square' : 'oval');
        const cornerStyle = el.shadowCorners || (shape === 'square' ? 'sharp' : 'rounded');

        sCtx.beginPath();
        if (shape === 'oval') {
          sCtx.ellipse(0, 0, Math.max(1, sw / 2), Math.max(1, sh / 2), 0, 0, Math.PI * 2);
        } else {
          // Square / Rectangular shape
          if (cornerStyle === 'sharp') {
            // Sharp 90-degree corners (Острые углы)
            sCtx.rect(-sw / 2, -sh / 2, sw, sh);
          } else {
            // Rounded corners (Закругленные углы)
            const radius = Math.min(el.shadowCornerRadius ?? 10, sw / 2, sh / 2);
            drawRoundRectPath(sCtx, -sw / 2, -sh / 2, sw, sh, radius);
          }
        }
        sCtx.fill();
        sCtx.restore();
      }

      sCtx.restore();

      // 3. Composite the merged mask onto the target canvas with the group's exact opacity
      targetCtx.save();
      targetCtx.globalAlpha = groupAlpha;
      targetCtx.drawImage(shadowCanvas, 0, 0, bw, bh, minX - originX, minY - originY, bw, bh);
      targetCtx.restore();
    }
  });
};

/**
 * Offscreen lighting buffer for rendering multi-pass illumination and shadows
 */
let offscreenLightCanvas: HTMLCanvasElement | null = null;
let offscreenLightCtx: CanvasRenderingContext2D | null = null;

const getOffscreenLightingContext = (w: number, h: number) => {
  if (!offscreenLightCanvas) {
    offscreenLightCanvas = document.createElement('canvas');
  }
  if (offscreenLightCanvas.width !== w || offscreenLightCanvas.height !== h) {
    offscreenLightCanvas.width = w;
    offscreenLightCanvas.height = h;
    offscreenLightCtx = offscreenLightCanvas.getContext('2d');
  }
  return offscreenLightCtx;
};

/**
 * Main 2D Lighting & Shading Compositor.
 * Creates smooth ambient darkness and punches realistic illuminated light pools with torch flares.
 */
export const drawRoomLightingPass = (
  ctx: CanvasRenderingContext2D,
  roomW: number,
  roomH: number,
  elements: RoomElement[],
  lighting: RoomLightingSettings | undefined,
  timeSec: number,
  zoom: number,
  selectedElementIds: string[] = [],
  isPlaytest: boolean = false,
  originX: number = 0,
  originY: number = 0
) => {
  const darkness = lighting?.ambientDarkness ?? 0;
  const isEnabled = lighting?.enableLighting ?? false;

  if (!isEnabled || darkness <= 0.01 || roomW <= 0 || roomH <= 0) {
    return;
  }

  const ambientHex = lighting?.ambientColor || '#070a14';
  const ambientRgb = hexToRgb(ambientHex);

  const lightCtx = getOffscreenLightingContext(roomW, roomH);
  if (!lightCtx) return;

  // 1. Clear offscreen light buffer and fill with ambient darkness
  lightCtx.globalCompositeOperation = 'source-over';
  lightCtx.clearRect(0, 0, roomW, roomH);
  lightCtx.fillStyle = `rgba(${ambientRgb.r}, ${ambientRgb.g}, ${ambientRgb.b}, ${darkness})`;
  lightCtx.fillRect(0, 0, roomW, roomH);

  // 2. Punch light holes in the darkness using 'destination-out'
  const lightEmitters = elements.filter(el => el.visible !== false && isLightEmitter(el));
  
  if (lightEmitters.length > 0) {
    lightCtx.save();
    lightCtx.globalCompositeOperation = 'destination-out';

    for (const el of lightEmitters) {
      const info = getElementLightInfo(el, timeSec);
      const intensity = Math.min(1.0, info.intensity);
      const lx = info.x - originX;
      const ly = info.y - originY;
      
      const lightGrad = lightCtx.createRadialGradient(lx, ly, 0, lx, ly, info.radius);
      // Punch out darkness from 100% at center to 0% at outer radius
      lightGrad.addColorStop(0, `rgba(0, 0, 0, ${intensity})`);
      lightGrad.addColorStop(0.35, `rgba(0, 0, 0, ${intensity * 0.88})`);
      lightGrad.addColorStop(0.7, `rgba(0, 0, 0, ${intensity * 0.45})`);
      lightGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      lightCtx.fillStyle = lightGrad;
      lightCtx.beginPath();
      lightCtx.arc(lx, ly, info.radius, 0, Math.PI * 2);
      lightCtx.fill();
    }
    lightCtx.restore();

    // 3. Add warm colored light tint and ambient falloff onto the buffer
    lightCtx.save();
    lightCtx.globalCompositeOperation = 'source-over';
    for (const el of lightEmitters) {
      const info = getElementLightInfo(el, timeSec);
      const intensity = info.intensity;
      const { r, g, b } = info.rgb;
      const lx = info.x - originX;
      const ly = info.y - originY;

      const tintGrad = lightCtx.createRadialGradient(lx, ly, 0, lx, ly, info.radius);
      tintGrad.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${0.28 * intensity})`);
      tintGrad.addColorStop(0.4, `rgba(${r}, ${g}, ${b}, ${0.14 * intensity})`);
      tintGrad.addColorStop(0.8, `rgba(${r}, ${g}, ${b}, ${0.04 * intensity})`);
      tintGrad.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);

      lightCtx.fillStyle = tintGrad;
      lightCtx.beginPath();
      lightCtx.arc(lx, ly, info.radius, 0, Math.PI * 2);
      lightCtx.fill();
    }
    lightCtx.restore();
  }

  // 4. Draw composite lighting buffer onto main room canvas
  ctx.save();
  ctx.drawImage(offscreenLightCanvas!, originX, originY);
  ctx.restore();

  // 6. If editor mode: Draw active light gizmo & radius circle for selected light sources
  if (!isPlaytest && selectedElementIds.length > 0) {
    for (const el of lightEmitters) {
      if (selectedElementIds.includes(el.id)) {
        const info = getElementLightInfo(el, timeSec);
        ctx.save();
        
        // Dashed radius outline
        ctx.beginPath();
        ctx.arc(info.x, info.y, info.radius, 0, Math.PI * 2);
        ctx.strokeStyle = info.color;
        ctx.lineWidth = 1.5 / zoom;
        ctx.setLineDash([4 / zoom, 4 / zoom]);
        ctx.stroke();

        // Light center icon/star
        ctx.beginPath();
        ctx.arc(info.x, info.y, 4 / zoom, 0, Math.PI * 2);
        ctx.fillStyle = info.color;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1 / zoom;
        ctx.stroke();

        ctx.restore();
      }
    }
  }
};

