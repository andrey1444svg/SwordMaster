import { 
  DifficultyConfig, 
  Ingredient, 
  Weapon, 
  WeaponType,
  CharacterStats, 
  Skill,
  IngredientType,
  UpgradeRecipe,
  InventoryItem,
  EquipmentState,
  EquipmentSlotType,
  EquipmentCategory
} from '../types/game';

export const DIFFICULTY_CONFIGS: Record<string, DifficultyConfig> = {
  easy: {
    id: 'easy',
    name: 'Ученик',
    description: 'Для мягкого ознакомления. Враги слабее, сбалансированные ресурсы.',
    hpMultiplier: 0.7,
    damageMultiplier: 0.84, // +20% (ранее 0.7)
    xpMultiplier: 1.0,
    dropRateMultiplier: 1.4,
    scoreMultiplier: 1.0,
    color: '#34d399', // Emerald
    badge: '🟢 Легкий'
  },
  normal: {
    id: 'normal',
    name: 'Воин',
    description: 'Стандартная сложность. Сбалансированный боковой скроллер.',
    hpMultiplier: 1.0,
    damageMultiplier: 1.2, // +20% (ранее 1.0)
    xpMultiplier: 1.2,
    dropRateMultiplier: 1.0,
    scoreMultiplier: 1.25,
    color: '#38bdf8', // Sky
    badge: '🔵 Нормальный'
  },
  hard: {
    id: 'hard',
    name: 'Мастер',
    description: 'Враги бьют больно и имеют больше ХП. +20% к опыту и редкие материалы!',
    hpMultiplier: 1.5,
    damageMultiplier: 1.68, // +20% (ранее 1.4)
    xpMultiplier: 1.44,
    dropRateMultiplier: 1.3,
    scoreMultiplier: 1.8,
    color: '#fbbf24', // Amber
    badge: '🟡 Сложный'
  },
  nightmare: {
    id: 'nightmare',
    name: 'Демон',
    description: 'Настоящее испытание для мастеров фехтования. Безумный урон и орада врагов.',
    hpMultiplier: 2.2,
    damageMultiplier: 2.4, // +20% (ранее 2.0)
    xpMultiplier: 1.728,
    dropRateMultiplier: 1.8,
    scoreMultiplier: 2.5,
    color: '#f43f5e', // Rose
    badge: '🔴 Безумие'
  }
};

export const INGREDIENTS: Record<IngredientType, Ingredient> = {
  iron_ore: {
    id: 'iron_ore',
    name: 'Осколок мглы',
    description: 'Обычный ингредиент 1-го тира. Осколок сконденсированной тьмы, используемый для базового усиления снаряжения.',
    icon: '⚙️',
    rarity: 'common',
    color: '#94a3b8'
  },
  magic_crystal: {
    id: 'magic_crystal',
    name: 'Магический кристалл',
    description: 'Магический ингредиент 2-го тира (зеленый). Кристалл сгущенной маны для зачарования снаряжения.',
    icon: '💎',
    rarity: 'magic',
    color: '#4ade80'
  },
  monster_core: {
    id: 'monster_core',
    name: 'Ядро монстра',
    description: 'Редкий ингредиент 3-го тира (синий). Пульсирующий источник жизненной силы чудовищ для ковки мощных доспехов.',
    icon: '🩸',
    rarity: 'rare',
    color: '#38bdf8'
  },
  ancient_rune: {
    id: 'ancient_rune',
    name: 'Печать пустоты',
    description: 'Эпический ингредиент 4-го тира (фиолетовый). Могущественная печать из глубин Бездны для легендарных кузнечных работ.',
    icon: '📜',
    rarity: 'epic',
    color: '#c084fc'
  },
  fire_essence: {
    id: 'fire_essence',
    name: 'Огненная эссенция',
    description: 'Эпический ингредиент наивысшего порядка. Концентрированное пламя древних богов.',
    icon: '🔥',
    rarity: 'epic',
    color: '#ef4444'
  }
};

export const UNARMED_FIST_WEAPON: Weapon = {
  id: 'unarmed_fist',
  name: 'Кулаки',
  type: 'fist',
  rarity: 'common',
  minDamage: 1,
  maxDamage: 3,
  length: 18,
  weight: 0.6,
  critChance: 0.025,
  critMultiplier: 1.25,
  element: 'none',
  upgradeLevel: 0,
  maxUpgradeLevel: 0,
  description: 'Голые кулаки. Быстрые удары в ближнем бою.',
  color: '#f43f5e',
  glowColor: '#f43f5e',
  iconName: 'Hand'
};

export const STARTER_WEAPONS: Weapon[] = [
  {
    id: 'starter_sword',
    name: 'Стальной Меч',
    type: 'sword',
    rarity: 'common',
    minDamage: 3,
    maxDamage: 6,
    length: 80,
    weight: 0.9,
    critChance: 0.01,
    critMultiplier: 1.25,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    doubleStrikeChance: 0.06,
    description: '• Уникальный эффект: Двойной удар 6% шанс мгновенно восстановить атаку.',
    color: '#cbd5e1',
    glowColor: '#38bdf8',
    iconName: 'Sword'
  },
  {
    id: 'starter_katana',
    name: 'Стальная Катана',
    type: 'katana',
    rarity: 'common',
    minDamage: 3,
    maxDamage: 7,
    length: 85,
    weight: 0.7,
    critChance: 0.02,
    critMultiplier: 1.30,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    doubleStrikeChance: 0.06,
    description: '• Уникальный эффект: Двойной удар 6% шанс мгновенно восстановить атаку.',
    color: '#94a3b8',
    glowColor: '#7dd3fc',
    iconName: 'Sword'
  },
  {
    id: 'starter_axe',
    name: 'Железный Топор',
    type: 'axe',
    rarity: 'common',
    minDamage: 4,
    maxDamage: 8,
    length: 82,
    weight: 1.3,
    critChance: 0.015,
    critMultiplier: 1.35,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    ruthlessnessRatio: 0.0038025,
    description: '• Уникальный эффект: Безжалостность +0.38% (+0.05%/ур.) урона за каждый 1% недостающего здоровья цели.',
    color: '#cbd5e1',
    glowColor: '#f97316',
    iconName: 'Axe'
  },
  {
    id: 'starter_mace',
    name: 'Железный Молот',
    type: 'hammer',
    rarity: 'common',
    minDamage: 5,
    maxDamage: 10,
    length: 88,
    weight: 1.6,
    critChance: 0.015,
    critMultiplier: 1.4,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    stunChance: 0.0504,
    stunDurationMin: 2,
    stunDurationMax: 2,
    bonusDamageMultiplier: 0.50,
    description: '• Уникальный эффект: Оглушение 5% шанс на 2 сек. и +50% доп. урона.',
    color: '#cbd5e1',
    glowColor: '#f59e0b',
    iconName: 'Hammer'
  },
  {
    id: 'starter_spear',
    name: 'Копье Ополченца',
    type: 'spear',
    rarity: 'common',
    minDamage: 3,
    maxDamage: 7,
    length: 105,
    weight: 1.1,
    critChance: 0.02,
    critMultiplier: 1.3,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    bleedChance: 0.06,
    bleedDamageRatio: 1.00,
    description: '• Уникальный эффект: Рваная рана 6% шанс наносит 100% урона за 2.5 сек.',
    color: '#cbd5e1',
    glowColor: '#ef4444',
    iconName: 'Sword'
  },
  {
    id: 'starter_rapier',
    name: 'Стальная Рапира',
    type: 'rapier',
    rarity: 'common',
    minDamage: 3,
    maxDamage: 6,
    length: 92,
    weight: 0.8,
    critChance: 0.02,
    critMultiplier: 1.35,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    doubleStrikeChance: 0.06,
    description: '• Уникальный эффект: Двойной удар 6% шанс мгновенно восстановить атаку.',
    color: '#cbd5e1',
    glowColor: '#38bdf8',
    iconName: 'Sword'
  },
  {
    id: 'starter_greatsword',
    name: 'Тяжелый Двуручник',
    type: 'greatsword',
    rarity: 'common',
    minDamage: 6,
    maxDamage: 12,
    length: 100,
    weight: 1.5,
    critChance: 0.03,
    critMultiplier: 1.45,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    doubleStrikeChance: 0.06,
    description: '• Уникальный эффект: Двойной удар 6% шанс мгновенно восстановить атаку.',
    color: '#cbd5e1',
    glowColor: '#a855f7',
    iconName: 'Sword'
  },
  {
    id: 'starter_dagger',
    name: 'Охотничий Нож',
    type: 'dagger',
    rarity: 'common',
    minDamage: 2,
    maxDamage: 5,
    length: 65,
    weight: 0.6,
    critChance: 0.035,
    critMultiplier: 1.35,
    element: 'none',
    upgradeLevel: 0,
    maxUpgradeLevel: 10,
    doubleStrikeChance: 0.06,
    description: '• Уникальный эффект: Двойной удар 6% шанс мгновенно восстановить атаку.',
    color: '#cbd5e1',
    glowColor: '#10b981',
    iconName: 'Sword'
  }
];

export function getMaxXpForLevel(level: number): number {
  if (level <= 1) return 250;
  if (level === 2) return 400;
  return 250 + (level - 1) * 150 + Math.round((level - 1) * (level - 2) * 25);
}

export const INITIAL_STATS: CharacterStats = {
  level: 1,
  xp: 0,
  maxXp: 250,
  statPoints: 0,
  
  strength: 9,     // 3 + 6 = 9
  agility: 11,     // 5 + 6 = 11
  endurance: 5,    // 5 * 3 = 15 HP (+ 15 base = 30 HP)
  intelligence: 4, // 4 * 3 = 12 Mana

  hp: 30,
  maxHp: 30,
  mana: 12,
  maxMana: 12,

  moveSpeed: 7,
  jumpPower: -18
};

export const INITIAL_SKILLS: Skill[] = [];

export function getUpgradeRecipe(currentLevel: number): UpgradeRecipe {
  const nextLevel = Math.min(currentLevel + 1, 10);
  
  // 1st upgrade: 5 ingredients, etc. (multiplied by 5)
  const costIngredients: Record<IngredientType, number> = {} as any;
  
  if (nextLevel >= 1) {
    costIngredients.iron_ore = nextLevel * 5;
  }
  if (nextLevel >= 2) {
    costIngredients.magic_crystal = (nextLevel - 1) * 5;
  }
  if (nextLevel >= 3) {
    costIngredients.monster_core = (nextLevel - 2) * 5;
  }
  if (nextLevel >= 4) {
    costIngredients.ancient_rune = (nextLevel - 3) * 5;
  }
  if (nextLevel >= 5) {
    costIngredients.fire_essence = (nextLevel - 4) * 5;
  }

  return {
    costIngredients,
    damageGain: nextLevel * 2,
    lengthGain: 2,
    critGain: nextLevel * 0.01,
    critMultiplierGain: nextLevel * 0.02
  };
}

export const EQUIPMENT_SLOT_META: Record<
  EquipmentSlotType,
  { label: string; code: string; iconName: string; category: EquipmentCategory; order: number }
> = {
  weapon: { label: 'Оружие', code: 'ОР', iconName: 'Sword', category: 'weapon', order: 1 },
  helmet: { label: 'Шлем', code: 'ШЛ', iconName: 'HardHat', category: 'helmet', order: 2 },
  cloak: { label: 'Плащ', code: 'ПЛ', iconName: 'Wind', category: 'cloak', order: 3 },

  chest: { label: 'Нагрудник', code: 'НА', iconName: 'Shirt', category: 'chest', order: 4 },
  bracers: { label: 'Наручи', code: 'НА', iconName: 'Watch', category: 'bracers', order: 5 },
  gloves: { label: 'Перчатки', code: 'ПЕ', iconName: 'Hand', category: 'gloves', order: 6 },
  belt: { label: 'Пояс', code: 'ПО', iconName: 'Minimize2', category: 'belt', order: 7 },
  pants: { label: 'Штаны', code: 'ШТ', iconName: 'Footprints', category: 'pants', order: 8 },

  boots: { label: 'Ботинки', code: 'БО', iconName: 'Sparkle', category: 'boots', order: 9 },
  ring1: { label: 'Кольцо', code: 'КО', iconName: 'CircleDot', category: 'ring', order: 10 },
  ring2: { label: 'Кольцо', code: 'КО', iconName: 'CircleDot', category: 'ring', order: 11 },
  trinket1: { label: 'Аксессуар', code: 'АК', iconName: 'Sparkles', category: 'trinket', order: 12 },
  trinket2: { label: 'Аксессуар', code: 'АК', iconName: 'Sparkles', category: 'trinket', order: 13 },
};

export function weaponToInventoryItem(w: Weapon): InventoryItem {
  return {
    id: `item_${w.id}`,
    name: w.name,
    category: 'weapon',
    rarity: w.rarity,
    icon: w.iconName || 'Sword',
    description: w.description,
    level: w.upgradeLevel,
    stats: {
      damageMin: w.minDamage,
      damageMax: w.maxDamage,
      critChance: w.critChance,
      critMultiplier: w.critMultiplier - 1.0,
    },
    salvageYield: {
      iron_ore: 10 + w.upgradeLevel * 4,
      magic_crystal: w.rarity !== 'common' ? 3 + w.upgradeLevel : 1,
      monster_core: w.rarity === 'epic' ? 2 : 0,
      ancient_rune: 0,
    },
    weaponData: w,
  };
}

export function ensureWeaponData(item: InventoryItem): Weapon {
  const name = item.name.toLowerCase();
  let detectedType: WeaponType = 'sword';

  if (name.includes('топор') || name.includes('секир') || name.includes('секач') || item.icon === 'Axe') {
    detectedType = 'axe';
  } else if (name.includes('молот') || name.includes('булав') || name.includes('крушител') || name.includes('моргенштерн') || item.icon === 'Hammer') {
    detectedType = 'hammer';
  } else if (name.includes('катана') || name.includes('нодати') || name.includes('мурамаса') || name.includes('сакур')) {
    detectedType = 'katana';
  } else if (name.includes('рапир') || name.includes('шпаг') || name.includes('эсток')) {
    detectedType = 'rapier';
  } else if (name.includes('копье') || name.includes('копьё') || name.includes('пика') || name.includes('дротик') || name.includes('алебард')) {
    detectedType = 'spear';
  } else if (name.includes('кинжал') || name.includes('клык') || name.includes('стилет') || name.includes('нож')) {
    detectedType = 'dagger';
  } else if (name.includes('двуручн') || name.includes('великий меч') || name.includes('клеймор') || name.includes('цвайхендер')) {
    detectedType = 'greatsword';
  } else if (item.weaponData?.type) {
    detectedType = item.weaponData.type;
  }

  if (item.weaponData) {
    const w = {
      ...item.weaponData,
      type: detectedType
    };

    if (detectedType === 'hammer') {
      if (w.stunChance === undefined) {
        w.stunChance = item.rarity === 'magic' ? 0.0504 : item.rarity === 'rare' ? 0.0756 : item.rarity === 'epic' ? 0.126 : 0.0252;
      }
      if (w.bonusDamageMultiplier === undefined) {
        w.bonusDamageMultiplier = item.rarity === 'magic' ? 0.65 : item.rarity === 'rare' ? 0.80 : item.rarity === 'epic' ? 1.00 : 0.50;
      }
      if (w.stunDurationMin === undefined) {
        w.stunDurationMin = 2.0;
      }
      if (w.stunDurationMax === undefined) {
        w.stunDurationMax = 2.0;
      }
    } else if (detectedType === 'sword' || detectedType === 'rapier' || detectedType === 'katana' || detectedType === 'greatsword' || detectedType === 'dagger') {
      if (w.doubleStrikeChance === undefined) {
        w.doubleStrikeChance = item.rarity === 'magic' ? 0.06 : item.rarity === 'rare' ? 0.10 : item.rarity === 'epic' ? 0.15 : 0.03;
      }
    } else if (detectedType === 'spear') {
      if (w.bleedChance === undefined) {
        w.bleedChance = item.rarity === 'magic' ? 0.06 : item.rarity === 'rare' ? 0.10 : item.rarity === 'epic' ? 0.20 : 0.04;
      }
      if (w.bleedDamageRatio === undefined) {
        w.bleedDamageRatio = item.rarity === 'magic' ? 1.20 : item.rarity === 'rare' ? 1.50 : item.rarity === 'epic' ? 1.85 : 0.95;
      }
    } else if (detectedType === 'axe') {
      if (w.ruthlessnessRatio === undefined) {
        w.ruthlessnessRatio = item.rarity === 'magic' ? 0.00232375 : item.rarity === 'rare' ? 0.0038025 : item.rarity === 'epic' ? 0.0054925 : 0.0012675;
      }
    }

    return w;
  }

  const wLen = detectedType === 'greatsword' ? 100 
    : detectedType === 'dagger' ? 65 
    : detectedType === 'spear' ? 105 
    : detectedType === 'axe' ? 82 
    : detectedType === 'hammer' ? 88 
    : detectedType === 'katana' ? 85
    : detectedType === 'rapier' ? 92
    : 80;

  const wWeight = detectedType === 'greatsword' ? 1.5 
    : detectedType === 'hammer' ? 1.6 
    : detectedType === 'axe' ? 1.3 
    : detectedType === 'spear' ? 1.1 
    : detectedType === 'dagger' ? 0.6 
    : detectedType === 'katana' ? 0.7
    : detectedType === 'rapier' ? 0.8
    : 0.9;

  return {
    id: `wep_${item.id}`,
    name: item.name,
    type: detectedType,
    rarity: item.rarity === 'magic' ? 'rare' : (item.rarity as any),
    minDamage: item.stats?.damageMin || 4,
    maxDamage: item.stats?.damageMax || 8,
    length: wLen,
    weight: wWeight,
    critChance: item.stats?.agility ? 0 : (item.stats?.critChance || 0),
    critMultiplier: (item.stats?.agility || item.stats?.critChance) ? 1.25 : 1.25,
    element: 'none',
    upgradeLevel: item.level || 0,
    maxUpgradeLevel: 10,
    description: item.description,
    color: item.rarity === 'epic' ? '#c084fc' : item.rarity === 'rare' ? '#38bdf8' : item.rarity === 'magic' ? '#4ade80' : '#cbd5e1',
    glowColor: item.rarity === 'epic' ? '#a855f7' : item.rarity === 'rare' ? '#0284c7' : item.rarity === 'magic' ? '#22c55e' : '#94a3b8',
    iconName: item.icon,
    doubleStrikeChance: (detectedType === 'sword' || detectedType === 'rapier' || detectedType === 'katana' || detectedType === 'greatsword' || detectedType === 'dagger') ? (
      item.rarity === 'magic' ? 0.06 :
      item.rarity === 'rare' ? 0.10 :
      item.rarity === 'epic' ? 0.15 :
      0.03
    ) : undefined,
    stunChance: detectedType === 'hammer' ? (
      item.rarity === 'magic' ? 0.0504 :
      item.rarity === 'rare' ? 0.0756 :
      item.rarity === 'epic' ? 0.126 :
      0.0252
    ) : undefined,
    bonusDamageMultiplier: detectedType === 'hammer' ? (
      item.rarity === 'magic' ? 0.65 :
      item.rarity === 'rare' ? 0.80 :
      item.rarity === 'epic' ? 1.00 :
      0.50
    ) : undefined,
    stunDurationMin: detectedType === 'hammer' ? 2.0 : undefined,
    stunDurationMax: detectedType === 'hammer' ? 2.0 : undefined,
    bleedChance: detectedType === 'spear' ? (
      item.rarity === 'magic' ? 0.06 :
      item.rarity === 'rare' ? 0.10 :
      item.rarity === 'epic' ? 0.20 :
      0.04
    ) : undefined,
    bleedDamageRatio: detectedType === 'spear' ? (
      item.rarity === 'magic' ? 1.20 :
      item.rarity === 'rare' ? 1.50 :
      item.rarity === 'epic' ? 1.85 :
      0.95
    ) : undefined,
    ruthlessnessRatio: detectedType === 'axe' ? (
      item.rarity === 'magic' ? 0.00232375 :
      item.rarity === 'rare' ? 0.0038025 :
      item.rarity === 'epic' ? 0.0054925 :
      0.0012675
    ) : undefined
  };
}

export const INITIAL_EQUIPMENT: EquipmentState = {
  weapon: null,
  helmet: null,
  cloak: null,
  chest: null,
  bracers: null,
  gloves: null,
  belt: null,
  pants: null,
  boots: null,
  ring1: null,
  ring2: null,
  trinket1: null,
  trinket2: null
};

// Initial 30-slot inventory starts completely empty
export const INITIAL_INVENTORY: (InventoryItem | null)[] = new Array(30).fill(null);

